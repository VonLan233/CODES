local Old_PickupFn = ACTIONS.PICKUP.fn
ACTIONS.PICKUP.fn = function(act)
    if act.doer.components.inventory ~= nil and
        act.target ~= nil and
        act.target.components.inventoryitem ~= nil and
        not act.target:IsInLimbo() and
        not act.target:HasTag("catchable") then

        if act.target.components.characterspecific_huli and not act.target.components.characterspecific_huli:CanPickUp(act.doer) then
            return false, "CHARACTERSPECIFIC_HULI"
        end
    end

    return Old_PickupFn(act)
end

local function HasMihobell(doer)
    if doer.components.inventory and doer.components.inventory:FindItem(function(item)
        if item.prefab == "mihobell" then 
			return true 
			end 
		end) ~= nil then 
		return true 
	elseif doer.prefab == 'huli' then
		return true
	else
		return false 
	end 
end

local oldMIHOSTORE = ACTIONS.STORE.fn
ACTIONS.STORE.fn = function(act)
    if act.target 
		and act.target.prefab == "miho" 
		and act.target.components.container ~= nil 
		and act.invobject.components.inventoryitem ~= nil 
		and act.doer.components.inventory ~= nil then
        if HasMihobell(act.doer) then
            return oldMIHOSTORE(act) 
		else
            if act.doer.components.talker then 
				act.doer.components.talker:Say("没铃铛就不给你放东西!") 
			end 
			return true 
		end 
	else
		return oldMIHOSTORE(act)
	end 
end

local old_MIHOMAGE = ACTIONS.RUMMAGE.fn 
ACTIONS.RUMMAGE.fn = function(act)
    if act.target and act.target.prefab == "miho" then  
        result = act.doer.components.inventory:FindItem(function(item)
            if item.prefab == "mihobell" then 
				return true 
			end 
		end)
        if result or act.doer.prefab == 'huli' then 
			return old_MIHOMAGE(act) 
		else
            act.doer:DoTaskInTime(.4, function ()
            act.target.components.talker:Say("就不给你看!")
        end) 
			return false 
		end 
	else
		return old_MIHOMAGE(act) 
	end 
end


