-- Initialize equip action
--use "data/actions/equip"

-- Initialize givealltoplayer action.
--use "data/actions/givealltoplayer"

-- Initialize givetoplayer action
--use "data/actions/givetoplayer"

--- Initialize pickup action.
use "data/actions/pickup"

-- Initialize takeitem action.
--use "data/actions/takeitem"