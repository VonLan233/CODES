local marbles = Ingredient("turf_marble", 4, "images/inventoryimages/turfturf.xml")
local handfans = Ingredient("handfan", 1, "images/inventoryimages/items.xml")

-- local YINYANG = AddRecipeTab("狐狸特产", 998, "images/tab/yinyangtab.xml", "yinyangtab.tex", "hulibuilder")

-- AddRecipe( "bluegem", {Ingredient(_G.CHARACTER_INGREDIENT.HEALTH, 5)}, YINYANG, TECH.NONE) --test

if XHL_CL_SET > 0 then
	AddCharacterRecipe("xhl_cl",
		{ Ingredient("hulisoul", 3, "images/inventoryimages/items.xml"), Ingredient("gears", 2), Ingredient("goldnugget",
			4), Ingredient("livinglog", 3) }, TECH.NONE,
		{ builder_tag = "hulibuilder", atlas = "images/inventoryimages/items.xml" })
end

-- AddCharacterRecipe("xhl_cl",
-- { Ingredient("hulisoul", 3, atlas = "images/inventoryimages/items.xml"}) },
--  {SCIENCE = 0},
-- nil, nil, nil, nil, nil, atlas = "images/inventoryimages/items.xml"})
-- end

AddCharacterRecipe("xhl_cl_qp",
	{ Ingredient("hulisoul", 3, "images/inventoryimages/items.xml"), Ingredient("huligem_sj", 2,
		"images/inventoryimages/huligem.xml"), Ingredient("huligem_hc", 1, "images/inventoryimages/huligem.xml") },
	TECH.NONE, { builder_tag = "hulibuilder", atlas = "images/inventoryimages/xhl_cl_qp.xml" })

AddCharacterRecipe("huligem_qh",
	{ Ingredient("huligem_sj", 3, "images/inventoryimages/huligem.xml"), Ingredient("huligem_hc", 1,
		"images/inventoryimages/huligem.xml"), Ingredient("goldnugget", 2) }, TECH.NONE,
	{ builder_tag = "hulibuilder", atlas = "images/inventoryimages/huligem.xml" })

AddCharacterRecipe("huligem_gjqh",
	{ Ingredient("huligem_qh", 3, "images/inventoryimages/huligem.xml"), Ingredient("huligem_hc", 1,
		"images/inventoryimages/huligem.xml"), Ingredient("moonrocknugget", 1) }, TECH.NONE,
	{ builder_tag = "hulibuilder", atlas = "images/inventoryimages/huligem.xml" })

AddCharacterRecipe("huligem_jh",
	{ Ingredient("huligem_hc", 3, "images/inventoryimages/huligem.xml"), Ingredient("huligem_xy", 3,
		"images/inventoryimages/huligem.xml"), Ingredient("huligem_bj", 3, "images/inventoryimages/huligem.xml"),
		Ingredient("bluegem", 3) }, TECH.NONE,
	{ builder_tag = "hulibuilder", atlas = "images/inventoryimages/huligem.xml" })

AddCharacterRecipe("huligem_xy",
	{ Ingredient("huligem_sj", 3, "images/inventoryimages/huligem.xml"), Ingredient("huligem_hc", 1,
		"images/inventoryimages/huligem.xml"), Ingredient("redgem", 1) }, TECH.NONE,
	{ builder_tag = "hulibuilder", atlas = "images/inventoryimages/huligem.xml" })

AddCharacterRecipe("huligem_bj",
	{ Ingredient("huligem_sj", 3, "images/inventoryimages/huligem.xml"), Ingredient("huligem_hc", 1,
		"images/inventoryimages/huligem.xml"), Ingredient("purplegem", 1) }, TECH.NONE,
	{ builder_tag = "hulibuilder", atlas = "images/inventoryimages/huligem.xml" })

AddCharacterRecipe("huli_dango", { Ingredient("rabbit", 1), Ingredient("butter", 1), Ingredient("carrot", 1) }, TECH
.NONE, { numtogive = 6, builder_tag = "hulibuilder", atlas = "images/inventoryimages/items.xml" })

AddCharacterRecipe("handfan", { Ingredient("honey", 3), Ingredient("twigs", 1) }, TECH.NONE,
	{ builder_tag = "hulibuilder", atlas = "images/inventoryimages/items.xml" })

AddCharacterRecipe("gumifan",
	{ handfans, Ingredient("redgem", 1), Ingredient("goldnugget", 3), Ingredient("rope", 3), Ingredient("huligem_hc", 1,
		"images/inventoryimages/huligem.xml") }, TECH.NONE,
	{ builder_tag = "hulibuilder", atlas = "images/inventoryimages/items.xml" })

AddCharacterRecipe("foxmask", { Ingredient("goldnugget", 2), Ingredient("papyrus", 2), Ingredient("silk", 6) }, TECH
.NONE, { builder_tag = "hulibuilder", atlas = "images/inventoryimages/items.xml" })

AddCharacterRecipe("foxmask_new",
	{ Ingredient("huligem_hc", 1, "images/inventoryimages/huligem.xml"), Ingredient("yellowgem", 1), Ingredient(
	"moonrocknugget", 2), Ingredient("livinglog", 1) }, TECH.NONE,
	{ builder_tag = "hulibuilder", atlas = "images/inventoryimages/foxmask_new.xml" })

--AddCharacterRecipe("skirt", {Ingredient("beefalowool", 12), Ingredient("tentaclespots", 4), Ingredient("nightmarefuel", 2)},  TECH.NONE, {builder_tag = "hulibuilder", atlas = "images/inventoryimages/items.xml"})

AddCharacterRecipe("skirt_x",
	{ Ingredient("huligem_hc", 1, "images/inventoryimages/huligem.xml"), Ingredient("silk", 14), Ingredient(
	"tentaclespots", 5), Ingredient("beefalowool", 12) }, TECH.NONE,
	{ builder_tag = "hulibuilder", atlas = "images/inventoryimages/items.xml" })

AddCharacterRecipe("huli_rock_power",
	{ Ingredient("redgem", 1), Ingredient("transistor", 2), Ingredient("lightninggoathorn", 1), Ingredient("huligem_hc",
		1, "images/inventoryimages/huligem.xml") }, TECH.NONE,
	{ numtogive = 4, builder_tag = "hulibuilder", atlas = "images/inventoryimages/huli_rock_power.xml" })

AddCharacterRecipe("firepit_chill", { Ingredient("goldnugget", 8), Ingredient("cutstone", 15), Ingredient("nitre", 4) },
	TECH.NONE,
	{ placer = "firepit_chill_placer", min_spacing = 1, builder_tag = "hulibuilder", atlas =
	"images/inventoryimages/building.xml" })

AddCharacterRecipe("firepit_ghost", { Ingredient("goldnugget", 8), Ingredient("cutstone", 15), Ingredient("nitre", 3) },
	TECH.NONE,
	{ placer = "firepit_ghost_placer", min_spacing = 1, builder_tag = "hulibuilder", atlas =
	"images/inventoryimages/building.xml" })

AddCharacterRecipe("gumipot", { Ingredient("boards", 4), Ingredient("cutstone", 2), Ingredient("ice", 6) }, TECH.NONE,
	{ placer = "gumipot_placer", min_spacing = 1, builder_tag = "hulibuilder", atlas =
	"images/inventoryimages/building.xml" })

AddCharacterRecipe("huli_fangzi", { Ingredient("wall_stone_item", 15), Ingredient("boards", 10) }, TECH.NONE,
	{ placer = "huli_fangzi_placer", min_spacing = 4, builder_tag = "hulibuilder", atlas =
	"images/inventoryimages/building.xml" })

AddCharacterRecipe("huli_tingzi",
	{ Ingredient("wall_stone_item", 15), Ingredient("boards", 5), Ingredient("goldnugget", 5) }, TECH.NONE,
	{ placer = "huli_tingzi_placer", min_spacing = 4, builder_tag = "hulibuilder", atlas =
	"images/inventoryimages/building.xml" })

--●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●

AddCharacterRecipe("turf_asia", { Ingredient("beefalowool", 4), Ingredient("silk", 2) }, TECH.NONE,
	{ numtogive = 4, builder_tag = "hulibuilder", atlas = "images/inventoryimages/turfturf.xml" })

AddCharacterRecipe("turf_orient", { Ingredient("beefalowool", 4), Ingredient("silk", 2) }, TECH.NONE,
	{ numtogive = 4, builder_tag = "hulibuilder", atlas = "images/inventoryimages/turfturf.xml" })

AddCharacterRecipe("turf_flamerose", { Ingredient("beefalowool", 4), Ingredient("silk", 2) }, TECH.NONE,
	{ numtogive = 4, builder_tag = "hulibuilder", atlas = "images/inventoryimages/turfturf.xml" })

AddCharacterRecipe("turf_marble", { Ingredient("marble", 2), Ingredient("flint", 10) }, TECH.NONE,
	{ numtogive = 4, builder_tag = "hulibuilder", atlas = "images/inventoryimages/turfturf.xml" })

AddCharacterRecipe("turf_jade", { marbles, Ingredient("goldnugget", 2), Ingredient("greengem", 1) }, TECH.NONE,
	{ numtogive = 4, builder_tag = "hulibuilder", atlas = "images/inventoryimages/turfturf.xml" })

AddCharacterRecipe("wall_asia_item",
	{ Ingredient("cutstone", 10), Ingredient("huli_rock_power", 1, "images/inventoryimages/huli_rock_power.xml") },
	TECH.NONE, { numtogive = 6, builder_tag = "hulibuilder", atlas = "images/inventoryimages/wall_asia_item.xml" })
