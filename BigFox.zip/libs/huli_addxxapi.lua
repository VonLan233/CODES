AddClassPostConstruct("widgets/hoverer",function(self)
	local old_SetString = self.text.SetString
	self.text.SetString = function(text,str) 
		local target = TheInput:GetHUDEntityUnderMouse()
		if target ~= nil then
			target = target.widget ~= nil and target.widget.parent ~= nil and target.widget.parent.item
		else
			target = TheInput:GetWorldEntityUnderMouse()
		end
		if target ~= nil then
			if target.prefab == 'miregg' or target.prefab == 'miregg_cracked' then
				-- local name = target:GetDisplayName()
				local name = target._label and target._label:value()
				if name then
					str = str.."\n"..name
				end
			end
			if target.prefab == 'mir' or target.prefab == 'mir2' then
				local lv_sys = target.replica.huli_levelsys
				local c_lv = lv_sys:Get('当前等级')
				local m_lv = lv_sys:Get('最大等级')
				local c_exp = lv_sys:Get('当前经验值')
				local u_exp = lv_sys:Get('升级经验值')
				-- local m_exp = target.replica.huli_levelsys and target.replica.huli_levelsys:Get('最大经验值')
				
				if c_lv and m_lv and c_exp and u_exp then
					str = str..'\n等级：'..c_lv..'/'..m_lv..'\n经验值：'..c_exp..'/'..u_exp
				end
			end
		end
		return old_SetString(text,str)
	end
end)

local cmp = {"sanity", "hunger", "health"}
for _, v in pairs(cmp) do
	AddComponentPostInit(v, function(self)
		self.DeltaTask = {}
		function self:HL_StartRegen(key, val, dt)
			self:HL_StopRegen(key)
			self.DeltaTask[key] = self.inst:DoPeriodicTask(dt, function()
				self:DoDelta(val)
			end)
		end
		
		function self:HL_StopRegen(key)
			if self.DeltaTask[key] then
				self.DeltaTask[key]:Cancel()
				self.DeltaTask[key] = nil
			end
		end
		
	end)
end

AddComponentPostInit("health", function(self, inst)
	local old_DoDelta = self.DoDelta
	self.DoDelta = function(self, amount, overtime, cause, ignore_invincible, afflicter, ignore_absorb, ...)
		local old_currenthealth = self.currenthealth
		local val = old_DoDelta(self, amount, overtime, cause, ignore_invincible, afflicter, ignore_absorb, ...)
		if afflicter and not (inst:HasTag("wall") or inst:HasTag("structure")) then 
			local delta_val = self.currenthealth - old_currenthealth
			-- local aff = (afflicter.prefab == 'huli' and afflicter) or (afflicter.master and afflicter.master.prefab == 'huli' and afflicter.master)
			if afflicter['获取经验值fn'] then --注意，小龙也有。
				afflicter['获取经验值fn'](afflicter, delta_val)
			else
				if afflicter.master and afflicter.master['获取经验值fn'] then
					afflicter.master['获取经验值fn'](afflicter.master, delta_val)
				end
			end
		end
		return val
	end
end)

AddComponentPostInit("combat", function(self, inst)
	local old_CanTarget = self.SetTarget
	self.SetTarget = function(self, target, ...) --防止我们的专属宠物会自相残杀
		if target and (target == inst._player or (target._player and target._player == inst._player)) then
			return
		end
		old_CanTarget(self, target, ...)
	end
end)

--[[
AddPrefabPostInit('huli', function(inst)
	
	local function GetPointSpecialActions(inst, pos, useitem, right)
		if right and inst.replica.combat and inst.replica.combat:GetWeapon() ~= nil and inst.replica.combat:GetWeapon().prefab == 'gumifan' then
			return { ACTIONS.BLINK }
		end
		return {}
	end

	local function CanSoulhop(inst, souls)
		local rider = inst.replica.rider
		if rider == nil or not rider:IsRiding() then
			return true
		end
		return false
	end

	local function OnSetOwner(inst)
		if inst.components.playeractionpicker ~= nil then
			inst.components.playeractionpicker.pointspecialactionsfn = GetPointSpecialActions
		end
	end

	local function TryToPortalHop(inst, souls, consumeall)
		return true
	end

	inst:AddTag("soulstealer")
	inst:ListenForEvent("setowner", OnSetOwner) --客机
	inst.CanSoulhop = CanSoulhop --客机
	
	inst.TryToPortalHop = TryToPortalHop

end)

AddPrefabPostInit("spider", function(inst) --测试用
	if inst.components.health then
		inst.components.health.minhealth = 1
		inst.components.health.externalabsorbmodifiers:SetModifier(inst, 0.5, "自身减伤")
	end
end)

AddPlayerPostInit(function(inst)
	local old_OnSave = inst.OnSave
	inst.OnSave = function(inst, data, ...)
		data.xxx = inst.xxx
		if old_OnSave then
			old_OnSave(inst, data, ...)
		end
	end
	
	local old_OnLoad = inst.OnLoad
	inst.OnLoad = function(inst, data, ...)
		inst.xxx = data.xxx
		if old_OnLoad then
			old_OnLoad(inst, data, ...)
		end
	end
	
end)

AddPrefabPostInit("cursed_monkey_token", function(inst) 
	inst:ListenForEvent("onpickup", function(inst, data)
		if data.owner.prefab == "huli" then
			inst:DoTaskInTime(FRAMES, function()
				inst:Remove()
			end)
		end
	end)
end)
]]
----------------------------------------------------------------------------------------------

-- local function prs()
	-- for k, v in pairs(Prefabs) do
		-- if PrefabExists(k) == 'ice' then
			-- print('11')
		-- end
	-- end
-- end

-------------------------------------------------------------------------------------------------------------------------------

local function user_items(inst)
	if not inst.components.characterspecific_huli then
		inst:AddComponent("characterspecific_huli")	
		inst.components.characterspecific_huli:SetOwner("huli")
	end
end
AddPrefabPostInit("gumifan", user_items) 
--AddPrefabPostInit("foxmask", user_items) 
--AddPrefabPostInit("skirt", user_items) 
AddPrefabPostInit("skirt_x", user_items) 
AddPrefabPostInit("mihobell", user_items) 
AddPrefabPostInit("miregg", user_items) 

-- AddStategraphPostInit("wilson", function(sg) 
	-- local old_fn = sg.events["attacked"].fn
	-- sg.events["attacked"].fn = function(inst, data)
		-- if inst:HasTag("huli") then
			-- return
		-- end
		-- return old_fn(inst, data)
	-- end
-- end)

local function checkfn()

end

