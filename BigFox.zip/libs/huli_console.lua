GLOBAL.hl_ = {}
GLOBAL.hlc_ = {}
GLOBAL.hlcc_ = {}


hl_["大狐狸等级"] = function(val)
	local inst = ConsoleCommandPlayer()
	if inst.components.huli_levelsys then
		inst.components.huli_levelsys:LvDoDelta(val or 0)
	end
end

hl_["大狐狸经验"] = function(val)
	local inst = ConsoleCommandPlayer()
	if inst.components.huli_levelsys then
		inst.components.huli_levelsys:ExpDoDelta(val or 0)
	end
end

hl_["小狐狸(lv)"] = function(level)
	local inst = ConsoleCommandPlayer()
	if inst.components.huli_petleash then
		local pt = inst:GetPosition()
		local xhl = inst.components.huli_petleash:SpawnPetAt(pt.x, 0, pt.z, "huliclone")
		if level and xhl.components.huli_levelsys then
			xhl.components.huli_levelsys:LvDoDelta(level)
		end
	end
end

hl_["小龙(lv)"] = function(level, exp)
	local inst = ConsoleCommandPlayer()
	if inst.components.huli_petleash_mir then
		local pt = inst:GetPosition()
		for k, v in pairs(inst.components.huli_petleash_mir.pets) do
			if v and v.components.huli_levelsys then
				if level then 
					v.components.huli_levelsys:LvDoDelta(level)
				end
				if exp then 
					v.components.huli_levelsys:ExpDoDelta(exp)
				end
			end
		end
	end
end

hl_["小龙孵化(时间)"] = function(time)
	local inst = ConsoleCommandPlayer()
	if inst.huli_miregg and inst.huli_miregg.components.huli_hatchable then
		if time then 
			inst.huli_miregg.components.huli_hatchable:OnUpdate(time)
		end
	end
end

hl_["狐狸币"] = function(val)
	if ThePlayer.components.huli_store then
		ThePlayer.components.huli_store:CoinDoDelta(val or 0)
	end
end

hl_["火元素"] = function(val)
	if ThePlayer.components.huli_elesys then
		ThePlayer.components.huli_elesys:FireDoDelta(val)
	end
end

hl_["冰元素"] = function(val)
	if ThePlayer.components.huli_elesys then
		ThePlayer.components.huli_elesys:IceDoDelta(val)
	end
end

hl_["狐狸宝石"] = function(count)

	local bs = {
		"huligem_sj",
		"huligem_qh",
		"huligem_hc",
		"huligem_jh",
		"huligem_gjqh",
		"huligem_xy",
		"huligem_bj",
	}
	count = count or 1

	for k, v in pairs(bs) do
		for i = 1, count do 
			c_give(v)
		end
	end
end

hl_["狐狸地毯"] = function(count)

	local tf = {
		"turf_marble",
		"turf_jade",
		"turf_asia",
		"turf_orient",
		"turf_flamerose",
	}
	
	for k, v in pairs(tf) do
		for i = 1, count do 
			c_give(v)
		end
	end
end

hl_["狐狸装备"] = function()

	local eqp = {
		"gumifan",
		"skirt_x",
		"foxmask",
		"foxmask_new",
		"handfan",
	}
	
	for k, v in pairs(eqp) do
		c_give(v)
	end
end

local tab = {}
for i, v in pairs(hl_) do
	table.insert(tab, '_["'..i..'"]')
end

--★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★

hlc_["减伤buff"] = function(absorb)
	if ThePlayer.components.health then
		ThePlayer.components.health.externalabsorbmodifiers:SetModifier(ThePlayer, absorb, "控制台")
	end
end

hlc_["攻击buff"] = function(m)
	if ThePlayer.components.combat then
		ThePlayer.components.combat.externaldamagemultipliers:SetModifier(ThePlayer, m, "控制台")
	end
end

hlc_["血量"] = function(val)
	if ThePlayer.components.health then
		ThePlayer.components.health:DoDelta(val)
	end
end

hlc_["精神"] = function(val)
	if ThePlayer.components.sanity then
		ThePlayer.components.sanity:DoDelta(val)
	end
end

hlc_["饥饿"] = function(val)
	if ThePlayer.components.hunger then
		ThePlayer.components.hunger:DoDelta(val)
	end
end

hlc_["解锁所有配方"] = function(player)
	c_freecrafting(player)
end

hlc_["回档"] = function(count)
	c_rollback(count or 0)
end

hlc_["清空世界"] = function()
	c_emptyworld()
end

hlc_["炸服"] = function(xx)
	c_forcecrash(xx)
end

hlc_["关服(s)"] = function(save)
	if not save then
		c_shutdown(false)
	else
		c_shutdown()
	end
end

local tab1 = {}
for i, v in pairs(hlc_) do
	table.insert(tab1, '_["'..i..'"]')
end

AddClassPostConstruct("screens/consolescreen", function(self)
	if ThePlayer and ThePlayer.prefab == 'huli' then
		self.console_edit:AddWordPredictionDictionary({words = tab, delim = "hl", num_chars = 0, postfix='()'})
		self.console_edit:AddWordPredictionDictionary({words = tab1, delim = "hlc", num_chars = 0, postfix='()'})
	end
end)

--[[
function _G.hl_fn(pp)
	if type(pp) == "function" then
		pp = pp()
	end
	if pp == nil then print('空加载') return end
	if type(pp) == "table" then
		if next(pp) == nil then print('空表') return end
		for k, v in pairs(pp) do
			if type(v) == "table" then
				for h, n in pairs(v) do
					if type(n) == "table" then
						for j, m in pairs(n) do
							if type(m) == "table" then
								for q, w in pairs(m) do
									if type(w) == "table" then
										for e, r in pairs(w) do
											print('加载打印的5：'..tostring(e)..'：'..tostring(r))
										end
									else
										print('加载打印的4：'..tostring(q)..'：'..tostring(w))
									end
								end
							else
								print('加载打印的3：'..tostring(j)..'：'..tostring(m))
							end
						end
					else
						print('加载打印的2：'..tostring(h)..'：'..tostring(n))
					end
				end
			else
				print('加载打印的1：'..tostring(k)..'：'..tostring(v))
			end
		end
	else
		print('加载打印的：'..tostring(pp))
	end
end

function _G.ddd(p)
	local inst = ConsoleCommandPlayer()
	local total = 0
	local has_name_count = 0
	local no_name_count = 0
    local counted_name = {}
    local counted_noname = {}
	
	for k, v in pairs(p or Prefabs) do
		total = total + 1
		local name = STRINGS.NAMES[string.upper(k)]
		if name then
			has_name_count = has_name_count + 1
			table.insert(counted_name, k)
		else
			no_name_count = no_name_count + 1
			table.insert(counted_noname, k)
		end
	end
	table.sort(counted_name)
	table.sort(counted_noname)
	
    for k, v in pairs(counted_name) do
		local name = STRINGS.NAMES[string.upper(v)]
		print('', name, v)
    end
	
    for k, v in pairs(counted_noname) do
		print('', '没有 name 的预制物：', v)
    end
	
	if p then
		print('', string.format("饥荒中（包含模组）共有 %d 种预制物，【%d 拥有 name】，【%d  没有 name】\n 【若只想打印自己MOD所有预制物，在控制台输入函数时括号中不要输入参数即可】", total, has_name_count, no_name_count))
	else
		print('', string.format("MOD中共有 %d 种预制物，【%d 拥有 name】，【 %d 没有 name】\n 【若想打印饥荒所有预制物，在控制台输入函数时在括号中输入 Prefabs】", total, has_name_count, no_name_count))
	end

end

function _G.aaa()
    local items = {
		"winter_ornament_light1",
		"winter_ornament_light2",
		"winter_ornament_light3",
		"winter_ornament_light4",
		"winter_ornament_light5",
		"winter_ornament_light6",
		"winter_ornament_light7",
		"winter_ornament_light8",
    }

    local chord = 1.5
    local away_step = 0.25
    local theta = 0

    for k, stacks in pairs(items) do
		for k = 1, 20 do
			local inst = DebugSpawn(stacks)
			if inst ~= nil then
				local away = away_step * theta
				local x,y,z = inst.Transform:GetWorldPosition()
				local spiral_x = math.cos(theta) * away
				local spiral_z = math.sin(theta) * away
				x = x + spiral_x
				z = z + spiral_z
				inst.Transform:SetPosition(x, y, z)
				if away == 0 then
					away = away_step
				end
				theta = theta + chord / away
			end
		end
    end
end

local cooking = require('cooking')
_G['库存物品统计'] = function(p, spawn) --统计所有预制物中的库存物品【p = Prefabs，spawn = 生成实体后再做筛选】
	local inst = ConsoleCommandPlayer()
    local counted_name = 0
    local counted_noname = {}
    local itemtab = _G['所有项目库存物品']
	local itemtab_hasname = {} --有名字的库存物品
	local itemtab_noname = {} --没有名字的库存物品
	local ents = {}
	for _, item in pairs(itemtab) do
 		local name = STRINGS.NAMES[string.upper(item)]
		if name then
			table.insert(itemtab_hasname, item)
		else
			table.insert(itemtab_noname, item)
		end
	end
	table.sort(itemtab_hasname)
	table.sort(itemtab_noname)
	
	if not spawn then --参数 spawn 无效时输出所有库存预制物
		for _, item in pairs(itemtab_hasname) do
			local name = STRINGS.NAMES[string.upper(item)]
			for k, v in pairs(p) do
				if  k == item then
					counted_name = counted_name + 1
					print('', name, item)
				end
			end
		end
		
		for  _, item in pairs(itemtab_noname) do
			for k in pairs(p) do
				if k == item then
					counted_noname = counted_noname + 1
					print('', '没有 name 的预制物：', k)
				end
			end
		end
		print('', string.format("库存中共有 %d 种【拥有名字】、 %d 种【没有名字】且不同的预制物", counted_name, counted_noname))
		
	else
	
		local chord = 1.5
		local away_step = 0.25
		local theta = 0

		for k, item in ipairs(itemtab_hasname) do
			local ent = DebugSpawn(item)
			if ent then
			
				local away = away_step * theta 
				local x,y,z = ent.Transform:GetWorldPosition()
				local spiral_x = math.cos(theta) * away
				local spiral_z = math.sin(theta) * away
				x = x + spiral_x
				z = z + spiral_z
				ent.Transform:SetPosition(x, y, z)
				if away == 0 then
					away = away_step
				end
				theta = theta + chord / away
	--------------------------------------------------------------------------
				if ent.components.inventoryitem then
					local function IsCookRec()
						for k, v in pairs({"cookpot", "portablecookpot", "archive_cookpot"}) do
							if cooking.GetRecipe(v, ent.prefab) ~= nil then
								return true
							end
						end
					end
					if ent.components.equippable or ent.components.edible or ent.components.health or GetValidRecipe(ent.prefab) or IsCookRec() then
						ent:DoTaskInTime(0, ent.Remove )
					else
						counted_name = counted_name + 1
						table.insert(ents, ent.prefab)
					end
					
				else
					ent:DoTaskInTime(0, ent.Remove )
				end
			end
		end
		table.sort(ents)
		for _, ent in ipairs(ents) do
			local name = STRINGS.NAMES[string.upper(ent)]
			print('', name, ent)
		end
		print('', string.format("库存中共有 %d 种可以xxx的预制物", counted_name))
	end
end
]]
-- function _G['实体统计']()
    -- local total = 0
    -- local unk = 0
    -- local counted = {}
    -- for k,v in pairs(Ents) do
        -- if v.prefab ~= nil then
            -- if counted[v.prefab] == nil then
				-- counted[v.prefab] = 1
            -- else
                -- counted[v.prefab] = counted[v.prefab] + 1
            -- end
            -- total = total + 1
        -- else
            -- unk = unk + 1
        -- end
    -- end

	-- local function pairsByKeys(t, f)
		-- local a = {}
		-- for n in pairs(t) do
			-- table.insert(a, n)
		-- end
		-- table.sort(a, f)
		-- local i = 0      --迭代变量
		-- local iter = function ()   --迭代函数
			-- i = i + 1
			-- if a[i] == nil then
				-- return nil
			-- else
				-- return a[i], t[a[i]]
			-- end
		-- end
		-- return iter
	-- end

    -- for k,v in pairsByKeys(counted) do
		-- local name = STRINGS.NAMES[string.upper(k)]
        -- print(name, k, v)
    -- end

    -- print(string.format("世界上有 %d 种不同的预制物实体, 总数 %d  (和 %d 未知)", GetTableSize(counted), total, unk))
-- end

--★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★


