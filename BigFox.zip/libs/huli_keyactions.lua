
local function huli_statekey(inst)

	if inst.components.health:IsDead() then return end
	if inst['形态'] == "红狐狸" or inst['形态'] == "冰狐狸" then
		if inst.statekey <= 0 then
			inst.statekey = inst.statekey + 1
		else
			inst.statekey = inst.statekey - 1
		end
		if inst.components.sanity then
			inst.components.sanity:DoDelta(-20)
		end
		if inst.components.hunger then
			inst.components.hunger:DoDelta(-30)
		end
	elseif inst['形态'] == "白狐狸" or inst['形态'] == "月狐狸" then
		inst.components.talker:Say(hl_loc('当前状态无法变身!', 'Current state cannot be transformed!'))
	else
		inst.components.talker:Say(hl_loc('都快完蛋了还想变身!', "Almost dead, can't be transformed!"))
	end
end
AddModRPCHandler("huli_rpc", "huli_statekey", huli_statekey)

local function INFO_HL(inst)
if inst:HasTag("playerghost") then return end
	if inst['形态'] == "红狐狸" then 
		if inst.components.huli_elesys['当前火元素'] < inst.components.huli_elesys['最大火元素'] then
			inst.components.talker:Say("当前形态:"..(inst['形态']).."\n当前等级: "..(inst.level).."\n当前火元素:"..(inst.components.huli_elesys['当前火元素']).."/"..(inst.components.huli_elesys['最大火元素']))
		else
			inst.components.talker:Say("当前形态:"..(inst['形态']).."\n当前等级: "..(inst.level).."\n火元素已满".."/"..(inst.components.huli_elesys['最大火元素']))
		end
	elseif inst['形态'] == "冰狐狸" then 
		if inst.components.huli_elesys['当前冰元素'] < inst.components.huli_elesys['最大冰元素'] then
			inst.components.talker:Say("当前形态:"..(inst['形态']).."\n当前等级: "..(inst.level).."\n当前冰元素:"..(inst.components.huli_elesys['当前冰元素']).."/"..(inst.components.huli_elesys['最大冰元素']))
		else
			inst.components.talker:Say("当前形态:"..(inst['形态']).."\n当前等级: "..(inst.level).."\n冰元素已满".."/"..(inst.components.huli_elesys['最大冰元素']))
		end
	else 
		inst.components.talker:Say("当前形态:"..(inst['形态']).."\n当前等级: "..(inst.level))
	end
end
AddModRPCHandler("huli_rpc", "INFO_HL", INFO_HL)

local function call_xhl(inst)
    local pets = inst.components.huli_petleash.pets 
	local pet = inst.components.huli_petleash.numpets
	if pet > 0 then
		for k,v in pairs(pets) do
			local distsq = inst:GetDistanceSqToInst(v)
			-- if v and v:IsValid() then
					if distsq < 33^2 then
						if v.components.xhl_command:IsStaying() then
							v.components.xhl_command:SetStaying(false, inst)
						else
							v.components.xhl_command:SetStaying(true, inst)
						end
					else
						inst.components.talker:Say(hl_loc('小狐狸不在范围内', 'Baby out of range'))
						v.components.talker:Say(hl_loc('我似乎感觉到老妈在呼唤我', 'I seem to feel my mother calling me.?'))
					end
			-- end
		end
	else
		inst.components.talker:Say(hl_loc('小狐狸还没出生\n也有可能死光了.', 'The fox is not yet born\n It could be dead...'))
	end
end
AddModRPCHandler("huli_rpc", "call_xhl", call_xhl)

----------------------------------------------------------------
-- Party 
----------------------------------------------------------------
local Start_BurnPartyTime = function(inst) 
	if inst:HasTag("playerghost") then return end
	
	local winter = TheWorld.state.iswinter
	local fullmoon = TheWorld.state.isfullmoon
	local hunger = inst.components.hunger:GetPercent()
	local sanity = inst.components.sanity:GetPercent()
	local Min_IE = inst.components.huli_elesys['当前冰元素']
	local Min_FR = inst.components.huli_elesys['当前火元素']
	local eqp = inst.components.combat:GetWeapon()
	if inst.components.huli_levelsys:Get('当前等级') >= 1 then
		--if not winter and not fullmoon then
		if inst['形态'] == "红狐狸" then
			if not eqp or eqp.prefab ~= "gumifan" then 
				inst.components.talker:Say(hl_loc('需要装备芭蕉扇!', 'Need to equip gumifan fan!')) 
				return 
			end
			if hunger >= .25 then
				-- if inst.redsikllstate == 'NOCD' then
					if not inst:HasTag("盛宴状态开启") then
						inst:AddTag("盛宴状态开启")
						inst.components.talker:Say(hl_loc('开启盛宴状态!', 'Open fire skill status!'))
					elseif inst:HasTag("盛宴状态开启") then
						inst:RemoveTag("盛宴状态开启")
						inst.components.talker:Say(hl_loc('关闭盛宴状态!', 'Close fire skill status!'))
					end
				-- elseif inst.redsikllstate == '盛宴冷却中' then
					-- inst.components.talker:Say("冷却时间:"..(inst.FireSikllCD).."秒")
				-- end
			elseif hunger < .25 then
				if inst.redsikllstate == '盛宴冷却中' then
					inst.components.talker:Say("冷却时间"..(inst.FireSikllCD).."秒")
				elseif inst.redsikllstate == 'NOCD' then
					inst.components.talker:Say(hl_loc('肚子饿，没力气啦.', "I'm hungry，No strength.")) 
				end
			end
		--else
			--inst.components.talker:Say("要变回红狐狸才能放哦.")
		--end -------------------------------------------------------------------------
	--elseif winter and not fullmoon then
		elseif inst['形态'] == "冰狐狸" then
			if hunger >= .25 and Min_IE >= 7 then
				if not inst:HasTag("冰域状态开启") then		
					inst:AddTag("冰域状态开启")
					inst.components.talker:Say(hl_loc('开启冰域状态!', 'Open ice skill status!!'))
				elseif inst:HasTag("冰域状态开启") then
					inst:RemoveTag("冰域状态开启")
					inst.components.talker:Say(hl_loc('关闭冰域状态!', 'Close ice skill status!'))
				end
			elseif hunger >= .25 and Min_IE < 7 then
				if not inst:HasTag("冰域状态开启") then
					if inst.icesikllstate == '冰域冷却中' then
						inst.components.talker:Say("元素不足.\n冷却时间"..(inst.IceSikllCD).."秒")
					elseif not inst.icesikllstate == '冰域冷却中' then
						inst.components.talker:Say(hl_loc('元素不足,无法开启冰域状态.', 'Insufficient ice element\n Unable to turn on ice skill state.')) 
					end
				end
			elseif hunger < .25 and Min_IE >= 7 then
				if not inst:HasTag("冰域状态开启") then
					if inst.icesikllstate == '冰域冷却中' then
						inst.components.talker:Say("肚子饿了,不能放技能.\n冷却时间"..(inst.IceSikllCD).."秒")
					elseif inst.icesikllstate == 'NOCD' then
						inst.components.talker:Say(hl_loc('肚子饿，没力气啦.', "I'm hungry，No strength.")) 
					end
				end
			elseif hunger < .25 and Min_IE < 7 then
				if not inst:HasTag("冰域状态开启") then
					if inst.icesikllstate == '冰域冷却中' then
						inst.components.talker:Say("肚子饿了,元素不够了.\n冷却时间"..(inst.IceSikllCD).."秒")
					elseif inst.icesikllstate == 'NOCD' then
						inst.components.talker:Say("不仅肚子饿，元素也不够.") 
					end
				end
			end
		else
			inst.components.talker:Say(hl_loc('当前状态无法施放技能.', 'Unable to cast skills in current state.'))
		end
		--end
	else
		inst.components.talker:Say(hl_loc('要升级才能开启技能哦.', 'You need to upgrade to open skills.'))
	end
end

local function SkillState(inst)
	if inst:HasTag("playerghost") then return end
	Start_BurnPartyTime(inst)
end
AddModRPCHandler("huli_rpc", "SkillState", SkillState)

-----------------------------------------------------------------------------------------------------------------------------------------------------------------

local function HULI_DODGE_TX(inst)
inst:DoTaskInTime(.2, function()
	if not inst:HasTag("playerghost") and inst.prefab == "huli" then
	--inst.AnimState:PlayAnimation("jumpout")
	inst.sg.statemem.action = inst.bufferedaction
	inst.sg:SetTimeout(.7)
	SpawnPrefab("bee_poof_big").Transform:SetPosition(inst.Transform:GetWorldPosition())
	end
end)
end

local function HULI_DODGE_TX_WALL(inst)
inst:DoTaskInTime(.35, function()
	if not inst:HasTag("playerghost") and inst.prefab == "huli" then
	--inst.AnimState:PlayAnimation("jumpout")
	inst.sg.statemem.action = inst.bufferedaction
	inst.sg:SetTimeout(.7)
	SpawnPrefab("bee_poof_big").Transform:SetPosition(inst.Transform:GetWorldPosition())
	end
end)
end

local interaction_list = {
	'wall_asia',
	
	'wall_hay',
	'wall_wood',
	'wall_stone',
	'wall_ruins',
	'wall_moonrock',
	
	"rock1",
	"rock2",
	--"rock_ice",
	"rock_moon",
	"rock_flintless",
	"rock_flintless_med",
	"rock_flintless_low",
	"pond",
	"pond_mos",
	"pond_cave",
	"lava_pond",
	
	"evergreen",
	"evergreen_sparse",
	"deciduoustree",
	"livingtree",
	
	"pighouse",
	"rabbithouse",
	"catcoonden",
	"spiderden",
	
	"pigman",
	"bunnyman",
	"perd",
	"spider",
	"frog",
	"hound",
	"firehound",
	"icehound",
	"walrus",
	"merm",
	"knight",
	"bishop",
	"krampus",
	"mossling",
	"chester",
	"tallbird",
	"babybeefalo",
	
	"molehill",
	"mound",
	"skeleton",
	"skeleton_player",
	
	"twigs"
}

for k, v in pairs(interaction_list) do
	AddPrefabPostInit(v,function(inst)
		if GLOBAL.TheWorld.ismastersim then
			inst:AddComponent("interactions_huli")
		end
	end)
end

AddPlayerPostInit(function(inst)
	if GLOBAL.TheWorld.ismastersim then
	if inst.prefab == "huli" then
		inst:AddComponent("interactions_huli")
		inst:DoPeriodicTask(0.25,function()
			if inst.Transform and inst.Transform.GetRotation then
				inst.old_rotation = inst.Transform:GetRotation()
			end
		end)
	end
	end
end)

AddAction("WALLJUMP_HL", "跳", function(act)
	if act.doer ~= nil and act.target ~= nil and act.doer:HasTag('player') and act.target.components.interactions_huli and act.target:HasTag("wall") and (act.target.components.health == nil or not act.target.components.health:IsDead()) then
		act.target.components.interactions_huli:WallJump(act.doer)
		return true
	else
		return false
	end
end)

AddAction("JUMPOVER_HL", "跳", function(act)
	if act.doer ~= nil and act.target ~= nil and act.doer:HasTag('player') and act.target.components.interactions_huli and (act.target:HasTag("boulder") or act.target:HasTag("watersource") or act.target:HasTag("lava") or act.doer == act.target or act.target:HasTag("cattoy")) then
		act.target.components.interactions_huli:Jump(act.doer)
		return true
	else
		act.doer.sg:GoToState("idle")
		return false
	end
end)

if HULI_TY_SET > 0 then
	AddComponentAction("SCENE", "interactions_huli", function(inst, doer, actions, right)
		if doer.prefab == 'huli' then
			if right then
				if inst:HasTag("wall") and (inst.components.health == nil or not inst.components.health:IsDead()) then
					table.insert(actions, GLOBAL.ACTIONS.WALLJUMP_HL)
				elseif inst:HasTag("boulder") or inst:HasTag("frozen") or inst:HasTag("rocky") then --or inst:HasTag("lava") or inst == doer or inst:HasTag("cattoy") then
					table.insert(actions, GLOBAL.ACTIONS.JUMPOVER_HL)
				end
			end
		end
	end)
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local function HULI_DODGE_A(inst)
	local act_jo = BufferedAction(inst, inst, ACTIONS.JUMPOVER_HL)
	if not inst.components.timer:TimerExists("HULI_TY_A") then
		inst.components.locomotor:PushAction(act_jo, true)
	end
	inst.components.timer:StartTimer("HULI_TY_A", 1.2)
end
AddModRPCHandler("huli_rpc", "HULI_DODGE_A", HULI_DODGE_A)

-- AddPlayerPostInit(function(inst)
	-- if inst.prefab == "huli" then
		-- TheInput:AddKeyDownHandler(KEY_G, function()
			-- if TheInput:IsKeyDown(KEY_CTRL) then
				-- SendModRPCToServer(MOD_RPC["huli"]["HULI_DODGE_A"])
			-- end
		-- end)
	-- end
-- end)

local state_walljump = GLOBAL.State{ name = "walljump_huli", --翻墙
	tags = { "doing", "busy" },

	onenter = function(inst)
		inst.components.locomotor:Stop()
		inst.AnimState:PlayAnimation("jump_pre")
		inst.AnimState:PlayAnimation("jumpout")
		inst.Physics:SetMotorVel(0, 0, 0)
		HULI_DODGE_TX_WALL(inst)
		
		inst.sg.statemem.action = inst.bufferedaction
		inst.sg:SetTimeout(2)
		if not GLOBAL.TheWorld.ismastersim then
			inst:PerformPreviewBufferedAction()
		end
	end,

	timeline =
	{
		GLOBAL.TimeEvent(4 * GLOBAL.FRAMES, function(inst)
			inst.sg:RemoveStateTag("busy")
		end),
		GLOBAL.TimeEvent(9 * GLOBAL.FRAMES, function(inst)
			if GLOBAL.TheWorld.ismastersim then
				inst:PerformBufferedAction()
			end
			inst.Physics:SetMotorVel(1.5, 0, 0)
		end),
		GLOBAL.TimeEvent(15 * GLOBAL.FRAMES, function(inst)
			inst.Physics:SetMotorVel(1, 0, 0)
		end),
		GLOBAL.TimeEvent(15.2 * GLOBAL.FRAMES, function(inst)
			inst.SoundEmitter:PlaySound("dontstarve/movement/bodyfall_dirt")
		end),
		GLOBAL.TimeEvent(17 * GLOBAL.FRAMES, function(inst)
			inst.Physics:SetMotorVel(0.5, 0, 0)
		end),
		GLOBAL.TimeEvent(18 * GLOBAL.FRAMES, function(inst)
			inst.Physics:Stop()
		end),
	},
	
	onupdate = function(inst)
		if not GLOBAL.TheWorld.ismastersim then
			if inst:HasTag("doing") then
				if inst.entity:FlattenMovementPrediction() then
					inst.sg:GoToState("idle", "noanim")
				end
			elseif inst.bufferedaction == nil then
				inst.sg:GoToState("idle", true)
			end
		end
	end,
	
	ontimeout = function(inst)
		if not GLOBAL.TheWorld.ismastersim then
			inst:ClearBufferedAction()  -- client
		end
		inst.sg:GoToState("idle")
	end,
	
	onexit = function(inst)
		if inst.bufferedaction == inst.sg.statemem.action then
			inst:ClearBufferedAction()
		end
		inst.sg.statemem.action = nil
	end,
}
AddStategraphState("wilson", state_walljump)
AddStategraphState("wilson_client", state_walljump)

local state_freejump_pre = GLOBAL.State{ name = "freejump_pre_huli", --起步跳
	tags = { "doing", "busy", "canrotate", "nomorph" },

	onenter = function(inst)
		inst.components.locomotor:Stop()
		inst.AnimState:PlayAnimation("jump_pre")
		inst.sg:SetTimeout(GLOBAL.FRAMES*18)
		
		if not GLOBAL.TheWorld.ismastersim then
			inst:PerformPreviewBufferedAction()
		end
	end,

	timeline =
	{
		GLOBAL.TimeEvent(1 * GLOBAL.FRAMES, function(inst)
			if GLOBAL.TheWorld.ismastersim then
				inst:PerformBufferedAction()
			end
		end),
	},
	
	events =
	{
		GLOBAL.EventHandler("animover", function(inst)
			inst.sg:GoToState("freejump_huli")
		end),
	},
	
	onupdate = function(inst)
		if not GLOBAL.TheWorld.ismastersim then
			if inst:HasTag("doing") then
				if inst.entity:FlattenMovementPrediction() then
					inst.sg:GoToState("idle", "noanim")
				end
			elseif inst.bufferedaction == nil then
				inst.sg:GoToState("idle", true)
			end
		end
	end,

	ontimeout = function(inst)
		if not GLOBAL.TheWorld.ismastersim then  -- client
			inst:ClearBufferedAction()
		end
		inst.sg:GoToState("idle")
	end,

	onexit = function(inst)
		if inst.bufferedaction == inst.sg.statemem.action then
			inst:ClearBufferedAction()
		end
		inst.sg.statemem.action = nil
	end,
}
AddStategraphState("wilson", state_freejump_pre)
AddStategraphState("wilson_client", state_freejump_pre)

AddStategraphState("wilson", GLOBAL.State{ name = "freejump_huli",  --跳过程
	tags = { "doing", "busy" },

	onenter = function(inst)
		inst.components.locomotor:Stop()
		--GLOBAL.ChangeToGhostPhysics(inst)
		inst.Physics:ClearCollisionMask()
		inst.Physics:CollidesWith(GLOBAL.COLLISION.GROUND)
		inst.Physics:CollidesWith(GLOBAL.COLLISION.CHARACTERS)
		inst.Physics:CollidesWith(GLOBAL.COLLISION.GIANTS)
	
		inst.AnimState:PlayAnimation("jumpout")
		inst.Physics:SetMotorVel(9.3, 0, 0)
		HULI_DODGE_TX(inst)
		inst.sg.statemem.action = inst.bufferedaction
		inst.sg:SetTimeout(30 * GLOBAL.FRAMES)
	end,

	timeline =
	{
		GLOBAL.TimeEvent(4.5 * GLOBAL.FRAMES, function(inst)
			inst.Physics:SetMotorVel(8.4, 0, 0)
		end),
		GLOBAL.TimeEvent(9 * GLOBAL.FRAMES, function(inst)
			inst.Physics:SetMotorVel(7.7, 0, 0)
		end),
		GLOBAL.TimeEvent(13.5 * GLOBAL.FRAMES, function(inst)
			inst.Physics:SetMotorVel(7.1, 0, 0)
		end),
		GLOBAL.TimeEvent(15.2 * GLOBAL.FRAMES, function(inst)
			inst.SoundEmitter:PlaySound("dontstarve/movement/bodyfall_dirt")
		end),
		GLOBAL.TimeEvent(16 * GLOBAL.FRAMES, function(inst)
			inst.Physics:SetMotorVel(2, 0, 0)
		end),
		GLOBAL.TimeEvent(18 * GLOBAL.FRAMES, function(inst)
			inst.Physics:Stop()
		end),
	},

	events =
	{
		GLOBAL.EventHandler("animqueueover", function(inst)
			local x,y,z = inst.Transform:GetWorldPosition()
			if inst.AnimState:AnimDone() then
				GLOBAL.ChangeToCharacterPhysics(inst)
				inst.Transform:SetPosition(x,0,z)
				inst.sg:GoToState("idle")
			end
		end),
	},
	
	ontimeout = function(inst)
		if not GLOBAL.TheWorld.ismastersim then  -- client
			inst:ClearBufferedAction()
		end
		GLOBAL.ChangeToCharacterPhysics(inst)
		local x,y,z = inst.Transform:GetWorldPosition()
		inst.Transform:SetPosition(x,0,z)
		inst.sg:GoToState("idle")
	end,
	
	onexit = function(inst)
		GLOBAL.ChangeToCharacterPhysics(inst)
		local x,y,z = inst.Transform:GetWorldPosition()
		inst.Transform:SetPosition(x,0,z)
		if inst.bufferedaction == inst.sg.statemem.action then
			inst:ClearBufferedAction()
		end
		inst.sg.statemem.action = nil
	end,
})

AddStategraphActionHandler("wilson", GLOBAL.ActionHandler(GLOBAL.ACTIONS.WALLJUMP_HL, "walljump_huli"))
AddStategraphActionHandler("wilson_client", GLOBAL.ActionHandler(GLOBAL.ACTIONS.WALLJUMP_HL, "walljump_huli"))
AddStategraphActionHandler("wilson", GLOBAL.ActionHandler(GLOBAL.ACTIONS.JUMPOVER_HL, "freejump_pre_huli"))
AddStategraphActionHandler("wilson_client", GLOBAL.ActionHandler(GLOBAL.ACTIONS.JUMPOVER_HL, "freejump_pre_huli"))



