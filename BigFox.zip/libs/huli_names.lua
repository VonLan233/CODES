

STRINGS.NAMES.FIREPIT_GHOST = hl_loc("红焰营火", "Blaze Fire Pit")
STRINGS.RECIPE_DESC.FIREPIT_GHOST = hl_loc("尤其的热.\n会热晕你的!", "Better hot firepit.\nIt will burn you!")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.FIREPIT_GHOST = hl_loc({
	EMBERS = "黑暗来了.",
	GENERIC = "我将会活到天明的!",
	HIGH = "真是受不了了!",
	LOW = "黑暗侵蚀了.",
	NORMAL = "这是火.",
	OUT = "我有不好的预感.",
},
{
	EMBERS = "Darkness is looming.",
	GENERIC = "I might survive this night!",
	HIGH = "A vision of Hell!",
	LOW = "The gloom encroaches.",
	NORMAL = "It's a fire.",
	OUT = "That is not a good sign.",
})

STRINGS.NAMES.FIREPIT_CHILL = hl_loc("冰焰营火", "Frozen Fire Pit")
STRINGS.RECIPE_DESC.FIREPIT_CHILL = hl_loc("尤其的冷.\n会冻住你的!", "Better cold firepit.\nIt will freeze you!")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.FIREPIT_CHILL = hl_loc({
	EMBERS = "黑暗来了.",
	GENERIC = "我将会活到天明的!",
	HIGH = "真是受不了了!",
	LOW = "黑暗侵蚀了.",
	NORMAL = "这是火.",
	OUT = "我有不好的预感.",
},
{
	EMBERS = "Darkness is looming.",
	GENERIC = "I might survive this night!",
	HIGH = "A vision of Hell!",
	LOW = "The gloom encroaches.",
	NORMAL = "It's a fire.",
	OUT = "That is not a good sign.",
})

GLOBAL.STRINGS.NAMES.XHL_CL = hl_loc("小狐狸", "Little fox")
GLOBAL.STRINGS.RECIPE_DESC.XHL_CL = hl_loc("让我们一起\n来造小孩吧!", "Let's make little \nfox together!"		)

GLOBAL.STRINGS.NAMES.HULICLONE = hl_loc("小狐狸", "Little fox")
GLOBAL.STRINGS.RECIPE_DESC.HULICLONE = hl_loc("让我们一起\n来造小孩吧!", "Let's make little \nfox together!")
GLOBAL.STRINGS.CHARACTERS.GENERIC.DESCRIBE.HULICLONE = hl_loc({
	GENERIC_A = "我们家的小屁孩", 
	GENERIC_B = "终于长大了点",
	GENERIC_C = "小狐狸现在很厉害",
	DAJIA = "小狐狸正在打架",
	CANXUE = "小狐狸受伤了",
	TONGYONG = "是别人家的小狐狸…"
},
{
	GENERIC_A = "My little fox", 
	GENERIC_B = "Finally grew up a little.",
	GENERIC_C = "The little fox is very strong now.",
	DAJIA = "The little fox is fighting.",
	CANXUE = "The little fox was injured.",
	TONGYONG = "It's someone else's little fox…"
})

STRINGS.NAMES.XHL_CL_QP = hl_loc("大狐狸的水晶球", "Fox's Crystal Ball")
STRINGS.RECIPE_DESC.XHL_CL_QP = hl_loc("把小狐狸装起来\n但不可以吃哦.", "Load the little fox in.")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.XHL_CL_QP = hl_loc("拿来装小狐狸的.", "Pack the Little Fox.")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.XHL_CL_QP_DB_BUILD = hl_loc("小狐狸在里面.", "The little fox is inside.")

STRINGS.NAMES.HANDFAN = hl_loc("棒棒糖扇", "Hand Fan")
STRINGS.RECIPE_DESC.HANDFAN = hl_loc("儿童轮风扇.", "The Round Fan for children.")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.HANDFAN = hl_loc("它是我唯一的朋友!", "It's my only friend!")

GLOBAL.STRINGS.NAMES.GUMIFAN = hl_loc("狐狸的芭蕉扇", "Fox Gumi Fan")
GLOBAL.STRINGS.RECIPE_DESC.GUMIFAN = hl_loc("成年人专用!\n能砍树、挖矿、当铲子哦!", "Adult-specific!\nCan cut trees, dig mines, and be shovels!")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.GUMIFAN = hl_loc("它是我唯一的朋友!\n而且会烧毁一切!", "It's my only friend!\nIt will burn everything!")

GLOBAL.STRINGS.NAMES.HULISOUL = hl_loc("灵魂结晶", "Soul crystallization")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.HULISOUL = hl_loc("造小孩用!", "Making Little Foxes!\nUpgrade Little Fox!")

GLOBAL.STRINGS.NAMES.HULI_ROCK_POWER = hl_loc("能源石", "Energy stone")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.HULI_ROCK_POWER = hl_loc("给房子充能用!", "Charge the house!")
GLOBAL.STRINGS.RECIPE_DESC.HULI_ROCK_POWER = hl_loc("给房子充能用!\n也可以当燃料!", "Charge the house!\nIt can also be used as fuel!")

GLOBAL.STRINGS.NAMES.HULIGEM_SJ = hl_loc("水晶石", "Crystal stone")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.HULIGEM_SJ = hl_loc("可以拿来合成各种宝石!", "It can be used to synthesize various gemstones!")

GLOBAL.STRINGS.NAMES.HULIGEM_HC = hl_loc("合成石", "Synthetic stone")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.HULIGEM_HC = hl_loc("合成各种宝石的辅助物品!", "Auxiliaries for the synthesis of various gemstones!")

GLOBAL.STRINGS.NAMES.HULIGEM_QH = hl_loc("强化石", "intensify stone")
GLOBAL.STRINGS.RECIPE_DESC.HULIGEM_QH = hl_loc("不用充钱\n也能变强!", "It can make you stronger!")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.HULIGEM_QH = hl_loc({"可以拿来强化装备!", "闪闪发光的宝石", "变强变强变强"}, {"Can be used to strengthen equip!", "Sparkling gemstone", "Strengthen, Strengthen and Strengthen..."})

GLOBAL.STRINGS.NAMES.HULIGEM_GJQH = hl_loc("高级强化石", "Advanced intensify Stone")
GLOBAL.STRINGS.RECIPE_DESC.HULIGEM_GJQH = hl_loc("想变得更强么\n那你还在等什么!", "Want to be stronger?\nThen what are you waiting for!")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.HULIGEM_GJQH = hl_loc({"可以拿来强化装备!", "闪闪发光的宝石", "珍贵的高级宝石", "要变得更强"}, {"Can be used to strengthen equip!", "Sparkling gemstone", "Precious high-grade gem", "To be stronger"})

GLOBAL.STRINGS.NAMES.HULIGEM_JH = hl_loc("进化石", "Evolutionary stone")
GLOBAL.STRINGS.RECIPE_DESC.HULIGEM_JH = hl_loc("装备进化用!", "Equip Evolution!")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.HULIGEM_JH = hl_loc({"装备进化的必需品!", "美丽无瑕", "给力!", "有了它就有了力量"}, {"Equip Evolutionary Necessaries!", "Immaculate", "Awesome!", "With it, there is strength."})

GLOBAL.STRINGS.NAMES.HULIGEM_XY = hl_loc("幸运石", "Lucky stone")
GLOBAL.STRINGS.RECIPE_DESC.HULIGEM_XY = hl_loc("你是欧皇么!什么,不是?\n那还在犹豫什么!", "Are you very lucky？What,No?\nWhat is that hesitating about?")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.HULIGEM_XY = hl_loc({"提升装备强化成功率!", "运气也是实力的一部分", "就算你是欧皇\n偶尔也是需要它!", "非洲人必备"}, {"Enhancing the Success Rate of Equip intensify!", "Luck is also part of strength."})

GLOBAL.STRINGS.NAMES.HULIGEM_BJ = hl_loc("保级石", "Grade protective stone")
GLOBAL.STRINGS.RECIPE_DESC.HULIGEM_BJ = hl_loc("保护装备强化\n失败时不掉级!", "Protection equipment is not \ndowngraded when it fails!")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.HULIGEM_BJ = hl_loc({"保护装备强化失败时不掉级!", "可以让你之前的努力不白费", "珍贵物品,请勿乱扔"}, {"Protection equipment is not downgraded when it fails!", "Can make your previous efforts not in vain", "Precious items, don't throw"})

-- GLOBAL.STRINGS.NAMES.GUMIFANMINI = hl_loc("小芭蕉扇", "Small banana fan")
-- GLOBAL.STRINGS.RECIPE_DESC.GUMIFANMINI = hl_loc("小盆友专用!", "For children!")

STRINGS.NAMES.MIHO = hl_loc("小狐狸箱", "miho")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.MIHO = hl_loc("啊哈哈哈... 真是个可爱傲娇的小狐狸.", "Aha ha ha... What a lovely and cocky little fox!.")

STRINGS.NAMES.MIHOBELL = hl_loc("狐狸铃铛", "miho bell")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.MIHOBELL = hl_loc({ "神秘的铃铛. 小狐狸在哪里?", "过来，小狐狸! 过来!", "铃铛的声音好可爱.", }, { "Mysterious bell. Where is the little fox?", "Come over, little fox! Come over!", "The sound of the bell is so cute.", })

STRINGS.NAMES.TURF_ASIA = hl_loc("亚洲地毯", "Asia Flooring")
STRINGS.RECIPE_DESC.TURF_ASIA = hl_loc("亚洲风格的地毯!", "Asia style carpet. Disposable!")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.TURF_ASIA = hl_loc("这个地毯做得很好!", "This carpet is blazing pattern!")

STRINGS.NAMES.TURF_FLAMEROSE = hl_loc("红玫瑰地毯", "Flame Rose Flooring")
STRINGS.RECIPE_DESC.TURF_FLAMEROSE = hl_loc("玫瑰样的地毯!", "Flame rose carpet. Disposable!")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.TURF_FLAMEROSE = hl_loc("真像玫瑰一样美丽!", "Flame pattern is beautiful floor!")

STRINGS.NAMES.TURF_ORIENT = hl_loc("东方地毯", "Orient Flooring")
STRINGS.RECIPE_DESC.TURF_ORIENT = hl_loc("东方风格的地毯!", "Orient style carpet. Disposable!")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.TURF_ORIENT = hl_loc("哇哦! 你知道东方文化吗!", "Wow! The mysterious pattern carpet!")

STRINGS.NAMES.TURF_MARBLE = hl_loc("大理石地板", "Marble Flooring")
STRINGS.RECIPE_DESC.TURF_MARBLE = hl_loc("大理石做成的地板!", "A floor made of marble!")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.TURF_MARBLE = hl_loc("哇!这地板真硬!", "Wow! This floor is so hard!")

STRINGS.NAMES.TURF_JADE = hl_loc("金镶玉地板", "Gold-inlaid Jade Flooring")
STRINGS.RECIPE_DESC.TURF_JADE = hl_loc("非常珍贵的地板!", "Very precious floor!")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.TURF_JADE = hl_loc("你知道什么叫土豪吗!", "Do you know what is local tyrant!")

STRINGS.NAMES.FOXMASK = hl_loc("狐狸面具", "Fox Mask")
STRINGS.RECIPE_DESC.FOXMASK = hl_loc("是一个综合型\n的笑脸面具呢.", "It's a comprehensive type.\nSmiling face mask.")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.FOXMASK = hl_loc("防止伤害.", "Prevent injury.")

STRINGS.NAMES.FOXMASK_NEW = hl_loc("狐狸面具[白]", "Fox Mask[white]")
STRINGS.RECIPE_DESC.FOXMASK_NEW = hl_loc("拥有强大的防御能力.\n装备时右键点击变幻", "Have a strong defensive capability.\nRight click to transform when equipping")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.FOXMASK_NEW = hl_loc("防止伤害.", "Prevent injury.")

STRINGS.NAMES.SKIRT_X = hl_loc("狐狸裙子", "Fox dress")
STRINGS.RECIPE_DESC.SKIRT_X = hl_loc("性能强大的裙子\n可以强化升级", "Very powerful skirt")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.SKIRT_X = hl_loc("防雨防寒防伤回脑残还能装东西", "Rain proof, cold proof, injury proof, brain damage proof, and can also contain things")

STRINGS.NAMES.HULI_DANGO = hl_loc("狐狸的兔兔包", "Dango")
STRINGS.RECIPE_DESC.HULI_DANGO = hl_loc( "看起来很美味\n狐狸家族的最爱.", "It looks delicious.\nFavorites of the Fox Family.")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.HULI_DANGO = hl_loc("狐狸家族最喜欢啦.", "The Fox family likes it best.")

STRINGS.NAMES.GUMIPOT = hl_loc("冷冻罐子", "GumiPot")
STRINGS.RECIPE_DESC.GUMIPOT = hl_loc("和冰箱一样.", "Like a refrigerator.")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.GUMIPOT = hl_loc({
	CANXUE = "罐子快坏了.",
	OWNER = "这个罐子是我的.",
	TONGYONG = "这是别人家的罐子…",
	NOOWNER = "这个罐子没有主人…",
},
{
	CANXUE = "The jar is going to be broken..",
	OWNER = "This can is mine.",
	TONGYONG = "This is someone else's jar.…",
	NOOWNER = "This can has no owner…",
})

STRINGS.NAMES.HULI_FANGZI = hl_loc("狐狸房子", "Fox house")
STRINGS.RECIPE_DESC.HULI_FANGZI = hl_loc("优美的房子.\n还可以当仓库", "Beautiful house.\nIt can also be used as a warehouse.")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.HULI_FANGZI = hl_loc("非常优美的房子!应该有人在睡觉了!", "Very beautiful house!\nSomebody should be sleeping.!")

STRINGS.NAMES.HULI_TINGZI = hl_loc("狐狸亭子", "Fox Pavilion")
STRINGS.RECIPE_DESC.HULI_TINGZI = hl_loc("午睡亭子.", "Afternoon nap Pavilion.")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.HULI_TINGZI = hl_loc("非常舒服的亭子!可能被别人霸占了!", "Very comfortable Pavilion!\nMay be occupied by others!")

STRINGS.NAMES.HULI_RECHARGENPC = hl_loc("\n点我打开充值界面\n放入交易物品后点'充值'", "\nClick me to open the trade interface\nAfter placing trading items, point 'Trade'")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.HULI_RECHARGENPC = hl_loc("萌萌达的狐狸充值员", "Lovely Fox Recharge clerk")

STRINGS.CHARACTER_DESCRIPTIONS.huli = "作者:那八(代码与部分贴图)\n攻击有几率触发点燃(打断敌人攻击)效果!\n杀死怪物有几率掉灵魂结晶!"
STRINGS.CHARACTER_QUOTES.huli = hl_loc("我是萌萌达的狐狸·你会和我玩么", "I am a cute fox.Will you play with me?")
STRINGS.CHARACTER_TITLES.huli = hl_loc("大狐狸", "Millennium Fox")
STRINGS.CHARACTER_NAMES.huli = hl_loc("huli", "huli")

STRINGS.CHARACTERS.HULI = hl_loc(require "speech_huli", require "speech_huli_eng")
STRINGS.NAMES.HULI = hl_loc("狐狸狐狸", "Millennium Fox")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.HULI = hl_loc({
	GENERIC = "这是萌萌达的大狐狸!",
	ATTACKER = "小狐狸起来很萌...",
	MURDERER = "萌货!",
	REVIVER = "朋友的另一种形态.",
	GHOST = "我想我可以救他.",
},
{
	GENERIC = "This is a lovely Fox!",
	ATTACKER = "The fox is very cute...",
	MURDERER = "Lovely fellow!",
	REVIVER = "Another Form of Friends.",
	GHOST = "I think I can save him..",
})

STRINGS.NAMES.MIREGG = hl_loc("大狐狸的小龙蛋", "Imoogi Egg")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.MIREGG = hl_loc("大狐狸的小龙蛋.", "Mysterious green eggs..")

STRINGS.NAMES.MIREGG_CRACKED = hl_loc("大狐狸的小龙蛋", "Hatching Imoogi Egg")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.MIREGG_CRACKED = hl_loc("大狐狸的小龙蛋.", "Mysterious green Hatching eggs.")

STRINGS.NAMES.MIR = hl_loc("小龙", "Imoogi")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.MIR = hl_loc("卖萌小龙？", "Tiny Orient Dragon.\nSo cute!")

STRINGS.NAMES.MIR2 = hl_loc("小龙", "Imoogi")
STRINGS.CHARACTERS.GENERIC.DESCRIBE.MIR2 = hl_loc("卖萌小龙？", "Tiny Orient Dragon.")




