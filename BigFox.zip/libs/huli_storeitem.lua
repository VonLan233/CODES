local goodsitem = {
	[1] = { --资源类
		{"ash", 10}, ----灰 
		{"petals", 10}, ----花瓣 
		{"foliage", 10}, ----蕨叶
		{"stinger", 10}, ----蜂刺 
		{"poop", 15}, ----便便 
		{"rocks", 15}, ----岩石
		{"cutgrass", 15}, ----草 
		{"twigs", 15}, ----树枝 
		{"log", 15}, ----木头 
		{"charcoal", 20}, ----木炭 
		{"guano", 20}, ----鸟粪
		{"pinecone", 25}, ----松果 
		{"acorn", 25}, ----橡果,桦木果
		{"flint", 30}, ----燧石 
		{"slurtle_shellpieces", 30}, ----蜗牛龟壳片 
		{"slurtleslime", 30}, ----蜗牛龟粘液 
		{"nitre", 30}, ----硝石 
		{"cutreeds", 30}, ----采下的芦苇 
		{"ice", 30}, ----冰 
		{"beefalowool", 35}, ----牛毛 
		{"butterflywings", 40}, ----蝴蝶翅膀
		{"silk", 50}, ----蜘蛛丝
		{"fireflies", 60}, ----萤火虫
		{"horn", 60}, ----牛角 
		{"marble", 60}, ----大理石
		{"cutlichen", 60}, ----摘下的苔藓 
		{"guano", 70}, ----鸟粪 
		{"dug_grass", 70}, ----草根 
		{"dug_sapling", 70}, ----树苗 
		{"feather_crow", 80}, ----乌鸦羽毛 
		{"petals_evil", 80}, ----噩梦花瓣 
		{"feather_robin", 80}, ----红雀羽毛 
		{"dug_berrybush", 90}, ----浆果丛
		{"goldnugget", 100}, ----金子
		{"beardhair", 100}, ----胡子 
		{"boneshard", 100}, ----硬骨头 
		{"spidergland", 100}, ----蛛蛛腺
		{"barnacle", 110}, ----藤壶 
		{"potato", 110}, ----土豆 
		{"tomato", 110}, ----西红柿 
		{"pepper", 110}, ----辣椒 
		{"garlic", 110}, ----大蒜 
		{"onion", 110}, ----洋葱 
		{"mole", 110}, ----鼹鼠 
		{"slurper_pelt", 125}, ----啜食者皮
		{"honeycomb", 130}, ----蜂巢 
		{"thulecite_pieces", 150}, ----铥矿碎片
		{"moonglass", 150}, ----月亮碎片
		{"tentaclespots", 150}, ----触手皮
		{"goose_feather", 160}, ----鸭毛
		{"malbatross_feather", 160}, ----邪天翁羽毛
		{"houndstooth", 160}, ----犬牙 
		{"ghostflower", 200}, ----哀悼荣耀
		{"pigskin", 200}, ----猪皮
		{"spore_medium", 200}, ----红色孢子
		{"spore_small", 200}, ----绿色孢子
		{"spore_tall", 200}, ----蓝色孢子
		{"lucky_goldnugget", 233}, ----幸运黄金
		{"livinglog", 260}, ----活木
		{"lavae_tooth", 260}, ----岩浆虫尖牙
		{"glommerflower", 280}, ----格罗姆花
		{"moonstorm_spark", 300}, ----月熠 
		{"manrabbit_tail", 300}, ----兔人尾巴 
		{"moonrocknugget", 300}, ----月之石
		{"saltrock", 330}, ----盐晶
		-- {"nightmarefuel", 330}, ----噩梦燃料
		{"walrus_tusk", 350}, ----海象牙
		{"feather_canary", 350}, ----橙黄羽毛，金丝雀羽毛
		{"moonglass_charged", 400}, ----注能月亮碎片
		{"lureplantbulb", 400}, ----食人花种子 
		{"steelwool", 420}, ----钢丝棉
		{"fossil_piece", 500}, ----化石碎片
		{"redgem", 700}, ----红宝石 
		{"bluegem", 750}, ----蓝宝石 
		{"gears", 800}, ----齿轮
		-- {"moonrockcrater", 800}, ----有洞的月亮石
		{"glommerwings", 900}, ----格罗姆翅膀 
		{"halloween_ornament_1", 998}, ----幽灵装饰 
		{"halloween_ornament_2", 998}, ----蝙蝠装饰 
		{"halloween_ornament_3", 998}, ----蜘蛛装饰 
		{"halloween_ornament_4", 998}, ----触手装饰 
		{"halloween_ornament_5", 998}, ----穴居悬蛛装饰 
		{"halloween_ornament_6", 998}, ----乌鸦装饰 
		{"halloweenpotion_embers", 998}, ----石灰硫化晶体 
		{"halloweenpotion_moon", 998}, ----月亮精华液 
		{"halloweenpotion_sparks", 998}, ----硝化硫酸晶体 
		{"winter_ornament_boss_hermithouse", 998}, ----感伤装饰 
		{"winter_ornament_boss_pearl", 998}, ----感伤装饰 
		{"carnival_prizeticket", 998}, ----奖票 
		{"antliontrinket", 998}, ----沙滩玩具 
		{"lightninggoathorn", 1200}, ----电羊角
		-- {"purplegem", 1100}, ----紫宝石 
		{"moonstorm_static_item", 1500}, ----约束静电 
		{"orangegem", 1600}, ----橙宝石 
		{"yellowgem", 2200}, ----黄宝石 
		{"greengem", 3500}, ----绿宝石 
		{"shadowheart", 5000}, ----暗影之心
		-- {"bearger_fur", 6666}, ----熊皮
		{"hermit_pearl", 6666}, ----珍珠的珍珠
		{"deerclops_eyeball", 6666}, ----眼球
		{"klaussackkey", 6666}, ----麋鹿茸
		{"atrium_key", 8888}, ----远古钥匙
		{"dragon_scales", 10000}, ----龙蝇皮
		{"opalpreciousgem", 12000}, ----彩虹宝石
		{"shroom_skin", 13000}, ----蘑菇皮
		{"minotaurhorn", 15000}, ----犀牛角,守护者之角
	},
	
	[2] = { --装备类
		{"waterplant_bomb", 120}, ----种壳 
		{"tentaclespike", 230}, ----触手尖刺 
		{"armorsnurtleshell", 600}, ----蜗牛龟盔甲 	
		{"spiderhat", 300}, ----蜘蛛帽 
		{"walrushat", 600}, ----海象帽 
		{"slurtlehat", 2000}, ----蜗牛帽子 
	},

	[3] = { --食物类
		{"spoiled_food", 10}, ----腐烂食物 
		{"wetgoop", 10}, ----失败料理
		{"seeds", 20}, ----种子
		{"carrot", 25}, ----胡萝卜
		{"berries", 25}, ----浆果 
		{"monstermeat", 30}, ----怪物肉
		{"berries_juicy", 35}, ----多汁浆果
		{"lightbulb", 40}, ----荧光果 
		{"honey", 40}, ----蜂蜜 
		{"froglegs", 40}, ----蛙腿 
		{"rottenegg", 40}, ----烂鸡蛋 
		{"phlegm", 50}, ----浓鼻涕
		{"smallmeat", 50}, ----小肉 
		{"drumstick", 50}, ----鸟腿
		{"bird_egg", 60}, ----鸟蛋
		{"cave_banana", 60}, ----洞穴香蕉 
		{"batwing", 60}, ----蝙蝠翅膀 
		{"pumpkin", 80}, ----南瓜 
		{"pomegranate", 80}, ----石榴 
		{"corn", 80}, ----玉米 
		{"eggplant", 80}, ----茄子 
		{"watermelon", 80}, ----西瓜 
		{"fish", 90}, ----鱼 
		{"red_cap", 100}, ----采摘的红蘑菇 
		{"blue_cap", 100}, ----采摘的蓝蘑菇 
		{"meat", 110}, ----大肉 
		-- {"kelp", 120}, ----海带叶
		{"glommerfuel", 120}, ----格罗姆的粘液
		{"jammypreserves", 120}, ----果酱
		{"durian", 120}, ----榴莲 
		{"green_cap", 130}, ----采摘的绿蘑菇 
		{"cactus_meat", 150}, ----仙人掌肉 
		{"plantmeat", 160}, ----食人花肉 
		{"durian_cooked", 160}, ----超臭榴莲
		{"dragonfruit", 220}, ----火龙果
		{"icecream", 230}, ----冰淇淋
		{"cactus_flower", 400}, ----仙人掌花
		{"eel", 400}, ----鳗鱼 
		{"trunk_summer", 500}, ----象鼻
		{"goatmilk", 600}, ----带电的羊奶
		{"butter", 600}, ----黄油
		{"halloweencandy_4", 666}, ----粘液蜘蛛
		{"trunk_winter", 750}, ----冬象鼻
		{"royal_jelly", 800}, ----蜂王浆
		{"mandrake", 1000}, ----曼德拉草
		{"fig", 1100}, ----无花果
	},

	[4] = {
		-- {"huli_dango", 220}, ----
		{"hulisoul", 100}, ----
		{"huligem_sj", 20}, ----
		{"huligem_hc", 35}, ----
		
	}
}

TUNING.GOODSITEM = goodsitem
TUNING.PRIZEITEM = {
	'rocks', ----岩石
	'cutgrass', ----草
	'twigs', ----树枝
	'log', ----木头
	'charcoal', ----木炭
	'ash', ----灰
	'cutreeds', ----采下的芦苇
	'lightbulb', ----荧光果
	'petals', ----花瓣
	'petals_evil', ----噩梦花瓣
	'pinecone', ----松果
	'foliage', ----蕨叶
	'cutlichen', ----摘下的苔藓
	'wormlight', ----发光蓝莓
	'lureplantbulb', ----食人花种子
	'flint', ----燧石
	'nitre', ----硝石
	'redgem', ----红宝石
	'bluegem', ----蓝宝石
	'purplegem', ----紫宝石
	'greengem', ----绿宝石
	'orangegem', ----橙宝石
	'yellowgem', ----黄宝石
	'rope', ----绳子
	'boards', ----木板
	'cutstone', ----石砖
	'transistor', ----机器原件
	'papyrus', ----纸
	'houndstooth', ----犬牙
	'pigskin', ----猪皮
	'manrabbit_tail', ----兔人尾巴
	'beardhair', ----胡子
	'beefalowool', ----牛毛
	'honeycomb', ----蜂巢
	'stinger', ----蜂刺
	'feather_crow', ----乌鸦羽毛
	'feather_robin', ----红雀羽毛
	'feather_robin_winter', ----雪雀羽毛
	'horn', ----牛角
	'moonrocknugget', ----月之石
	'livinglog', ----活木
	'monstermeat', ----怪物肉
	'spoiled_food', ----腐烂食物
	'monstermeat_dried', ----怪物肉干
	'red_cap', ----采摘的红蘑菇
	'slurtleslime', ----蜗牛液
	'slurtle_shellpieces', ----蜗牛龟壳片
	'butterflywings', ----蝴蝶翅膀
	'glommerwings', ----格罗姆翅膀
	'glommerflower', ----格罗姆花
	'glommerfuel', ----格罗姆的粘液
	'rottenegg', ----烂鸡蛋
	'durian_cooked', ----熟榴莲
	'poop', ----便便
	'guano', ----鸟粪
	'wathgrithrhat', ----女武神帽
	'boomerang', ----回旋镖
	'winterhat', ----冬帽
	'minerhat', ----矿工帽
	'spiderhat', ----蜘蛛帽
	'beehat', ----蜂帽
	'walrushat', ----海象帽
	'slurtlehat', ----蜗牛帽子
	'bushhat', ----丛林帽	
	'boneshard', ----硬骨头
	'ice', ----冰
	'goldnugget', ----金子
	'nightmarefuel', ----噩梦燃料
	'red_cap_cooked', ----煮熟的红蘑菇
	'durian', ----榴莲
	'rainhat', ----防雨帽
	'icehat', ----冰帽
	'watermelonhat', ----西瓜帽
	'catcoonhat', ----浣熊帽
	'sweatervest', ----小巧背心
	'trunkvest_summer', ----夏日背心
	'trunkvest_winter', ----寒冬背心
	'armorslurper', ----饥饿腰带
	'raincoat', ----雨衣
	'molehat', ----鼹鼠帽
	'strawhat', ----草帽
	'flowerhat', ----花环
	'beefalohat', ----牛毛帽
	'featherhat', ----羽毛帽
	'tophat', ----高礼帽
	'earmuffshat', ----兔耳罩
	'armordragonfly', ----蜻蜓盔甲
	'beargervest', ----熊背心
	'eyebrellahat', ----眼睛帽
	'hawaiianshirt', ----夏威夷衬衫
	'tentaclespike', ----狼牙棒
	'blowdart_pipe', ----吹箭
	'blowdart_sleep', ----麻醉吹箭
	'blowdart_fire', ----燃烧吹箭
	'hambat', ----火腿短棍
	'footballhat', ----猪皮帽
	'nightsword', ----暗影剑
	'batbat', ----蝙蝠棒
	'ruins_bat', ----远古短棒
	'spear_wathgrithr', ----瓦丝格雷斯矛
	'armormarble', ----大理石盔甲
	'armor_sanity', ----夜魔盔甲
	'armorsnurtleshell', ----蜗牛龟盔甲
	'armorruins', ----远古盔甲
	'ruinshat', ----远古盔甲
	'gunpowder', ----火药
	'heatrock', ----保温石
}	

local containers = require "containers"
local params = containers.params
params.huli_rechargenpc = { 
	widget = {	
		slotpos = {},
		animbank = "ui_miho_4x4", 
		animbuild = "ui_gumipot_4x4",
		pos = Vector3(0, 140, 0), 
		side_align_tip = 160,
		buttoninfo = {
			text = hl_loc('充值', 'Trade'),
			position = Vector3(0, -170, 0),
		}
	},
    type = "huli_rechargenpc",}	
for y = 2.5, -.5, -1 do
    for x = 0, 3 do
        table.insert(params.huli_rechargenpc.widget.slotpos,
		Vector3(72*x-93*2+77, 72*y-75*2+75, 0))
    end
end	

for k, v in pairs(params) do
    containers.MAXITEMSLOTS = math.max(containers.MAXITEMSLOTS, v.widget.slotpos ~= nil and #v.widget.slotpos or 0)
end

local function It1(item)
	for k, v in pairs(TUNING.GOODSITEM) do
		for i, j in pairs(v) do
			if item.prefab == j[1] then
				return true
			end
		end
	end
end

local function It2(item)
	-- local recipe = _G.AllRecipes[item.prefab]
	local recipe = GetValidRecipe(item.prefab)
	if recipe ~= nil then		
		for k, v in pairs(recipe.character_ingredients) do
			if IsCharacterIngredient(v.type) and It1(item) then
				return true
			end
		end
	end
end

local HULI_STORE_HSJG_SET = GetModConfigData("huli_store_hsjg_set")

function _G.NPCRechargeFn(wtf, inst)
	if inst._player == nil then 
		inst.components.talker:Say(hl_loc('点也没用，因为我只是一只萌萌哒！', 'Please call me from the Fox Store.'))
		return 
	end
	local container = inst.components.container
	local doer = inst._player
	-- local doer = inst.components.container.opener
	local store = doer.components.huli_store
	local GoldCoin = store.huli_coin
	local Get_GoldCoin = 0
	local recipe = nil
	if container:IsEmpty() then
		inst.components.talker:Say(hl_loc('请放入兑换狐狸币的物品',  'Please put in the items that need to trade fox coins'))
	else
		for i = 1, container:GetNumSlots() do
			local item = container:GetItemInSlot(i)
			local stacksize = 1
			local itempercent = 1
			local recrate = HULI_STORE_HSJG_SET / 100
			
			if item ~= nil then 
				recipe = GetValidRecipe(item.prefab)
				if item.components.stackable then 
					stacksize = item.components.stackable:StackSize()
				end
				if item.components.armor then
					itempercent = itempercent * item.components.armor:GetPercent()
				elseif item.components.finiteuses then
					itempercent = itempercent * item.components.finiteuses:GetPercent()
				elseif item.components.perishable then
					itempercent = itempercent * item.components.perishable:GetPercent()
				end
				if recipe ~= nil and not It2(item) then
					for k, v in ipairs(recipe.ingredients) do
						-- local amt = math.max(1, math.ceil(v.amount*stacksize*itempercent))
						item:Remove()
						local amt = math.floor(v.amount*stacksize*itempercent+.5)
						for n = 1, amt do
							inst:DoTaskInTime(.02, function() 
								container:GiveItem(SpawnPrefab(v.type))
							end)
						end
					end
				else
					for list = 1, #TUNING.GOODSITEM do
						for items = 1, #TUNING.GOODSITEM[list] do
							if item.prefab == TUNING.GOODSITEM[list][items][1] then
								Get_GoldCoin = math.floor(TUNING.GOODSITEM[list][items][2]*stacksize*itempercent*recrate)
								store:CoinDoDelta(Get_GoldCoin)
								item:Remove()
							end
						end
					end
				end
			end
		end
		inst:DoTaskInTime(.01, function() 
			if Get_GoldCoin ~= 0 then
				inst.components.talker:Say(hl_loc('充值成功，获得', 'Successful trade，Get【')..(store.huli_coin - GoldCoin)..hl_loc('狐狸币\n可分解的物品将被分解', '】Fox coins\nItems that can be broken down will be broken down'))
			else
				inst.components.talker:Say(hl_loc('分解物品', 'Decompose articles'))
			end
		end)
	end
end
AddModRPCHandler("huli_rpc", 'rechargenpc', NPCRechargeFn)

function params.huli_rechargenpc.widget.buttoninfo.fn(inst, doer)
	if _G.TheWorld.ismastersim then
		NPCRechargeFn(doer, inst)
	else
		SendModRPCToServer(MOD_RPC['huli_rpc']['rechargenpc'], inst)
	end
end

-- function params.huli_rechargenpc.itemtestfn(container, item, slot)
	-- if _G.AllRecipes[item.prefab] ~= nil then
		-- return true
	-- end
	-- return false
-- end

local huli_storeui = require('widgets/huli_storeui')
local function AddStoreUi(self)
	if self.owner.prefab == 'huli' then
		self.huli_storeui = self:AddChild(huli_storeui(self.owner, goodsitem))
	end
end
if HULI_STORE_SET == "开启" then
	AddClassPostConstruct('widgets/controls', AddStoreUi)
end

