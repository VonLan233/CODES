------------------------------------------------游泳模块-通常设置------------------------------------------------
AddComponentPostInit("floater",function(self)
	self.float_params = nil 
	self.SetFloatParams = function(self,x,y,z)
		self.float_params = Vector3(x,y,z)
	end 
	
	local old_OnLandedClient = self.OnLandedClient
	self.OnLandedClient = function(self,...)
		old_OnLandedClient(self,...)
		self.inst.AnimState:SetFloatParams((self.float_params or Vector3(-0.05, 1.0, self.bob_percent)):Get())
	end 
	
	if not TheNet:IsDedicated() then
        self.inst:ListenForEvent("sizedirty", function()
            local size = self._size:value()
			if size then 
				if self.front_fx then
					self.front_fx.AnimState:PlayAnimation("idle_front_" .. size, true)
				end
				if self.back_fx then
					self.back_fx.AnimState:PlayAnimation("idle_back_" .. size, true)
				end
			end
        end)
    end
	
	self._size = net_string(self.inst.GUID, "floater._size", "sizedirty")
	self._size:set(self.size)
	
	
	local old_SetSize = self.SetSize
	self.SetSize = function(self,size,...)
		old_SetSize(self,size,...)
		self._size:set(size)
		self._size:set_local(size)
	end 
end)

AddComponentPostInit("drownable",function(self)
	self.shoulddrowntest = nil  
	function self:SetShouldDrownTest(fn)
		self.shoulddrowntest = fn 
	end
	
	local old_ShouldDrown = self.ShouldDrown 
	function self:ShouldDrown(...)		
		return (self.shoulddrowntest == nil or self.shoulddrowntest(self.inst)) and old_ShouldDrown(self,...)
	end
end)

AddComponentPostInit("locomotor",function(self)
	self.last_want_to_ocean_fishing_time = 0
	
	
	self.StartCheckFishing = function(self)
		self:StopCheckFishing()
		self.FishingCheckTask = self.inst:DoPeriodicTask(0,function()
			local action = self.inst:GetBufferedAction()
			if (action and (action.action == ACTIONS.OCEAN_FISHING_CAST or action.action == ACTIONS.OCEAN_FISHING_POND))
			or self.inst.sg and self.inst.sg:HasStateTag("fishing")
			then
				self.last_want_to_ocean_fishing_time = GetTime()
			end 
		end)
	end 
	
	self.StopCheckFishing = function(self)
		if self.FishingCheckTask then
			self.FishingCheckTask:Cancel()
		end
		self.FishingCheckTask = nil 
	end
	
	self:StartCheckFishing()
end)
---------------------------------------------------------------------------------------------------------------
-- end


local old_PlayFootstep = GLOBAL.PlayFootstep
GLOBAL.PlayFootstep = function(inst, volume, ispredicted,...)
	if inst:HasTag("huli") and inst:IsOnOcean() then 
		local rad = math.random() * 0.5
		local roa = math.random() * 2 * PI
		local offset = Vector3(math.cos(roa),0,math.sin(roa)) * rad
		inst.SoundEmitter:PlaySound("turnoftides/common/together/water/splash/jump_small",nil,volume or 1,ispredicted)
		-- SpawnAt("splash_sink",inst:GetPosition() + offset).Transform:SetScale(0.4,0.4,1)
	else
		return old_PlayFootstep(inst, volume, ispredicted,...)
	end 
end

AddStategraphPostInit("wilson", function(sg)
	local old_onsink = sg.events["onsink"].fn 
	sg.events["onsink"].fn = function(inst,data,...)
		if inst.components.huli_swimmer and not (inst.components.drownable and inst.components.drownable:ShouldDrown()) then 
			inst.components.huli_swimmer:StartSwimServer()
		else
			return old_onsink(inst,data,...)
		end
	end 
	
	local old_sink_state_onenter = sg.states["sink"].onenter
	sg.states["sink"].onenter = function(inst, shore_pt,...)
		if inst.components.huli_swimmer and not (inst.components.drownable and inst.components.drownable:ShouldDrown()) then 
			inst.components.huli_swimmer:StartSwimServer()
			inst.sg:GoToState("idle",true)
		else
			return old_sink_state_onenter(inst,shore_pt,...)
		end
	end 
end)

AddComponentPostInit("locomotor",function(self)
	local old_OnUpdate = self.OnUpdate
	self.OnUpdate = function(self,dt,...)
		old_OnUpdate(self,dt,...)
		local pos = self.inst:GetPosition()
		if TheWorld.has_ocean 
		and not self.inst:HasTag("playerghost")
		and not self.inst:HasTag("incar")
		and not self.hopping and self.inst.components.huli_swimmer 
		and not (self.inst._inhuahouse and self.inst._inhuahouse:value())
		and not (self.inst._inmythhouse and self.inst._inmythhouse:value())
		and pos.y <= 0.05
		and GetTime() - self.last_want_to_ocean_fishing_time >= 0.5 
		then 		
			local too_early_top_hop = self.time_before_next_hop_is_allowed > 0
			
			local x,y,z = self.inst:GetPosition():Get()
			local boat = TheWorld.Map:GetPlatformAtPoint(x,z)
				
			local rad = 0.75
			local extend_rad = 0.4
			local scan_rad = self.hop_distance 
			local rotation = self.inst.Transform:GetRotation() * DEGREES				
			local next_x,next_y,next_z = x + rad * math.cos(rotation),y,z - rad * math.sin(rotation)
			
			
			local scan_x,scan_z = x + scan_rad * math.cos(rotation),z - scan_rad * math.sin(rotation)
			local other_platform = TheWorld.Map:GetPlatformAtPoint(scan_x, scan_z)
			
			-- local now_onwater = not TheWorld.Map:IsVisualGroundAtPoint(x, 0, z)
			local now_onwater = TheWorld.Map:IsOceanAtPoint(x, y, z)
			local dest_is_onwater = TheWorld.Map:IsOceanAtPoint(next_x, y, next_z)
			-- local dest_is_onwater = not TheWorld.Map:IsVisualGroundAtPoint(next_x, 0, next_z)
			
			-- print("TestHopping:",too_early_top_hop,other_platform,boat,dest_is_onwater,now_onwater)
			if not too_early_top_hop 
				and not other_platform 
				and (not boat or self.inst:HasTag("CAN_JUMP_ON_BOAT"))
				and ((dest_is_onwater and not now_onwater) or (not dest_is_onwater and now_onwater)) then  
				self:StartHopping(next_x + extend_rad * math.cos(rotation),next_z - extend_rad * math.sin(rotation))
			end 
		end 
	end 
end)
