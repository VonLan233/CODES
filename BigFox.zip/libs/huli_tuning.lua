
local huli_language_set = GetModConfigData("huli_language_set")
local locale = LOC.GetLocaleCode()
_G['大狐狸语言'] = true
if huli_language_set == 'AUTO' then
	_G['大狐狸语言'] = locale == "zh" or locale == "zhr" or locale == "zht" 
elseif huli_language_set == 'Chs' then
	_G['大狐狸语言'] = true
elseif huli_language_set == 'Eng' then
	_G['大狐狸语言'] = false
end

function _G.hl_loc(zh, en)
	return _G['大狐狸语言'] and zh or en
end

--------------------------------------------------------------------------------------------
-------------------------------huli_statekey
	TUNING.HULI_KEYACTIONS_HULI_STATEKEY = hl_loc('当前状态无法变身!', 'Current state cannot be transformed!')
	TUNING.HULI_KEYACTIONS_HULI_STATEKEY_1 = hl_loc('都快完蛋了还想变身!', "Almost dead, can't be transformed!")
	
-------------------------------call_xhl
	TUNING.HULI_KEYACTIONS_CALL_XHL = hl_loc('宝贝跟我来!', 'Baby come with me!')
	TUNING.HULI_KEYACTIONS_CALL_XHL_1 = hl_loc('来喽来喽!', "I'm coming.I'm coming.!")
	TUNING.HULI_KEYACTIONS_CALL_XHL_2 = hl_loc('小狐狸停下来!', 'Baby stay here!')
	TUNING.HULI_KEYACTIONS_CALL_XHL_3 = hl_loc('收到!', 'Received!')
	TUNING.HULI_KEYACTIONS_CALL_XHL_4 = hl_loc('小狐狸不在范围内', 'Baby out of range')
	TUNING.HULI_KEYACTIONS_CALL_XHL_5 = hl_loc('我似乎感觉到老妈在呼唤我', 'I seem to feel my mother calling me.?')
	TUNING.HULI_KEYACTIONS_CALL_XHL_6 = hl_loc('小狐狸还没出生\n也有可能死光了.', 'The fox is not yet born\n It could be dead...')

-------------------------------Start_BurnPartyTime
	TUNING.HULI_KEYACTIONS_WEAPON_GUMIFAN = hl_loc('需要装备芭蕉扇!', 'Need to equip gumifan fan!')
	TUNING.HULI_KEYACTIONS_RED_SKILL_STATE = hl_loc('开启盛宴状态!', 'Open fire skill status!')
	TUNING.HULI_KEYACTIONS_RED_SKILL_STATE_OFF = hl_loc('关闭盛宴状态!', 'Close fire skill status!')
	
	TUNING.HULI_KEYACTIONS_ICE_SKILL_STATE = hl_loc('开启冰域状态!', 'Open ice skill status!!')
	TUNING.HULI_KEYACTIONS_ICE_SKILL_STATE_OFF = hl_loc('关闭冰域状态!', 'Close ice skill status!')
	TUNING.HULI_KEYACTIONS_ICE_SKILL_ELEMENT_FALSE = hl_loc('元素不足,无法开启冰域状态.', 'Insufficient ice element\n Unable to turn on ice skill state.')
	
	TUNING.HULI_KEYACTIONS_SKILL_HUNGRY_CLOSE = hl_loc('肚子饿，没力气啦.', "I'm hungry，No strength.")
	TUNING.HULI_KEYACTIONS_STATE_NOT = hl_loc('当前状态无法施放技能.', 'Unable to cast skills in current state.')
	TUNING.HULI_KEYACTIONS_LEVAL_NOT = hl_loc('要升级才能开启技能哦.', 'You need to upgrade to open skills.')

-------------------------------huli
	TUNING.HULI_GETEXP_FULL = hl_loc('经验储量已满!', 'Exp value is full!')
	TUNING.HULI_RED_SKILL_READY = hl_loc('盛宴冷却好喽!', 'Fire skill is ready!')
	TUNING.HULI_RED_SKILL_ELEMENT_CLOSE = hl_loc('火元素不足,关闭盛宴状态.', 'Insufficient fire element，Close fire skill status.')
	TUNING.HULI_RED_SKILL_HUNGRY_CLOSE = hl_loc('肚子饿了,关闭盛宴状态.', "I'm hungry，Close fire skill status.")
	
	TUNING.HULI_ICE_SKILL_READY = hl_loc('冰域冷却好喽!', 'Ice skill is ready!')
	TUNING.HULI_ICE_SKILL_ELEMENT_CLOSE = hl_loc('冰元素不足,关闭冰域状态.', 'Insufficient ice element，Close ice skill status.')
	TUNING.HULI_ICE_SKILL_HUNGRY_CLOSE = hl_loc('肚子饿了,关闭冰域状态.', "I'm hungry，Close ice skill status.")
	
--■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

-------------------------------UI
	TUNING.HULI_INFOUI_LEVELUP = hl_loc('升级', 'Level up')
	TUNING.HULI_INFOUI_LEVELUP_1 = hl_loc('已满级', 'The level is full.')
	TUNING.HULI_INFOUI_LEVELUP_2 = hl_loc('经验不足', 'Insufficient empirical value')
	
--◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆
	TUNING.HULI_INFOUI_LEVEL_TEXT = hl_loc('等级：', 'Level：')
	TUNING.HULI_INFOUI_HULISTATE_TEXT = hl_loc('当前形态：', 'State：')
	TUNING.HULI_INFOUI_HULIDAMAGE_TEXT = hl_loc('当前伤害：', 'Current Attack：')
	TUNING.HULI_INFOUI_HULIABSORB_TEXT = hl_loc('自身伤害减免：', 'Self dmg absorb：')
	TUNING.HULI_INFOUI_HULI_WALKSPEED_TEXT = hl_loc('移动速度：', 'Moving speed：')
	TUNING.HULI_INFOUI_SKILLCD_TEXT = hl_loc('技能CD：', 'SkillCD：')
	TUNING.HULI_INFOUI_SKILLCD_TEXT_ENABLE = hl_loc('(启用)', '(Enable)')
	TUNING.HULI_INFOUI_SKILLCD_TEXT_DISABLE = hl_loc('(禁用)', '(Disable)')
	TUNING.HULI_INFOUI_SKILLCD_TEXT_READY = hl_loc('技能已就绪', 'Skill is ready')
	TUNING.HULI_INFOUI_FIRE_ELEMENT_TEXT = hl_loc('火元素：', 'Fire element：')
	TUNING.HULI_INFOUI_FIRE_ELEMENT_TEXT_FULL = hl_loc('火元素：已满/', 'Fire element：Full/')
	TUNING.HULI_INFOUI_ICE_ELEMENT_TEXT = hl_loc('冰元素：', 'Ice element：')
	TUNING.HULI_INFOUI_ICE_ELEMENT_TEXT_FULL = hl_loc('冰元素：已满/', 'Ice element：Full/')
	TUNING.HULI_INFOUI_WORLDTEMP_TEXT = hl_loc('气温：', 'World temp:')
---------------------------------------------------------------------------------
	TUNING.HULI_INFOUI_HULI_EXP_TEXT = hl_loc('经验：', 'Exp：')
	TUNING.HULI_INFOUI_HULIDMGMULT_TEXT = hl_loc('伤害倍率：', 'Damage Multipler：')
	TUNING.HULI_INFOUI_HULI_WALKSPEEDMULT_TEXT = hl_loc('移速倍率：', 'Speed multiplier：')
	TUNING.HULI_INFOUI_PETNUMBER_TEXT = hl_loc('小狐狸数量：', 'Number of pets：')
--◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆◆	
-------------------------------fireskill
	TUNING.HULI_INFOUI_FIRESKILL_ON = hl_loc('启用火焰盛宴技能', 'Enable Flame Feast Skills')
	TUNING.HULI_INFOUI_FIRESKILL_OFF = hl_loc('禁用火焰盛宴技能', 'Disable Flame Feast Skills')
-------------------------------iceskill
	TUNING.HULI_INFOUI_ICESKILL_ON = hl_loc('启用冰域技能', 'Enable ice domain skills')
	TUNING.HULI_INFOUI_ICESKILL_OFF = hl_loc('禁用冰域技能', 'Disable ice domain skills')
-------------------------------info_textbutton
	TUNING.HULI_INFOUI_TEXTBUTTON = hl_loc('查看详情', 'On details')
	TUNING.HULI_INFOUI_TEXTBUTTON_OFF = hl_loc('关闭详情', 'Off details')
	TUNING.HULI_INFOUI_TEXTBUTTON_3 = hl_loc('点击查看/关闭详细属性', 'Click to view/Close detailed properties')
-------------------------------level_up
	TUNING.HULI_INFOUI_LEVEL_UP = hl_loc('点击升级', 'Click to level up')
	TUNING.HULI_INFOUI_LEVEL_UP_1 = hl_loc('', '')
	
-------------------------------头衔控制面板
	TUNING.HULI_INFO_DETAILS_LABEL_CONTROL = hl_loc('头衔控制器', 'Title control')
	
-------------------------------头衔
	TUNING.HULI_INFO_DETAILS_LABEL = hl_loc('显示头衔', 'Display title')
	TUNING.HULI_INFO_DETAILS_LABEL_1 = hl_loc('隐藏头衔', 'Hidden titles')
	
--■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■商店■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

-------------------------------huli_storeitem
	TUNING.HULI_STOREITEM_1 = hl_loc('充值', 'Trade')
	TUNING.HULI_STOREITEM_2 =hl_loc('请放入兑换狐狸币的物品',  'Please put in the items that need to trade fox coins')
	TUNING.HULI_STOREITEM_3 = hl_loc('充值成功，获得', 'Successful trade，Get【')
	TUNING.HULI_STOREITEM_4 = hl_loc('狐狸币\n可分解的物品将被分解', '】Fox coins\nItems that can be broken down will be broken down')
	TUNING.HULI_STOREITEM_5 = hl_loc('分解物品', 'Decompose articles')
-------------------------------huli_rechargenpc
	TUNING.HULI_RECHARGENPC_1 = hl_loc('该物品不能兑换狐狸币或者不支持分解！\n扔出物品！', "This item can't be exchanged for Fox currency or doesn't support decomposition！\nThrow out item！")
	TUNING.HULI_RECHARGENPC_2 = hl_loc('★狐狸充值员★', '★Fox recharger★')

-------------------------------huli_storeui
	TUNING.HULI_STOREUI_ItemBuyFn_1 = hl_loc('狐狸币不足，请充值！', 'Fox coins are not enough，Please recharge！')
------Class
	TUNING.HULI_STOREUI_Class_1 = hl_loc('关闭', 'Close')
	TUNING.HULI_STOREUI_Class_2 = hl_loc('狐狸商店', 'Fox store')
	TUNING.HULI_STOREUI_Class_3 = hl_loc('上一页', 'last page')
	TUNING.HULI_STOREUI_Class_4 = hl_loc('下一页', 'next page')
	TUNING.HULI_STOREUI_Class_5 = hl_loc('狐狸币', 'Fox coins')
	TUNING.HULI_STOREUI_Class_6 = hl_loc('我要充钱', 'I want to recharge.')
	
-------------------------------huli_petleash
	TUNING.HULI_PETLEASH_1 = hl_loc('鬼啊.....我闪！', 'Ghost....BayBay！')
	TUNING.HULI_PETLEASH_2 = hl_loc('欢迎下次光临，再见！', 'Looking forward to your next visit，BayBay！')
	TUNING.HULI_PETLEASH_3 = hl_loc('只能召唤一只萌萌达的充值员', 'You can only summon a cute recharge agent')
	TUNING.HULI_PETLEASH_4 = hl_loc('欢迎光临狐狸充值店！', 'Welcome to Fox recharge shop！')
	TUNING.HULI_PETLEASH_5 = hl_loc('溜了', 'BayBay！!')
	
-------------------------------
-------------------------------

--选人界面人物三维显示
TUNING.HULI_HEALTH = 100
TUNING.HULI_HUNGER = 120
TUNING.HULI_SANITY = 100
--生存几率
STRINGS.CHARACTER_SURVIVABILITY.huli = hl_loc('有手就行', 'simple')

--选人界面初始物品显示，MOD物品需要定义图片路径
TUNING.GAMEMODE_STARTING_ITEMS.DEFAULT.HULI = {
	"gumifan",
	"mihobell",
	"miho",
	"miregg",
}

for k, v in pairs(TUNING.GAMEMODE_STARTING_ITEMS.DEFAULT.HULI) do
	TUNING.STARTING_ITEM_IMAGE_OVERRIDE[v] = {
		atlas = "images/minimapicons/"..v..".xml",
		image = v..".tex",
	}
end



