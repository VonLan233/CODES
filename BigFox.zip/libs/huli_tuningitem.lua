GLOBAL.TUNING.ITEM =
{
	all_rockitem = {
		{"rock1"},	--卵矿
		{"rock2"},	--带金矿
		{"rock_flintless"},	--洞穴卵石
		{"rock_moon"},	--月石矿
		{"rock_moon_shell"}, --高级月石矿
		{"moonglass_rock"},	--月光石矿
		{"rock_petrified_tree_tall"}, --石化树矿
	},
	
	buildrepairitem = {
		-- {pref = "ice", wl = 0}, --冰
		{pref = "log", wl = 65}, --木头
		{pref = "boards", wl = 330}, --木板
		{pref = "wall_wood_item", wl = 100}, --木墙
		{pref = "livinglog", wl = 160}, --魂木
		{pref = "rocks", wl = 35}, --岩石
		{pref = "flint", wl = 55}, --燧石
		{pref = "cutstone", wl = 220}, --石砖
		{pref = "wall_stone_item", wl = 120}, --石墙
		{pref = "thulecite_pieces", wl = 80}, --铥矿石碎片
		{pref = "thulecite", wl = 600}, 	--铥矿石
		{pref = "wall_ruins_item", wl = 120}, --铥墙
		{pref = "goldnugget", wl = 120}, --黄金
		{pref = "bluegem", wl = 140}, 	--蓝宝石
		{pref = "redgem", wl = 150}, 	--红宝石
		{pref = "purplegem", wl = 160},	--紫宝石
		{pref = "orangegem", wl = 170},	--橙宝石
		{pref = "yellowgem", wl = 180}, 	--黄宝石
		{pref = "greengem", wl = 230 },	--绿宝石
		{pref = "opalpreciousgem", wl = 400 }, --彩色宝石
		{pref = "moonrocknugget", wl = 150},	--月之石
		{pref = "moonrockseed", wl = 400},	--月石种子
		{pref = "huligem_sj", wl = 15},	--水晶石
		{pref = "huligem_qh", wl = 46, 1}, --强化石
		{pref = "huligem_gjqh", wl = 220, 1}, --高级强化石
		{pref = "huligem_hc", wl = 20}, --合成石
		{pref = "huligem_jh", wl = 500}, --进化石
		{pref = "huligem_xy", wl = 200}, --幸运石
		{pref = "huligem_bj", wl = 200}, --保级石
	},
	
    foxmask = {
		{"moonglass", 200}, 	--月玻璃石
		{"bluegem", 200}, 	--蓝宝石
		{"redgem", 300}, 	--红宝石
		{"purplegem", 400},	--紫宝石
		{"orangegem", 500},	--橙宝石
		{"yellowgem", 600}, 	--黄宝石
		{"greengem", 800 },	--绿宝石
		{"opalpreciousgem", 1500 }, --彩色宝石
		{"hulisoul", 50}, 	--灵魂结晶
		{"moonrockseed", 500},	--月石种子
		{"huligem_sj", 30},	--水晶石
		{"huligem_qh", 100, 1}, --强化石
		{"huligem_gjqh", 400, 1}, --高级强化石
		{"huligem_hc", 100}, --合成石
		-- {"huligem_jh", 3000}, --进化石
		{"huligem_xy", 700}, --幸运石
		{"huligem_bj", 700}, --保级石
		{"livinglog", 100}, --魂木
		{"pigskin", 50}, --猪皮
		{"slurper_pelt", 100}, --缀食者皮
		{"silk", 50}, --蛛蛛丝
		{"papyrus", 80}, --纸莎草
		{"bearger_fur", 300}, --熊皮
		{"tentaclespots", 100}, --触手皮
		{"dragon_scales", 3000}, --鳞片
	},

	foxmask_new = {
		{"rocks", 15}, --岩石
		{"flint", 20}, --燧石
		{"thulecite_pieces", 30}, --铥矿石碎片
		{"goldnugget", 50}, --黄金
		{"thulecite", 160}, 	--铥矿石
		{"moonglass", 200}, 	--月玻璃石
		{"bluegem", 200}, 	--蓝宝石
		{"redgem", 300}, 	--红宝石
		{"purplegem", 400},	--紫宝石
		{"orangegem", 500},	--橙宝石
		{"yellowgem", 600}, 	--黄宝石
		{"greengem", 800 },	--绿宝石
		{"opalpreciousgem", 1500 }, --彩色宝石
		{"hulisoul", 50}, 	--灵魂结晶
		{"moonrocknugget", 100},	--月之石
		{"moonrockseed", 500},	--月石种子
		{"huligem_sj", 30},	--水晶石
		{"huligem_qh", 100, 1}, --强化石
		{"huligem_gjqh", 400, 1}, --高级强化石
		{"huligem_hc", 100}, --合成石
		{"huligem_jh", 3000}, --进化石
		{"huligem_xy", 700}, --幸运石
		{"huligem_bj", 700}, --保级石
		{"livinglog", 100}, --魂木
		{"pigskin", 30}, --猪皮
		{"tentaclespots", 80}, --触手皮
		{"dragon_scales", 2000}, --鳞片
		{"houndstooth", 20}, --狗牙
		{"horn", 50},		--牛角
		{"walrus_tusk", 80}, --海象牙
		{"lightninggoathorn", 100}, --闪电羊角
		{"minotaurhorn", 1000}, --远古守护者角
	},

	gumifan = {
		{"rocks", 10}, --岩石
		{"flint", 12}, --燧石
		{"thulecite_pieces", 20}, --铥矿石碎片
		{"goldnugget", 50}, --黄金
		{"thulecite", 120}, 	--铥矿石
		{"moonglass", 200}, 	--月玻璃石
		{"bluegem", 200}, 	--蓝宝石
		{"redgem", 220}, 	--红宝石
		{"purplegem", 300},	--紫宝石
		{"orangegem", 350},	--橙宝石
		{"yellowgem", 400}, 	--黄宝石
		{"greengem", 600 },	--绿宝石
		{"opalpreciousgem", 1300 }, --彩色宝石
		{"moonrocknugget", 100},	--月之石
		{"moonrockseed", 500},	--月石种子
		{"huligem_sj", 30},	--水晶石
		{"huligem_qh", 100, 1}, --强化石
		{"huligem_gjqh", 400, 1}, --高级强化石
		{"huligem_hc", 100}, --合成石
		{"huligem_jh", 2000}, --进化石
		{"huligem_xy", 600}, --幸运石
		{"huligem_bj", 700}, --保级石
		{"livinglog", 80}, --魂木
		{"pigskin", 20}, --猪皮
		{"tentaclespots", 50}, --触手皮
		{"dragon_scales", 1500}, --鳞片
		{"houndstooth", 10}, --狗牙
		{"horn", 20},		--牛角
		{"walrus_tusk", 30}, --海象牙
		{"lightninggoathorn", 10}, --闪电羊角
		{"minotaurhorn", 1000}, --远古守护者角
	},
	
	skirt = {
		{"moonglass", 200}, 	--月玻璃片
		{"bluegem", 200}, 	--蓝宝石
		{"redgem", 260}, 	--红宝石
		{"purplegem", 330},	--紫宝石
		{"orangegem", 400},	--橙宝石
		{"yellowgem", 500}, 	--黄宝石
		{"greengem", 700 },	--绿宝石
		{"opalpreciousgem", 1000 }, --彩色宝石
		{"huligem_sj", 30},	--水晶石
		{"huligem_qh", 100, 1}, --强化石
		{"huligem_gjqh", 400, 1}, --高级强化石
		{"huligem_hc", 100}, --合成石
		{"huligem_jh", 2000}, --进化石
		{"huligem_xy", 600}, --幸运石
		{"huligem_bj", 600}, --保级石
		{"livinglog", 100}, --魂木
		{"pigskin", 80}, --猪皮
		{"silk", 30}, --蛛蛛丝
		{"beefalowool", 20}, --牛毛
		{"tentaclespots", 100}, --触手皮
		{"bearger_fur", 300}, --熊皮
		{"goose_feather", 500}, --掉落的羽毛
		{"dragon_scales", 2000}, --鳞片
	},	

	gemrockloot = {
		{"huligem_sj",  .2,  .3,  .4,  .5,  .6},	--水晶石
		{"huligem_sj",  .1,  .2,  .3,  .4,  .5},	--水晶石
		{"huligem_sj",   0,  .1,  .2,  .3,  .4},	--水晶石
		{"huligem_hc", .05,  .1,  .2,  .3,  .4}, --合成石
		{"huligem_qh",   0, .08, .12,  .2,  .3}, --强化石
		-- {"huligem_qh",   0,   0,   0,  .1,  .2}, --强化石
		{"huligem_gjqh", 0,   0, .02, .04, .07}, --高级强化石
		-- {"huligem_hc",   0,   0,  .1,  .2,  .5}, --合成石
		{"huligem_jh",   0,   0, .01, .02, .03}, --进化石
		{"huligem_xy",   0, .02, .05,  .1,  .2}, --幸运石
		{"huligem_bj",   0, .02, .05,  .1,  .2}, --保级石
	},

	gemmonsterloot = {
		{pref = "hulisoul", ca = .05, cb = .1, cc = .2, cd = .5, ce = .7},	--灵魂结晶
		{pref = "hulisoul", ca = 0, cb = 0, cc = .15, cd = .3, ce = .6},	--灵魂结晶
		{pref = "huligem_sj", ca = .1, cb = .3, cc = .5, cd = .8, ce = .9},	--水晶石
		{pref = "huligem_sj", ca = .1, cb = .2, cc = .5, cd = .7, ce = .9},	--水晶石
		{pref = "huligem_sj", ca = 0, cb = .1, cc = .4, cd = .7, ce = .9},	--水晶石
		{pref = "huligem_qh", ca = 0, cb = .08, cc = .2, cd = .5, ce = .7}, --强化石
		{pref = "huligem_qh", ca = 0, cb = 0, cc = .2, cd = .5, ce = .6}, --强化石
		{pref = "huligem_gjqh", ca = 0, cb = 0, cc = .03, cd = .1, ce = .15}, --高级强化石
		{pref = "huligem_hc", ca = .03, cb = .2, cc = .5, cd = .7, ce = .8}, --合成石
		{pref = "huligem_hc", ca = 0, cb = .1, cc = .3, cd = .6, ce = .7}, --合成石
		{pref = "huligem_jh", ca = 0, cb = 0, cc = .02, cd = .08, ce = .14}, --进化石
		{pref = "huligem_xy", ca = 0, cb = .02, cc = .2, cd = .5, ce = .7}, --幸运石
		{pref = "huligem_bj", ca = 0, cb = .02, cc = .2, cd = .5, ce = .7}, --保级石
	},
	
}

for k, v in pairs(TUNING.ITEM.gumifan) do
	AddPrefabPostInit(v[1], function(inst)
		if not inst.components.z_huli_rp_gumifan then
			inst:AddComponent("z_huli_rp_gumifan") 
		end 
	end)
end

for k, v in pairs(TUNING.ITEM.foxmask) do
	AddPrefabPostInit(v[1], function(inst)
		if not inst.components.z_huli_rp_foxmask then
			inst:AddComponent("z_huli_rp_foxmask") 
		end 
	end)
end

for k, v in pairs(TUNING.ITEM.foxmask_new) do
	AddPrefabPostInit(v[1], function(inst)
		if not inst.components.z_huli_rp_foxmask_new then
			inst:AddComponent("z_huli_rp_foxmask_new") 
		end 
	end)
end

for k, v in pairs(TUNING.ITEM.skirt) do
	AddPrefabPostInit(v[1], function(inst)
		if not inst.components.z_huli_rp_skirt then
			inst:AddComponent("z_huli_rp_skirt") 
		end 
	end)
end


tradableitem =
{
	--"skirt",
	"skirt_x",
	"handfan",
	"gumifan",
	"foxmask",
	"foxmask_new",
	"calibur",
	--"calibur_x",
	"axe",
	"goldenaxe",
	"armor_sanity",
	"umbrella",
	"grass_umbrella",
	"hambat",
	"spear",
	"tentaclespike",
	"nightsword",
	"torch",
	"armorwood",
	"pickaxe",
	"goldenpickaxe",
	"blowdart_sleep",
	"blowdart_fire",
	"blowdart_pipe",
	"boomerang",
	"ice_projectile",
	"fire_projectile",
	"fishingrod",
	"bugnet",
	"hammer",
	"shovel",
	"goldenshovel",
	"pitchfork",
	"cane",
	"armormarble",
	"armorgrass",
	"sweatervest",
	"trunkvest_summer",
	"trunkvest_winter",
	"armorsnurtleshell",
	"lighter",
	"nightlight",
	--"batbat",
	"lucy",
	"armorruins",
	"armorslurper",
	"multitool_axe_pickaxe",
	"ruins_bat",
	"nightstick",
	"lantern",

	"rocks",
	"flint",
	"goldnugget",
	"thulecite_pieces",
	"thulecite",
	"bluegem",
	"redgem",
	"purplegem",
	"orangegem",
	"yellowgem",
	"greengem",
	"opalpreciousgem",
	"hulisoul",
	"moonrocknugget",
	"houndstooth",
	"horn",
	"walrus_tusk",
	"dragon_scales",
	"livinglog",
	"huligem",
}

-- for k, v in pairs(tradableitem) do
	-- AddPrefabPostInit(v,function(inst)
		-- if not inst.components.tradable then
			-- inst:AddComponent("tradable") 
		-- end 
	-- end)
-- end
AddPrefabPostInitAny(function(inst)
	-- if inst.components.weapon then
	if inst.components.equippable then
		if not inst.components.tradable then
			inst:AddComponent("tradable") 
		end 
	end
end)
