
local loc = locale == "zh" or locale == "zhr" or locale == "zht" 
local function hl_loc(zh, en)
	return loc and zh or en
end

name = "大狐狸(Millennium Fox)"
description = [[
		v2.5.7.0*一只可爱的狐狸*
·内置MOD使用说明，在人物信息面板>>>帮助/Help
·内置MOD使用说明，在人物信息面板>>>帮助/Help
·内置MOD使用说明，在人物信息面板>>>帮助/Help

·红狐狸：（专属技能：火焰盛焰）...·冰狐狸：（专属技能：冰域）.
·月狐狸：月圆之夜（暂无专属技能）.只吃肉...·白狐狸：精神低的时候，只吃肉
·狐狸专属物品、建筑：在专属物品栏制作.
·狐狸箱：月圆给放满兔兔包（每个格子放一个即可）可以升级狐狸箱（豪华版）.
·可以造小狐狸，小狐狸可以升级、打怪、卖萌等.
·装备可以强化升级【鼠标拿起物品移动到装备上，再点右键】
.建筑可以修理【鼠标拿起修理物品移动到建筑上时，再点击鼠标右键即可修理】。

·默认《技能》键【R】,（按键请到游戏内设置）
·默认《跳跃》键【G】,（按键请到游戏内设置）
·默认《大狐狸变身》键【Z】,（按键请到游戏内设置）
·默认《小狐狸控制》键【X】,（按键请到游戏内设置）
......以下省略N字。
]]

author = "那八(代码与部分贴图)"
version = "2.5.7.0" 

forumthread = ""
 
api_version = 10
 
dst_compatible = true
dont_starve_compatible = false
reign_of_giants_compatible = false
all_clients_require_mod = true
 
icon_atlas = "modicon.xml"
icon = "modicon.tex"
 
server_filter_tags = {
"character",
}

local op_on_off = {
	{description = hl_loc("关闭", "Disable"), data = 0},
	{description = hl_loc("开启", "Enable"), data = 1}
}
	  
local op_comkey = {
	{description = hl_loc("关闭", "Disable"), data = 0},
	-- {description="RSHIFT", data = 303}, -- 右shift
	{description="LSHIFT", data = 304}, -- 左shift
	-- {description="RCTRL", data = 305}, -- 右ctrl
	{description="LCTRL", data = 306}, -- 左ctrl
	-- {description="RALT", data = 307}, -- 右alt
	{description="LALT", data = 308}, -- 左alt
}

local allkey = { 
	{description="TAB", data = 9},
	{description="KP_PERIOD", data = 266},
	{description="KP_DIVIDE", data = 267},
	{description="KP_MULTIPLY", data = 268},
	{description="KP_MINUS", data = 269},
	{description="KP_PLUS", data = 270},
	{description="KP_ENTER", data = 271},
	{description="KP_EQUALS", data = 272},
	{description="MINUS", data = 45},
	{description="EQUALS", data = 61},
	{description="SPACE", data = 32},
	{description="ENTER", data = 13},
	{description="ESCAPE", data = 27},
	{description="HOME", data = 278},
	{description="INSERT", data = 277},
	{description="DELETE", data = 127},
	{description="END", data   = 279},
	{description="PAUSE", data = 19},
	{description="PRINT", data = 316},
	{description="CAPSLOCK", data = 301},
	{description="SCROLLOCK", data = 302},
	{description="RSHIFT", data = 303}, -- 右shift
	{description="LSHIFT", data = 304}, -- 左shift
	{description="RCTRL", data = 305}, -- 右ctrl
	{description="LCTRL", data = 306}, -- 左ctrl
	{description="RALT", data = 307}, -- 右alt
	{description="LALT", data = 308}, -- 左alt
	{description="ALT", data = 400},
	{description="CTRL", data = 401},
	{description="SHIFT", data = 402},
	{description="BACKSPACE", data = 8},
	{description="PERIOD", data = 46},
	{description="SLASH", data = 47},
	{description="LEFTBRACKET", data     = 91},
	{description="BACKSLASH", data     = 92},
	{description="RIGHTBRACKET", data = 93},
	{description="TILDE", data = 96},
	{description="A", data = 97},
	{description="B", data = 98},
	{description="C", data = 99},
	{description="D", data = 100},
	{description="E", data = 101},
	{description="F", data = 102},
	{description="G", data = 103},
	{description="H", data = 104},
	{description="I", data = 105},
	{description="J", data = 106},
	{description="K", data = 107},
	{description="L", data = 108},
	{description="M", data = 109},
	{description="N", data = 110},
	{description="O", data = 111},
	{description="P", data = 112},
	{description="Q", data = 113},
	{description="R", data = 114},
	{description="S", data = 115},
	{description="T", data = 116},
	{description="U", data = 117},
	{description="V", data = 118},
	{description="W", data = 119},
	{description="X", data = 120},
	{description="Y", data = 121},
	{description="Z", data = 122},
	{description="F1", data = 282},
	{description="F2", data = 283},
	{description="F3", data = 284},
	{description="F4", data = 285},
	{description="F5", data = 286},
	{description="F6", data = 287},
	{description="F7", data = 288},
	{description="F8", data = 289},
	{description="F9", data = 290},
	{description="F10", data = 291},
	{description="F11", data = 292},
	{description="F12", data = 293},
	{description="UP", data = 273},
	{description="DOWN", data = 274},
	{description="RIGHT", data = 275},
	{description="LEFT", data = 276},
	{description="PAGEUP", data = 280},
	{description="PAGEDOWN", data = 281},
	{description="0", data = 48},
	{description="1", data = 49},
	{description="2", data = 50},
	{description="3", data = 51},
	{description="4", data = 52},
	{description="5", data = 53},
	{description="6", data = 54},
	{description="7", data = 55},
	{description="8", data = 56},
	{description="9", data = 57},
}


local function AddConfig( name, label, hover, options, default)
    return {name = name, label = label, hover = hover, options = options, default = default}
end
-- local _language = TheNet:GetLanguageCode()
-- if _language == 'english' then
-- end	

local function sdhsjg()
	local xx = {}
	for k = 1, 10 do
		xx[k] = {description = 10*k.."%", data = 10*k}
	end
	return xx
end

configuration_options =
{ 
    -- {name = "testkey",
		-- label = "测试",
		-- options =
		-- {
			-- {description="关闭", data = 0},
			-- {description = "左Ctrl", data = 41},
			-- {description="X", data = 120},
			-- {description="Z", data = 122},

      -- },
	  -- default = 122
	-- },
	
    {name = "huli_language_set",
		label = hl_loc("语言", "language"),
		options =
		{
            {description = hl_loc("自动", "AUTO"), data = 'AUTO'},
            {description = "简体中文", data = 'Chs'},
            {description = "English", data = 'Eng'}
      },
	  default = 'AUTO'
	},
	
    {name = "huli_science_bonus_set",
		label = hl_loc("科技等级", "science"),
		hover = hl_loc("科技等级", "Science and technology level"),
		options =
		{
            {description = hl_loc("0级", "0"), data = 0},
            {description = hl_loc("默认", "Default"), data = 1},
            {description = hl_loc("2级", "2"), data = 2}
		},
	  default = 1
	},
	
    {name = "huli_store_set",
		label = hl_loc("狐狸商店", "Fox store"),
		options =
		{
            {description = hl_loc("开启", "Enable"), data = "开启"},
            {description =hl_loc("关闭", "Disable"), data = "关闭"}
      },
	  default = "开启"
	},
	
    {name = "huli_store_hsjg_set",
		label = hl_loc("商店回收价格", "Store Recycling price"),
		options = sdhsjg(),
		default = 20
	},
			
    {name = "huli_getlevelexp_set",
		label = hl_loc("经验值获得倍率", "Gain experience value multiplication"),
		hover = hl_loc("经验值获得倍率", "Gain experience value multiplication"),
		options =
		{
            {description = hl_loc("默认", "Default"), data = 1},
            {description = "1.5", data = 1.5},
            {description = "2", data = 2},
            {description = "2.5", data = 2.5},
            {description = "3", data = 3},
            {description = "4", data = 4},
            {description = "6", data = 6},
            {description = "8", data = 8},
            {description = "10", data = 10},
            {description = "20", data = 20},
            {description = "50", data = 50},
            {description = "100", data = 100},
		},
	  default = 1
	},
	
    {name = "huli_equiplevelup_set",
		label = hl_loc("装备强化成功倍率", "Success rate of equipment strengthening"),
		hover = hl_loc("装备强化成功倍率", "Success rate of equipment strengthening"),
		options =
		{
            {description = hl_loc("默认", "Default"), data = 1},
            {description = "1.5", data = 1.5},
            {description = "2", data = 2},
            {description = "2.5", data = 2.5},
            {description = "3", data = 3},
            {description = "4", data = 4},
            {description = "6", data = 6},
            {description = "8", data = 8},
            {description = "10", data = 10},
            {description = "20", data = 20},
            {description = "50", data = 50},
            {description = "100", data = 100},
		},
	  default = 1
	},
	
    {name = "huli_gem_droppro_set",
		label = hl_loc("专属宝石掉落倍率", "Exclusive gem drop rate"),
		hover = "",
		options =
		{
            {description = hl_loc("默认", "Default"), data = 1},
            {description = "1.5", data = 1.5},
            {description = "2", data = 2},
            {description = "2.5", data = 2.5},
            {description = "3", data = 3},
            {description = "4", data = 4},
            {description = "5", data = 5},
		},
	  default = 1
	},
	
    {name = "xhl_cl_set",
		label = hl_loc("开关小狐狸制造功能", "Fox manufacturing function"),
		hover = hl_loc("开关小狐狸制造功能", "Turn small fox manufacturing on or off."),
		options = op_on_off,
	  default = 1
	},
	
    {name = "gumifan_set_mine",
		label = hl_loc("开关芭蕉扇挖矿功能", "Turn the GumiFan mining function on or off"),
		hover = hl_loc("开关芭蕉扇挖矿功能", "Turn the GumiFan mining function on or off"),
		options = op_on_off,
	  default = 1
	},
	
	{name = "gumifan_set_chop",
		label = hl_loc("开关芭蕉扇砍树功能", "Turn on or off the GumiFan tree cutting function"),
		hover = hl_loc("开关芭蕉扇砍树功能", "Turn on or off the GumiFan tree cutting function."),
		options = op_on_off,
	  default = 1
	},
	
	{name = "gumifan_set_dig",
		label = hl_loc("开关芭蕉扇铲子功能", "Turn GumiFan shovel function on or off."),
		hover = hl_loc("开关芭蕉扇铲子功能", "Turn GumiFan shovel function on or off."),
		options = op_on_off,
	  default = 0
	},
		
	{name = "huli_ty_set",
		label = hl_loc("开关右键点击物体的跳跃功能", "Turn on or off the right-click object jump function"),
		hover = hl_loc("防止与【更多动作MOD】的右键功能冲突.\n此设置不影响键盘按键跳跃功能.", "Turn on or off the right-click object jump function"),
		options = op_on_off,
	  default = 1
	},
	
	{ name = "Title",label = hl_loc("功能按键请到游戏内设置", "Please set function"), options = {{description = "", data = ""},},default = "",}, 
	{ name = "Title",label = hl_loc("功能按键请到游戏内设置", "keys in the game"), options = {{description = "", data = ""},},default = "",}, 

	--[[{name = "huli_trans_combinationkey_set",
		label = "大狐狸变身组合键设置",
		hover = "Fox Transform key combination setting\n设置组合键后，先《按住》组合键后再按施放键.",
		options = op_comkey,
	  default = 0
	},
		
	{name = "xhl_call_combinationkey_set",
		label = "小狐狸控制组合键设置",
		hover = "Little fox control key combination setting\n设置组合键后，先《按住》组合键后再按施放键.",
		options = op_comkey,
	  default = 0
	},
		
	{name = "huli_jn_combinationkey_set",
		label = "大狐狸技能组合键设置",
		hover = "Fox skill key combination setting\n设置组合键后，先《按住》组合键后再按施放键.",
		options = op_comkey,
	  default = 0
	},
		
	{name = "huli_ty_combinationkey_set",
		label = "大狐狸跳跃组合键设置",
		hover = "Fox Jumping Key Set\n设置组合键后，先《按住》组合键后再按施放键.",
		options = op_comkey,
	  default = 0
	},
	
	AddConfig("huli_transform_set", "设置·大狐狸变身按键", "Fox change key.", allkey, 122),	
	AddConfig("xhl_control_set", "设置·小狐狸控制按键", "Little fox control button\n设置控制小狐狸的按键.", allkey, 120),		
	AddConfig("huli_jn_key_set", "设置·大狐狸技能按键", "fox skill button\n设置《火焰盛焰》《冰域》技能的施放按键.", allkey, 114),		
	AddConfig("huli_ty_key_set", "设置·键盘跳跃按键", "Keyboard jump button\n大狐狸跳跃能力按键设置.", allkey, 103),]]
		
}