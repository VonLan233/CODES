GLOBAL.setmetatable(env,{__index=function(t,k) return GLOBAL.rawget(GLOBAL,k) end}) 

PrefabFiles = {
	"huli", 
	"huli_none", 
	"gumifan", 
	--"skirt", 
	"skirt_x", 
	"foxmask", 
	"foxmask_new", 
	"huliclone", 
	"hulisoul", 
	"huli_gem", 
	"handfan",
	"turfturf",	
	"gumipot",
	"firepit_ghost_fire", 
	"firepit_chill_fire",	
	"firepit_ghost", 
	"firepit_chill", 
	"turf_marble", 
	"turf_jade", 
	"miho",	
	"mihobell",
	"huli_fx",
	"xhl_cl",
	"icefox_fx",
	"huli_dango",
	"xhl_cl_qp",
	"xhl_cl_qp_fx",
	"huli_fangzi",
	"huli_tingzi",
	"huli_rock_power",
	"huli_rechargenpc",
	"huli_wall",
	"mir",
	"miregg",
	"huli_light_test",
}

Assets = {
    Asset( "IMAGE", "images/saveslot_portraits/huli.tex" ),
    Asset( "ATLAS", "images/saveslot_portraits/huli.xml" ),

    Asset( "IMAGE", "images/selectscreen_portraits/huli.tex" ),
    Asset( "ATLAS", "images/selectscreen_portraits/huli.xml" ),
	
    Asset( "IMAGE", "images/selectscreen_portraits/huli_silho.tex" ),
    Asset( "ATLAS", "images/selectscreen_portraits/huli_silho.xml" ),

    Asset( "IMAGE", "bigportraits/huli.tex" ),
    Asset( "ATLAS", "bigportraits/huli.xml" ),
	
	Asset( "IMAGE", "images/map_icons/huli.tex" ),
	Asset( "ATLAS", "images/map_icons/huli.xml" ),
	
	Asset( "IMAGE", "images/avatars/avatar_huli.tex" ),
    Asset( "ATLAS", "images/avatars/avatar_huli.xml" ),
	
	Asset( "IMAGE", "images/avatars/avatar_ghost_huli.tex" ),
    Asset( "ATLAS", "images/avatars/avatar_ghost_huli.xml" ),

	Asset( "IMAGE", "images/avatars/self_inspect_huli.tex" ),
    Asset( "ATLAS", "images/avatars/self_inspect_huli.xml" ),
	
	Asset( "IMAGE", "images/firetab.tex" ),
	Asset( "ATLAS", "images/firetab.xml" ),
	Asset( "IMAGE", "images/firetab_off.tex" ),
	Asset( "ATLAS", "images/firetab_off.xml" ),
	Asset( "IMAGE", "images/icetab.tex" ),
	Asset( "ATLAS", "images/icetab.xml" ),
	Asset( "IMAGE", "images/icetab_off.tex" ),
	Asset( "ATLAS", "images/icetab_off.xml" ),
	Asset( "IMAGE", "images/info_ui.tex" ),
	Asset( "ATLAS", "images/info_ui.xml" ),
	Asset( "IMAGE", "images/huli_button.tex" ),
	Asset( "ATLAS", "images/huli_button.xml" ),
	Asset( "IMAGE", "images/huli_button1.tex" ),
	Asset( "ATLAS", "images/huli_button1.xml" ),
	Asset( "IMAGE", "images/huli_levelup.tex" ),
	Asset( "ATLAS", "images/huli_levelup.xml" ),
	Asset( "IMAGE", "images/huli_callallxhl.tex" ),
	Asset( "ATLAS", "images/huli_callallxhl.xml" ),
	Asset( "IMAGE", "images/sort_button.tex" ),
	Asset( "ATLAS", "images/sort_button.xml" ),

----------------------------------------------------------------------------

	Asset( "ATLAS", "images/inventoryimages/turfturf.xml" ),
	Asset( "IMAGE", "images/inventoryimages/turfturf.tex" ),
	Asset( "ATLAS", "images/inventoryimages/items.xml" ),
	Asset( "IMAGE", "images/inventoryimages/items.tex" ),
	Asset( "ATLAS", "images/inventoryimages/huligem.xml" ),
	Asset( "IMAGE", "images/inventoryimages/huligem.tex" ),
	Asset( "ATLAS", "images/inventoryimages/building.xml" ),
	Asset( "IMAGE", "images/inventoryimages/building.tex" ),
	Asset( "ATLAS", "images/inventoryimages/wall_asia_item.xml" ),
	Asset( "IMAGE", "images/inventoryimages/wall_asia_item.tex" ),
	Asset( "ATLAS", "images/inventoryimages/foxmask_new.xml" ),
	Asset( "IMAGE", "images/inventoryimages/foxmask_new.tex" ),
	Asset( "ATLAS", "images/inventoryimages/huli_rock_power.xml" ),
	Asset( "IMAGE", "images/inventoryimages/huli_rock_power.tex" ),
	Asset( "ANIM", "anim/foxmask_new.zip" ),
	Asset( "ANIM", "anim/huligem_sj.zip" ),
	Asset( "ANIM", "anim/huligem_qh.zip" ),
	Asset( "ANIM", "anim/huligem_jh.zip" ),
	Asset( "ANIM", "anim/huligem_hc.zip" ),
	Asset( "ANIM", "anim/huligem_gjqh.zip" ),
	Asset( "ANIM", "anim/huligem_xy.zip" ),
	Asset( "ANIM", "anim/huligem_bj.zip" ),
	
----------------------------------------------------------------------------
	Asset( "IMAGE", "images/minimapicons/gumifan.tex" ),
	Asset( "ATLAS", "images/minimapicons/gumifan.xml" ),
	Asset( "IMAGE", "images/minimapicons/gumipot.tex" ),
	Asset( "ATLAS", "images/minimapicons/gumipot.xml" ),
	Asset( "IMAGE", "images/minimapicons/huliclone.tex" ),
	Asset( "ATLAS", "images/minimapicons/huliclone.xml" ),
	Asset( "IMAGE", "images/minimapicons/firepit_h.tex" ),
	Asset( "ATLAS", "images/minimapicons/firepit_h.xml" ),
	Asset( "IMAGE", "images/minimapicons/firepit_c.tex" ),
	Asset( "ATLAS", "images/minimapicons/firepit_c.xml" ),
	Asset( "IMAGE", "images/minimapicons/miho.tex" ),
	Asset( "ATLAS", "images/minimapicons/miho.xml" ),
	Asset( "IMAGE", "images/minimapicons/mihobell.tex" ),
	Asset( "ATLAS", "images/minimapicons/mihobell.xml" ),
	Asset( "IMAGE", "images/minimapicons/huli_fangzi.tex" ),
	Asset( "ATLAS", "images/minimapicons/huli_fangzi.xml" ),
	Asset( "IMAGE", "images/minimapicons/huli_tingzi.tex" ),
	Asset( "ATLAS", "images/minimapicons/huli_tingzi.xml" ),
	Asset( "IMAGE", "images/minimapicons/miregg.tex" ),
	Asset( "ATLAS", "images/minimapicons/miregg.xml" ),
	Asset( "IMAGE", "images/minimapicons/mir.tex" ),
	Asset( "ATLAS", "images/minimapicons/mir.xml" ),
------------------------------------------------------------------------------

    Asset( "ANIM", "anim/ui_chest_3x3.zip" ),
    Asset( "ANIM", "anim/huli.zip" ),
	Asset( "ANIM", "anim/huli_fox_ice.zip" ),
	Asset( "ANIM", "anim/huli_fox_white.zip" ),
	Asset( "ANIM", "anim/huli_fox_moon.zip" ),
	Asset( "ANIM", "anim/huli_dango.zip" ),	
	Asset("ANIM", "anim/ui_miho_4x4.zip"),
	Asset("ANIM", "anim/ui_miho_5x5.zip"),
	Asset("ANIM", "anim/huli_fangzi_ui.zip"),
	Asset("ANIM", "anim/ui_gumipot_4x4.zip"),
	Asset("ANIM", "anim/ui_skirtbag_2x8.zip"),
	Asset("ANIM", "anim/ui_hulicl_3x3.zip"),
	Asset( "ANIM", "anim/wharang_fx_ground_fire.zip" ),
	Asset( "ANIM", "anim/wharang_fx_ring.zip" ),

	Asset( "ANIM", "anim/miho.zip" ),
	Asset( "ANIM", "anim/miho_new.zip" ),
	Asset( "IMAGE", "images/tab/yinyangtab.tex"),
	Asset( "ATLAS", "images/tab/yinyangtab.xml"),
	
	Asset( "SOUNDPACKAGE" , "sound/foxpointup.fev" ),
    Asset( "SOUND" , "sound/foxpointup.fsb" ),
	Asset( "SOUNDPACKAGE" , "sound/wharangfan.fev" ),
	Asset( "SOUND" , "sound/wharangfan.fsb" ),
	
	Asset("ATLAS", "images/storehud/huli_storebutton.xml"),
	Asset("IMAGE", "images/storehud/huli_storebutton.tex"),
	Asset("ATLAS", "images/storehud/goodslistimg.xml"),
	Asset("IMAGE", "images/storehud/goodslistimg.tex"),
	Asset("ATLAS", "images/storehud/recharge.xml"),
	Asset("IMAGE", "images/storehud/recharge.tex"),
	Asset("ATLAS", "images/storehud/huli_coinico.xml"),
	Asset("IMAGE", "images/storehud/huli_coinico.tex"),
}

AddMinimapAtlas("images/map_icons/huli.xml")
AddMinimapAtlas("images/minimapicons/huliclone.xml")
AddMinimapAtlas("images/minimapicons/gumifan.xml")
AddMinimapAtlas("images/minimapicons/firepit_h.xml")
AddMinimapAtlas("images/minimapicons/firepit_c.xml")
AddMinimapAtlas("images/minimapicons/mihobell.xml")
AddMinimapAtlas("images/minimapicons/miho.xml")
AddMinimapAtlas("images/minimapicons/gumipot.xml")
AddMinimapAtlas("images/minimapicons/huli_fangzi.xml")
AddMinimapAtlas("images/minimapicons/huli_tingzi.xml")
AddMinimapAtlas("images/minimapicons/miregg.xml")
AddMinimapAtlas("images/minimapicons/mir.xml")

local huli_atlas = {
	huligem = {
		"huligem_sj.tex",
		"huligem_qh.tex",
		"huligem_hc.tex",
		"huligem_gjqh.tex",
		"huligem_jh.tex",
		"huligem_xy.tex",
		"huligem_bj.tex",
	},

	items = {
		"hulisoul.tex",
		"huliclone.tex",
		"xhl_cl.tex",
		"gumifan.tex",
		"handfan.tex",
		"foxmask.tex",
		"skirt.tex",
		"skirt_x.tex",
		"mihobell.tex",
		"huli_dango.tex",
	},

	turfturf = {
		"turf_asia.tex",
		"turf_flamerose.tex",
		"turf_orient.tex",
		"turf_jade.tex",
		"turf_marble.tex" ,
	},
}
for img, v in pairs(huli_atlas) do
	for _, tex in pairs(v) do
		RegisterInventoryItemAtlas("images/inventoryimages/"..img..".xml", tex)
	end
end
RegisterInventoryItemAtlas("images/inventoryimages/foxmask_new.xml", "foxmask_new.tex")
RegisterInventoryItemAtlas("images/inventoryimages/huli_rock_power.xml", "huli_rock_power.tex")
RegisterInventoryItemAtlas("images/inventoryimages/miregg.xml", "miregg.tex")
RegisterInventoryItemAtlas("images/inventoryimages/miregg_cracked.xml", "miregg_cracked.tex")
RegisterInventoryItemAtlas("images/inventoryimages/wall_asia_item.xml", "wall_asia_item.tex")
RegisterInventoryItemAtlas("images/inventoryimages/xhl_cl_qp.xml", "xhl_cl_qp.tex")
RegisterInventoryItemAtlas("images/inventoryimages/xhl_cl_qp_db.xml", "xhl_cl_qp_db.tex")

local require = GLOBAL.require
local STRINGS = GLOBAL.STRINGS
local Recipe = GLOBAL.Recipe
local Ingredient = GLOBAL.Ingredient
local RECIPETABS = GLOBAL.RECIPETABS
local Vector3 = GLOBAL.Vector3
local GROUND = GLOBAL.GROUND
local TUNING = GLOBAL.TUNING
local ACTIONS = GLOBAL.ACTIONS
--ACTIONS.GIVE.priority = 2  --设置优先级
--ACTIONS.ADDFUEL.priority = 4
--ACTIONS.COOK.priority = 3
--ACTIONS.USEITEM.priority = 2
GLOBAL.hl_modinfo = modinfo
GLOBAL.hl_modname = modname

_G.XHL_CL_SET = GetModConfigData("xhl_cl_set")
_G.HULI_STORE_SET = GetModConfigData("huli_store_set")
_G.HULI_SCIENCE_BONUS_SET = GetModConfigData("huli_science_bonus_set")
_G.HULI_GETLEVELEXP_SET = GetModConfigData("huli_getlevelexp_set")
_G.HULI_EQUIPLEVELUP_SET = GetModConfigData("huli_equiplevelup_set")
_G.HULI_GEM_DROPPRO_SET = GetModConfigData("huli_gem_droppro_set")

_G.GUMIFAN_SET_MINE = GetModConfigData("gumifan_set_mine")
_G.GUMIFAN_SET_CHOP = GetModConfigData("gumifan_set_chop")
_G.GUMIFAN_SET_DIG = GetModConfigData("gumifan_set_dig")
_G.HULI_TY_SET = GetModConfigData("huli_ty_set")

--[[
_G.HULI_TRANSFORM_SET = GetModConfigData("huli_transform_set")
_G.XHL_CONTROL_SET = GetModConfigData("xhl_control_set")
_G.HULI_JN_KEY_SET = GetModConfigData("huli_jn_key_set")
_G.HULI_TY_KEY_SET = GetModConfigData("huli_ty_key_set")

_G.HULI_TRANS_COMBINATIONKEY_SET = GetModConfigData("huli_trans_combinationkey_set")
_G.XHL_CALL_COMBINATIONKEY_SET = GetModConfigData("xhl_call_combinationkey_set")
_G.HULI_JN_COMBINATIONKEY_SET = GetModConfigData("huli_jn_combinationkey_set")
_G.HULI_TY_COMBINATIONKEY_SET = GetModConfigData("huli_ty_combinationkey_set")
]]


-- modimport("libs/huli_swimming.lua")
-- modimport("tileadder.lua")
modimport("libs/huli_tuning.lua")
modimport("libs/huli_names.lua")
modimport("libs/huli_tuningitem.lua")
modimport("libs/huli_keyactions.lua")
modimport("libs/huli_storeitem.lua")
modimport("libs/huli_widgets.lua")
modimport("libs/huli_addxxapi.lua")
modimport("libs/huli_Recipe.lua")
modimport("data/actions/huli_actions")
modimport("libs/strings_gumifan.lua")
modimport("libs/strings_gumifan_eng.lua")
modimport("libs/strings_xhl.lua")
modimport("libs/huli_console.lua")
modimport("libs/huli_inventoryimages.lua")
AddMinimap()

--增加人物到mod人物列表的里面 性别为女性（MALE, FEMALE, ROBOT, NEUTRAL, and PLURAL）
AddModCharacter("huli", "FEMALE")

---------------------------------------------------------------------------------------------------------------------------------------

AddReplicableComponent("huli_levelsys")
AddReplicableComponent("xhl_command")

local XHL_FOLLOW = GLOBAL.Action({priority=99, instant=true, ghost_valid=true})

XHL_FOLLOW.id = "XHL_FOLLOW"
-- XHL_FOLLOW.str = "点击开始跟随!"
XHL_FOLLOW.strfn = function(act)
	if act.target ~= nil and act.target.replica.xhl_command ~= nil then
		if act.target.replica.xhl_command:IsCurrentlyStaying() then
			return "FOLLOW" 
		end
	end
	return act.target ~= nil and "STOPFOLLOW"
end

XHL_FOLLOW.fn = function(act)
	local targ = act.target
	local doer = act.doer
	if targ and targ.components.xhl_command then
		if targ.components.xhl_command:IsStaying() then
			targ.components.xhl_command:SetStaying(false, doer)
		else
			targ.components.xhl_command:SetStaying(true, doer)
		end
		return true	
	end 
end
AddAction(XHL_FOLLOW)

AddComponentAction("SCENE", "xhl_command", function(inst, doer, actions, right)
	if inst['所有者net'] then
		local owner = inst['所有者net']:value()
		if right and doer == owner then
			table.insert(actions, GLOBAL.ACTIONS.XHL_FOLLOW)
		end
	end
end)

STRINGS.ACTIONS.XHL_FOLLOW = {
	FOLLOW = hl_loc("右键-开始跟随", 'Right click - start following'),
	STOPFOLLOW = hl_loc("右键-停止跟随", 'Right click - stop following'),
}
GLOBAL.STRINGS.HULICLONE_TALK_PANICFIRE = { "喔喔!", "我烧着了!", "要烧伤了!" }
GLOBAL.STRINGS.HULICLONE_TALK_FIGHT = {"冲啊!冲啊!冲啊!"}

local XHL_DB = GLOBAL.Action({priority = 99})
XHL_DB.id = "XHL_DB"
XHL_DB.str = hl_loc("打包小狐狸", 'Pack Little Fox')
XHL_DB.fn = function(act)
	local target = act.target	
	local invobject = act.invobject
	local doer = act.doer
	if target ~= nil then
		local targetpos = target:GetPosition()
		local package = GLOBAL.SpawnPrefab("xhl_cl_qp_db_build")
		if package and package.components.xhl_qp_db then
			package.components.xhl_qp_db:Pack(target)
			package.Transform:SetPosition( targetpos:Get() )
			invobject:Remove()
			if doer and doer.SoundEmitter then
				doer.SoundEmitter:PlaySound("dontstarve/common/staff_dissassemble")
			end
		end
	end
	return true
end
AddAction(XHL_DB) 

AddComponentAction("USEITEM", "z_huli_xhl_qp" , function(inst, doer, target, actions) 
	if target:HasTag("huliclone") and target.prefab == "huliclone" then
		if target['所有者net'] and target['所有者net']:value() == doer then
			table.insert(actions, GLOBAL.ACTIONS.XHL_DB)
		end
    end
end)
AddStategraphActionHandler("wilson",ActionHandler(ACTIONS.XHL_DB, "dolongaction"))
AddStategraphActionHandler("wilson_client",ActionHandler(ACTIONS.XHL_DB, "dolongaction"))
---------------------------------------------------

-- local function addfn(inst)
	-- if not inst:HasTag('修理模式') then
		-- inst:AddTag('修理模式')
		-- print('1')
	-- else
		-- inst:RemoveTag('修理模式')
		-- print('2')
	-- end
-- end
-- AddModRPCHandler("huli_rpc", 'addfn', addfn)

-- local function givexx(inst)
	-- for i = 1, 5 do
		-- local addt_prod = SpawnPrefab('ice')
		-- inst.components.lootdropper:SpawnLootPrefab('ice', pt)
		-- inst.components.inventory:GiveItem(addt_prod, nil, pt)
	-- end
-- end
-- AddModRPCHandler("huli_rpc", 'givexx', givexx)

-- local function addhuli_key(inst)
	-- if not inst.components.huli_key then
		-- inst:AddComponent("huli_key") 
	-- end 
	-- TheInput:AddKeyDownHandler(KEY_Z, function() SendModRPCToServer(MOD_RPC['huli']['givexx']) end)
-- end
-- AddPlayerPostInit(addhuli_key)

for k, v in pairs(TUNING.ITEM.buildrepairitem) do
	AddPrefabPostInit(v.pref, function(inst)
		if not inst.components.z_huli_tongyong then
			inst:AddComponent("z_huli_tongyong") 
		end 
	end)
end

TUNING.HULIBUILD_NAIJIUDU_TASK = 1
TUNING.HULIBUILD_MINWORK = 5000
TUNING.HULIBUILD_MAXWORK = 99999
TUNING.HULIBUILD_NAIJIUDU_CONSUME = .2

local HULI_BUILD_REPAIR = GLOBAL.Action({priority = 99})
HULI_BUILD_REPAIR.id = "HULI_BUILD_REPAIR"
HULI_BUILD_REPAIR.str = hl_loc("<右键-修理>", 'Right click - Repair')
HULI_BUILD_REPAIR.fn = function(act)
	local target = act.target	
	local invobject = act.invobject
	local doer = act.doer
	if target ~= nil then
		for k, v in pairs(TUNING.ITEM.buildrepairitem) do
			if invobject.prefab == v.pref then
				local wk = target.components.workable
				if wk ~= nil and wk.workleft < target.maxwork - 5 then
					local stkitem = invobject.components.stackable and invobject.components.stackable:StackSize()
					local xvalue = target.maxwork - math.floor(wk.workleft + .5)
					target.AnimState:PlayAnimation("hit")
					
					if xvalue / v.wl - stkitem >= 0 then
						wk.workleft = wk.workleft + v.wl * stkitem
						if wk.workleft >= target.maxwork then
							wk.workleft = target.maxwork
						end
						invobject:Remove()
					else
						local Consumeitem = math.ceil(xvalue / v.wl)
						local item = invobject.components.stackable and  invobject.components.stackable:Get(Consumeitem)
						wk.workleft = wk.workleft + v.wl * Consumeitem
						if wk.workleft >= target.maxwork then
							wk.workleft = target.maxwork
						end
						item:Remove()
					end
				else
					doer.components.talker:Say(hl_loc("已经修好了!", "Already fixed."))
				end
			end
		end
	end
	return true
end
AddAction(HULI_BUILD_REPAIR) 
-- _G.TESTKEY = GetModConfigData("testkey")
AddComponentAction("USEITEM", "z_huli_tongyong" , function(inst, doer, target, actions, right) 
	if right then
		if target:HasTag("huli_build") then
			table.insert(actions, ACTIONS.HULI_BUILD_REPAIR) 
		end
	end
end)
AddStategraphActionHandler("wilson",ActionHandler(ACTIONS.HULI_BUILD_REPAIR, "doshortaction"))
AddStategraphActionHandler("wilson_client",ActionHandler(ACTIONS.HULI_BUILD_REPAIR, "doshortaction"))

TUNING.HULIFANGZI_MINPOWER = 200
TUNING.HULIFANGZI_MAXPOWER = 99999
TUNING.HULIFANGZI_POWER_VAL = 300
TUNING.HULIFANGZI_POWER_TASK = 1
TUNING.HULIFANGZI_POWER_CONSUME = .1

function _G.huli_fangzilight(inst)
	inst.Light:Enable(true)
	inst.Light:SetRadius(6)
	inst.Light:SetFalloff(.65)
	inst.Light:SetIntensity(.85)
	inst.Light:SetColour(246/255, 211/255, 0/255)
	-- inst.AnimState:SetBloomEffectHandle( "shaders/anim.ksh" )
end

local HULI_BUILD_CHONGDIAN = GLOBAL.Action({priority = 99})
HULI_BUILD_CHONGDIAN.id = "HULI_BUILD_CHONGDIAN"
HULI_BUILD_CHONGDIAN.str = hl_loc("<右键-充能!>", "<Right click - Charge>")
HULI_BUILD_CHONGDIAN.fn = function(act)
	local target = act.target	
	local invobject = act.invobject
	local doer = act.doer
	if target ~= nil then
		if invobject.components.z_huli_power then
			if target.nimpower < target.maxpower - 5 then
				local stkitem = invobject.components.stackable and invobject.components.stackable:StackSize()
				local xvalue = target.maxpower - math.floor(target.nimpower + .5)
				target.AnimState:PlayAnimation("hit")
				
				if xvalue / TUNING.HULIFANGZI_POWER_VAL - stkitem >= 0 then
					target.nimpower = target.nimpower + TUNING.HULIFANGZI_POWER_VAL * stkitem
					if target.nimpower >= target.maxpower then
						target.nimpower = target.maxpower
					end
					invobject:Remove()
				else
					local Consumeitem = math.ceil(xvalue / TUNING.HULIFANGZI_POWER_VAL)
					local item = invobject.components.stackable and  invobject.components.stackable:Get(Consumeitem)
					target.nimpower = target.nimpower + TUNING.HULIFANGZI_POWER_VAL * Consumeitem
					if target.nimpower >= target.maxpower then
						target.nimpower = target.maxpower
					end
					item:Remove()
				end				
			else
				doer.components.talker:Say(hl_loc("能源已经充满了!", "Energy is full."))
			end	
			
			target.components.preserver:SetPerishRateMultiplier(.05)
			if target.powertask == nil then
				target.powertask = target:DoPeriodicTask(TUNING.HULIFANGZI_POWER_TASK, function() 
					if target.nimpower > 0 then
						target.nimpower = target.nimpower - TUNING.HULIFANGZI_POWER_CONSUME
						if TheWorld.state.isnight then
							huli_fangzilight(target)
						elseif TheWorld.state.isdusk then
							if target:HasTag('siestahut') then target:RemoveTag('siestahut') end
						else
							target.Light:Enable(false)
							if not target:HasTag('siestahut') then target:AddTag('siestahut') end
						end
						target.is_cooling = true
					elseif target.nimpower <= 0 then
						target.nimpower = 0
						target.is_cooling = false
						target.Light:Enable(false)
						target.components.preserver:SetPerishRateMultiplier(1)
						if target:HasTag('siestahut') then target:RemoveTag('siestahut') end
						if TheWorld.state.isday then
							target.components.sleepingbag:DoWakeUp()
						end
						if target.powertask ~= nil then
							target.powertask:Cancel()
							target.powertask = nil
						end
					end
				end)
			end
		end
	end  
	return true
end
AddAction(HULI_BUILD_CHONGDIAN) 

AddComponentAction("USEITEM", "z_huli_power" , function(inst, doer, target, actions, right) 
	if right then
		if target:HasTag("huli_fangzi") then
			table.insert(actions, ACTIONS.HULI_BUILD_CHONGDIAN) 
		end
	end
end)
AddStategraphActionHandler("wilson",ActionHandler(ACTIONS.HULI_BUILD_CHONGDIAN, "give"))
AddStategraphActionHandler("wilson_client",ActionHandler(ACTIONS.HULI_BUILD_CHONGDIAN, "give"))

TUNING.HULIGUMIPOT_ICE_VAL = 100
TUNING.HULIGUMIPOT_MINICE_TASK = 1
TUNING.HULIGUMIPOT_MINICE_CONSUME = .1

AddPrefabPostInit('ice', function(inst)
	if not inst.components.z_huli_gumipotice then
		inst:AddComponent('z_huli_gumipotice')
	end
end)

local HULI_GUMIPOT_JIABING = GLOBAL.Action({priority = 98})
HULI_GUMIPOT_JIABING.id = "HULI_GUMIPOT_JIABING"
HULI_GUMIPOT_JIABING.str = hl_loc("<右键-添加冰块>", "<Right click - add ice>")
HULI_GUMIPOT_JIABING.fn = function(act)
	local target = act.target	
	local invobject = act.invobject
	local doer = act.doer
	if target ~= nil then
		if invobject.components.z_huli_gumipotice then
			if target.minice ~= nil and target.minice < target.maxwork - 5 then				
				local stkitem = invobject.components.stackable and invobject.components.stackable:StackSize()
				local xvalue = target.maxwork - math.floor(target.minice + .5)
				target.AnimState:PlayAnimation("hit")
				
				if xvalue / TUNING.HULIGUMIPOT_ICE_VAL - stkitem >= 0 then
					target.minice = target.minice + TUNING.HULIGUMIPOT_ICE_VAL * stkitem
					if target.minice >= target.maxwork then
						target.minice = target.maxwork
					end
					invobject:Remove()
				else
					local Consumeitem = math.ceil(xvalue / TUNING.HULIGUMIPOT_ICE_VAL)
					local item = invobject.components.stackable and  invobject.components.stackable:Get(Consumeitem)
					target.minice = target.minice + TUNING.HULIGUMIPOT_ICE_VAL * Consumeitem
					if target.minice >= target.maxwork then
						target.minice = target.maxwork
					end
					item:Remove()
				end	
			else
				doer.components.talker:Say(hl_loc("冰库已经满了!", "The freezer is full."))
			end
		end
		if not target:HasTag("fridge") then target:AddTag("fridge") end
		if target.minicetask == nil then
			target.minicetask = target:DoPeriodicTask(TUNING.HULIGUMIPOT_MINICE_TASK, function() 
				if target.minice > 0 then 
					target.minice = target.minice - TUNING.HULIGUMIPOT_MINICE_CONSUME
				else
					target.minice = 0
					if target:HasTag("fridge") then target:RemoveTag("fridge") end
					if target.minicetask then
						target.minicetask:Cancel()
						target.minicetask = nil
					end
				end
			end)
		end
	end
	return true
end
AddAction(HULI_GUMIPOT_JIABING) 

AddComponentAction("USEITEM", "z_huli_gumipotice" , function(inst, doer, target, actions, right) 
	if right then
		if target:HasTag("huli_gumipot") then
			table.insert(actions, ACTIONS.HULI_GUMIPOT_JIABING) 
		end
	end
end)
AddStategraphActionHandler("wilson",ActionHandler(ACTIONS.HULI_GUMIPOT_JIABING, "give"))
AddStategraphActionHandler("wilson_client",ActionHandler(ACTIONS.HULI_GUMIPOT_JIABING, "give"))

local HULI_GUMIPOT_QUBING = Action({priority=99, 
-- instant=true,
canforce=true,
extra_arrive_dist=function(doer, dest, bufferedaction) return .2 end
})
HULI_GUMIPOT_QUBING.id = "HULI_GUMIPOT_QUBING"
HULI_GUMIPOT_QUBING.str = hl_loc("<右键-取冰块!>", "<Right click - get ice>")
HULI_GUMIPOT_QUBING.fn = function(act)
	local target = act.target
	local invobject = act.invobject
	local doer = act.doer
	
	if target.minice >= 300 then
		for i = 1, 3 do
			target.minice = target.minice - TUNING.HULIGUMIPOT_ICE_VAL
			doer:DoTaskInTime(.2, function()
				local ice = SpawnPrefab('ice')
				doer.components.inventory:GiveItem(ice)
			end)
		end
		target.AnimState:PlayAnimation("hit")
	elseif target.minice > TUNING.HULIGUMIPOT_ICE_VAL and target.minice < 300 then 
		target.minice = target.minice - TUNING.HULIGUMIPOT_ICE_VAL
		doer:DoTaskInTime(.2, function()
			local ice = SpawnPrefab('ice')
			doer.components.inventory:GiveItem(ice)
		end)
		-- doer.sg:GoToState("doshortaction")
		target.AnimState:PlayAnimation("hit")
	else
		doer.components.talker:Say(hl_loc('没有冰块可拿了!', 'There is no ice to take.'))
	end
	if target.minice <= 0 then
		target.minice = 0
		if target:HasTag("fridge") then target:RemoveTag("fridge") end
		if target.minicetask then
			target.minicetask:Cancel()
			target.minicetask = nil
		end
	end
	return true	
end
AddAction(HULI_GUMIPOT_QUBING)

AddComponentAction("SCENE", "z_huli_gumipot", function(inst, doer, actions, right)
	if right then
		table.insert(actions, ACTIONS.HULI_GUMIPOT_QUBING)
	end
end)
AddStategraphActionHandler("wilson",ActionHandler(ACTIONS.HULI_GUMIPOT_QUBING, "doshortaction"))
AddStategraphActionHandler("wilson_client",ActionHandler(ACTIONS.HULI_GUMIPOT_QUBING, "doshortaction"))

local HULI_FANGZI_STORE = Action({priority=98, canforce=true, mount_valid=true, extra_arrive_dist=function(doer, dest, bufferedaction) return .2 end})
HULI_FANGZI_STORE.id = "HULI_FANGZI_STORE"
-- HULI_FANGZI_STORE.str = "<靠近房子>"
HULI_FANGZI_STORE.strfn = function(act)
	if act.target ~= nil and act.target:HasTag('打开') then
		return "CLOSE" 
	end
	return act.target ~= nil and "OPEN"
end
HULI_FANGZI_STORE.fn = function(act) 
	local targ = act.target
	local doer = act.doer
	if targ.components.container ~= nil then
		if targ.components.container:IsOpen() then
			targ.components.container:Close(doer)
			doer:PushEvent("closecontainer", { container = targ })
		else
			doer:PushEvent("opencontainer", { container = targ })
			targ.components.container:Open(doer)
		end
		return true 
	end
end
AddAction(HULI_FANGZI_STORE)

AddComponentAction("SCENE", "z_huli_fangzi", function(inst, doer, actions, right)
	if right then
		table.insert(actions, ACTIONS.HULI_FANGZI_STORE)
	end
end)
AddStategraphActionHandler("wilson",ActionHandler(ACTIONS.HULI_FANGZI_STORE, "doshortaction"))
AddStategraphActionHandler("wilson_client",ActionHandler(ACTIONS.HULI_FANGZI_STORE, "doshortaction"))

STRINGS.ACTIONS.HULI_FANGZI_STORE = {
	OPEN = hl_loc("右键-打开仓库", 'Right click to open the warehouse'),
	CLOSE = hl_loc("右键-关闭仓库", 'Right click - Close Warehouse'),
}

local SKIRT_X = GLOBAL.Action({ priority=99, instant=true, mount_valid=true})
SKIRT_X.id = "SKIRT_X"
SKIRT_X.strfn = function(act)
	local targ = act.target or act.invobject
	local doer = act.doer
	local inv = act.invobject
	if targ ~= nil and targ.replica.container and targ.replica.container:IsOpenedBy(doer) then
		return 'CLOSE'
	end
	return 'OPEN'
end

SKIRT_X.fn = function(act)
	local targ = act.target or act.invobject
	local doer = act.doer
	local inv = act.invobject
	if targ.components.container then
		if targ.components.container:IsOpen() then
			targ.components.container:Close(doer)
			doer:PushEvent("closecontainer", { container = targ })
		else
			targ.components.container:Open(doer)
			doer:PushEvent("opencontainer", { container = targ })
		end
		return true
	end
end
AddAction(SKIRT_X) 

AddComponentAction("INVENTORY", "container" , function(inst, doer, actions, right) 
	if inst.prefab == 'skirt_x' and inst.replica.equippable:IsEquipped() then
		table.insert(actions, ACTIONS.SKIRT_X) 
	end
end)

AddStategraphActionHandler("wilson",ActionHandler(ACTIONS.SKIRT_X, "doshortaction"))
AddStategraphActionHandler("wilson_client",ActionHandler(ACTIONS.SKIRT_X, "doshortaction"))
STRINGS.ACTIONS.SKIRT_X = {
	OPEN = hl_loc("右键-打开", 'Right click - Open'),
	CLOSE = hl_loc("右键-关闭", 'Right click - Close'),
}

local HULI_QH = GLOBAL.Action({ priority=100})
HULI_QH.id = "HULI_QH"
HULI_QH.str = hl_loc("右键-强化", 'Right click - Strengthen')
HULI_QH.fn = function(act)
	local targ = act.target
	local doer = act.doer
	local inv = act.invobject
	if targ.QiangHuaFn ~= nil then
		targ:QiangHuaFn(doer, inv)
	else
		doer.components.talker:Say('出BUG了，快去叫作者修BUG')
	end
	return true
end
AddAction(HULI_QH) 

AddComponentAction("USEITEM", "z_huli_qianghua" , function(inst, doer, target, actions, right) 
	if target:HasTag('huli_level_item') and target._level:value() < target._maxlevel:value() then
		table.insert(actions, ACTIONS.HULI_QH) 
	end
end)
AddStategraphActionHandler("wilson",ActionHandler(ACTIONS.HULI_QH, "doshortaction"))
AddStategraphActionHandler("wilson_client",ActionHandler(ACTIONS.HULI_QH, "doshortaction"))

local HULI_XIULI = GLOBAL.Action({ priority=99})
HULI_XIULI.id = "HULI_XIULI"
HULI_XIULI.str = hl_loc("右键-修理", 'Right click - Repair')
HULI_XIULI.fn = function(act)
	local targ = act.target
	local doer = act.doer
	local inv = act.invobject
	if targ.XiuLiFn ~= nil then
		targ:XiuLiFn(doer, inv)
	else
		doer.components.talker:Say('出BUG了，快去叫作者修BUG')
	end
	return true
end
AddAction(HULI_XIULI) 

AddComponentAction("USEITEM", "z_huli_rp_gumifan" , function(inst, doer, target, actions, right) 
	if target.prefab == 'gumifan' then
		table.insert(actions, ACTIONS.HULI_XIULI) 
	end
end)
AddComponentAction("USEITEM", "z_huli_rp_foxmask" , function(inst, doer, target, actions, right) 
	if target.prefab == 'foxmask' then
		table.insert(actions, ACTIONS.HULI_XIULI) 
	end
end)
AddComponentAction("USEITEM", "z_huli_rp_foxmask_new" , function(inst, doer, target, actions, right) 
	if target.prefab == 'foxmask_new' then
		table.insert(actions, ACTIONS.HULI_XIULI) 
	end
end)
AddComponentAction("USEITEM", "z_huli_rp_skirt" , function(inst, doer, target, actions, right) 
	if target.prefab == 'skirt_x' then
		table.insert(actions, ACTIONS.HULI_XIULI) 
	end
end)
AddStategraphActionHandler("wilson",ActionHandler(ACTIONS.HULI_XIULI, "doshortaction"))
AddStategraphActionHandler("wilson_client",ActionHandler(ACTIONS.HULI_XIULI, "doshortaction"))

local HULI_JINHUA = GLOBAL.Action({ priority=199})
HULI_JINHUA.id = "HULI_JINHUA"
HULI_JINHUA.str = hl_loc("右键-进化", 'Right click - Evolution')
HULI_JINHUA.fn = function(act)
	local targ = act.target
	local doer = act.doer
	local inv = act.invobject
	if targ.JinHuaFn ~= nil then
		targ:JinHuaFn(doer, inv)
	else
		doer.components.talker:Say('出BUG了，快去叫作者修BUG')
	end
	return true
end
AddAction(HULI_JINHUA) 

AddComponentAction("USEITEM", "z_huli_jinhua" , function(inst, doer, target, actions, right) 
	if target.prefab == 'foxmask' then
		table.insert(actions, ACTIONS.HULI_JINHUA) 
	end
end)
AddStategraphActionHandler("wilson",ActionHandler(ACTIONS.HULI_JINHUA, "doshortaction"))
AddStategraphActionHandler("wilson_client",ActionHandler(ACTIONS.HULI_JINHUA, "doshortaction"))

--------------------------------------------------------------------------------
local containers = require "containers"
local params = containers.params
---------------------------狐狸箱-----------------------------
params.miho ={widget = {slotpos = {},
    animbank = "ui_miho_4x4", animbuild = "ui_miho_4x4",
    pos = Vector3(0, 140, 0), side_align_tip = 160, },
    type = "chest",}
for y = 2.45, -.65, -1 do
    for x = .1, 3.2 do
		table.insert(params.miho.widget.slotpos,
		Vector3(70*x-93*2+75, 70*y-75*2+75, 0))
	end 
end
	
params.miho_new ={widget = {slotpos = {},
    animbank = "ui_chest_3x3", animbuild = "ui_miho_5x5",
    pos = Vector3(0, 160, 0), side_align_tip = 160, },
    type = "chest",}
for y = 3, -1.1, -1 do
    for x = -.37, 3.64 do
		table.insert(params.miho_new.widget.slotpos,
		Vector3(70*x-93*2+75, 70*y-75*2+75, 0))
	end 
end
-------------------------罐子-----------------------------
params.gumipot ={ widget = { slotpos = {},
    animbank = "ui_miho_4x4", animbuild = "ui_gumipot_4x4",
    pos = Vector3(0, 140, 0), side_align_tip = 160, },
    type = "chest",}	
for y = 2.5, -.5, -1 do
    for x = 0, 3 do
        table.insert(params.gumipot.widget.slotpos,
		Vector3(72*x-93*2+77, 72*y-75*2+75, 0))
    end
end	
----------------裙子--------------------
params.skirt_x ={ widget = { slotpos = {},
    animbank = "ui_krampusbag_2x8", animbuild = "ui_skirtbag_2x8",
    pos = Vector3(0, -60, 0), },
	issidewidget = true,
    type = "pack",}
for y = .2, 6.2 do
    table.insert(params.skirt_x.widget.slotpos, Vector3(-162, -70 * y + 240, 0))
	table.insert(params.skirt_x.widget.slotpos, Vector3(-162 + 75, -70 * y + 240, 0))
end
-----------------房子----------------------
params.huli_fangzi ={widget = {slotpos = {},
    animbank = "ui_chest_3x3", animbuild = "huli_fangzi_ui",
    pos = Vector3(0, 200, 0), side_align_tip = 160, },
    type = "chest",}
for y = 3.9, -2.15, -1 do
    for x = -5.9, 9.1 do
		table.insert(params.huli_fangzi.widget.slotpos,
		Vector3(70*x-93*2+75, 70*y-75*2+75, 0))
	end 
end

for k, v in pairs(params) do
    containers.MAXITEMSLOTS = math.max(containers.MAXITEMSLOTS, v.widget.slotpos ~= nil and #v.widget.slotpos or 0)
end

function params.skirt_x.itemtestfn(container, item, slot)
	if container.inst._level:value() >= 11 then
		return true
	end
	return false
end

--[[local old_widgetsetup = containers.widgetsetup
function containers.widgetsetup(container, prefab, data)
	local pref = prefab or container.inst.prefab
	if pref == 'huli_fangzi' then 
		local t = params[pref]
		if t ~= nil then 
			for k, v in pairs(t) do 
				container[k] = v 
			end
			container:SetNumSlots(container.widget.slotpos ~= nil and #container.widget.slotpos or 0) 
		end
	else 
		return old_widgetsetup(container, prefab)
	end 
end

function params.miho.itemtestfn(container, item, slot)
	if item.components.edible then
		return true
	end
	return false
end

local oldwidgetsetup = containers.widgetsetup
containers.widgetsetup = function(container, prefab)
	if not prefab and container.inst.prefab == "huli_rechargenpc" then
		prefab = "krampus_sack" 
		prefab = "chester" 
	end
	oldwidgetsetup(container, prefab)
end]]

---------------------------------------------------------------------------------
function _G.get_modinfoname()
	for k,v in pairs(ModManager.mods) do	
		if v.modinfo and v.modinfo.name ~= nil then
			if string.find(v.modinfo.name, "show me") or
			 string.find(v.modinfo.name, "Show me") or
			 string.find(v.modinfo.name, "Show Me") or
			 string.find(v.modinfo.name, "show Me") or
			 string.find(v.modinfo.name, "提示语句") then
				return true
			end
		end
	end
end

--[[local function key_test(inst)  --测试用，链接gumifan函数OnUnequip
	local hands = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS) --手
	local head = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HEAD)	--头
	local body = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.BODY) --身体
	--local currents = inst.components.inventory:Equip(current)
	local equipslot = hands or head or body
	--if inst.components.inventory:FindItem(finditemfn) then
	if inst.components.inventory:EquipHasTag("gumifan") then
	--if inst.components.inventory:EquipHasTag("foxmask") then
		if inst.key_test <= 0 then
			inst.key_test = inst.key_test + 1
			equipslot.components.weapon:SetDamage(10)
			--head.components.waterproofer:SetEffectiveness(.1)
			inst.Light:Enable(true)
			inst.Light:SetRadius(5)
			inst.Light:SetFalloff(.8)
			inst.Light:SetIntensity(.8)
			inst.Light:SetColour(255/255,20/255,20/255)
			print("000")
		else
			equipslot.components.weapon:SetDamage(20)
			--head.components.waterproofer:SetEffectiveness(.3)
			inst.key_test = inst.key_test - 1 
			inst.Light:Enable(false)
			print("111")
		end
	else
		inst.Light:Enable(false)
		print("333")
	end
end
AddModRPCHandler("huli_rpc", "key_test", key_test)]]

--[[【【【【【【【【【【【【【【【【测试用】】】】】】】】】】】】】】】】】】】
local HULI_SHUNYI = GLOBAL.Action({ priority=199, distance=666})
HULI_SHUNYI.id = "HULI_SHUNYI"
HULI_SHUNYI.str = "右键-GHS"
HULI_SHUNYI.fn = function(act)
	local targ = act.target
	local doer = act.doer
	local inv = act.invobject
	
	local pt = act:GetActionPoint()
	local doerpt = doer:GetPosition()
	if pt ~= nil then
		-- doer.Physics:Teleport(pt:Get())
		doer.components.groundpounderds.numRings = 10
		doer.components.groundpounderds.damageRings = 10
		-- doer.components.groundpounderds.groundpoundfx = "largeguard_alterguardian_projectile"
		-- doer.components.groundpounderds.groundpoundfx = "alterguardian_laserscorch"
		-- doer.components.groundpounderds.groundpoundfx = "alterguardian_lasertrail"
		doer.components.groundpounderds.groundpoundfx = "huli_ground_firefx"
		-- doer.components.groundpounderds:GroundPound(1)
		doer.components.groundpounderds:GetPoints5(pt)
		-- print(pt)
	else
		doer.components.talker:Say('出BUG了，快去叫作者修BUG')
	end
	-- doer.sg:GoToState("helmsplitter_pre")
	-- doer.components.talker:Say('修BUG')
	return true
end
AddAction(HULI_SHUNYI) 

AddComponentAction("POINT", "equippable" , function(inst, doer, pos, actions, right) 
-- AddComponentAction("SCENE", "health", function(inst, doer, actions, right)
	if right then
		if inst.prefab == 'gumifan' or inst.prefab == 'axe' then
		-- if inst == doer then
			table.insert(actions, ACTIONS.HULI_SHUNYI) 
		end
	end
end)
AddStategraphActionHandler("wilson",ActionHandler(ACTIONS.HULI_SHUNYI, "attack_prop_pre"))
AddStategraphActionHandler("wilson_client",ActionHandler(ACTIONS.HULI_SHUNYI, "attack_prop_pre"))]]

--[[local playeractionpicker = require "components/playeractionpicker"
function playeractionpicker:GetRightClickActions(position, target)
	if self.disable_right_click then
		return {}
	end

	if self.rightclickoverride ~= nil then
		local actions, usedefault = self.rightclickoverride(self.inst, target, position)
		if not usedefault or (actions ~= nil and #actions > 0) then
			return actions or {}
		end
	end

	local steering_actions = self:GetSteeringActions(self.inst, position, true)
	if steering_actions ~= nil then
		--self.disable_right_click = true
		return steering_actions
	end    

	local actions = nil
	local useitem = self.inst.replica.inventory:GetActiveItem()
	local equipitem = self.inst.replica.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
	local ispassable = self.map:IsPassableAtPoint(position:Get())
	if self.inst.prefab == 'huli' and self.inst.replica.inventory:EquipHasTag("gumifan") then
		ispassable = true
	end

	if target ~= nil and self.containers[target] then
		--check if we have container widget actions
		actions = self:GetSceneActions(target, true)
	elseif useitem ~= nil then
		--if we're specifically using an item, see if we can use it on the target entity
		if useitem:IsValid() then
			if target == self.inst then
				actions = self:GetInventoryActions(useitem, true)
			elseif target ~= nil and (not target:HasTag("walkableplatform") or (useitem:HasTag("repairer") and not useitem:HasTag("deployable"))) then
				actions = self:GetUseItemActions(target, useitem, true)
			else
				actions = self:GetPointActions(position, useitem, true)
			end
		end
	elseif target ~= nil and not target:HasTag("walkableplatform") then
		--if we're clicking on a scene entity, see if we can use our equipped object on it, or just use it
		if equipitem ~= nil and equipitem:IsValid() then
			actions = self:GetEquippedItemActions(target, equipitem, true)

			--strip out all other actions for weapons with right click special attacks
			if equipitem.components.aoetargeting ~= nil then
				return (#actions <= 0 or actions[1].action == ACTIONS.CASTAOE) and actions or {}
			end
		end

		if actions == nil or #actions == 0 then
			actions = self:GetSceneActions(target, true)
		end
	elseif equipitem ~= nil and equipitem:IsValid() and (ispassable or equipitem:HasTag("allow_action_on_impassable") or (equipitem.components.aoetargeting ~= nil and equipitem.components.aoetargeting.alwaysvalid and equipitem.components.aoetargeting:IsEnabled())) then
		actions = self:GetPointActions(position, equipitem, true)
	end

	if (actions == nil or #actions <= 0) and (target == nil or target:HasTag("walkableplatform")) and ispassable then
		actions = self:GetPointSpecialActions(position, useitem, true)
	end

	return actions or {}
end
]]
--【【【【【【【【【【【【【【【【】】】】】】】】】】】】】】】】】】】
--------------------------------------------------------------------------------------------------------------------------------------------------------

TUNING.FOXMASK_NAIJIUDU_TASK = 1
TUNING.FOXMASK_NAIJIUDU_CONSUME = .25
TUNING.FOXMASKNEW_NAIJIUDU_TASK = 1
TUNING.FOXMASKNEW_NAIJIUDU_CONSUME = .2
TUNING.SKIRT_NAIJIUDU_TASK = 1
TUNING.SKIRT_NAIJIUDU_CONSUME = .3

