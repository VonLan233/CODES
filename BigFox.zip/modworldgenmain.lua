-- GLOBAL.require("map/tasks")
-- GLOBAL.require("constants")
-- modimport 'scripts/tile_huli.lua'
require("map/rooms/mir_rooms")
modimport 'tileadder.lua'
AddTiles()

AddTaskPreInit("Forest hunters", function(task)
	task.room_choices["大狐狸的龙蛋"] = 1
end)
	
-- local turfed_huli = legacyBonuses and turfed_legacy or {
	-- insulationWinterMult = 1, insulationWinterAdd = 60,
	-- insulationSummerMult = 1, insulationSummerAdd = 60,
	-- sanityMult = 1, sanityAdd = 0,
	-- moistureMult = 0,
	-- speedMult = nil, speedAdd = nil, speed = nil,
-- }

-- AddTile("ASIA", 60, "asia", 
-- {name = "asia", 
-- noise_texture = "levels/textures/noise_asia.tex", 
-- runsound = "dontstarve/movement/run_carpet", 
-- walksound="dontstarve/movement/walk_carpet", 
-- snowsound="dontstarve/movement/run_snow", 
-- turfed = turfed_huli},
-- {noise_texture = "levels/textures/mini_noise_asia.tex"},
-- true)

-- AddTile("ORIENT", 61, "orient",
-- {name = "orient", 
-- noise_texture = "levels/textures/noise_orient.tex",
-- runsound = "dontstarve/movement/run_carpet",
-- walksound="dontstarve/movement/walk_carpet",
-- snowsound="dontstarve/movement/run_snow",
-- mudsound = "dontstarve/movement/run_mud",
-- turfed = turfed_huli},
-- {noise_texture = "levels/textures/mini_noise_orient.tex"},
-- true)

-- AddTile("FLAMEROSE", 62, "flamerose",
-- {name = "flamerose", 
-- noise_texture = "levels/textures/noise_flamerose.tex",
-- runsound = "dontstarve/movement/run_carpet",
-- walksound="dontstarve/movement/walk_carpet",
-- snowsound="dontstarve/movement/run_snow",
-- mudsound = "dontstarve/movement/run_mud",
-- turfed = turfed_huli},
-- {noise_texture = "levels/textures/mini_noise_flamerose.tex"},
-- true)

-- AddTile("MARBLE", 63, "marble",
-- {name = "marble", 
-- noise_texture = "levels/textures/noise_marble.tex",
-- runsound = "dontstarve/movement/run_carpet",
-- walksound="dontstarve/movement/walk_carpet",
-- snowsound="dontstarve/movement/run_snow",
-- mudsound = "dontstarve/movement/run_mud",
-- turfed = turfed_huli},
-- {noise_texture = "levels/textures/mini_noise_flamerose.tex"},
-- true)

-- AddTile("JADE", 64, "jade",
-- {name = "orient", 
-- noise_texture = "levels/textures/noise_jade.tex",
-- runsound = "dontstarve/movement/run_carpet",
-- walksound="dontstarve/movement/walk_carpet",
-- snowsound="dontstarve/movement/run_snow",
-- mudsound = "dontstarve/movement/run_mud",
-- turfed = turfed_huli},
-- {noise_texture = "levels/textures/mini_noise_jade.tex"},
-- true)

--[[AddTile("JADE", 86, "jade",
{noise_texture = "levels/textures/noise_jade.tex"},
{noise_texture = "levels/textures/mini_noise_jade.tex"},
{runsound = "dontstarve/movement/run_carpet"},
{walksound="dontstarve/movement/walk_carpet"},
{snowsound="dontstarve/movement/run_ice"},
{mudsound = "dontstarve/movement/run_mud"} )]]
