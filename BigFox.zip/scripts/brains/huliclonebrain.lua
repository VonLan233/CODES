require "behaviours/wander"
require "behaviours/faceentity"
require "behaviours/chaseandattack"
require "behaviours/panic"
require "behaviours/follow"
require "behaviours/attackwall"
require "behaviours/standstill"
require "behaviours/chattynode"
require "behaviours/runaway"

local SummonClone = Class(Brain, function(self, inst)
    Brain._ctor(self, inst)
end)

--Images will help chop, mine and fight.

-- local MIN_FOLLOW_DIST = 2
-- local TARGET_FOLLOW_DIST = 4
-- local MAX_FOLLOW_DIST = 4

local START_FACE_DIST = 2
local KEEP_FACE_DIST = 4

local MIN_FOLLOW_CLOSE = 2
local TARGET_FOLLOW_CLOSE = 3
local MAX_FOLLOW_CLOSE = 13

local KEEP_WORKING_DIST = MAX_FOLLOW_CLOSE
local SEE_WORK_DIST = MAX_FOLLOW_CLOSE

local TRADE_DIST = 20

local closeitem = {
	umbrella = true,
	grass_umbrella = true,
	torch = true,
	lantern = true,
	nightstick = true,
}

local function CheckForClosely(inst)
	local handitem = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
	if handitem and closeitem[handitem.prefab] then
		return true
	end
end

local function GetWanderPosition(inst)
	local leader = inst.components.follower and inst.components.follower.leader 
	if leader ~= nil then
		return Point(leader.Transform:GetWorldPosition())
	end
	-- return inst.components.xhl_command.currentstaylocation
end

local function HasStateTags(inst, tags)
    for i, v in ipairs(tags) do
        if inst.sg:HasStateTag(v) then
            return true
        end
    end
end

local function KeepWorkingAction(inst, actiontags)
    return inst.components.follower.leader ~= nil
        and inst.components.follower.leader:IsNear(inst, KEEP_WORKING_DIST)
        and HasStateTags(inst.components.follower.leader, actiontags)
end

local function StartWorkingCondition(inst, actiontags)
    return inst.components.follower.leader ~= nil
        and HasStateTags(inst.components.follower.leader, actiontags)
        and not HasStateTags(inst, actiontags)
end

local function FindObjectToWorkAction(inst, action)
    if inst.sg:HasStateTag("working") then
        return
    end
    local target = FindEntity(inst.components.follower.leader, SEE_WORK_DIST, nil, { action.id.."_workable" }, { "INLIMBO" })
    return target ~= nil
        and BufferedAction(inst, target, action)
        or nil
end

local function GetLeader(inst)
    return inst.components.follower.leader
end

local function StayHere(inst)
	return inst.components.xhl_command:IsCurrentlyStaying() 
		or not GetLeader(inst)
end

local function GetFaceTargetFn(inst)
    -- local target = FindClosestPlayerToInst(inst, START_FACE_DIST, true)
    local target = inst.components.follower.leader
    return target
end

local function KeepFaceTargetFn(inst, target)
    -- return inst:IsNear(target, KEEP_FACE_DIST)
	return inst.components.follower.leader == target
end

local function GetTraderFn(inst)
    local x, y, z = inst.Transform:GetWorldPosition()
    local players = FindPlayersInRange(x, y, z, TRADE_DIST, true)
    for i, v in ipairs(players) do
        if inst.components.trader and inst.components.trader:IsTryingToTradeWithMe(v) then
            return v
        end
    end
end

local function KeepTraderFn(inst, target)
    return inst.components.trader and inst.components.trader:IsTryingToTradeWithMe(target)
end

function SummonClone:OnStart()
    local root = PriorityNode(
    {
		StandStill(self.inst, StayHere, StayHere),
		--RunAway(self.inst, "hiding", 3, 6),
		WhileNode( function() return self.inst.components.health:GetPercent() < .8 and self.inst.components.combat.target and self.inst.components.combat:InCooldown() end, "Dodge", RunAway(self.inst, function() return self.inst.components.combat.target end, 4, 5)),
		
		WhileNode( function() return self.inst.components.combat.target == nil or not self.inst.components.combat:InCooldown() end,
			"AttackMomentarily",
			ChaseAndAttack(self.inst, 3, 20)
		),
		
        -- ChaseAndAttack(self.inst, 3),  --追击行为
        WhileNode(function()
                return StartWorkingCondition(self.inst, { "chopping", "prechop" })
                    and KeepWorkingAction(self.inst, { "chopping", "prechop" })
            end,
            "keep chopping",
            DoAction(self.inst, function() return FindObjectToWorkAction(self.inst, ACTIONS.CHOP) end)),

        WhileNode(function()
                return StartWorkingCondition(self.inst, { "mining", "premine" })
                    and KeepWorkingAction(self.inst, { "mining", "premine" })
            end,
            "keep mining",
            DoAction(self.inst, function() return FindObjectToWorkAction(self.inst, ACTIONS.MINE) end)),
			
		ChattyNode(self.inst, "PIG_TALK_ATTEMPT_TRADE",
            FaceEntity(self.inst, GetTraderFn, KeepTraderFn)),
		-- IfNode(function() return CheckForClosely(self.inst) end, "Follow Closely",
			-- Follow(self.inst, GetLeader, MIN_FOLLOW_CLOSE, TARGET_FOLLOW_CLOSE, MAX_FOLLOW_CLOSE, true)),
		IfNode(function() return not StayHere(self.inst) end, 
			"Follow leader",
			Follow(self.inst, GetLeader, MIN_FOLLOW_CLOSE, TARGET_FOLLOW_CLOSE, MAX_FOLLOW_CLOSE)
		),
		WhileNode(function() return self.inst.components.follower.leader ~= nil and self.inst:IsNear(self.inst.components.follower.leader, KEEP_FACE_DIST) end,
			"Face leader",
			FaceEntity(self.inst, GetFaceTargetFn, KeepFaceTargetFn )
		),
        WhileNode(function() return not StayHere(self.inst) end, 
			"Wander leader",
			Wander(self.inst, GetWanderPosition, MAX_FOLLOW_CLOSE, {
                    minwalktime = .5,
                    randwalktime = .8,
                    minwaittime = 2,
                    randwaittime = 5
                }
			)
		),
		-- IfNode(function() return not CheckForClosely(self.inst) end, "Follow from Distance",
			-- Follow(self.inst, GetLeader, MIN_FOLLOW, TARGET_FOLLOW, MAX_FOLLOW, true)),
    }, .25)

    self.bt = BT(self.inst, root)
end

function SummonClone:OnStop()
end

return SummonClone

