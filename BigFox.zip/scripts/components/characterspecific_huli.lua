local CharacterSpecific_HuLi = Class(function(self, inst)
    self.inst = inst

    self.character = nil
    self.storable = false
    self.comment = "这是狐狸的."
end)

function CharacterSpecific_HuLi:CanPickUp(doer)
	if doer and doer.prefab ~= self.character then
		return false
	end
		return true
end

function CharacterSpecific_HuLi:SetOwner(name)
    self.character = name
end

function CharacterSpecific_HuLi:IsStorable()
	return self.storable
end

function CharacterSpecific_HuLi:SetStorable(value)
	self.storable = value
end

function CharacterSpecific_HuLi:GetComment()
	return self.comment
end

function CharacterSpecific_HuLi:SetComment(comment)
	self.comment = comment
end

return CharacterSpecific_HuLi