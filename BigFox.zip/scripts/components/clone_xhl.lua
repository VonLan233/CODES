local Clone_Xhl = Class(function(self, inst)
	self.inst = inst
	self.time_to_convo = 8
	inst:StartUpdatingComponent(self)
	
	inst:ListenForEvent("oneatsomething", function(inst, data) 
		if inst._player == nil then return end
		if data.food and data.food.components.edible then
			if data.food.components.perishable and not data.food.components.perishable:IsFresh() then
				if data.food.components.perishable:IsStale() then
					inst.components.talker:Say("真下流!")
				elseif data.food.components.perishable:IsSpoiled() then
					inst.components.talker:Say("真讨厌!") end
			end
		end
	end)
	
	inst:WatchWorldState("startdusk", function()
		if inst._player == nil then return end
		if math.random() < 0.33 then
			inst.components.talker:Say("太阳要下山了!")
		elseif math.random() < 0.33 then
			inst.components.talker:Say("该回家了!")
		elseif math.random() < 0.33 then
			inst.components.talker:Say("该回家煮饭饭了!")
		end
	end)

	inst:ListenForEvent("torchranout", function(inst, data)
	inst.components.talker:Say("火把火把!")	end)
	
	local dt = 3
	--[[self.inst:DoPeriodicTask(dt,function()
	--local x, y, z = self.inst.Transform:GetWorldPosition()
	--local master = TheSim:FindEntities(x,y,z,5, {"huli"}, nil, nil)
	local owner = self.inst.components.follower.leader
	if owner ~= nil then
	local distsq = self.inst:GetDistanceSqToInst(owner)
		if distsq <= 64 then
				self:OnUp(dt)			
				--self.inst:DoPeriodicTask(dt, function() self:OnUp(dt) end)
				--self.inst:DoPeriodicTask(dt, function() self:OnUps(dt) end)
			else
				self:OnUps(dt)
		end
	end
	end)]]
	
	self.inst:DoPeriodicTask(dt, function() 
		if self.inst._player == nil then return end 
		self:OnUp(dt) 
	end)
end)

function Clone_Xhl:InCooldown()
	if self.lastcommenttime then
		local time_since_comment = GetTime() - self.lastcommenttime
		if time_since_comment < 30 then
			return true	end
	end
	return false
end

function Clone_Xhl:OnUpdate()
	if not self:InCooldown() then
		local currenthealth = self.inst.components.health.currenthealth / self.inst.components.health.maxhealth	
		if currenthealth < 0.5 then
			if currenthealth < 0.1 then
				self.inst.components.talker:Say("要完了要完了!") 
			else
				self.inst.components.talker:Say("妈妈!我受伤了,救救!") 
			end
				self.lastcommenttime = GetTime()
				self.inst.AnimState:PlayAnimation("hungry")	
		end
	end
end

function Clone_Xhl:OnUp(dt)
    self.time_to_convo = self.time_to_convo - dt
    if self.time_to_convo <= 0 then
        self:MakeConversation() 
	end
end

function Clone_Xhl:OnUps(dt)
    self.time_to_convo = self.time_to_convo - dt
    if self.time_to_convo <= 0 then
        self:MakeConversations() end
end

function Clone_Xhl:IsStaying()
	-- return self.inst.replica.xhl_command:IsCurrentlyStaying()
	return self.inst.components.xhl_command:IsStaying()
end

function Clone_Xhl:Say(list)
    self.inst.components.talker:Say(list[math.random(#list)])
	if self.inst.tak == "xhl_attack" then
		self.time_to_convo = math.random(8, 20)
	elseif self.inst.tak == "xhl_talk" 
		or self.inst.tak == "xhl_staying" 
		or self.inst.tak == "xhl_leader_dead" then
		self.time_to_convo = math.random(30, 60)
	end
end

--[[function Clone_Xhl:Says(list)
    self.inst.components.talker:Say(list[math.random(#list)])
	if self.inst.tak == "xhl_attack" then
	self.time_to_convo = math.random(3, 4) 
	end
end]]

function Clone_Xhl:MakeConversation()
    local other = self.inst.components.combat.target
	local hastarget = self.inst.components.combat:HasTarget()
	local owner = self.inst._player or self.inst.components.follower:GetLeader()

	if owner ~= nil then 
		local distsq = self.inst:GetDistanceSqToInst(owner)
		if not owner:HasTag("playerghost") then
		--print("111")
			if not owner.components.health:IsDead() then
			--print("222")
				if not self:IsStaying() and distsq < 2048 then
					if hastarget then
						self.inst.tak = "xhl_attack"
						if not other:HasTag("wall") and not other:HasTag("structure") and not other:HasTag("hulibuilder") then
							self:Say(STRINGS.XHL.attack)
						elseif other:HasTag("structure") and not other:HasTag("hulibuilder") then
						self:Say(STRINGS.XHL.attack_build) 
						end
					elseif not hastarget then
						self.inst.tak = "xhl_talk"
						if self.inst.sg:HasStateTag("xhlsleep") then
							self:Say(STRINGS.XHL.night) 
						elseif self.inst.sg:HasStateTag("xhlcold") then
							self:Say(STRINGS.XHL.cold) 
						else
							self:Say(STRINGS.XHL.talk)
						end
					end
				elseif self:IsStaying() and distsq >= 2048 then
						self.inst.tak = "xhl_staying"
						self:Say({
						"B站UP主“爱喝假酒的FA”\n有本萌的视频解说哦",
						"妈妈什么时候回来呢!", 
						"把我一个人扔这里不带我去玩,真讨厌",
						"好看的皮囊千篇一律,有趣的灵魂两百多斤!",
						"不能动,会不会跳出只怪兽把我吃了",
						"淡定淡定",
						"好无聊啊",
						"你看不到我.看不到了......",
						})
				elseif self:IsStaying() and distsq < 2048 then
					self.inst.tak = "xhl_talk"
					if self.inst.sg:HasStateTag("xhlsleep") then
						self:Say(STRINGS.XHL.night) 
					elseif self.inst.sg:HasStateTag("xhlcold") then
						self:Say(STRINGS.XHL.cold) 
					else
						self:Say(STRINGS.XHL.talk)
					end
				end
			else
			--print("444")
					self:Say({
					"6啊,居然挂了!",
					})
			end
		elseif owner:HasTag("playerghost") then
				--print("333")
				self.inst.tak = "xhl_leader_dead"
				self:Say({
				"真菜,这都能挂……", 
				"以后叫妳麻麻鬼,嘻嘻", 
				"做鬼好玩嘛,宝宝也想玩……",
				"作崇试金石或者让队友给个\n救赎之心就可以复活哦",
				"有孟婆汤喝么",
				"能看到其它鬼么",
				"好无聊啊",
				})
		end
	end
end

--[[function Clone_Xhl:MakeConversations()
	if self:IsStaying() then
		self.inst.tak = "xhl_staying"
		self:Say({
		"本MOD全球首发群：83430383!", 
		"妈妈什么时候回来呢!", 
		"把我一个人扔这里不带我去玩,麻麻真讨厌",
		"好看的皮囊千篇一律,有趣的灵魂两百多斤!",
		"不能动,会不会跳出只怪兽把我吃了",
		"淡定淡定",
		"好无聊啊",
		})
	end
end]]

return Clone_Xhl