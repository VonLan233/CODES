local GroundPounderDS = Class(function (self, inst)
    self.inst = inst
    self.numRings = 1
    self.damageRings = 1
    self.bonusdamage = 0
    self.ewai_multiplier = 1
    self.damagerange = 3
    self.radiusStepDistance = 2
    self.ringDelay = .1
    self.initialRadius = 1
    self.pointDensity = .25
    self.destructionRings = 2
    self.noTags = {"FX", "NOCLICK", "DECOR", "INLIMBO", "wall", "companion"}
    self.destroyer = false
    self.burner = false
    self.groundpoundfx = "groundpound_fx"
    self.groundpoundringfx = "groundpoundring_fx"
end)

function GroundPounderDS:GetPoints(pt)
    local points = {}
    local radius = self.initialRadius

    for i = 1, self.numRings do
        local theta = 0
        local circ = 2 * math.pi * radius
        local numPoints = circ * self.pointDensity

        for p = 1, numPoints do
            if not points[i] then
                points[i] = {}
            end

            local offset = Vector3(radius * math.cos(theta), 0, -radius * math.sin(theta))
            local point = pt + offset
            table.insert(points[i], point)
            theta = theta - (2 * math.pi / numPoints)
        end

        radius = radius + self.radiusStepDistance
    end
    return points
end

function GroundPounderDS:DestroyPoints(points, breakobjects, dodamage)
    --local weapon = self.inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
    --local sdamage = self.inst.components.combat:Damage(weapon, 1) 
    --local sdamage = weapon.components.weapon.damage
    local getEnts = breakobjects or dodamage

    for k, v in pairs(points) do
        local ents = nil
        if getEnts then
            ents = TheSim:FindEntities(v.x, v.y, v.z, self.damagerange, nil, self.noTags)
        end
        if ents and breakobjects then
            for k2, v2 in pairs(ents) do
                -- Don't net any insects when we do work
                if v2 and self.destroyer and v2.components.workable and v2.components.workable.workleft > 0 and v2.components.workable.action ~= ACTIONS.NET then
                    v2.components.workable:Destroy(self.inst)
                end
                if v2 and self.burner and v2.components.burnable and not v2:HasTag("fire") and not v2:HasTag("burnt") then
                    v2.components.burnable:Ignite()
                end
            end
        end
        if ents and dodamage then
            for k2, v2 in pairs(ents) do
                if v2 and v2.components.health and not v2.components.health:IsDead() and self.inst.components.combat:CanTarget(v2) then
                    --local weapon = self.inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
                    local weapon = self.inst.components.combat:GetWeapon()
                    local df_damage = self.inst.components.combat.defaultdamage / 2
                    local damagemult = self.inst.components.combat.damagemultiplier or 1
                    if weapon ~= nil then
                        df_damage = weapon.components.weapon.damage / 2
                    end

                    v2.components.combat:GetAttacked(self.inst, self.bonusdamage + (self.ewai_multiplier * damagemult * df_damage))
                    --self.inst.components.combat:DoAttack(v2, nil, nil, nil, self.groundpounddamagemult)
                end
            end
        end

        if not (TheWorld.Map and TheWorld.Map:GetTileAtPoint(v.x, v.y, v.z) == GROUND.IMPASSABLE) then
            SpawnPrefab(self.groundpoundfx).Transform:SetPosition(v.x, 0, v.z)
        end
    end
end

function GroundPounderDS:GroundPoundTest(pt)
    local pt = pt or self.inst:GetPosition()

    SpawnPrefab(self.groundpoundringfx).Transform:SetPosition(pt:Get())
    local points = self:GetPoints(pt)

    local delay = 0

    for i = 1, self.numRings do
        self.inst:DoTaskInTime(delay, function ()
            self:DestroyPoints(points[i], i <= self.destructionRings, i <= self.damageRings)
        end)
        delay = delay + self.ringDelay
    end
end

function GroundPounderDS:GroundPound(num, nextDelay, pt)
    local delay = 0.2
    local num = num or 1
    local nextDelay = nextDelay or .4
    if num > 1 then
        for i = 1, num do
            self.inst:DoTaskInTime(delay, function ()
                self:GroundPoundTest(pt)
            end)
            delay = delay + nextDelay
        end
    else
        self.inst:DoTaskInTime(delay, function ()
            self:GroundPoundTest(pt)
        end)
    end
end
return GroundPounderDS
