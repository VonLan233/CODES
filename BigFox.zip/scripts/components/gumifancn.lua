local GumiFanCn = Class(function(self, inst)
    self.inst = inst
    self.time_to_convo = 10
    self.inst:ListenForEvent("equipped", function(_, data) self:OnEquipped(data.owner) end)
	self.inst:ListenForEvent("ondropped", function() self:OnDropped() end)
	--self.inst:ListenForEvent("finishedwork", function(_, data) self:OnFinishedWork(data.target) end, GetPlayer())
    local dt = 5
    self.inst:DoPeriodicTask(dt, function() self:OnUpdate(dt) end)
    self.warnlevel = 0
end)

function GumiFanCn:OnEquipped()
	if self.inst.components.finiteuses:GetPercent() <= 0 then
		return
	end
	local owner = self.inst.components.inventoryitem.owner
	if owner and owner:HasTag("huli") then
		self:Say(hl_loc(STRINGS.GUMIFAN.on_pickedup, STRINGS.GUMIFAN_ENG.on_pickedup)) 
	end
end

function GumiFanCn:OnDropped()
	if self.inst.components.finiteuses:GetPercent() <= 0 then
		return
	end
	self:Say(hl_loc(STRINGS.GUMIFAN.on_dropped, STRINGS.GUMIFAN_ENG.on_dropped))
end

function GumiFanCn:Say(list, sound_override)
    self.sound_override = sound_override
    self.inst.components.talker:Say(list[math.random(#list)])
    self.time_to_convo = math.random(60, 100)
end

function GumiFanCn:OnUpdate(dt)
    self.time_to_convo = self.time_to_convo - dt
    if self.time_to_convo <= 0 then
		hl_loc(self.MakeConversation, self.MakeConversation_eng)(self)
    end
end

function GumiFanCn:MakeConversation()
	if self.inst.components.finiteuses:GetPercent() <= 0 then
		return
	end
    --local grand_owner = self.inst.components.inventoryitem:GetGrandOwner()
    local owner = self.inst.components.inventoryitem.owner
    local quiplist = nil
    if owner and owner:HasTag("huli") and self.inst.components.equippable:IsEquipped() then
		quiplist = STRINGS.GUMIFAN.equipped
	elseif owner and not owner:HasTag("huli") and self.inst.components.equippable:IsEquipped() then
		quiplist = STRINGS.GUMIFAN.other_owner
	elseif owner == nil then
		quiplist = STRINGS.GUMIFAN.on_alone
	end
    if quiplist then
        self:Say(quiplist)
    end
end

function GumiFanCn:MakeConversation_eng()
	if self.inst.components.finiteuses:GetPercent() <= 0 then
		return
	end
    --local grand_owner = self.inst.components.inventoryitem:GetGrandOwner()
    local owner = self.inst.components.inventoryitem.owner
    local quiplist = nil
    if owner and owner:HasTag("huli") and self.inst.components.equippable:IsEquipped() then
		quiplist = STRINGS.GUMIFAN_ENG.equipped
	elseif owner and not owner:HasTag("huli") and self.inst.components.equippable:IsEquipped() then
		quiplist = STRINGS.GUMIFAN_ENG.other_owner
	end
    if quiplist then
        self:Say(quiplist)
    end
end

return GumiFanCn