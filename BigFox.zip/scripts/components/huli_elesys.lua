
local function c_fire(self, val)
	if self.inst['当前火元素net'] then
		self.inst['当前火元素net']:set(val)
	end
end

local function m_fire(self, val)
	if self.inst['最大火元素net'] then
		self.inst['最大火元素net']:set(val)
	end
end

local function c_ice(self, val)
	if self.inst['当前冰元素net'] then
		self.inst['当前冰元素net']:set(val)
	end
end

local function m_ice(self, val)
	if self.inst['最大冰元素net'] then
		self.inst['最大冰元素net']:set(val)
	end
end

local EleSys = Class(function(self, inst)
	self.inst = inst
	self['当前火元素'] = 0
	self['最大火元素'] = 100

	self['当前冰元素'] = 0
	self['最大冰元素'] = 100
	
	inst:ListenForEvent( "大狐狸形态", function() self:AutoRegen(3) end)
	inst:ListenForEvent( "等级变更事件", function() self:AutoRegen(3) end)

end,
nil,
{
	['当前火元素'] = c_fire,
	['最大火元素'] = m_fire,
	
	['当前冰元素'] = c_ice,
	['最大冰元素'] = m_ice,
})

function EleSys:FireDoDelta(val) --火
	if not val then return end
	local old = self['当前火元素']

	self['当前火元素'] = self['当前火元素'] + (val)
	
	if self['当前火元素'] >= self['最大火元素'] then
		self['当前火元素'] = self['最大火元素']
	end
	
	if self['当前火元素'] <= 0 then
		self['当前火元素'] = 0
	end
	
	if old >= self['最大火元素'] then return end
	
	if self['火元素变更fn'] ~= nil then
		self['火元素变更fn'](self.inst, self['当前火元素'], self['最大火元素'])
	end
	self.inst:PushEvent('火元素变更事件')
end

function EleSys:IceDoDelta(val) --冰
	if not val then return end
	local old = self['当前冰元素']
	
	self['当前冰元素'] = self['当前冰元素'] + (val)
	
	if self['当前冰元素'] >= self['最大冰元素'] then
		self['当前冰元素'] = self['最大冰元素']
	end
	
	if self['当前冰元素'] <= 0 then
		self['当前冰元素'] = 0
	end
	
	if old >= self['最大冰元素'] then return end
	
	if self['冰元素变更fn'] ~= nil then
		self['冰元素变更fn'](self.inst, self['当前冰元素'], self['最大冰元素'])
	end
	self.inst:PushEvent('冰元素变更事件')
end

function EleSys:AutoRegen(dt) 
	self:StopRegen()
	self['自动回复'] = self.inst:DoPeriodicTask(dt, function()
		if self.inst['形态'] == '红狐狸' then
			self:FireDoDelta(self:RedElementMo())
		elseif self.inst['形态'] == '冰狐狸' then
			self:IceDoDelta(self:IceElementMo())
		else
			self:StopRegen()
		end
	end, 0.25)
end

function EleSys:StartRegen(val, dt) --
	self:StopRegen('周期')
	self['周期'] = self.inst:DoPeriodicTask(dt or 0.5, function()
		if self.inst['形态'] == '红狐狸' then
			self:FireDoDelta(val)
		elseif self.inst['形态'] == '冰狐狸' then
			self:IceDoDelta(val)
		else
			self:StopRegen('周期')
		end
	end, 0.25)
end

function EleSys:StopRegen(key)
	if not key then
		key = '自动回复'
	end
	if self[key] then
		self[key]:Cancel()
		self[key] = nil
	end
end

local ele_offset = 15
function EleSys:RedElementMo()
	local st = TheWorld.state.temperature
	local lvsys = self.inst.components.huli_levelsys
	local fire_ele = 0
	if st >= 20 then
		fire_ele = 1 + (lvsys:Get('当前等级') / ele_offset + (st - 20) / 20)
	elseif st < 20 then
		fire_ele = 1 + (lvsys:Get('当前等级') / ele_offset - (20 - st) / 30)
	end
	return fire_ele
end

function EleSys:IceElementMo()
	local st = TheWorld.state.temperature
	local lvsys = self.inst.components.huli_levelsys
	local ice_ele = 0
	if st >= 20 then
		ice_ele = 1 + (lvsys:Get('当前等级') / ele_offset - (st - 20) / 40)
	elseif st < 20 then
		ice_ele = 1 + (lvsys:Get('当前等级') / ele_offset + (20 - st) / 12)
	end
	return ice_ele
end

function EleSys:Set(type, val)
	self[type] = val
end

function EleSys:SetAllMax(val)
	self['最大火元素'] = val
	self['最大冰元素'] = val
end

function EleSys:Get(info)
	return self[info]	
end

function EleSys:OnSave()
    local data =
    {
		['当前火元素'] = self['当前火元素'],
		['最大火元素'] = self['最大火元素'],
		
		['当前冰元素'] = self['当前冰元素'],
		['最大冰元素'] = self['最大冰元素'],
    }

    return data
end

function EleSys:OnLoad(data)
    if data then
        self['当前火元素'] = data['当前火元素']
		self['最大火元素'] = data['最大火元素']

        self['当前冰元素'] = data['当前冰元素']
        self['最大冰元素'] = data['最大冰元素']

    end
	if self['加载火元素fn'] then
		self['加载火元素fn'](self.inst, self['当前火元素'], self['最大火元素'])
	end
	if self['加载冰元素fn'] then
		self['加载冰元素fn'](self.inst, self['当前冰元素'], self['最大冰元素'])
	end
end

return EleSys
