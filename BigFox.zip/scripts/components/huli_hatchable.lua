local Hhh = Class(function(self, inst)
    self.inst = inst
    self["孵化阶段"] = 0
    self["孵化时间"] = TUNING.TOTAL_DAY_TIME * 10
	self.dt = 1
	
	inst:ListenForEvent( "onputininventory", function(inst, oo) self:StartUpdating(oo) end)
	inst:ListenForEvent( "ondropped", function() self:StopUpdating() self["破壳"](self) end)
	inst:ListenForEvent( "孵化进入二阶段", function() self:OnState() end)
	self:ShowInfo()
end)

function Hhh:OnState()
	if self.invowner and self.invowner.components.inventory then
		self.inst:Remove()
		self.invowner.components.inventory:GiveItem(SpawnPrefab("miregg_cracked"))
	end
end

function Hhh:Delay(time)
    self.inst:DoTaskInTime(time, function() self.delay = false end)
end

local function TimeFormat(second)
	local t = {}
	t['天'] = math.floor(second/86400)
	t['时'] = math.fmod(math.floor(second/3600), 24)
	t['分'] = math.fmod(math.floor(second/60), 60)
	t['秒'] = math.fmod(second, 60)

    return string.format("%02d", t['秒']), 
		string.format("%02d", t['分']), 
		string.format("%02d", t['时']), 
		string.format("%02d", t['天'])
end

function Hhh:ShowInfo()
	if self.inst._label then
		if self["孵化阶段"] == 0 then
			self.inst._label:set(hl_loc("未开始孵化", "Not hatched"))
		elseif self["孵化阶段"] == 1 or self["孵化阶段"] == 2 then
			local ss, mm, hh = TimeFormat(self["孵化时间"])
			local time = 0
			if self["孵化时间"] < 60 then
				time = ss
			elseif self["孵化时间"] > 60 and self["孵化时间"] < 3600 then
				time = mm..':'..ss
			elseif self["孵化时间"] >= 3600 then
				time = hh..':'..mm..':'..ss
			end
			self.inst._label:set(hl_loc("孵化阶段：", "Incubation stage：")..self["孵化阶段"]..hl_loc("\n孵化时间：", "\nIncubation time：")..time)
		elseif self["孵化阶段"] == 3 then
			self.inst._label:set(hl_loc("扔出以完成孵化", "Throw out to complete incubation"))
		end
	end
end

Hhh["破壳"] = function(self)
	if self["孵化阶段"] ~= 3 then return end
	if self.invowner then
		if self.invowner.components.huli_petleash_mir then
			local x, y, z = self.invowner.Transform:GetWorldPosition()
			local mir = self.invowner.components.huli_petleash_mir:SpawnPetAt(x, y, z, "mir")
			if mir then
				mir.sg:GoToState("hatch")
				local fx = SpawnPrefab("collapse_small")
				fx.Transform:SetPosition(mir.Transform:GetWorldPosition())
				self.inst:Remove()
			end
		end
	end
end

function Hhh:CanHatchOwner()
    return self.invowner and self.invowner.prefab == "huli"
end

function Hhh:StopUpdating()
    if self.task then
        self.task:Cancel()
        self.task = nil
    end
end

function Hhh:StartUpdating(owner)
	print('持有者：', owner.prefab)
	self.invowner = owner
	if owner.prefab == "huli" then
		owner.huli_miregg = self.inst
	end
	if not self:CanHatchOwner() then 
		self:StopUpdating()
		return 
	end
	if self["孵化阶段"] == 0 then
		self["孵化阶段"] = 1
	end
    if not self.task then
        self.task = self.inst:DoPeriodicTask(self.dt, function() self:OnUpdate(self.dt) end, 0)
    end
end

-- local FIRE_MUST_TAGS = { "HASHEATER" }
-- local FIRE_MUST_NOT_TAGS = { "INLIMBO" }
function Hhh:OnUpdate(dt)	
    -- local x, y, z = self.inst.Transform:GetWorldPosition()
    -- local ents = TheSim:FindEntities(x, y, z, TUNING.HATCH_CAMPFIRE_RADIUS, FIRE_MUST_TAGS, FIRE_MUST_NOT_TAGS)
    -- local heatindex = 0
    -- for _, ent in ipairs(ents) do
        -- if ent.components.heater ~= nil and (ent.components.heater:IsExothermic() or ent.components.heater:IsEndothermic()) then 
            -- heatindex = heatindex + (ent.components.heater:GetHeat(self.inst) or 0) 
        -- end
    -- end
	self["孵化时间"] = self["孵化时间"] - dt
	self:ShowInfo()
	if self["孵化时间"] <= 0 then
		self["孵化时间"] = 0
		if self["孵化阶段"] == 1 then
			self.inst:PushEvent("孵化进入二阶段")
		elseif self["孵化阶段"] == 2 then
			self["孵化阶段"] = 3
		end
	end
	-- print("孵化时间："..self["孵化时间"])
	-- print("孵化阶段："..self["孵化阶段"])
end

function Hhh:LongUpdate(dt)
	self:OnUpdate(dt)	
end

function Hhh:OnSave()
    local data =
    {
        state = self["孵化阶段"],
        t = self["孵化时间"],
    }
    return data
end

function Hhh:OnLoad(data)
    if data then
        self["孵化阶段"] = data.state
        self["孵化时间"] = data.t
		self:ShowInfo()
    end
end

return Hhh
