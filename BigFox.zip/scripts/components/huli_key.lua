local function IsHUDScreen(inst) 
	local defaultscreen = false 
	if TheFrontEnd:GetActiveScreen() and TheFrontEnd:GetActiveScreen().name  and type(TheFrontEnd:GetActiveScreen().name) == "string"  and TheFrontEnd:GetActiveScreen().name == "HUD" then 
		defaultscreen = true 
	end 
	return defaultscreen 
end  

local HuLi_Key = Class(function(self, inst)
	self.inst = inst
	self.handler = TheInput:AddKeyHandler(function(key, down) self:OnRawKey(key, down) end )
	
end)

function HuLi_Key:OnRawKey(key, down)
	local player = ThePlayer
  	if (key and not down) and not IsPaused() then
      	player:PushEvent("keypressed", {inst = self.inst, player = player, key = key})
    elseif key and down and not IsPaused() then
      	player:PushEvent("keydown", {inst = self.inst, player = player, key = key})
	end
end

function HuLi_Key:CanUseKey()
	return IsHUDScreen(self.inst)
end

function HuLi_Key:AddActionListener(Namespace, Key, Action)
	self.inst:ListenForEvent("keypressed", function(inst, data)
		if data.inst == ThePlayer then
			if data.key == Key then
				if self:CanUseKey() and not ThePlayer:HasTag("playerghost") then
					if TheWorld.ismastersim then
						ThePlayer:PushEvent("keyaction"..Namespace..Action, { Namespace = Namespace, Action = Action, Fn = MOD_RPC_HANDLERS[Namespace][MOD_RPC[Namespace][Action].id] })
					else
						SendModRPCToServer( MOD_RPC[Namespace][Action] )
					end
				end
			end
		end
	end)

	if TheWorld.ismastersim then
		self.inst:ListenForEvent("keyaction"..Namespace..Action, function(inst, data)
			if not data.Action == Action and not data.Namespace == Namespace then
				return
			end
          
			data.Fn(inst)
		end, self.inst) 
    end
end

function HuLi_Key:AddListenerZuHeKey(key, comkey, Namespace, Action)
	self.inst:ListenForEvent("keypressed", function(inst, data)
		if data.inst == ThePlayer then
			if data.key == key then
				-- if self.inst.components.playercontroller:IsControlPressed(control) then
				if self:CanUseKey() and not ThePlayer:HasTag("playerghost") then
					if comkey > 0 then
						if self:IsKeyDown(comkey) then
							if TheWorld.ismastersim then
								ThePlayer:PushEvent("keyaction"..Namespace..Action, { Namespace = Namespace, Action = Action, Fn = MOD_RPC_HANDLERS[Namespace][MOD_RPC[Namespace][Action].id] })
							else
								SendModRPCToServer( MOD_RPC[Namespace][Action] )
							end
						end
					else
						if TheWorld.ismastersim then
							ThePlayer:PushEvent("keyaction"..Namespace..Action, { Namespace = Namespace, Action = Action, Fn = MOD_RPC_HANDLERS[Namespace][MOD_RPC[Namespace][Action].id] })
						else
							SendModRPCToServer( MOD_RPC[Namespace][Action] )
						end
					end
				end
			end
		end
	end)

	if TheWorld.ismastersim then
		self.inst:ListenForEvent("keyaction"..Namespace..Action, function(inst, data)
			if not data.Action == Action and not data.Namespace == Namespace then
				return
			end
          
			data.Fn(inst)
		end, self.inst) 
    end
end

function HuLi_Key:ControlKeyDown(control, fn)
	TheInput:AddControlHandler(control, fn)
end

function HuLi_Key:IsControlKeyDown(control)
	return self.inst.components.playercontroller ~= nil and self.inst.components.playercontroller:IsControlPressed(control)
end

function HuLi_Key:IsControlKeyDownFn(control, Namespace, Action)
	if self.inst.components.playercontroller ~= nil then
		if self.inst.components.playercontroller:IsControlPressed(control) then
			SendModRPCToServer(MOD_RPC[Namespace][Action])
		end
	end
end

function HuLi_Key:IsMouseDown(button)
	return TheInput:IsMouseDown(button) 
end

-- local function iskeydown()
	-- return TheInput:IsKeyDown(KEY_CTRL) 
-- end

function HuLi_Key:IsKeyDown(key)
	return TheInput:IsKeyDown(key) 
end

-- function HuLi_Key:OnDownKey(key, comkey, Namespace, Action)
	-- TheInput:AddKeyDownHandler(key, function() 	
		-- if self:CanUseKey() and not ThePlayer:HasTag("playerghost") then
			-- self:SetZuHeKey(comkey, Namespace, Action) 
		-- end
	-- end)
-- end

return HuLi_Key