
local function c_lv(self, val)
	self.inst.replica.huli_levelsys:Set('当前等级', val)
end

local function m_lv(self, val)
	self.inst.replica.huli_levelsys:Set('最大等级', val)
end

local function c_exp(self, val)
	self.inst.replica.huli_levelsys:Set('当前经验值', val)
end

local function u_exp(self, val)
	self.inst.replica.huli_levelsys:Set('升级经验值', val)
end

local function m_exp(self, val)
	self.inst.replica.huli_levelsys:Set('最大经验值', val)
end

function huli_levelsyss(inst)
	return inst.components.huli_levelsys
end

local LvLv = Class(function(self, inst)
	self.inst = inst
	self['当前等级'] = 0
	self['最大等级'] = 3
	
	self['当前经验值'] = 0
	self['升级经验值'] = 100
	self['最大经验值'] = 1000

end,
nil,
{
	['当前等级'] = c_lv,
	['最大等级'] = m_lv,
	
	['当前经验值'] = c_exp,
	['升级经验值'] = u_exp,
	['最大经验值'] = m_exp,
})

LvLv['等级变更'] = function(self, val)
	self:LvDoDelta(val)
end

function LvLv:LvDoDelta(val)
	if not val then return end
	local old_lv = self['当前等级']
	if (old_lv >= self['最大等级'] and val >= 0) or (old_lv <= 0 and val <= 0) then
		return
	end
	
	self['当前等级'] = self['当前等级'] + (val)
	
	if self.inst.components.talker then
		if self['当前等级'] > old_lv then
			self.inst.components.talker:Say(hl_loc('升级！', 'Level up！'))
		elseif self['当前等级'] < old_lv then
			self.inst.components.talker:Say(hl_loc('降级！', 'level down！'))
		end
	end
	
	if self['当前等级'] >= self['最大等级'] then
		self['当前等级'] = self['最大等级']
		self.inst:DoTaskInTime(2, function()
			if self.inst.components.talker then
				self.inst.components.talker:Say(hl_loc('已经满级了！', 'Max Level！'))
			end
		end)
	end
	
	if self['当前等级'] <= 0 then
		self['当前等级'] = 0
		self.inst:DoTaskInTime(2, function()
			if self.inst.components.talker then
				self.inst.components.talker:Say(hl_loc('最小等级！', 'Min Level！'))
			end
		end)
	end
	
	if self['等级变更fn'] ~= nil then
		self['等级变更fn'](self.inst, self['当前等级'], self['最大等级'])
	end
	self.inst:PushEvent('等级变更事件')
end

function LvLv:ExpDoDelta(val)
	if not val then return end
	local old_exp = self['当前经验值']
	if (old_exp >= self['最大经验值'] and val >= 0) or (old_exp <= 0 and val <= 0) then
		return
	end
	
	self['当前经验值'] = self['当前经验值'] + (val)
	if self['当前经验值'] >= self['最大经验值'] then
		self['当前经验值'] = self['最大经验值']
		if self.inst.components.talker then
			self.inst.components.talker:Say(hl_loc('经验已满！', 'Max exp！'))
		end
	end
	
	if self['当前经验值'] <= 0 then
		self['当前经验值'] = 0
	end
	
	if self['经验值变更fn'] ~= nil then
		self['经验值变更fn'](self.inst)
	end
	self.inst:PushEvent('经验值变更事件')
	
	if self['自动升级'] then
		if self['当前经验值'] >= self['升级经验值'] and self['当前等级'] < self['最大等级'] then
			self:LvDoDeltaForExp(1)
		end
	end
end

function LvLv:LvDoDeltaForExp(val)
	if not val then return end
	if self['当前经验值'] < self['升级经验值'] then
		if self.inst.components.talker then
			self.inst.components.talker:Say(hl_loc('经验值不足', 'Insufficient empirical value'))
		end
		return
	end
	
	if self['当前等级'] >= self['最大等级'] then
		if self.inst.components.talker then
			self.inst.components.talker:Say(hl_loc('已经满级了', 'The level is full.'))
		end
		return
	end
	
	if val > 0 then
		for i = 1, val do
			self:ExpDoDelta(-self['升级经验值'])	
			self:LvDoDelta(val)
		end
	else
		-- self:ExpDoDelta()	
		self:LvDoDelta(val)
	end

end

function LvLv:Set(data)
	if data['当前等级'] then
		self['当前等级'] = data['当前等级']
	end
	if data['最大等级'] then
		self['最大等级'] = data['最大等级']
	end
	
	if data['当前经验值'] then
		self['当前经验值'] = data['当前经验值']
	end
	if data['升级经验值'] then
		self['升级经验值'] = data['升级经验值']
	end
	if data['最大经验值'] then
		self['最大经验值'] = data['最大经验值']
	end
	
	if data['自动升级'] then
		self['自动升级'] = data['自动升级']
	end
end

function LvLv:Get(info)
	return self[info]	
end

function LvLv:SetMaxLv(val)
	self['最大等级'] = val
end

function LvLv:SetUpExp(val, set_max_exp)
	self['升级经验值'] = val
	if not set_max_exp then return end
	if set_max_exp == true then
		self['最大经验值'] = val
	elseif type(set_max_exp) == 'number' then
		self['最大经验值'] = set_max_exp
	end
end

function LvLv:SetMaxExp(val)
	self['最大经验值'] = val
end

function LvLv:OnSave()
    local data =
    {
		['当前等级'] = self['当前等级'],
		['最大等级'] = self['保存最大等级'] and self['最大等级'] or nil,
		
		['当前经验值'] = self['当前经验值'],
		['升级经验值'] = self['升级经验值'],
		['最大经验值'] = self['最大经验值'],

    }

    return data
end

function LvLv:OnLoad(data)
    if data then
        self['当前等级'] = data['当前等级']
		if data['最大等级'] ~= nil then
			self['最大等级'] = data['最大等级']
		end
        self['当前经验值'] = data['当前经验值']
        self['升级经验值'] = data['升级经验值']
		self['最大经验值'] = data['最大经验值']

    end
	if self['加载等级fn'] then
		self['加载等级fn'](self.inst, self['当前等级'], self['最大等级'])
	end
end

return LvLv
