
local LvLv = Class(function(self, inst)
	self.inst = inst
	
	self['当前等级net'] = net_shortint(inst.GUID, "当前等级net", "当前等级net")
	self['最大等级net'] = net_shortint(inst.GUID, "最大等级net", "最大等级net")
	
	self['当前经验值net'] = net_int(inst.GUID, "当前经验值net", "当前经验值net")
	self['升级经验值net'] = net_int(inst.GUID, "升级经验值net", "升级经验值net")
	self['最大经验值net'] = net_int(inst.GUID, "最大经验值net", "最大经验值net")
	
end)

function LvLv:Set(name, val)
	self[name..'net']:set(val)
end

function LvLv:Get(name)
	return self[name..'net']:value()
end


return LvLv
