
local PetLeash = Class(function(self, inst)
    self.inst = inst

    self.petprefab = nil
    self.pets = {}
    self.maxpets = 1
    self.numpets = 0
	
    self.npc = nil

    self.onspawnfn = nil
    self.ondespawnfn = nil

    self._onremovepet = function(pet)
        if self.pets[pet] ~= nil then
            self.pets[pet] = nil
            self.numpets = self.numpets - 1
        end
    end
    self._onremovenpc = function()
		self.npc = nil
    end
end)

function PetLeash:SetPetPrefab(prefab)
    self.petprefab = prefab
end

function PetLeash:SetOnSpawnFn(fn)
    self.onspawnfn = fn
end

function PetLeash:SetOnDespawnFn(fn)
    self.ondespawnfn = fn
end

function PetLeash:SetMaxPets(num)
    self.maxpets = num
end

function PetLeash:GetMaxPets()
    return self.maxpets
end

function PetLeash:GetNumPets()
    return self.numpets
end

function PetLeash:IsFull()
    return self.numpets >= self.maxpets
end

function PetLeash:HasPetWithTag(tag)
    for k, v in pairs(self.pets) do
        if v:HasTag(tag) then
            return true
        end
    end
    return false
end

function PetLeash:GetPets()
    return self.pets
end

function PetLeash:IsPet(pet)
    return self.pets[pet] ~= nil
end

local function LinkPet(self, pet)
    self.pets[pet] = pet
    self.numpets = self.numpets + 1
    self.inst:ListenForEvent("onremove", self._onremovepet, pet)
    pet.persists = false

    if self.inst.components.leader ~= nil then
        self.inst.components.leader:AddFollower(pet)
    end
	pet._player = self.inst
	if pet['所有者net'] then
		pet['所有者net']:set(self.inst)
	end
end

function PetLeash:LinkPet(pet)
    if self.numpets >= self.maxpets or pet == nil then
        return nil
    end
	if pet ~= nil then
		LinkPet(self, pet)
		if self.onspawnfn ~= nil then
            self.onspawnfn(self.inst, pet)
        end
	end
end
--■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
local function DoEffects(npc)
    SpawnPrefab("spawn_fx_medium").Transform:SetPosition(npc.Transform:GetWorldPosition())
end

local function LinkNPC(self, npc)
    self.npc = npc
	npc._player = self.inst
    npc.persists = false
	if self.npc ~= nil then
		npc:DoPeriodicTask(.2, function()
			npc:ForceFacePoint(self.inst.Transform:GetWorldPosition())
		end)
		npc:DoPeriodicTask(1.5, function()
			if self.inst:IsValid() then
				local dist = npc:GetDistanceSqToInst(self.inst)
				if self.inst:HasTag('playerghost') then
					npc.components.talker:Say(hl_loc('鬼啊.....我闪！', 'Ghost....BayBay！'))
					npc:DoTaskInTime(.8, function() 
						DoEffects(npc)
						if npc.components.container ~= nil then
							npc.components.container:DropEverything()
						end
						npc:DoTaskInTime(.3, function() 
							npc:Remove() 
						end)
					end)
				else
					if dist > 233 then
						npc.components.talker:Say(hl_loc('欢迎下次光临，再见！', 'Looking forward to your next visit，BayBay！'))
						npc:DoTaskInTime(1, function() 
							DoEffects(npc)
							if npc.components.container ~= nil then
								npc.components.container:DropEverything()
							end
							npc:DoTaskInTime(.3, function() 
								npc:Remove() 
							end)
						end)
					end
				end
			end
		end)
	end
	
    self.inst:ListenForEvent("onremove", self._onremovenpc, npc)
end

function PetLeash:SpawnNPCAt(x, y, z, prefaboverride)
    local petprefab = prefaboverride or self.petprefab
	if petprefab == nil then
		return nil
	end
    if self.npc ~= nil then
		self.inst.components.talker:Say(hl_loc('只能召唤一只萌萌达的充值员', 'You can only summon a cute recharge agent'))
        return nil
    end

    local npc = SpawnPrefab(petprefab, nil, nil, self.inst.userid)
    if npc ~= nil then
        LinkNPC(self, npc)
		npc:DoTaskInTime(.3, function() 
			if npc.Physics ~= nil then
				npc.Physics:Teleport(x+math.random(-2,2), y, z+math.random(-2,2))
			elseif npc.Transform ~= nil then
				npc.Transform:SetPosition(x+math.random(-2,2), y, z+math.random(-2,2))
			end
			npc:DoTaskInTime(.2, function() npc.components.talker:Say(hl_loc('欢迎光临狐狸充值店！', 'Welcome to Fox recharge shop！')) end)
			if self.onspawnfn ~= nil then
				self.onspawnfn(self.inst, npc)
			end
		end)
    end
    
    return npc
end

--■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

function PetLeash:SpawnPetAt(x, y, z, prefaboverride)
    local petprefab = prefaboverride or self.petprefab
    if self.numpets >= self.maxpets or petprefab == nil then
        return nil
    end

    local pet = SpawnPrefab(petprefab, nil, nil, self.inst.userid)
    if pet ~= nil then
        LinkPet(self, pet)

        if pet.Physics ~= nil then
            pet.Physics:Teleport(x, y, z)
        elseif pet.Transform ~= nil then
            pet.Transform:SetPosition(x, y, z)
        end
        if self.onspawnfn ~= nil then
            self.onspawnfn(self.inst, pet)
        end
    end
    
    return pet
end

function PetLeash:CallAllPets()
	if self.inst:HasTag("playerghost") or (self.inst.components.health and self.inst.components.health:IsDead()) then 
		self.inst.components.talker:Say(hl_loc("你是一只鬼，没有手怎么召！", "You have become a ghost. Cannot summon Little fox"))
		return 
	end
	self.inst.sg:GoToState("castspell")
	self.inst:DoTaskInTime(2, function()
		if next(self.pets) ~= nil then
			if not self.inst.components.timer:TimerExists("CallAllPets") then
				local x, y, z = self.inst.Transform:GetWorldPosition()
				for k, v in pairs(self.pets) do
					local fx = SpawnPrefab("spawn_fx_medium")
					fx.Transform:SetPosition(x+math.random(-3, 3), y, z+math.random(-3, 3))
					if v and v.Physics ~= nil then
						v:DoTaskInTime(.3, function()
							v.Physics:Teleport(fx.Transform:GetWorldPosition())
						end)
					elseif v.Transform ~= nil then
						v:DoTaskInTime(.3, function()
							v.Transform:SetPosition(fx.Transform:GetWorldPosition())
						end)
					end
				end
			else
				self.inst.components.talker:Say(hl_loc("召唤冷却中，请稍后尝试！", "Cooling, please try later!"))
			end
			self.inst.components.timer:StartTimer("CallAllPets", 10)
			
		else
			self.inst.components.talker:Say(hl_loc("没有小狐狸可以召唤", "No little fox can summon"))
		end	
	end)
end

function PetLeash:CallMihobell()
	if self.inst:HasTag("playerghost") or (self.inst.components.health and self.inst.components.health:IsDead()) then 
		self.inst.components.talker:Say(hl_loc("你是一只鬼，没有手怎么召！", "You have become a ghost. Cannot summon mihobell"))
		return 
	end
	self.inst.sg:GoToState("castspell")
	self.inst:DoTaskInTime(2, function()
		if self.inst.mihobell then
			local v = self.inst.mihobell
			local owner = v.components.inventoryitem.owner
			if v and not v:IsValid()  then 
				v = SpawnSaveRecord(v)
				self.inst:GiveMihobell(v) 
				if self.inst.miho and self.inst.miho:IsValid() then
					v:RebindMiho(self.inst.miho)
				end
				self.inst.components.talker:Say("...................................！")
				return 
			end
			if owner and owner == v.owner then self.inst.components.talker:Say(hl_loc("你是在找BUG么！", "mihobell is already in your inventory!")) return end
			if not self.inst.components.timer:TimerExists("CallMihobell") then
				local x, y, z = self.inst.Transform:GetWorldPosition()
				local fx = SpawnPrefab("spawn_fx_medium")
				fx.Transform:SetPosition(x+math.random(-3, 3), y, z+math.random(-3, 3))
				v:DoTaskInTime(.2, function(v)
					if owner then
						if owner.components.container then
							owner.components.container:DropItem(v)
						elseif owner.components.inventory then
							owner.components.inventory:DropItem(v)
						end
					end
					if v and v.Physics ~= nil then
						v.Physics:Teleport(fx.Transform:GetWorldPosition())
					elseif v.Transform ~= nil then
						v.Transform:SetPosition(fx.Transform:GetWorldPosition())
					end
					self.inst.components.talker:Say(hl_loc("召唤成功~", "Successfully summoned~"))
				end)
			else
				self.inst.components.talker:Say(hl_loc("召唤冷却中，请稍后尝试！", "Cooling, please try later!"))
			end
			self.inst.components.timer:StartTimer("CallMihobell", 10)
			
		elseif not self.inst.mihobell then
			self.inst:GiveMihobell() 
			self.inst.components.talker:Say(hl_loc("已重新召唤~~", "mihobell has been regenerated"))
		end	
	end)
end

function PetLeash:DespawnPet(pet)
    if self.pets[pet] ~= nil then
        if self.ondespawnfn ~= nil then
            self.ondespawnfn(self.inst, pet)
        else
            pet:Remove()
        end
    end
end

function PetLeash:DespawnNpc(npc)
    if npc ~= nil then
		npc.components.talker:Say(hl_loc('溜了', 'BayBay！!'))
		npc:DoTaskInTime(.3, function()
			if npc.components.container ~= nil then
				npc.components.container:DropEverything()
			end
			npc:DoTaskInTime(1, function() npc:Remove() end)
		end)
    end
end

function PetLeash:DespawnAllPets()
    local toremove = {}
    for k, v in pairs(self.pets) do
        table.insert(toremove, v)
    end
    for i, v in ipairs(toremove) do
        self:DespawnPet(v)
    end
	
	self:DespawnNpc(self.npc)
end

function PetLeash:OnSave()
    if next(self.pets) ~= nil then
        local data = {}
        for k, v in pairs(self.pets) do
            local saved--[[, refs]] = v:GetSaveRecord()
            table.insert(data, saved)
        end
        return { pets = data }
    end
end

function PetLeash:OnLoad(data)
    if data ~= nil and data.pets ~= nil then
        for i, v in ipairs(data.pets) do
            local pet = SpawnSaveRecord(v)
            if pet ~= nil then
                LinkPet(self, pet)

                if self.onspawnfn ~= nil then
                    self.onspawnfn(self.inst, pet)
                end
            end
        end
        if self.inst.migrationpets ~= nil then
            for k, v in pairs(self.pets) do
                table.insert(self.inst.migrationpets, v)
            end
        end
    end
end

function PetLeash:OnRemoveFromEntity()
    for k, v in pairs(self.pets) do
        self.inst:RemoveEventCallback("onremove", self._onremovepet, v)
    end
	self.inst:RemoveEventCallback("onremove", self._onremovenpc, self.npc)
end

PetLeash.OnRemoveEntity = PetLeash.DespawnAllPets

return PetLeash
