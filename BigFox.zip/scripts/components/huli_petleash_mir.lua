local PetLeash_Mir = Class(function(self, inst)
    self.inst = inst

    self.petprefab = nil
    self.pets = {}
    self.maxpets = 1
    self.numpets = 0

    self.onspawnfn = nil
    self.ondespawnfn = nil

    self._onremovepet = function(pet)
        if self.pets[pet] ~= nil then
            self.pets[pet] = nil
            self.numpets = self.numpets - 1
        end
    end
end)

function PetLeash_Mir:SetPetPrefab(prefab)
    self.petprefab = prefab
end

function PetLeash_Mir:SetOnSpawnFn(fn)
    self.onspawnfn = fn
end

function PetLeash_Mir:SetOnDespawnFn(fn)
    self.ondespawnfn = fn
end

function PetLeash_Mir:SetMaxPets(num)
    self.maxpets = num
end

function PetLeash_Mir:GetMaxPets()
    return self.maxpets
end

function PetLeash_Mir:GetNumPets()
    return self.numpets
end

function PetLeash_Mir:IsFull()
    return self.numpets >= self.maxpets
end

function PetLeash_Mir:HasPetWithTag(tag)
    for k, v in pairs(self.pets) do
        if v:HasTag(tag) then
            return true
        end
    end
    return false
end

function PetLeash_Mir:GetPets()
    return self.pets
end

function PetLeash_Mir:IsPet(pet)
    return self.pets[pet] ~= nil
end

local function LinkPet(self, pet)
    self.pets[pet] = pet
    self.numpets = self.numpets + 1
    self.inst:ListenForEvent("onremove", self._onremovepet, pet)
    pet.persists = false

    if self.inst.components.leader ~= nil then
        self.inst.components.leader:AddFollower(pet)
    end
	pet._player = self.inst
	if pet['所有者net'] then
		pet['所有者net']:set(self.inst)
	end
	-- self.inst['已有小龙'] = true
end

function PetLeash_Mir:SpawnPetAt(x, y, z, prefaboverride, skin)
    local petprefab = prefaboverride or self.petprefab
    if self.numpets >= self.maxpets then
		if self.inst.components.talker then
			self.inst.components.talker:Say(hl_loc("宠物已满", "pet full"))
		end
        return nil
    end
    if petprefab == nil then
		if self.inst.components.talker then
			self.inst.components.talker:Say(hl_loc("未正确生成小龙", "Imoogi was not generated correctly"))
		end
        return nil
    end
	
    local pet = SpawnPrefab(petprefab, skin, nil, self.inst.userid)
    if pet ~= nil then
        LinkPet(self, pet)

        if pet.Physics ~= nil then
            pet.Physics:Teleport(x, y, z)
        elseif pet.Transform ~= nil then
            pet.Transform:SetPosition(x, y, z)
        end

        if self.onspawnfn ~= nil then
            self.onspawnfn(self.inst, pet)
        end
    end

    return pet
end

function PetLeash_Mir:DespawnPet(pet)
    if self.pets[pet] ~= nil then
        if self.ondespawnfn ~= nil then
            self.ondespawnfn(self.inst, pet)
        else
            pet:Remove()
        end
    end
end

function PetLeash_Mir:DespawnAllPets()
    local toremove = {}
    for k, v in pairs(self.pets) do
        table.insert(toremove, v)
    end
    for i, v in ipairs(toremove) do
        self:DespawnPet(v)
    end
end

function PetLeash_Mir:OnSave()
    if next(self.pets) ~= nil then
        local data = {}
        for k, v in pairs(self.pets) do
			v.temp_save_platform_pos = true
            local saved--[[, refs]] = v:GetSaveRecord()
			v.temp_save_platform_pos = nil
            table.insert(data, saved)
        end
        return { pets = data }
    end
end

function PetLeash_Mir:OnLoad(data)
    if data ~= nil and data.pets ~= nil then
        for i, v in ipairs(data.pets) do
			v.is_snapshot_save_record = self.inst.is_snapshot_user_session
            local pet = SpawnSaveRecord(v)
			v.is_snapshot_save_record = nil
            if pet ~= nil then
                LinkPet(self, pet)

                if self.onspawnfn ~= nil then
                    self.onspawnfn(self.inst, pet)
                end
            end
        end
        if self.inst.migrationpets ~= nil then
            for k, v in pairs(self.pets) do
                table.insert(self.inst.migrationpets, v)
            end
        end
    end
end

function PetLeash_Mir:OnRemoveFromEntity()
    for k, v in pairs(self.pets) do
        self.inst:RemoveEventCallback("onremove", self._onremovepet, v)
    end
end

PetLeash_Mir.OnRemoveEntity = PetLeash_Mir.DespawnAllPets

function PetLeash_Mir:TransferComponent(newinst)
    local newcomponent = newinst.components.petleash

end

return PetLeash_Mir
