
local function Gethulicoin(self, huli_coin) 
	self.inst._huli_coin:set(huli_coin) 
end

local HuLi_Store = Class(function(self, inst)
    self.inst = inst
    self.huli_coin = 0

end,
nil,
{
    huli_coin = Gethulicoin, --储存当前的数值为class数据

})

function HuLi_Store:CoinDoDelta(value)
    self.huli_coin = self.huli_coin + value
	self.inst._huli_coin:set(self.huli_coin) 
end

function HuLi_Store:ItemBuy(prefab, coinconsume, num)
	num = num or 1
	coinconsume = coinconsume * num
    if self.huli_coin >= coinconsume then
		self:CoinDoDelta(-coinconsume)
		for k = 1, num do
			self.inst.components.inventory:GiveItem(SpawnPrefab(prefab))
		end
	else
		if self.inst.components.talker then
			self.inst.components.talker:Say(hl_loc('狐狸币不足，请充值！', 'Fox coins are not enough，Please recharge！'))
		end
    end
end

function HuLi_Store:LuckDraw(prefab, coinconsume) 
			
    if self.huli_coin >= coinconsume then
		self.inst.SoundEmitter:PlaySound("dontstarve/HUD/research_available")
		self:CoinDoDelta(-coinconsume)
		self.inst.components.inventory:GiveItem(SpawnPrefab(prefab))
    end
end

function HuLi_Store:OnSave()
    local data = {
        huli_coin = self.huli_coin		
    }   
    return data
end

function HuLi_Store:OnLoad(data)
    self.huli_coin = data.huli_coin	
end

return HuLi_Store
