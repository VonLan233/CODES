local function UpdateFloater(inst)
	if inst.components.huli_swimmer then 
		if inst.components.drownable and inst.components.drownable:ShouldDrown() then 
			return 
		end 
		if not inst.components.huli_swimmer:IsSwimming() and inst.components.huli_swimmer:CanSwim() then  
			inst.components.huli_swimmer:StartSwimServer()
		elseif inst.components.huli_swimmer:IsSwimming() and not inst.components.huli_swimmer:CanSwim() then  
			inst.components.huli_swimmer:StopSwimServer()
		end 
	end
end 

local function RestartUpdateFloater(inst)
	local self = inst.components.huli_swimmer
	if self.UpdateFloaterTask then 
		self.UpdateFloaterTask:Cancel()
	end
	self.UpdateFloaterTask = inst:DoPeriodicTask(0,UpdateFloater)
end 

local function StopUpdateFloater(inst)
	local self = inst.components.huli_swimmer
	if self.UpdateFloaterTask then 
		self.UpdateFloaterTask:Cancel()
	end
	self.UpdateFloaterTask = nil 
end 


local function ReCalcSwimDebuff(inst)
	inst.components.huli_swimmer:ReCalcSwimDebuff()
end 

local function OnDismounted(inst,data)
	inst.components.huli_swimmer:ReCalcSwimDebuff()
	if data and data.target and data.target.components.health and not data.target.components.health:IsDead() then 
		data.target.components.health:Kill()
	end
end 


local HuLiSwimmer = Class(function(self, inst)
	self.inst = inst
	
	self.anim_idx = 0 -- zero based index

	self.start_swim_splash_scale = 1
	self.stop_swim_splash_scale = 1
	
	self.start_swim_splash_sound = "large"
	self.stop_swim_splash_sound = "medium"
	
	--self.float_params = Vector3(0.45, 1.0,0.5)
	
	self.onstartswim = nil 
	self.onstopswim = nil 
	
	self.wave_offset = 0 
	self.swimming_scale = 1
	
	self:SetFloatParams(0,0,0)
	
	if not TheNet:IsDedicated() then
        self.inst:ListenForEvent("huli_swimming_dirty", function()
            if self._isswimming:value() then
                self:StartSwimClient()
            else
                self:StopSwimClient()
            end
        end)
    end
	
	self._isswimming = net_bool(inst.GUID, "HuLiSwimmer._isswimming", "huli_swimming_dirty")
	self._isswimming:set(false)
	
	if TheNet:GetIsMasterSimulation() then
		--if not inst:HasTag("playerghost") then 
		self.UpdateFloaterTask = inst:DoPeriodicTask(0,UpdateFloater)
		--end 
		--inst:ListenForEvent("makeplayerghost",StopUpdateFloater)
		--inst:ListenForEvent("respawnfromghost",RestartUpdateFloater)
		--inst:ListenForEvent("respawnfromcorpse",RestartUpdateFloater)
	end 
end)



local ANIMS = { "idle_loop_1", "idle_loop_2", "idle_loop_3" }

function HuLiSwimmer:SetOnStartSwim(fn)
	self.onstartswim = fn 
end 

function HuLiSwimmer:SetOnStopSwim(fn)
	self.onstopswim = fn 
end 

function HuLiSwimmer:SetSplashParams(start_scale,start_sound,stop_scale,stop_sound)
	self.start_swim_splash_scale = start_scale or self.start_swim_splash_scale or 1
	self.start_swim_splash_sound = start_sound or self.start_swim_splash_sound or "large"
	self.stop_swim_splash_scale = stop_scale or self.stop_swim_splash_scale or 1
	self.stop_swim_splash_sound = stop_sound or self.stop_swim_splash_sound or "medium"
end 

function HuLiSwimmer:SetFloatParams(x,y,z)
	--self.float_params = Vector3(x,y,z)
	self.inst.components.floater:SetFloatParams(x,y,z)
end 


function HuLiSwimmer:IsSwimming()
	return self._isswimming:value()
end 

function HuLiSwimmer:CanSwim()
	--local buffer
	local pos_x, pos_y, pos_z = self.inst.Transform:GetWorldPosition()
	
	return  not TheWorld.Map:IsPassableAtPoint(pos_x, 0, pos_z) and
            not TheWorld.Map:IsVisualGroundAtPoint(pos_x, 0, pos_z) and
			not TheWorld.Map:GetPlatformAtPoint(pos_x, pos_z) and 
			not self.inst.sg:HasStateTag("jumping") and 
			not self.inst.sg:HasStateTag("aoe") and 
			not self.inst:HasTag("playerghost") and 
			self.inst.sg.currentstate.name ~= "hop_master" and 
			TheWorld.has_ocean and
			pos_y <= 0.05
end 

function HuLiSwimmer:TryCreateWaves(x, y, z, dir_x, dir_z)
	local fx = SpawnPrefab("icefox_fx")

    local radius = 0.5
    fx.Transform:SetPosition(x - dir_x * radius, y, z - dir_z * radius)    
	fx.Transform:SetScale(0.65,0.65,0.65)     

	self.anim_idx = (self.anim_idx + (math.random() > 0.5 and 1 or -1)) % #ANIMS
    fx.AnimState:PlayAnimation(ANIMS[self.anim_idx + 1])
	--fx.AnimState:SetMultColour(1,1,1,0.6)

    if fx.components.boattrailmover ~= nil then
	    fx.components.boattrailmover:Setup(dir_x, dir_z, 0.5, -0.125)
	end


	-- if self.lastWakeTime == nil or GetTime() - self.lastWakeTime > 0.5 then 
	-- 	self.lastWakeTime = GetTime()
	-- 	local wake = SpawnPrefab("wake_small")
	--     local rotation = self.inst.Transform:GetRotation()

	--     local theta = rotation * DEGREES
	--     local offset = Vector3(math.cos( theta ), 0, -math.sin( theta ))
	--     local pos = Vector3(self.inst.Transform:GetWorldPosition()) + offset
	--     wake.Transform:SetPosition(pos.x,pos.y,pos.z)
	--     wake.Transform:SetScale(1.1,1.1,1.1)

	--     wake.Transform:SetRotation(rotation - 90)
	-- end 
end 

function HuLiSwimmer:CreateSplash(pos,spawnchild,sound,scale)
	local x,y,z = self.inst.Transform:GetWorldPosition()
	if spawnchild then 
		pos = pos or Vector3(0,0,0)
	else
		pos = pos or Vector3(x,y,z)
	end 
	sound = sound or "small"
	scale = scale or 1
	local fx = SpawnAt("splash_sink",pos)
	fx.Transform:SetScale(scale,scale,scale)
	self.inst.SoundEmitter:PlaySound("turnoftides/common/together/water/splash/"..sound)
	if spawnchild then 
		self.inst:AddChild(fx)
	end
end 

function HuLiSwimmer:StartSwimClient()
	self.inst.DynamicShadow:Enable(false)
end

function HuLiSwimmer:StopSwimClient()
	self.inst.DynamicShadow:Enable(true)
	self.inst.AnimState:SetFloatParams(0,0,0)
end

function HuLiSwimmer:ReCalcSwimDebuff()
	local stamina = self.inst.components.stamina
	local locomotor = self.inst.components.locomotor
	local is_riding = self.inst.components.rider and self.inst.components.rider:IsRiding()
	local stamina_recoverrate = (is_riding and 1) or 1
	local stamina_consumerate = (is_riding and 0) or 1
	local speed = self.swimming_scale
	


	if self.inst:HasTag("player") then 
		if is_riding then 
			self.inst.components.floater:SetSize("large")
		else
			self.inst.components.floater:SetSize("small")
		end 
	end 
	
	if self:IsSwimming() then 
		if stamina then 
			stamina.externalrecoverratemultipliers:SetModifier(self.inst,stamina_recoverrate,"huli_swimming")
			stamina.externalconsumeratemultipliers:SetModifier(self.inst,stamina_consumerate,"huli_swimming")
		end 
		locomotor:SetExternalSpeedMultiplier(self.inst, "huli_swimming",speed)
	else
		if stamina then 
			stamina.externalrecoverratemultipliers:RemoveModifier(self.inst,"huli_swimming")
			stamina.externalconsumeratemultipliers:RemoveModifier(self.inst,"huli_swimming")
		end 
		locomotor:RemoveExternalSpeedMultiplier(self.inst, "huli_swimming")
	end
	

end 

function HuLiSwimmer:StartSwimServer()
	self.inst:ListenForEvent("equip",ReCalcSwimDebuff)
	self.inst:ListenForEvent("unequip",ReCalcSwimDebuff)
	self.inst:ListenForEvent("mounted",ReCalcSwimDebuff)
	self.inst:ListenForEvent("dismount",ReCalcSwimDebuff)
	self.inst:ListenForEvent("dismounted",OnDismounted)
	
	
	self.inst:PushEvent("on_landed")
	self._isswimming:set(true)
	self:ReCalcSwimDebuff()
	self.inst:AddTag("huli_swimming")
	
	
	
	if self.inst.components.hulisneaker and self.inst.components.hulisneaker:IsSneaking() then 
		self.inst.components.hulisneaker:StopSneak()
	end 
	
	self:CreateSplash(nil,nil,self.start_swim_splash_sound,self.start_swim_splash_scale) 
	
	if self.onstartswim then 
		self.onstartswim(self.inst) 
	end
	
	

	self.inst:StartUpdatingComponent(self)
end

function HuLiSwimmer:StopSwimServer()
	self.inst:PushEvent("on_no_longer_landed")
	
	self._isswimming:set(false)
	self:ReCalcSwimDebuff()
	self.inst:RemoveTag("huli_swimming")
	
	
	
	self:CreateSplash(nil,nil,self.stop_swim_splash_sound,self.stop_swim_splash_scale) 
	
	if self.onstopswim then 
		self.onstopswim(self.inst) 
	end
	self.inst:RemoveEventCallback("equip",ReCalcSwimDebuff)
	self.inst:RemoveEventCallback("unequip",ReCalcSwimDebuff)
	self.inst:RemoveEventCallback("mounted",ReCalcSwimDebuff)
	self.inst:RemoveEventCallback("dismount",ReCalcSwimDebuff)
	self.inst:RemoveEventCallback("dismounted",OnDismounted)
	self.inst:StopUpdatingComponent(self)
end

function HuLiSwimmer:OnUpdate(dt)
    local total_distance_traveled = self.total_distance_traveled
    local x, y, z = self.inst.Transform:GetWorldPosition()
    local wave_offset = self.wave_offset
	local is_riding = self.inst.components.rider and self.inst.components.rider:IsRiding()
	
	
    if not total_distance_traveled then
        self.last_x, self.last_z = x, z
        self.total_distance_traveled = 0
        return
    end

    local effect_spawn_rate = 2
    local dir_x, dir_z = x - self.last_x, z - self.last_z
    local distance_traveled = VecUtil_Length(dir_x, dir_z)
    distance_traveled = math.min(effect_spawn_rate, distance_traveled)

    total_distance_traveled = total_distance_traveled + distance_traveled

    dir_x, dir_z = VecUtil_Normalize(dir_x, dir_z)

    local angle_apart = 30

    if total_distance_traveled > effect_spawn_rate then   
        self:TryCreateWaves(x, y + wave_offset, z, dir_x, dir_z)

        total_distance_traveled = total_distance_traveled - effect_spawn_rate
    end        

    self.total_distance_traveled = total_distance_traveled

    self.last_x = x
    self.last_z = z
    self.last_dir_x = dir_x
    self.last_dir_z = dir_z

end


-----------player_common中的OnLoad函数会在延时0秒后强制将海上的玩家传送到大门处
-----------故写下此函数，再拉回来
function HuLiSwimmer:OnSave()
	local x,y,z = self.inst.Transform:GetWorldPosition()
	local current_worldid = TheShard:GetShardId()
	return {
		x = x,
		y = y,
		z = z,
		old_world_id = current_worldid,
	}
end

function HuLiSwimmer:OnLoad(data)
	if data then 
		local x,y,z = data.x,data.y,data.z
		local oldid = data.old_world_id
		local newid = TheShard:GetShardId()
		
		if newid == oldid then 
			self.inst:DoTaskInTime(0.1,function()
				self.inst.Transform:SetPosition(x,y,z)
			end)
		end 
	end 
end

return HuLiSwimmer