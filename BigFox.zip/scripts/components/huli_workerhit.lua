
local  HuLi_WorkerHit = Class(function(self, inst)
	self.inst = inst
	if not self.inst.components.timer then
		self.inst:AddComponent("timer")
	end
end)

function HuLi_WorkerHit:OnHit(worker, tyanim)
	if not tyanim then
		self.inst.AnimState:PlayAnimation("hit")
	end
	local wk = self.inst.components.workable
	local act = self.inst.components.workable:GetWorkAction()
	local msg = '<'..worker.name..">正在破坏<"
	
	-- if worker:HasTag('bearger') or worker:HasTag('deerclops') then
		-- self.inst.SoundEmitter:PlaySound("dontstarve/common/destroy_stone")
	-- else
	-- if act == ACTIONS.MINE then
		-- wk.workleft = wk.workleft + 1
		-- if self.inst.components.lootdropper ~= nil then
			-- for i = 1, 3 do
				-- self.inst.components.lootdropper:SpawnLootPrefab('ice')
			-- end
		-- end
	-- elseif act == ACTIONS.HAMMER then
	if self.inst.components.container ~= nil then
		self.inst.components.container:Close()
	end
	if self.inst._player ~= nil then
		if worker:HasTag('player') then
			if worker.userid == self.inst._player.userid then  
				--print(worker.userid)
				self.inst.SoundEmitter:PlaySound("dontstarve/common/destroy_stone")
				wk.workleft = wk.workleft - self.inst.maxwork * .08
				msg = '<'..worker.name..'>正在拆除自己的<'..self.inst.name..'>'
			else
				wk.workleft = wk.workleft + 1
				msg = msg..self.inst._player.name..'>的'..'<'..self.inst.name..'/'..self.inst._workleft:value()..'>'
			end
		-- TheNet:Announce(msg)
		else
			msg = msg..self.inst._player.name..'>的'..'<'..self.inst.name..'/'..self.inst._workleft:value()..'>'
		end
	else
		msg = msg..self.inst.name..'>'
	end
	if not self.inst.components.timer:TimerExists('') then
		TheNet:Announce(msg)
	end
	if self.inst.components.sleepingbag ~= nil and self.inst.components.sleepingbag.sleeper ~= nil then
        self.inst.components.sleepingbag:DoWakeUp()
    end
	self.inst.components.timer:StartTimer('', 10)
end

return HuLi_WorkerHit
