local function onstay(self, stay)
	if self.inst.replica.xhl_command then
		self.inst.replica.xhl_command._staying:set(stay)
	end
end

local Xhl_Command = Class(function(self, inst)
	self.inst = inst
	self.stay = false
	self.locations = {}
	
	inst:ListenForEvent("xhl_staying", function() self:Set() end)
end,
nil, 
{
	stay = onstay
})

function Xhl_Command:StayTalk(doer)
	self.inst:DoTaskInTime(.8, function()
		self.inst.components.talker:Say(hl_loc('收到!', 'Received!'))
	end)
	
	if doer and doer.components.talker then
		doer.components.talker:Say(hl_loc("留下来!", 'Stay!'))
	end
end

function Xhl_Command:FollowerTalk(doer)
	self.inst:DoTaskInTime(.8, function()
		self.inst.components.talker:Say(hl_loc('来喽来喽!', "I'm coming.I'm coming.!"))
	end)
	
	if doer and doer.components.talker then
		doer.components.talker:Say(hl_loc("跟我来!", 'follow me!'))
	end
end

function Xhl_Command:Set()
	if self.stay == true then
		self.inst.components.follower:StopFollowing()
		self.inst:AddTag("shadow")
		self.inst:AddTag("notarget")
		if self.inst.components.health then
			self.inst.components.health.invincible = true
		end
		self:RememberSitPos("currentstaylocation", Point(self.inst.Transform:GetWorldPosition())) 
	else
		if self.inst._player then
			self.inst.components.follower:SetLeader(self.inst._player)
			self.inst:RemoveTag("shadow")
			self.inst:RemoveTag("notarget")
			if self.inst.components.health then
				self.inst.components.health.invincible = false
			end
		end
	end
end

function Xhl_Command:SetStaying(stay, doer)
	self.stay = stay
	if doer then
		if stay then
			self:StayTalk(doer)
		else
			self:FollowerTalk(doer)
		end
	end
end

function Xhl_Command:IsCurrentlyStaying()
	return self.inst.replica.xhl_command and self.inst.replica.xhl_command._staying:value()
end

function Xhl_Command:IsStaying()
	return self.stay
end

function Xhl_Command:RememberSitPos(name, pos)
	self.locations[name] = pos
end

function Xhl_Command:OnSave()
	if self:IsCurrentlyStaying() then
		local data = 
		{ 
			stay = self.stay,
			varx = self.locations.currentstaylocation["x"], 
			vary = self.locations.currentstaylocation["y"], 
			varz = self.locations.currentstaylocation["z"]
		}
		return data
	end
end  

function Xhl_Command:OnLoad(data)
	if data then 
		self.stay = data.stay
		self.locations.currentstaylocation = {}
		self.locations.currentstaylocation["x"] = data.varx
		self.locations.currentstaylocation["y"] = data.vary
		self.locations.currentstaylocation["z"] = data.varz
	end
end

return Xhl_Command
