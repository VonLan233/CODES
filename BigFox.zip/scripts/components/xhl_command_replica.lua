

local Xhl_Command = Class(function(self, inst)
	self.inst = inst

	self._staying = net_bool(inst.GUID, "xhl_staying", "xhl_staying")

end)

function Xhl_Command:IsCurrentlyStaying()
	return self._staying:value()
end

return Xhl_Command
