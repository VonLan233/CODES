local function onname(self,name)
	self.inst._name:set(tostring(name))
end

local Xhl_qp_db = Class(function(self, inst)
	self.inst = inst
	self.package = nil
	self.name = nil
	self.packageuserid = nil
	self.health = 0
	self.level = 0
	self.leader = nil
end,
nil,
{
    name = onname,
})

local function get_name(target)
	local name = target:GetDisplayName() or (target.components.named and target.components.named.name)
	if not name or name == "MISSING NAME" then 
		return 
	end
	local adj = target:GetAdjective()
	if adj then
		name = adj.." "..name
	end
	return name
end

local function Getplayer(target)
	self.leader = target.replica.follower:GetLeader() 
end

local function get_userid(target)
	local leader = (target['所有者net']:value() and target['所有者net']:value().userid) or target.replica.follower:GetLeader().userid
	if leader ~= nil then
		return leader
	end
end

function Xhl_qp_db:GetName()
	return self.package and self.package.name
end

function Xhl_qp_db:Pack(target)
	self.package = target:GetSaveRecord()
	self.packageuserid = get_userid(target)
	self.name = get_name(target)
	target:Remove()
end

function Xhl_qp_db:Unpackbulid(pos, owner)
	local pet = SpawnSaveRecord(self.package)
	if pet ~= nil then
		pet.Transform:SetPosition( pos:Get() ) 
		owner.components.huli_petleash:LinkPet(pet)
	end
	self.package = nil
end

function Xhl_qp_db:OnSave()
	local data = {
		package = self.package,
		name = self.name,
		packageuserid = self.packageuserid,
	}
	return data
end

function Xhl_qp_db:OnLoad(data)
	if data then
		self.package = data.package
		self.name = data.name
		self.packageuserid = data.packageuserid
	end
end

return Xhl_qp_db