
local  Z_HuLi_ChongDian = Class(function(self, inst)
	self.inst = inst
end)

return Z_HuLi_ChongDian
