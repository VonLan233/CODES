
local  Z_HuLi_Power = Class(function(self, inst)
	self.inst = inst
end)

return Z_HuLi_Power
