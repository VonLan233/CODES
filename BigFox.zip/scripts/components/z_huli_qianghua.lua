
local  Z_HuLi_Xhl_QP = Class(function(self, inst)
	self.inst = inst
end)

return Z_HuLi_Xhl_QP
