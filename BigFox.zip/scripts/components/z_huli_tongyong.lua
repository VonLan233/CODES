
local  Z_HuLi_TongYong = Class(function(self, inst)
	self.inst = inst
end)

return Z_HuLi_TongYong
