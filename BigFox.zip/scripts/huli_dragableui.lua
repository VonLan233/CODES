local function DragableUI(self, possavename, widget)
	local function AddPoint(self,Valid)
		for k,v in pairs(Valid) do
			if Valid[k] ==true then
				self[k].point:Show()
			else
				self[k].point:Hide()
			end
		end
	end	
	function self:OnUIAddPoint(owner,data)
		if data and data.Valid then
			local Valid = data.Valid
			AddPoint(self,Valid)
		end
	end
	self.OnUIAddPointFn = function(owner,data) self:OnUIAddPoint(owner,data) end
	self.owner:ListenForEvent("UIAddPoint", self.OnUIAddPointFn)
	local OldOnControl = self.OnControl
	self.OnControl = function(self, control, down)
		local _key = self.owner.components.huli_key
		-- if self.owner.components.playercontroller:IsControlPressed(39) and control == 29 then
		if _key:IsKeyDown(KEY_CTRL) and control == 29 then
			if down then
				self:StartDrag()
			else
				self:EndDrag()
			end
		else
			self:EndDrag()
			return OldOnControl(self, control, down)
		end
	end
	
	--self:SetPosition(190,620,0)
	-- self:MoveToFront()
	-- self:MoveToBack()
	--self:StartUpdating()
	
	function self:SetDragPosition(x, y, z)
		local pos
		if type(x) == "number" then
			pos = Vector3(x, y, z)
		else
			pos = x
		end
		self:SetPosition(pos + self.dragPosDiff)
	end

	function self:StartDrag()
		if not self.followhandler then
			local mousepos = TheInput:GetScreenPosition()
			self.dragPosDiff = self:GetPosition() - mousepos
			self.followhandler = TheInput:AddMoveHandler(function(x,y) self:SetDragPosition(x,y) end)
			self:SetDragPosition(mousepos)
			--print("self:StartDrag()")
		end
	end

	function self:EndDrag()
		if self.followhandler then
			self.followhandler:Remove()
		end
		self.followhandler = nil
		self.dragPosDiff = nil
		-- self:MoveToBack()
		--print("self:EndDrag()")
		local s_pos = widget:GetWorldPosition()
		if possavename then
			local _,data = pcall(json.encode, s_pos)
			TheSim:SetPersistentString(possavename, data, false)
		end
	end

	function self:Scale_DoDelta(delta)
		self.scale = math.max(self.scale+delta,0.1)
		self:SetScale(self.scale,self.scale,self.scale)
		self:MoveToBack()
		--print("self:Scale_DoDelta()")
	end
end

return {
	DragableUI = DragableUI,
}