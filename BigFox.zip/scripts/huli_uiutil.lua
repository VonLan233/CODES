local Text = require "widgets/text" 

local function DragableUI(self, possavename, widget)
	local OldOnControl = self.OnControl
	self.OnControl = function(self, control, down)
		local _key = self.owner.components.huli_key
		-- if self.owner.components.playercontroller:IsControlPressed(39) and control == 29 then
		if _key:IsKeyDown(KEY_CTRL) and control == 29 then
			if down then
				self:StartDrag()
			else
				self:EndDrag()
			end
		else
			self:EndDrag()
			return OldOnControl(self, control, down)
		end
	end
	
	function self:SetDragPosition(x, y, z)
		local pos
		if type(x) == "number" then
			pos = Vector3(x, y, z)
		else
			pos = x
		end
		self:SetPosition(pos + self.dragPosDiff)
	end

	function self:StartDrag()
		if not self.followhandler then
			local mousepos = TheInput:GetScreenPosition()
			self.dragPosDiff = self:GetPosition() - mousepos
			self.followhandler = TheInput:AddMoveHandler(function(x,y) self:SetDragPosition(x,y) end)
			self:SetDragPosition(mousepos)
		end
	end

	function self:EndDrag()
		if self.followhandler then
			self.followhandler:Remove()
		end
		self.followhandler = nil
		self.dragPosDiff = nil
		local s_pos = widget:GetWorldPosition()
		if possavename then
			local _,data = pcall(json.encode, s_pos)
			TheSim:SetPersistentString(possavename, data, false)
		end
	end

end

local function CtrlScale(sc_ui)
	local tiptask
	local tipstr = hl_loc("按↑/↓键放大或缩小UI", "Press the ↑/↓ keys to enlarge or reduce the ui")

	if sc_ui.tooltip then
		tipstr = sc_ui.tooltip..'\n'..tipstr
	end
	sc_ui.tooltip = tipstr
	local function DoTask()
		if tiptask then
			tiptask:Cancel()
			tiptask = nil
		end
		tiptask = sc_ui.inst:DoTaskInTime(2.5, function()
			sc_ui.tooltip = nil
		end)
	end
	
	sc_ui.OnGainFocus = function()
		DoTask()
		TheCamera:SetControllable(false)
	end
	sc_ui.OnLoseFocus = function()
		sc_ui.tooltip = tipstr
		TheCamera:SetControllable(true)
	end
	
	local sc = 1
	local OldOnControl = sc_ui.OnControl
	sc_ui.OnControl = function(sc_ui, control, down)
		if sc_ui._base.OnControl(sc_ui, control, down) then return true end
		TheCamera:SetControllable(false)
		if control == CONTROL_FOCUS_UP and down then
			sc = sc + .1
			if sc > 3 then
				sc = 3
			end
			sc_ui:SetScale(sc)
			return true
		elseif control == CONTROL_FOCUS_DOWN and down then
			sc = sc - .1
			if sc <= .3 then
				sc = .3
			end
			sc_ui:SetScale(sc)
			return true
		else
			return OldOnControl(sc_ui, control, down)
		end
	end
end

return {
	DragableUI = DragableUI,
	CtrlScale = CtrlScale,
}