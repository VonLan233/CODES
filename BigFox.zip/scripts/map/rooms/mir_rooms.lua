AddRoom("大狐狸的龙蛋", 
	{
		colour={r=0.3,g=0.2,b=0.1,a=0.3},
		value = WORLD_TILES.FOREST, 
		contents =  
		{
			countprefabs= 
			{
				miregg = 1,
			}
		}
	})