require "prefabutil"

local assets =
{
    Asset("ANIM", "anim/fox_firepit_hot.zip"),
	Asset("ATLAS", "images/inventoryimages/building.xml")
}

local prefabs =
{
    "firepit_ghost_fire",
    "collapse_small",
}

local function onhammered(inst, worker)
    inst.components.lootdropper:DropLoot()
    local x, y, z = inst.Transform:GetWorldPosition()
    SpawnPrefab("ash").Transform:SetPosition(x, y, z)
    local fx = SpawnPrefab("collapse_small")
    fx.Transform:SetPosition(x, y, z)
    fx:SetMaterial("stone")
    inst:Remove()
end

local function onfinished(inst)
	inst.AnimState:PlayAnimation("hit")
	inst:ListenForEvent("animover", inst.Remove)
	inst.SoundEmitter:PlaySound("dontstarve/common/tent_dis_pre")
end

local function onhit(inst, worker)
	inst.components.huli_workerhit:OnHit(worker)
end

local function onextinguish(inst)
    if inst.components.fueled ~= nil then
        inst.components.fueled:InitializeFuelLevel(0)
    end
end

local function ontakefuel(inst)
    inst.SoundEmitter:PlaySound("dontstarve/common/fireAddFuel")
end

local function onupdatefueled(inst)
    local fueled = inst.components.fueled

    fueled.rate = TheWorld.state.israining and 1 + TUNING.FIREPIT_RAIN_RATE * TheWorld.state.precipitationrate or 1

    if inst.components.burnable ~= nil then
        inst.components.burnable:SetFXLevel(fueled:GetCurrentSection(), fueled:GetSectionPercent())
    end
end

local SECTION_STATUS =
{
    [0] = "OUT",
    [1] = "EMBERS",
    [2] = "LOW",
    [3] = "NORMAL",
    [4] = "HIGH",
}
local function getstatus(inst)
    return SECTION_STATUS[inst.components.fueled:GetCurrentSection()]
end

local function onbuilt(inst, data)
    local doer = data.builder
    if doer ~= nil then
        inst._player = {
            userid = doer.userid,
            name = doer.name,
        }
    end
    inst.AnimState:PlayAnimation("place")
    inst.AnimState:PushAnimation("idle", false)
    inst.SoundEmitter:PlaySound("dontstarve/common/fireAddFuel")
end

local function OnHaunt(inst, haunter)
    if math.random() <= TUNING.HAUNT_CHANCE_RARE and
        inst.components.fueled ~= nil and
        not inst.components.fueled:IsEmpty() then
        inst.components.fueled:DoDelta(TUNING.MED_FUEL)
        inst.components.hauntable.hauntvalue = TUNING.HAUNT_SMALL
        return true
    --#HAUNTFIX
    --elseif math.random() <= TUNING.HAUNT_CHANCE_HALF and
        --inst.components.workable ~= nil and
        --inst.components.workable:CanBeWorked() then
        --inst.components.workable:WorkedBy(haunter, 1)
        --inst.components.hauntable.hauntvalue = TUNING.HAUNT_SMALL
        --return true
    end
    return false
end

local function onsave(inst, data)  
	data._player = inst._player
	data.workleft = inst.components.workable.workleft
end

local function onload(inst, data) 
    if data ~= nil then
        inst._player = data._player
    end
	if data.workleft ~= nil then
		inst.components.workable.workleft = data.workleft
	end
end

local function get_name(inst)
	local name = STRINGS.NAMES[string.upper(inst.prefab)]
	local ownername = inst._ownername:value()
	local workleft = inst._workleft:value()
	local maxwork = inst._maxwork:value()
	local named = name..'\n业主:'..ownername..'\n耐久度:'..workleft..'/'..maxwork
	
	return named
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddMiniMapEntity()
    inst.entity:AddNetwork()

	inst._workleft = net_int(inst.GUID, "huli_firepit_ghost._workleft")
	inst._maxwork = net_int(inst.GUID, "huli_firepit_ghost._maxwork")
	inst._ownername = net_string(inst.GUID, "huli_firepit_ghost._ownername")
	inst.displaynamefn = get_name

    MakeObstaclePhysics(inst, .35)

    inst.MiniMapEntity:SetIcon("firepit_h.tex")
    inst.MiniMapEntity:SetPriority(1)

    inst.AnimState:SetBank("fox_firepit_hot")
    inst.AnimState:SetBuild("fox_firepit_hot")
    inst.AnimState:PlayAnimation("idle", false)

    inst:AddTag("campfire")
    inst:AddTag("structure")
	inst:AddTag("huli_build")
    inst:AddTag("wildfireprotected")

    --cooker (from cooker component) added to pristine state for optimization
    inst:AddTag("cooker")

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    -----------------------
    inst:AddComponent("burnable")
    --inst.components.burnable:SetFXLevel(2)
    inst.components.burnable:AddBurnFX("firepit_ghost_fire", Vector3(0, 0, 0))
    inst:ListenForEvent("onextinguish", onextinguish)

    -------------------------
    inst:AddComponent("lootdropper")
	inst:AddComponent("huli_workerhit")
    inst:AddComponent("workable")
    inst.components.workable:SetWorkAction(ACTIONS.HAMMER)
    inst.components.workable:SetWorkLeft(TUNING.HULIBUILD_MINWORK)
    inst.components.workable:SetOnFinishCallback(onhammered)
    inst.components.workable:SetOnWorkCallback(onhit)    
	
	inst.durabletask = inst:DoPeriodicTask(TUNING.HULIBUILD_NAIJIUDU_TASK, function() 
		local w = inst.components.workable
		if w.workleft > 0 then
			w.workleft = w.workleft - TUNING.HULIBUILD_NAIJIUDU_CONSUME
		else
			local fx = SpawnPrefab("collapse_big")
			fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
			fx:SetMaterial("wood")
			onfinished(inst)
		end
	end)

    -------------------------
    inst:AddComponent("cooker")
    -------------------------
    inst:AddComponent("fueled")
    inst.components.fueled.maxfuel = TUNING.FIREPIT_FUEL_MAX*3
    inst.components.fueled.accepting = true
    inst.components.fueled:SetSections(4)
    inst.components.fueled.bonusmult = TUNING.FIREPIT_BONUS_MULT
    inst.components.fueled.ontakefuelfn = ontakefuel
    inst.components.fueled:SetUpdateFn(onupdatefueled)
    inst.components.fueled:SetSectionCallback(function(section)
        if section == 0 then
            inst.components.burnable:Extinguish()
        else
            if not inst.components.burnable:IsBurning() then
                inst.components.burnable:Ignite()
            end
            inst.components.burnable:SetFXLevel(section, inst.components.fueled:GetSectionPercent())
        end
    end)
    inst.components.fueled:InitializeFuelLevel(TUNING.FIREPIT_FUEL_START)

    -----------------------------

    inst:AddComponent("hauntable")
    inst.components.hauntable.cooldown = TUNING.HAUNT_COOLDOWN_HUGE
    inst.components.hauntable:SetOnHauntFn(OnHaunt)

    -----------------------------

    inst:AddComponent("inspectable")
    inst.components.inspectable.getstatus = getstatus

	inst._player = nil
	inst.maxwork = TUNING.HULIBUILD_MAXWORK
	
	inst.OnSave = onsave
    inst.OnLoad = onload
    inst:ListenForEvent("onbuilt", onbuilt)
	
	inst:DoPeriodicTask(1.01, function() 
		inst._workleft:set(inst.components.workable.workleft) 
		inst._maxwork:set(inst.maxwork) 
		if inst._player ~= nil then
			inst._ownername:set(inst._player.name) 
		else
			inst._ownername:set('NONE') 
		end
	end)
	function inst.components.workable:Destroy(destroyer)
		if self:CanBeWorked() then
			self:WorkedBy(destroyer, 300)
			self.inst.SoundEmitter:PlaySound("dontstarve/common/destroy_stone")
		end
	end

    return inst
end

return Prefab("firepit_ghost", fn, assets, prefabs),
    MakePlacer("firepit_ghost_placer", "fox_firepit_hot", "fox_firepit_hot", "preview")
