local assets = {
    Asset("ANIM", "anim/fox_hat_fox.zip"),
    Asset("ANIM", "anim/fox_swap_hat_fox.zip"),
	Asset("ATLAS", "images/inventoryimages/items.xml"),
	Asset("IMAGE", "images/inventoryimages/items.tex"),
}

local function getab_count(inst)
	return .45 * 1.0257777^inst.level
end

local function insu_count(inst)
	return math.ceil(TUNING.INSULATION_TINY * 1.1348^inst.level)
end

local function wate_count(inst)
	return TUNING.WATERPROOFNESS_SMALLMED * 1.042^inst.level
end

local function abper(inst)
	return inst.components.armor.absorb_percent * 100
end

local function insu(inst)
	return inst.components.insulator.insulation
end

local function wate(inst)
	return inst.components.waterproofer.effectiveness * 100
end

local function onusehat(inst)
    local owner = inst.components.inventoryitem.owner
    if owner then
        owner.sg:GoToState("hide")
    end
end

local function unequip(inst)
	if inst.components.armor.condition > 0 then
		inst.components.armor:SetAbsorption(getab_count(inst))
		inst.components.insulator:SetInsulation(insu_count(inst))
		inst.components.waterproofer:SetEffectiveness(wate_count(inst))
	else
		inst.components.armor.condition = 0
		inst.components.armor:SetAbsorption(0)
		inst.components.insulator:SetInsulation(0)
		inst.components.waterproofer:SetEffectiveness(0)
	end
	--[[inst._condition:set(inst.components.armor.condition)
	inst._absorb_percent:set(abper(inst))
	inst._insulation:set(insu(inst))
	inst._effectiveness:set(wate(inst))]]
end

local function stopusinghat(inst, data)
	local hat = inst.components.inventory and inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HEAD)
	if hat.components.armor.condition > 0 then
		if hat and not (data.statename == "hide_idle" or data.statename == "hide") then
			hat.components.armor:SetAbsorption(getab_count(hat))
			hat.components.waterproofer:SetEffectiveness(wate_count(hat))
			hat.components.useableitem:StopUsingItem()
		else
			hat.components.armor:SetAbsorption(1)
			hat.components.waterproofer:SetEffectiveness(1)
		end
	else
		hat.components.armor:SetAbsorption(0)
		hat.components.insulator:SetInsulation(0)
		hat.components.waterproofer:SetEffectiveness(0)
	end
end

local function onequip(inst, owner) 
	owner.AnimState:OverrideSymbol("swap_hat", "fox_swap_foxhat", "swap_hat")
	owner.AnimState:Show("HAT")
	owner.AnimState:Hide("HAT_HAIR")
	owner.AnimState:Show("HAIR_NOHAT")
	owner.AnimState:Show("HAIR")
	local armor = inst.components.armor
	if armor.condition > 0 then
		inst.condition_val = inst:DoPeriodicTask(TUNING.FOXMASK_NAIJIUDU_TASK, function() 
			if armor.condition > 0 then
				armor.condition = armor.condition - TUNING.FOXMASK_NAIJIUDU_CONSUME
				inst:PushEvent("percentusedchange", { percent = armor:GetPercent() })
			elseif armor.condition <= 0 then
				if inst.condition_val then 
					inst.condition_val:Cancel() 
					inst.condition_val = nil 
				end
				armor.condition = 0
			end
		end)
	end
	inst:ListenForEvent("newstate", stopusinghat, owner) 
end

local function onunequip(inst, owner) 
	owner.AnimState:Hide("HAT")
	owner.AnimState:Hide("HAT_HAIR")
	owner.AnimState:Show("HAIR_NOHAT")
	owner.AnimState:Show("HAIR")
	if owner:HasTag("player") then
		owner.AnimState:Show("HEAD")
		owner.AnimState:Hide("HEAD_HAIR")
	end
	if inst.condition_val then 
		inst.condition_val:Cancel() 
		inst.condition_val = nil 
	end
	inst:RemoveEventCallback("newstate", stopusinghat, owner)
	unequip(inst)
end

local function TongYongFn(inst, armor)
	if inst.condition_val then 
		inst.condition_val:Cancel() 
		inst.condition_val = nil 
	end
	if inst.components.equippable:IsEquipped() then
		inst.condition_val = inst:DoPeriodicTask(TUNING.FOXMASK_NAIJIUDU_TASK, function() 
			if armor.condition > 0 then
				armor.condition = armor.condition - TUNING.FOXMASK_NAIJIUDU_CONSUME
				inst:PushEvent("percentusedchange", { percent = armor:GetPercent() })
			elseif armor.condition <= 0 then
				if inst.condition_val then 
					inst.condition_val:Cancel() 
					inst.condition_val = nil 
				end
			end
		end)
	end
	if inst.level >= inst.maxlevel then
		inst.level = inst.maxlevel
	end
	if armor.condition >= armor.maxcondition then
		armor.condition = armor.maxcondition
	end
	inst:PushEvent("percentusedchange", { percent = armor:GetPercent() })	
end

local function val(inst, item)
	for k, v in pairs(TUNING.ITEM.foxmask) do 
		if item.prefab == v[1] then
			if v[3] then
				return v[2], v[3]
			else
				return v[2], 0
			end
		end
	end
	return 0, 0
end

local function QiangHuaFn(inst, giver, item)
	local armor = inst.components.armor
	local rand = .83^inst.level*HULI_EQUIPLEVELUP_SET
	local rand2 = .9^inst.level*HULI_EQUIPLEVELUP_SET
	-- local gin_bj = giver.components.inventory and giver.components.inventory:Has("huligem_bj", 1)
	local gin_xy = giver.components.inventory and giver.components.inventory:Has("huligem_xy", 1)
	local value, lev = val(inst, item)
	
	if item.prefab == "huligem_qh" then
		if inst.level < inst.maxlevel then
			if gin_xy then
				rand = rand + .2
				giver.components.inventory:ConsumeByName("huligem_xy", 1)
			end
			if math.random() < rand then
				inst.level = inst.level + lev
				giver.components.talker:Say("强化成功")
			else
				giver.components.talker:Say("强化失败")
			end
			armor.condition = armor.condition + (armor.maxcondition* .02)
		end
	elseif item.prefab == "huligem_gjqh" then
		if inst.level < inst.maxlevel then
			if inst.level < 9 then
				inst.level = inst.level + lev
				giver.components.talker:Say("强化成功")
				if armor.condition < armor.maxcondition then
					armor.condition = armor.condition + (armor.maxcondition* .02)
				end
			else
				if gin_xy then
					rand2 = rand2 + .2
					giver.components.inventory:ConsumeByName("huligem_xy", 1)
				end
				if math.random() < rand2 then
					inst.level = inst.level + lev
					giver.components.talker:Say("强化成功")
				else
					giver.components.talker:Say("强化失败")
				end
				armor.condition = armor.condition + (armor.maxcondition* .02)
			end
		end
	end
	armor.maxcondition = math.ceil(1000 * 1.165906^inst.level)
	inst.components.armor:SetAbsorption(getab_count(inst))
	inst.components.insulator:SetInsulation(insu_count(inst))
	inst.components.waterproofer:SetEffectiveness(wate_count(inst))

	item.components.stackable:Get():Remove()
	TongYongFn(inst, armor)
end

local function JinHuaFn(inst, giver, item)
	local armor = inst.components.armor
	if item.prefab == "huligem_jh" then
		if inst.level >= inst.maxlevel then
			if armor.condition > 0 then
				local fmw = SpawnPrefab("foxmask_new")
				if fmw ~= nil then
					local fca = fmw.components.armor
					if giver and giver.components.inventory then
						inst:Remove()
						giver.components.inventory:GiveItem(fmw)
						giver.components.talker:Say("进化成功")
						fmw.level = 0
						fca.condition = armor.condition
						fca.maxcondition = math.ceil(2000 * 1.130699^fmw.level)
						if fca.condition >= fca.maxcondition then
							fca.condition = fca.maxcondition
						end
						fca:SetAbsorption(fca.absorb_percent + fmw.level / 100)
						fmw._insu = insu_count(inst)
						fmw.components.insulator:SetInsulation(insu_count(inst))
						fmw._wate = wate_count(inst)
						fmw.components.waterproofer:SetEffectiveness(wate_count(inst))
						fmw:PushEvent("percentusedchange", { percent = fca:GetPercent() })
					end
					item.components.stackable:Get():Remove()
				end
			else
				giver.components.talker:Say("耐久度过低,无法进化!")
			end
		else
			giver.components.talker:Say("等级未满,无法进化!")
		end
	end
end

local function XiuLiFn(inst, giver, item)
	local armor = inst.components.armor
	local xvalue = armor.maxcondition - armor.condition
	local stkitem = item.components.stackable and item.components.stackable:StackSize()
	local value = val(inst, item)
	
	if armor.condition < armor.maxcondition - 10 then						
		if xvalue / value - stkitem >= 0 then
			armor.condition = armor.condition + value * stkitem
			item:Remove()
		else
			local Consumeitem = math.ceil(xvalue / value)
			local items = item.components.stackable and  item.components.stackable:Get(Consumeitem)
			armor.condition = armor.condition + value * Consumeitem
			items:Remove()
		end	
		giver.components.talker:Say("修理成功!")
	else
		giver.components.talker:Say("已经修好了!")
	end
	TongYongFn(inst, armor)
end

local function onsave(inst, data) 
	data.level = inst.level
	data.condition = inst.components.armor.condition
	data.maxcondition = inst.components.armor.maxcondition
	data.absorb_percent = inst.components.armor.absorb_percent
	data.insulation = inst.components.insulator.insulation
	data.effectiveness = inst.components.waterproofer.effectiveness
end

local function onlaod(inst, data)
	if data then
		inst.level = data.level
		inst.components.armor.condition = data.condition
		inst.components.armor.maxcondition = data.maxcondition
		inst.components.armor:SetAbsorption(data.absorb_percent)
		inst.components.insulator.insulation = data.insulation
		inst.components.waterproofer.effectiveness = data.effectiveness
		--[[inst._level:set(data.level)
		inst._condition:set(data.condition)
		inst._maxcondition:set(data.maxcondition)
		inst._absorb_percent:set(data.absorb_percent * 100)
		inst._insulation:set(data.insulation)
		inst._effectiveness:set(data.effectiveness * 100)]]
	end
end

local function get_name(inst)
	local name = STRINGS.NAMES[string.upper(inst.prefab)]
	local level = inst._level:value()
	local maxlevel = inst._maxlevel:value()
	local condition = inst._condition:value()
	local maxcondition = inst._maxcondition:value()
	local absorb_percent = inst._absorb_percent:value()
	local insulation = inst._insulation:value()
	local effectiveness = inst._effectiveness:value()
	--local named = name.."\n强化等级"..level.."/"..maxlevel.."\n耐久度:"..condition.."/"..maxcondition.."\n防御力:"..absorb_percent.."%\n防热:"..insulation.."\n防水:"..effectiveness.."%\n "
	local named = name.."+"..level.."/"..maxlevel.."\n耐久度:"..condition.."/"..maxcondition.."\n防御力:"..absorb_percent.."%\n防热:"..insulation.."\n防水:"..effectiveness.."%"
	if get_modinfoname() then
		named = name.."+"..level..'/'..maxlevel
	end
	return named
end

local function foxmask()
	local inst = CreateEntity()

	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()
	
	MakeInventoryPhysics(inst)  
	
	inst._level = net_shortint(inst.GUID, "foxmask.level")
	inst._maxlevel = net_shortint(inst.GUID, "foxmask.maxlevel")	
	inst._condition = net_shortint(inst.GUID, "foxmask._condition")
	inst._maxcondition = net_shortint(inst.GUID, "foxmask._maxcondition")
	inst._absorb_percent = net_shortint(inst.GUID, "foxmask._absorb_percent")
	inst._insulation = net_shortint(inst.GUID, "foxmask._insulation")
	inst._effectiveness = net_shortint(inst.GUID, "foxmask._effectiveness")
	
    inst.AnimState:SetBank("fox_foxhat")
    inst.AnimState:SetBuild("fox_foxhat")
    inst.AnimState:PlayAnimation("anim")
	inst.AnimState:PlayAnimation("idle")
	inst.displaynamefn = get_name
	inst:AddTag("huli_level_item")

	inst.entity:SetPristine()
	inst:AddTag("huli_foxmask")

	if not TheWorld.ismastersim then
		return inst
	end
	
	inst:AddComponent("insulator")
    inst.components.insulator:SetInsulation(TUNING.INSULATION_TINY)
	inst.components.insulator:SetSummer()
	
	inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.atlasname = "images/inventoryimages/items.xml"
	
	inst:AddComponent("inspectable")	
	
	inst:AddComponent("timer")
	
	inst:AddComponent("waterproofer")
	inst.components.waterproofer:SetEffectiveness(TUNING.WATERPROOFNESS_SMALLMED)
	
	inst:AddComponent("useableitem")
	inst.components.useableitem:SetOnUseFn(onusehat)
	
	-- inst:AddComponent("trader")
	-- inst.components.trader:SetAcceptTest(setaccepttest)
	-- inst.components.trader.onaccept = onaccept
	-- inst.components.trader:Enable()
	
	inst:AddComponent("equippable")
	inst.components.equippable.equipslot = EQUIPSLOTS.HEAD
	inst.components.equippable:SetOnEquip( onequip )
	inst.components.equippable:SetOnUnequip( onunequip )
	
	inst:AddComponent("armor")
	inst.components.armor.condition = 1000
	inst.components.armor.maxcondition = 1000
	inst.components.armor:SetAbsorption(.45)
	
	inst.QiangHuaFn = QiangHuaFn
	inst.XiuLiFn = XiuLiFn
	inst.JinHuaFn = JinHuaFn
	inst.namefn = get_name
	inst.level = 0
	inst.maxlevel = 15
	inst.OnSave = onsave
	inst.OnLoad = onlaod
	
	inst._maxlevel:set(inst.maxlevel)
	inst:DoPeriodicTask(0, function() 
	inst._level:set(inst.level)
	inst._condition:set(inst.components.armor.condition)
	inst._maxcondition:set(inst.components.armor.maxcondition)
	inst._absorb_percent:set(inst.components.armor.absorb_percent * 100)
	inst._insulation:set(inst.components.insulator.insulation)
	inst._effectiveness:set(inst.components.waterproofer.effectiveness * 100) end)
	
	function inst.components.armor:SetCondition(amount)
		self.condition = math.min(amount, self.maxcondition)
		self.inst:PushEvent("percentusedchange", { percent = self:GetPercent() })
		
		if self.condition <= 0 then
			self.condition = 0
		end
	end
	return inst
end

-- STRINGS.NAMES.FOXMASK = "狐狸面具"
-- STRINGS.RECIPE_DESC.FOXMASK = "是一个综合型\n的笑脸面具呢."
-- STRINGS.CHARACTERS.GENERIC.DESCRIBE.FOXMASK = "防止伤害."

return Prefab("common/inventory/foxmask", foxmask, assets)
