local assets = {
    Asset("ANIM", "anim/foxmask_new.zip"),
    Asset("ANIM", "anim/swap_foxmask_new.zip"),
	Asset("ATLAS", "images/inventoryimages/foxmask_new.xml"),
	Asset("IMAGE", "images/inventoryimages/foxmask_new.tex"),
}

local function getab_count(inst)
	return .55 * 1.022^inst.level
end

local function abper(inst)
	return inst.components.armor.absorb_percent * 100
end

local function insu(inst)
	if inst.components.armor.condition > 0 then
		if inst._insu ~= nil then
			return inst._insu
		end
		return TUNING.INSULATION_SMALL
	end
	return inst.components.insulator.insulation
end

local function wate(inst)
	if inst.components.armor.condition > 0 then
		if inst._wate ~= nil then
			return inst._wate
		end
		return TUNING.WATERPROOFNESS_SMALLMED
	end
	return inst.components.waterproofer.effectiveness
end

local function onusehat(inst)
    local owner = inst.components.inventoryitem.owner
    if owner then
        owner.sg:GoToState("hide")
    end
end

local function unequip(inst)
	if inst.components.armor.condition > 0 then
		inst.components.armor:SetAbsorption(getab_count(inst))
		inst.components.insulator:SetInsulation(insu(inst))
		inst.components.waterproofer:SetEffectiveness(wate(inst))
	else
		inst.components.armor.condition = 0
		inst.components.armor:SetAbsorption(0)
		inst.components.insulator:SetInsulation(0)
		inst.components.waterproofer:SetEffectiveness(0)
	end
	--[[inst._condition:set(inst.components.armor.condition)
	inst._absorb_percent:set(abper(inst))
	inst._insulation:set(insu(inst))
	inst._effectiveness:set(wate(inst)*100)
	inst:PushEvent("percentusedchange", { percent = armor:GetPercent() })]]
end

local function stopusinghat(inst, data)
	local hat = inst.components.inventory and inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HEAD)
	if hat.components.armor.condition > 0 then
		if hat and not (data.statename == "hide_idle" or data.statename == "hide") then
			hat.components.armor:SetAbsorption(getab_count(hat))
			hat.components.waterproofer:SetEffectiveness(wate(hat))
			--hat._effectiveness:set(wate(hat)*100)
			hat.components.useableitem:StopUsingItem()
		else
			hat.components.armor:SetAbsorption(1)
			hat.components.waterproofer:SetEffectiveness(1)
			--hat._effectiveness:set(hat.components.waterproofer.effectiveness * 100)
		end
	else
		hat.components.armor:SetAbsorption(0)
		hat.components.insulator:SetInsulation(0)
		hat.components.waterproofer:SetEffectiveness(0)
		--hat._effectiveness:set(hat.components.waterproofer.effectiveness)
	end
end

local function onequip(inst, owner) 
	owner.AnimState:OverrideSymbol("swap_hat", "fox_swap_foxhat", "swap_hat")
	owner.AnimState:Show("HAT")
	owner.AnimState:Hide("HAT_HAIR")
	owner.AnimState:Show("HAIR_NOHAT")
	owner.AnimState:Show("HAIR")
	local armor = inst.components.armor
	if armor.condition > 0 then
		inst.condition_val = inst:DoPeriodicTask(TUNING.FOXMASKNEW_NAIJIUDU_TASK, function() 
			if armor.condition > 0 then
				armor.condition = armor.condition - TUNING.FOXMASKNEW_NAIJIUDU_CONSUME
				inst:PushEvent("percentusedchange", { percent = armor:GetPercent() })
			elseif armor.condition <= 0 then
				if inst.condition_val then 
					inst.condition_val:Cancel() 
					inst.condition_val = nil 
				end
				armor.condition = 0
			end
		--[[inst._condition:set(armor.condition)
		inst._absorb_percent:set(abper(inst))
		inst._insulation:set(insu(inst))]]
		--inst._effectiveness:set(wate(inst))
		end)
	end
	inst:ListenForEvent("newstate", stopusinghat, owner) 
end

local function onunequip(inst, owner) 
	owner.AnimState:Hide("HAT")
	owner.AnimState:Hide("HAT_HAIR")
	owner.AnimState:Show("HAIR_NOHAT")
	owner.AnimState:Show("HAIR")
	if owner:HasTag("player") then
		owner.AnimState:Show("HEAD")
		owner.AnimState:Hide("HEAD_HAIR")
	end
	if inst.condition_val then 
		inst.condition_val:Cancel() 
		inst.condition_val = nil 
	end
	inst:RemoveEventCallback("newstate", stopusinghat, owner)
	unequip(inst)
end
local function TongYongFn(inst, armor)
	if inst.condition_val then 
		inst.condition_val:Cancel() 
		inst.condition_val = nil 
	end
	if inst.components.equippable:IsEquipped() then
		inst.condition_val = inst:DoPeriodicTask(TUNING.FOXMASKNEW_NAIJIUDU_TASK, function() 
			if armor.condition > 0 then
				armor.condition = armor.condition - TUNING.FOXMASKNEW_NAIJIUDU_CONSUME
				inst:PushEvent("percentusedchange", { percent = armor:GetPercent() })
			elseif armor.condition <= 0 then
				if inst.condition_val then 
					inst.condition_val:Cancel() 
					inst.condition_val = nil 
				end
				armor.condition = 0
			end
		end)
	end
	if inst.level >= inst.maxlevel then
		inst.level = inst.maxlevel
	end
	if armor.condition >= armor.maxcondition then
		armor.condition = armor.maxcondition
	end
	inst:PushEvent("percentusedchange", { percent = armor:GetPercent() })	
end

local function val(inst, item)
	for k, v in pairs(TUNING.ITEM.foxmask_new) do 
		if item.prefab == v[1] then
			if v[3] then
				return v[2], v[3]
			else
				return v[2], 0
			end
		end
	end
	return 0, 0
end

local function QiangHuaFn(inst, giver, item)
	local armor = inst.components.armor
	local rand = .83^inst.level*HULI_EQUIPLEVELUP_SET
	local rand2 = .9^inst.level*HULI_EQUIPLEVELUP_SET
	-- local gin_bj = giver.components.inventory and giver.components.inventory:Has("huligem_bj", 1)
	local gin_xy = giver.components.inventory and giver.components.inventory:Has("huligem_xy", 1)
	local value, lev = val(inst, item)
	
	if item.prefab == "huligem_qh" then
		if inst.level < inst.maxlevel then
			if gin_xy then
				rand = rand + .2
				giver.components.inventory:ConsumeByName("huligem_xy", 1)
			end
			if math.random() < rand then
				inst.level = inst.level + lev
				giver.components.talker:Say("强化成功")
			else
				giver.components.talker:Say("强化失败")
			end
			armor.condition = armor.condition + (armor.maxcondition* .02)
		end
	elseif item.prefab == "huligem_gjqh" then
		if inst.level < inst.maxlevel then
			if inst.level < 9 then
				inst.level = inst.level + lev
				giver.components.talker:Say("强化成功")
				if armor.condition < armor.maxcondition then
					armor.condition = armor.condition + (armor.maxcondition* .02)
				end
			else
				if gin_xy then
					rand2 = rand2 + .2
					giver.components.inventory:ConsumeByName("huligem_xy", 1)
				end
				if math.random() < rand2 then
					inst.level = inst.level + lev
					giver.components.talker:Say("强化成功")
				else
					giver.components.talker:Say("强化失败")
				end
				armor.condition = armor.condition + (armor.maxcondition* .02)
			end
		end
	end
	armor.maxcondition = math.ceil(2000 * 1.130699^inst.level)
	inst.components.armor:SetAbsorption(getab_count(inst))
	inst.components.insulator:SetInsulation(insu(inst))
	inst.components.waterproofer:SetEffectiveness(wate(inst))

	item.components.stackable:Get():Remove()
	TongYongFn(inst, armor)
end

local function XiuLiFn(inst, giver, item)
	local armor = inst.components.armor
	local xvalue = armor.maxcondition - armor.condition
	local stkitem = item.components.stackable and item.components.stackable:StackSize()
	local value = val(inst, item)
	
	if armor.condition < armor.maxcondition - 10 then						
		if xvalue / value - stkitem >= 0 then
			armor.condition = armor.condition + value * stkitem
			item:Remove()
		else
			local Consumeitem = math.ceil(xvalue / value)
			local items = item.components.stackable and  item.components.stackable:Get(Consumeitem)
			armor.condition = armor.condition + value * Consumeitem
			items:Remove()
		end	
		giver.components.talker:Say("修理成功!")
	else
		giver.components.talker:Say("已经修好了!")
	end
	TongYongFn(inst, armor)
end

local function onsave(inst, data) 
	data.level = inst.level
	data.condition = inst.components.armor.condition
	data.maxcondition = inst.components.armor.maxcondition
	data.absorb_percent = inst.components.armor.absorb_percent
	data._insu = inst._insu
	data.insulation = inst.components.insulator.insulation
	data._wate = inst._wate
	data.effectiveness = inst.components.waterproofer.effectiveness
end

local function onlaod(inst, data)
	if data then
		inst.level = data.level
		inst.components.armor.condition = data.condition
		inst.components.armor.maxcondition = data.maxcondition
		inst.components.armor:SetAbsorption(data.absorb_percent)
		inst._insu = data._insu
		inst.components.insulator.insulation = data.insulation
		inst._wate = data._wate
		inst.components.waterproofer.effectiveness = data.effectiveness
		--[[inst._level:set(data.level)
		inst._condition:set(data.condition)
		inst._maxcondition:set(data.maxcondition)
		inst._absorb_percent:set(data.absorb_percent * 100)
		inst._insulation:set(data.insulation)
		inst._effectiveness:set(data.effectiveness * 100)]]
	end
end

local function get_name(inst)
	local name = STRINGS.NAMES[string.upper(inst.prefab)]
	local level = inst._level:value()
	local maxlevel = inst._maxlevel:value()
	local condition = inst._condition:value()
	local maxcondition = inst._maxcondition:value()
	local absorb_percent = inst._absorb_percent:value()
	local insulation = inst._insulation:value()
	local effectiveness = inst._effectiveness:value()
	--local named = name.."\n强化等级"..level.."/"..maxlevel.."\n耐久度:"..condition.."/"..maxcondition.."\n防御力:"..absorb_percent.."%\n防热:"..insulation.."\n防水:"..effectiveness.."%\n "
	local named = name.."+"..level..'/'..maxlevel.."\n耐久度:"..condition.."/"..maxcondition.."\n防御力:"..absorb_percent.."%\n防热:"..insulation.."\n防水:"..effectiveness.."%"
	if get_modinfoname() then
		named = name.."+"..level..'/'..maxlevel
	end
	return named
end

local function foxmask_new()
	local inst = CreateEntity()

	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()
	
	MakeInventoryPhysics(inst)  
	
	inst._level = net_shortint(inst.GUID, "foxmask_new.level")
	inst._maxlevel = net_shortint(inst.GUID, "foxmask_new.maxlevel")	
	inst._condition = net_shortint(inst.GUID, "foxmask_new._condition")
	inst._maxcondition = net_shortint(inst.GUID, "foxmask_new._maxcondition")
	inst._absorb_percent = net_shortint(inst.GUID, "foxmask_new._absorb_percent")
	inst._insulation = net_shortint(inst.GUID, "foxmask_new._insulation")
	inst._effectiveness = net_shortint(inst.GUID, "foxmask_new._effectiveness")
	
	inst.AnimState:SetBank("foxmask")
    inst.AnimState:SetBuild("foxmask_new")
	inst.AnimState:PlayAnimation("idle")
	inst.displaynamefn = get_name
	inst:AddTag("huli_level_item")

	inst.entity:SetPristine()
	if not TheWorld.ismastersim then
		return inst
	end
	
	inst:AddComponent("insulator")
    inst.components.insulator:SetInsulation(TUNING.INSULATION_SMALL)
	inst.components.insulator:SetSummer()
	
	inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.atlasname = "images/inventoryimages/foxmask_new.xml"
	
	inst:AddComponent("inspectable")	
	
	inst:AddComponent("timer")
	
	inst:AddComponent("waterproofer")
	inst.components.waterproofer:SetEffectiveness(TUNING.WATERPROOFNESS_SMALLMED)
	
	inst:AddComponent("useableitem")
	inst.components.useableitem:SetOnUseFn(onusehat)
	
	-- inst:AddComponent("trader")
	-- inst.components.trader:SetAcceptTest(setaccepttest)
	-- inst.components.trader.onaccept = onaccept
	-- inst.components.trader:Enable()
	
	inst:AddComponent("equippable")
	inst.components.equippable.equipslot = EQUIPSLOTS.HEAD
	inst.components.equippable:SetOnEquip( onequip )
	inst.components.equippable:SetOnUnequip( onunequip )
	
	inst:AddComponent("armor")
	inst.components.armor.condition = 2000
	inst.components.armor.maxcondition = 2000
	inst.components.armor:SetAbsorption(.55)
	
	inst.QiangHuaFn = QiangHuaFn
	inst.XiuLiFn = XiuLiFn
	inst.namefn = get_name
	inst.level = 0
	inst.maxlevel = 20
	inst._insu = nil
	inst._wate = nil
	inst.OnSave = onsave
	inst.OnLoad = onlaod
	
	inst._maxlevel:set(inst.maxlevel)
	inst:DoPeriodicTask(0, function() 
		inst._level:set(inst.level)
		inst._condition:set(inst.components.armor.condition)
		inst._maxcondition:set(inst.components.armor.maxcondition)
		inst._absorb_percent:set(inst.components.armor.absorb_percent * 100)
		if inst._insu ~= nil and inst.components.insulator.insulation > 0 then
			inst._insulation:set(inst._insu)
		else
			inst._insulation:set(inst.components.insulator.insulation)
		end
		if inst._wate ~= nil and inst.components.waterproofer.effectiveness > 0 and inst.components.waterproofer.effectiveness < 1 then
			inst._effectiveness:set(inst._wate * 100) 
		else
			inst._effectiveness:set(inst.components.waterproofer.effectiveness * 100) 
		end
	end)
	
	function inst.components.armor:SetCondition(amount)
		if self.indestructible then
			return
		end
		self.condition = math.min(amount, self.maxcondition)
		self.inst:PushEvent("percentusedchange", { percent = self:GetPercent() })
		
		if self.condition <= 0 then
			self.condition = 0
		end
	end

	return inst
end

-- STRINGS.NAMES.FOXMASK_NEW = "狐狸面具[白]"
-- STRINGS.RECIPE_DESC.FOXMASK_NEW = "拥有强大的\n防御能力."
-- STRINGS.CHARACTERS.GENERIC.DESCRIBE.FOXMASK_NEW = "防止伤害."

return Prefab("common/inventory/foxmask_new", foxmask_new, assets)
