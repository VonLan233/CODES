local gf_dig = require "strings_gf_dig"
local gf_mine = require "strings_gf_mine"
local gf_chopped = require "strings_gf_chopped"

local assets=
{
    Asset("ANIM", "anim/gumifan.zip"),
    Asset("ANIM", "anim/swap_gumifan.zip"),
	Asset( "SOUNDPACKAGE" , "sound/wharangfan.fev" ),
	Asset( "SOUND" , "sound/wharangfan.fsb" ),
    Asset("ATLAS", "images/inventoryimages/items.xml"),
	Asset("IMAGE", "images/inventoryimages/items.tex")
}
local function OnFinishedWork(inst, data)
    local on_chopped = {"呵呵!",
		"遥远的东方有一条龙.",
		"那看起来很有趣.",
		"它的名字叫中国!",
		"你在做什么?",
		"烧了树!",
		"你吃木头对吧?",
		"我要一个IPhone 6 Plus.",
		"你不能破坏大自然.\n但是我不关心.",
		"这是什么声音?",
		"好的",
		"知道古剑奇谭吗？",
		"我是古剑奇谭的小狐狸!",}
	local on_mine= {
        "摇起来!",
		"滚开!",
		"看起来好有趣.",
		"妲己，我才不是那个妖狐呢.",
		"你在做什么?",
		"你不会吃石头对吧？.",
		"听说B站的UP主“爱喝假酒的FA”在用我做解说?",
		"我要卖肾，用上IPhone 6 Plus.",
		"花千骨.",
		"猎狗是什么?",
		"没有的啦!",
		"我是卖报的小黄家!",  }
	local on_hammer= {
        "霹雳啪噼哩啪。。!",
		"樱桃小丸子!",
		"手也可以当锤子!",
		"我要去中国.",
		"中国最美!",
		"长城不知道是什么.",
		"你知道黄河吗?",
		"我想起英雄联盟的阿狸了.",
		"我要去召唤师峡谷.",
		"猪猪.", }
	local on_dig= {
        "挖挖挖.",
		"我是淘金者!",
		"挖金子双人版?",
		"小霸王游戏机的淘金者玩过吗？.",
		"我要挖点东西.",
		"我最好找主人帮忙!",
		"有没有觉得我很时尚!",
		"会不会从里面蹦出一个孙悟空?",}
	local on_net= {
        "哇!",
		"可以抓蝴蝶!",
		"这个是因特网吗？可以上QQ吗？!",
		"我要当蜘蛛，这样我就可以上网了.",
		"帮我包住这个秘密哦!",
		"我要做渔网，抓鱼，可是在饥荒里不可以呢!",
		"哈哈哈哈哈!",
		"乌龟和兔子!",
		"三天打鱼两天晒网.",
		"新朋友!", }
	
	local chopped = gf_chopped[math.random(#gf_chopped)]
	local mine = gf_mine[math.random(#gf_mine)]
	local hammer = on_hammer[math.random(#on_hammer)]
	local dig = gf_dig[math.random(#gf_dig)]
	local net = on_net[math.random(#on_net)]
    local rand = .25
    local eqp = inst.components.combat:GetWeapon()
	if eqp and eqp.prefab == 'gumifan'	then
		if data.action == ACTIONS.CHOP and  math.random() < rand then 
		   eqp.components.talker:Say(chopped) 
		elseif data.action == ACTIONS.MINE and  math.random() < rand then
		   eqp.components.talker:Say(mine)
		elseif data.action == ACTIONS.HAMMER and  math.random() < rand then
		   eqp.components.talker:Say(hammer)
		elseif data.action == ACTIONS.DIG and  math.random() < rand then
		   eqp.components.talker:Say(dig)
		elseif data.action == ACTIONS.NET and  math.random() < rand then
		   eqp.components.talker:Say(net)
		end 
	end
end

--[[local function DropItem(inst, owner)
	if inst.components.finiteuses:GetPercent() <= 0 then
		owner:DoTaskInTime(0, function() 
			owner.components.inventory:DropItem(inst) 
			if owner.components.talker ~= nil then
				owner.components.talker:Say("没耐久不能装备")
			end
		end)
	end
end]]

local function damage_count(inst)
	return math.ceil(33 * 1.051868^inst.level)
end

local function total_count(inst)
	return math.ceil(100 * 1.291543^inst.level)
end

local function onbuilt(inst, builder)
	inst.ownerid = builder.userid
end

local function OnEquip(inst, owner)
	owner.AnimState:OverrideSymbol("swap_object", "swap_gumifan", "swap_gumifan")
	owner.AnimState:Show("ARM_carry")
	owner.AnimState:Hide("ARM_normal")

	if owner:HasTag("huli") then
		inst:ListenForEvent("finishedwork", OnFinishedWork, owner)
	end
	if inst.components.finiteuses and inst.components.finiteuses:GetPercent() <= 0 then
		if inst.components.weapon ~= nil and owner.components.combat then
			local owdamage = owner.components.combat.defaultdamage
			inst.components.weapon:SetDamage(owdamage)
		end
		if owner ~= nil then
			if owner:HasTag("huli") then
				inst.finiteusestalk = inst:DoPeriodicTask(30, function() 
					inst.components.talker:Say("本神器没耐久啦.\n快给我金克拉") 
				end)
			else
				inst.finiteusestalk = inst:DoPeriodicTask(20, function() 
					owner.components.talker:Say("扇子没耐久啦.\n快给它金克拉") 
				end)
			end
		end
	end
	
end

local function OnUnequip(inst, owner)
	owner.AnimState:Hide("ARM_carry")
	owner.AnimState:Show("ARM_normal")

	if owner:HasTag("huli") then
		inst:RemoveEventCallback("finishedwork", OnFinishedWork, owner)
	end
	--[[if inst.components.gumifancn then 
	inst:RemoveComponent("gumifancn")
    inst:RemoveEventCallback("donetalking")
    inst:RemoveEventCallback("ontalk")
    inst:RemoveEventCallback("ondropped")
	inst:RemoveEventCallback("finishedwork")
		end]]
	if inst.finiteusestalk then
		inst.finiteusestalk:Cancel()
		inst.finiteusestalk = nil
	end
	if inst.components.finiteuses and inst.components.finiteuses:GetPercent() <= 0 then
		if inst.components.weapon ~= nil then
			inst.components.weapon:SetDamage(0)
		end
	end
	--owner.Light:Enable(false)
	--owner.key_test = 0
end

local function onfinished(inst)  
	if inst.components.tool ~= nil then
		inst:RemoveComponent("tool")
	end
	local owner = inst.components.inventoryitem:GetGrandOwner()
	--local owner = inst.components.inventoryitem.owner
	--owner:DoTaskInTime(0, function() owner.components.inventory:DropItem(inst) end)
	if owner ~= nil then
		if inst.components.equippable:IsEquipped() then
			if inst.components.weapon ~= nil and owner.components.combat ~= nil then
				local owdamage = owner.components.combat.defaultdamage
				inst.components.weapon:SetDamage(owdamage)
			end
		end
		if owner:HasTag("huli") then
			owner:DoTaskInTime(0, function() owner.components.talker:Say("扇子没耐久啦.\n快给它金克拉") end)
			inst.finiteusestalk = inst:DoPeriodicTask(30, function() inst.components.talker:Say("本神器没耐久啦.\n快给我金克拉") end)
		else
			owner:DoTaskInTime(0, function() owner.components.talker:Say("扇子没耐久啦.\n快给它金克拉") end)
			inst.finiteusestalk = inst:DoPeriodicTask(20, function() owner.components.talker:Say("扇子没耐久啦.\n快给它金克拉.") end)
		end
	end
end

local function TongYongFn(inst, fin)
	fin.total = total_count(inst)
	if inst.finiteusestalk then
		inst.finiteusestalk:Cancel()
		inst.finiteusestalk = nil
	end
	if inst.components.weapon ~= nil then
		inst.components.weapon:SetDamage(damage_count(inst))		
	end
	if not inst.components.tool then
		inst:AddComponent("tool")
		if GUMIFAN_SET_MINE > 0 then
			inst.components.tool:SetAction(ACTIONS.MINE)
		end
		if GUMIFAN_SET_CHOP > 0 then
			inst.components.tool:SetAction(ACTIONS.CHOP)
		end
		if GUMIFAN_SET_DIG > 0 then
			inst.components.tool:SetAction(ACTIONS.DIG)
		end
	end
	if inst.level >= inst.maxlevel then
		inst.level = inst.maxlevel
	end
	if fin.current >= fin.total then
		fin.current = fin.total
	end
	if fin:GetPercent() >= 1 then 
		fin:SetPercent(1)
	end	
end

local function val(inst, item)
	for k, v in pairs(TUNING.ITEM.gumifan) do 
		if item.prefab == v[1] then
			if v[3] then
				return v[2], v[3]
			else
				return v[2], 0
			end
		end
	end
	return 0, 0
end

local function QiangHuaFn(inst, giver, item)
	local fin = inst.components.finiteuses
	local rand = .83^inst.level*HULI_EQUIPLEVELUP_SET
	local rand2 = .9^inst.level*HULI_EQUIPLEVELUP_SET
	-- local gin_bj = giver.components.inventory and giver.components.inventory:Has("huligem_bj", 1)
	local gin_xy = giver.components.inventory and giver.components.inventory:Has("huligem_xy", 1)
	local value, lev = val(inst, item)
	
	if item.prefab == "huligem_qh" then
		if inst.level < inst.maxlevel then
			if gin_xy then
				rand = rand + .2
				giver.components.inventory:ConsumeByName("huligem_xy", 1)
			end
			if math.random() < rand then
				inst.level = inst.level + lev
				giver.components.talker:Say("强化成功")
			else
				giver.components.talker:Say("强化失败")
			end
			fin.current = fin.current + (fin.total* .02)
		end
	elseif item.prefab == "huligem_gjqh" then
		if inst.level < inst.maxlevel then
			if inst.level < 9 then
				inst.level = inst.level + lev
				giver.components.talker:Say("强化成功")
				if fin.current < fin.total then
					fin.current = fin.current + (fin.total* .02)
				end
			else
				if gin_xy then
					rand2 = rand2 + .2
					giver.components.inventory:ConsumeByName("huligem_xy", 1)
				end
				if math.random() < rand2 then
					inst.level = inst.level + lev
					giver.components.talker:Say("强化成功")
				else
					giver.components.talker:Say("强化失败")
				end
				fin.current = fin.current + (fin.total* .02)
			end
		end
	end
	item.components.stackable:Get():Remove()
	TongYongFn(inst, fin)
end

local function XiuLiFn(inst, giver, item)
	local fin = inst.components.finiteuses
	local xvalue = fin.total - fin.current
	local stkitem = item.components.stackable and item.components.stackable:StackSize()
	local value = val(inst, item)
	
	if fin.current < fin.total then						
		if xvalue / value - stkitem >= 0 then
			fin.current = fin.current + value * stkitem
			item:Remove()
		else
			local Consumeitem = math.ceil(xvalue / value)
			local items = item.components.stackable and  item.components.stackable:Get(Consumeitem)
			fin.current = fin.current + value * Consumeitem
			items:Remove()
		end	
		giver.components.talker:Say("修理成功!")
	else
		giver.components.talker:Say("已经修好了!")
	end
	TongYongFn(inst, fin)
end

local function onsave(inst, data) 
	data.level = inst.level 
	data.ownerid = inst.ownerid 
	data.damage = inst.components.weapon.damage
	data.current = inst.components.finiteuses.current
	data.total = inst.components.finiteuses.total
end

local function onlaod(inst, data)
	if data then
		if data.level ~= nil then
			inst.level = data.level
		end
		inst.ownerid = data.ownerid
		inst.components.weapon.damage = data.damage
		if data.current ~= nil then
			inst.components.finiteuses.current = data.current
		end
			inst.components.finiteuses.total = data.total
	end
end

local function get_name(inst)
	local name = STRINGS.NAMES[string.upper(inst.prefab)]
	local level = inst._level:value()
	local maxlevel = inst._maxlevel:value()
	local damage = inst._damage:value()
	local fini = inst._fini:value()
	local maxfini = inst._maxfini:value()
	local named = name.."+"..level..'/'..maxlevel.."\n伤害:"..damage.."\n耐久度:"..fini.."/"..maxfini
	
	if get_modinfoname() then
		named = name.."+"..level..'/'..maxlevel
	end
	return named
end

local function setspellfn(inst, target, pos, doer)
	local _hunger = 12
	local _san = 5
	local _fini = 50
	if not (doer.components.hunger or doer.components.sanity or inst.components.finiteuses) then
		return
	end
	if doer.components.hunger.current < _hunger then
		if doer.components.talker then
			doer.components.talker:Say(hl_loc("饿得没力气了", "Hungry to the point of exhaustion!"))
		end
		return
	end
	if doer.components.sanity.current < _san then
		if doer.components.talker then
			doer.components.talker:Say(hl_loc("没有精力施放法术了", "I don't have the energy to cast spells anymore!"))
		end
		return
	end
	if inst.components.finiteuses.current < _fini then
		if doer.components.talker then
			doer.components.talker:Say(hl_loc("扇子没耐久了", "Insufficient durability of Gumifan!"))
		end
		return
	end
	doer.components.hunger:DoDelta(-_hunger)
	doer.components.sanity:DoDelta(-_san)
	inst.components.finiteuses:Use(_fini)
	local x, y, z = inst.Transform:GetWorldPosition()
	local fx = SpawnPrefab("huli_longjuanfeng")
	fx.master = doer
	fx.Transform:SetPosition(x, y, z)
	fx.components.combat:SetDefaultDamage(damage_count(inst) / 5)
	fx.Transform:SetRotation(doer.Transform:GetRotation())

end

local function fn()
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddNetwork()
	inst.entity:SetPristine()
	inst.entity:AddSoundEmitter()
	MakeInventoryPhysics(inst)
	local minimap = inst.entity:AddMiniMapEntity()
    minimap:SetIcon("gumifan.tex")
	
	inst._level = net_shortint(inst.GUID, "gumifan._level")
	inst._maxlevel = net_shortint(inst.GUID, "gumifan._maxlevel")
	inst._damage = net_shortint(inst.GUID, "gumifan._damage")
	inst._fini = net_shortint(inst.GUID, "gumifan._fini")
	inst._maxfini = net_shortint(inst.GUID, "gumifan._maxfini")
	inst.displaynamefn = get_name
	
	inst.AnimState:SetBank("gumifan")
	inst.AnimState:SetBuild("gumifan")
	inst.AnimState:PlayAnimation("idle")
	inst:AddTag("sharp")
	inst:AddTag("gumifan")
	inst:AddTag("huli_level_item")
	
	inst:AddComponent("talker")
    --inst.components.talker.ontalk = ontalk
    inst.components.talker.fontsize = 32
    inst.components.talker.font = TALKINGFONT
    inst.components.talker.colour = Vector3(.9, .4, .4, 1)
    inst.components.talker.offset = Vector3(0,0,0)
    inst.components.talker.symbol = "swap_object"

	if not TheWorld.ismastersim then
		return inst
	end
	
	inst:AddComponent("finiteuses") 
    inst.components.finiteuses:SetConsumption(ACTIONS.MINE, 3)  
    inst.components.finiteuses:SetConsumption(ACTIONS.CHOP, 1) 
    inst.components.finiteuses:SetConsumption(ACTIONS.DIG, 2) 
    inst.components.finiteuses:SetUses(100)  
    inst.components.finiteuses:SetMaxUses(100)  
	inst.components.finiteuses:SetOnFinished(onfinished)
	
	-- inst:AddComponent("trader")
	-- inst.components.trader:SetAcceptTest(ShouldAcceptItem)
	-- inst.components.trader.onaccept = AcceptItem
	-- inst.components.trader:Enable()
	
	inst:AddComponent("tool")
	if GUMIFAN_SET_MINE > 0 then
		inst.components.tool:SetAction(ACTIONS.MINE)
	end
	--inst.components.tool:SetAction(ACTIONS.HAMMER)
	if GUMIFAN_SET_CHOP > 0 then
		inst.components.tool:SetAction(ACTIONS.CHOP)
	end
	if GUMIFAN_SET_DIG > 0 then
		inst.components.tool:SetAction(ACTIONS.DIG)
	end
		
	inst:AddComponent("equippable")
	inst.components.equippable:SetOnEquip(OnEquip)
	inst.components.equippable:SetOnUnequip(OnUnequip)
	
	inst:AddComponent("inspectable")
	inst:AddComponent("timer")
	
	inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.atlasname = "images/inventoryimages/items.xml"

    inst:AddComponent("gumifancn")
	
	inst:AddComponent("weapon")
	inst.components.weapon:SetDamage(33)
	inst.components.weapon:SetRange(.3)
	
	inst:AddComponent("spellcaster")
    inst.components.spellcaster.canuseonpoint = true
    inst.components.spellcaster.canuseontargets = true
    inst.components.spellcaster.canonlyuseoncombat = true
    inst.components.spellcaster.quickcast = true
    inst.components.spellcaster:SetSpellFn(setspellfn)
    inst.components.spellcaster.castingstate = "castspell_tornado"
	
	inst.QiangHuaFn = QiangHuaFn
	inst.XiuLiFn = XiuLiFn
	inst.namefn = get_name
	inst.level = 0
	inst.maxlevel = 18
	inst.ownerid = nil
	inst.OnSave = onsave
	inst.OnLoad = onlaod
	
	inst._maxlevel:set(inst.maxlevel)
	inst:DoPeriodicTask(0, function() 
	inst._level:set(inst.level)
	inst._damage:set(inst.components.weapon.damage) 
	inst._fini:set(inst.components.finiteuses.current) 
	inst._maxfini:set(inst.components.finiteuses.total) end)
	
	inst.OnBuiltFn = onbuilt

    inst:ListenForEvent("donetalking", function() inst.SoundEmitter:KillSound("talk") end)
    inst:ListenForEvent("ontalk", function() 
		if inst.components.gumifancn.sound_override then
			inst.SoundEmitter:KillSound("talk")
			inst.SoundEmitter:PlaySound(inst.components.gumifancn.sound_override, "special")
		else
			if not inst.SoundEmitter:PlayingSound("special") then
				inst.SoundEmitter:PlaySound("wharangfan/fan/fan_LP", "talk")
			end 
		end
	end)
	
	return inst 
end

return  Prefab("common/inventory/gumifan", fn, assets)