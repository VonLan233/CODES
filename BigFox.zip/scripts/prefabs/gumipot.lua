require "prefabutil"

local assets =
{
    Asset("ANIM", "anim/gumipot.zip"),
	Asset("ANIM", "anim/ui_gumipot_4x4.zip"),
	Asset("IMAGE", "images/inventoryimages/building.tex"),
	Asset("ATLAS", "images/inventoryimages/building.xml"),
}

local prefabs =
{
    "collapse_small",
}

local function onopen(inst)
    inst.AnimState:PlayAnimation("open")
    inst.SoundEmitter:PlaySound("dontstarve/wilson/chest_open")
end

local function onclose(inst)
    inst.AnimState:PlayAnimation("close")
    inst.SoundEmitter:PlaySound("dontstarve/wilson/chest_close")
end

local function onfinishd(inst)
	local d_ice = math.floor(inst.minice / TUNING.HULIGUMIPOT_ICE_VAL)
    inst.components.container:DropEverything()
	inst.components.container:Close()
	for i = 1, d_ice do
		inst.components.lootdropper:SpawnLootPrefab('ice')
	end
	inst.AnimState:PushAnimation("closed", false)
	inst.SoundEmitter:PlaySound("dontstarve/common/break_iceblock")
    local fx = SpawnPrefab("collapse_small")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
    fx:SetMaterial("metal")
    inst:Remove()
end

local function onfinish(inst)
	local d_ice = math.floor(inst.minice / TUNING.HULIGUMIPOT_ICE_VAL)
	inst.components.lootdropper:DropLoot()
    inst.components.container:DropEverything()
	inst.components.container:Close()
	for i = 1, d_ice do
		inst.components.lootdropper:SpawnLootPrefab('ice')
	end
	inst.AnimState:PushAnimation("closed", false)
	inst.SoundEmitter:PlaySound("dontstarve/common/break_iceblock")
    local fx = SpawnPrefab("collapse_small")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
    fx:SetMaterial("metal")
    inst:Remove()
end

local function onhit(inst, worker)
	inst.components.huli_workerhit:OnHit(worker)
end
--[[local function onhit(inst, worker)
    inst.AnimState:PlayAnimation("hit")
	local wk = inst.components.workable
	-- inst.AnimState:PushAnimation("idle", false)
	-- if worker and worker.name then
		-- if worker.name == "Bearger" or worker.name == "Deerclops" then
		if worker:HasTag('bearger') or worker:HasTag('deerclops') then
			inst.SoundEmitter:PlaySound("dontstarve/common/destroy_stone")
			local msg = worker.name.."正在攻击"
			if inst._player and inst._player.name then
				msg = msg..'<'..inst._player.name..'>的'
			end
			msg = msg..'<'..inst.name
			msg = msg..'/'..inst._workleft:value()..'>'
			TheNet:Announce(msg)
			print(msg)
		end
	-- end
    if worker:HasTag('player') then
			local msg = worker.name.."正在攻击"..inst.name
			print(msg)
			if inst._player ~= nil and inst._player.userid == worker.userid then  
				-- print(worker.userid)
				inst.SoundEmitter:PlaySound("dontstarve/common/destroy_stone")
				wk.workleft = wk.workleft - 23
			else
				wk.workleft = wk.workleft + 1
			end
			TheNet:Announce(msg)
		-- end
	end
end]]

local function onbuilt(inst, data)
    local doer = data.builder
   if doer ~= nil then
		-- print(inst._player.userid)
        inst._player = {
            userid = doer.userid,
            name = doer.name,
        }
    end
	inst.AnimState:PlayAnimation("place")
    inst.AnimState:PushAnimation("closed", false)
end

local function GetStatus(inst, viewer) 
	if inst._player ~= nil then
		return (viewer.userid == inst._player.userid and inst.components.workable ~= nil and inst.components.workable.workleft < 200 and "CANXUE")
		or (viewer.userid == inst._player.userid and "OWNER")
		or "TONGYONG"
	end
	return "NOOWNER"
end

local function onsave(inst, data) 
	data._player = inst._player
	data.workleft = inst.components.workable.workleft
	data.minice = inst.minice
end

local function onload(inst, data)   
	inst._player = data._player
	if data.workleft ~= nil then
		inst.components.workable.workleft = data.workleft
	end
	if data.minice ~= nil then
		inst.minice = data.minice
	end
end

local function get_name(inst)
	local name = STRINGS.NAMES[string.upper(inst.prefab)]
	local ownername = inst._ownername:value()
	local workleft = inst._workleft:value()
	local maxwork = inst._maxwork:value()
	local minice = inst._minice:value()
	local named = name..'\n拥有者:'..ownername..'\n耐久度:'..workleft..'/'..maxwork..'\n冰储量:'..minice..'/'..maxwork
	-- if get_modinfoname(inst) then
		-- named = name
	-- end
	return named
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddMiniMapEntity()
    inst.entity:AddNetwork()
	inst:AddTag("fridge")
    inst:AddTag("structure")
    inst:AddTag("huli_build")
    inst:AddTag("huli_gumipot")
	MakeObstaclePhysics(inst, .5)
	inst._workleft = net_int(inst.GUID, "gumipot._workleft")
	inst._maxwork = net_int(inst.GUID, "gumipot._maxwork")
	inst._minice = net_int(inst.GUID, "gumipot.minice")
	inst._ownername = net_string(inst.GUID, "gumipot._ownername")
	inst.displaynamefn = get_name
	
    inst.AnimState:SetBank("gumipot")
    inst.AnimState:SetBuild("gumipot")
    inst.AnimState:PlayAnimation("closed")
	inst.MiniMapEntity:SetIcon("gumipot.tex")
    MakeSnowCoveredPristine(inst)
    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("inspectable")
	inst.components.inspectable.getstatus = GetStatus
	
    inst:AddComponent("container")
    inst.components.container:WidgetSetup("gumipot")
    inst.components.container.onopenfn = onopen
    inst.components.container.onclosefn = onclose

    inst:AddComponent("lootdropper")
    inst:AddComponent("z_huli_gumipot")
    inst:AddComponent("huli_workerhit")
    inst:AddComponent("workable")
    inst.components.workable:SetWorkAction(ACTIONS.HAMMER)
    -- inst.components.workable:SetWorkAction(ACTIONS.MINE)
    inst.components.workable:SetWorkLeft(TUNING.HULIBUILD_MINWORK)
    inst.components.workable:SetOnWorkCallback(onhit) 
    inst.components.workable:SetOnFinishCallback(onfinish)
	
	inst.durabletask = inst:DoPeriodicTask(TUNING.HULIBUILD_NAIJIUDU_TASK, function() 
		local w = inst.components.workable
		if w.workleft > 0 then
			w.workleft = w.workleft - TUNING.HULIBUILD_NAIJIUDU_CONSUME
		else
			onfinishd(inst)
		end
	end)
	
	-- inst.OnBuiltFn = onbuilt
	inst:ListenForEvent("onbuilt", onbuilt)
    MakeSnowCovered(inst)   
    AddHauntableDropItemOrWork(inst)
	
	inst._player = nil
	inst.minice = TUNING.HULIGUMIPOT_ICE_VAL*6
	inst.maxwork = TUNING.HULIBUILD_MAXWORK
	inst.OnSave = onsave
    inst.OnLoad = onload
	inst:DoPeriodicTask(1.01, function() 
		inst._workleft:set(inst.components.workable.workleft) 
		inst._maxwork:set(inst.maxwork) 
		inst._minice:set(inst.minice) 
		if inst._player ~= nil then
			inst._ownername:set(inst._player.name) 
		else
			inst._ownername:set('NONE') 
		end
	end)
	
	inst.minicetask = inst:DoPeriodicTask(TUNING.HULIGUMIPOT_MINICE_TASK, function() 
		if inst.minice > 0 then
			inst.minice = inst.minice - TUNING.HULIGUMIPOT_MINICE_CONSUME
		else
			inst.minice = 0
			if inst:HasTag("fridge") then
				inst:RemoveTag("fridge")
			end
			if inst.minicetask then
				inst.minicetask:Cancel()
				inst.minicetask = nil
			end
		end
	end)
	
	function inst.components.workable:Destroy(destroyer)
		if self:CanBeWorked() then
			self:WorkedBy(destroyer, 800)
			self.inst.SoundEmitter:PlaySound("dontstarve/common/destroy_stone")
		end
	end

    return inst
end

return Prefab("common/gumipot", fn, assets, prefabs),
    MakePlacer("common/gumipot_placer", "gumipot", "gumipot", "closed")
