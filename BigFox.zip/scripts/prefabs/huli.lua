local MakePlayerCharacter = require "prefabs/player_common"
local assets = {

        Asset( "ANIM", "anim/huli.zip" ),
		Asset( "ANIM", "anim/huli_fox_ice.zip" ),
		Asset( "ANIM", "anim/huli_fox_white.zip" ),
		Asset( "ANIM", "anim/huli_fox_moon.zip" ),
        Asset( "ANIM", "anim/ghost_huli_build.zip" ),
}
local prefabs = {
        "huli_spiritfx",
	    "huli_spirit_evilfx",
}
local start_inv = {
         "gumifan",
		 --"skirt",
		 --"foxmask",
		 --"mihobell",
}

local Exp_P = 1.36

local function GetElement_Hit(inst, e_val)
	if inst['形态'] == "红狐狸" then
		inst.components.huli_elesys:FireDoDelta(e_val)
	elseif inst['形态'] == "冰狐狸" then
		inst.components.huli_elesys:IceDoDelta(e_val)
	end
end

local function onkilled(inst, data)
	local randombutterfly = .05
	local victim = data.victim
	
	local no_tag = victim:HasTag("wall") 
		  or victim:HasTag("structure") 
		  or victim:HasTag("epic")
		  or victim:HasTag("largecreature")
		  or victim:HasTag("chess")
		  or victim:HasTag("bat")
		  --or victim:HasTag("bird")
		  --or victim:HasTag("butterfly")
		  or (victim:HasTag("smallcreature") 
		  and not victim:HasTag("hostile")
		  and not victim:HasTag("bee"))

	local s_tag = victim:HasTag("largecreature") 
		and not victim:HasTag("epic") 
			
	local d_tag = victim:HasTag("epic") 
		and victim:HasTag("largecreature") 
		--if victim.components.freezable or victim:HasTag("monster") then
	if victim.components.lootdropper then
		for k, v in pairs(TUNING.ITEM.gemmonsterloot) do
			if not no_tag then
				victim.components.lootdropper:AddChanceLoot(v.pref, v.ca*HULI_GEM_DROPPRO_SET) 
			elseif victim:HasTag("chess") then
				victim.components.lootdropper:AddChanceLoot(v.pref, v.cb*HULI_GEM_DROPPRO_SET) 
			elseif s_tag then
				victim.components.lootdropper:AddChanceLoot(v.pref, v.cc*HULI_GEM_DROPPRO_SET) 
			elseif d_tag then
				victim.components.lootdropper:AddChanceLoot(v.pref, v.cd*HULI_GEM_DROPPRO_SET) 
			end
		end
		if math.random() < randombutterfly and victim:HasTag("butterfly") then
			victim.components.lootdropper:SpawnLootPrefab("butter") 
		end
	end
end

local function rockdrop_gem(inst, data)
	local tar = data.target
	if tar and tar.components.lootdropper then
		for k, v in pairs(TUNING.ITEM.gemrockloot) do
			if tar.prefab == "rock1" --岩石
			or tar.prefab == "rock_flintless" --岩石
			or tar.prefab == "stalagmite" --石笋（宽的）
			or tar.prefab == "stalagmite_tall" --石笋（尖的）
			or tar.prefab == "rock_petrified_tree_tall" then --石化树
				if math.random() < v[2]*HULI_GEM_DROPPRO_SET then
					tar.components.lootdropper:SpawnLootPrefab(v[1])
				end
			elseif tar.prefab == "rock2" then --岩石（含金的）
				if math.random() < v[3]*HULI_GEM_DROPPRO_SET then
					tar.components.lootdropper:SpawnLootPrefab(v[1])
				end
			elseif tar.prefab == "rock_moon" then --月岩
				if math.random() < v[4]*HULI_GEM_DROPPRO_SET then
					tar.components.lootdropper:SpawnLootPrefab(v[1])
				end
			elseif tar.prefab == "rock_moon_shell" then --可疑的巨石（月岩）
				if math.random() < v[5]*HULI_GEM_DROPPRO_SET then
					tar.components.lootdropper:SpawnLootPrefab(v[1])
				end
			elseif tar.prefab == "moonglass_rock" then --月光玻璃石
				if math.random() < v[6]*HULI_GEM_DROPPRO_SET then
					tar.components.lootdropper:SpawnLootPrefab(v[1])
				end
			end
		end
	end
end

local function SanityFn(inst)
if inst:HasTag("playerghost") then return end
	local x,y,z = inst.Transform:GetWorldPosition()	
	local delta = 0
	local max_rad = 10
	local ents = TheSim:FindEntities(x,y,z, max_rad, {"fire"})
    for k,v in pairs(ents) do 
    	if v.components.burnable and v.components.burnable.burning then
			local sz = TUNING.SANITYAURA_SMALL
			local rad = v.components.burnable:GetLargestLightRadius() or 1
			local distsq = inst:GetDistanceSqToInst(v)
			
			if inst['形态'] == "冰狐狸" then 
				if v.prefab == "firepit_chill" 
				or v.prefab == "coldfire" 
				or v.prefab == "coldfirepit" then
					sz = TUNING.SANITYAURA_SMALL 
				else
					sz = -TUNING.SANITYAURA_MED 
				end
			end
			sz = sz * ( math.min(max_rad, rad) / max_rad )
			delta = delta + sz/math.max(1, distsq) 
		end 
	end
    return delta 
end

local function levelupfx(inst)
	local pos = Vector3(inst.Transform:GetWorldPosition()) 
	pos.y = pos.y + 1
	local spirit_evil = SpawnPrefab("huli_spirit_evilfx")
	spirit_evil.Transform:SetPosition(pos:Get())
	spirit_evil.Transform:SetScale(.5,.5,.5) 
	inst.SoundEmitter:PlaySound("foxpointup/foxpoint/pointup")
end

local function LevelUpFn(inst, c_lv, max_lv)
	local MaxExpCumulative = (100 * (1 - Exp_P^(c_lv+5)) / (1 - Exp_P))+.01 - (100 * (1 - Exp_P^c_lv) / (1 - Exp_P)) 
    local upgrades = math.min(c_lv, max_lv)
	local hg = inst.components.hunger
	local san = inst.components.sanity
	local hl = inst.components.health
    hg.max = math.ceil (TUNING.HULI_HUNGER + upgrades * 5) --270
	san.max = math.ceil (TUNING.HULI_SANITY + upgrades * 7)  --310
    hl.maxhealth = math.ceil (TUNING.HULI_HEALTH + upgrades * 7) --310
	san:DoDelta(san.max * .15)
	hl:DoDelta(hl.maxhealth * .15)
	inst.components.huli_levelsys:SetUpExp(100 * Exp_P^c_lv, MaxExpCumulative)
	inst.components.huli_elesys:SetAllMax(math.floor(100 * 1.258925^c_lv))
	inst.components.huli_petleash.maxpets = 1 + math.floor(c_lv / 10)
	
	levelupfx(inst)
end

local function GetAtkExp(inst, val)
	local getexp = 0
	local e_val = 0

	if inst.components.huli_levelsys then
		getexp = math.abs(math.random(4, 15)/10 * val) * HULI_GETLEVELEXP_SET
		e_val = math.abs(math.random(3, 10)/10 * val)
		inst.components.huli_levelsys:ExpDoDelta(math.floor(getexp))
		GetElement_Hit(inst, math.floor(e_val))
	end
end

local function oneat_getexp(inst, food)
	local pos = Vector3(inst.Transform:GetWorldPosition()) pos.y = pos.y + 1
	-- if food and food.prefab == "huli_dango" then
	-- end
	local foodexp = 0
	local edi = food.components.edible
	if edi:GetHunger(inst) > (edi:GetHealth(inst) and edi:GetSanity(inst)) then
		foodexp = edi:GetHunger(inst)
	elseif edi:GetHealth(inst) > (edi:GetHunger(inst) and edi:GetSanity(inst)) then
		foodexp = edi:GetHealth(inst)
	elseif edi:GetSanity(inst) > (edi:GetHunger(inst) and edi:GetHealth(inst)) then
		foodexp = edi:GetSanity(inst)
	end
	local getexp = foodexp * HULI_GETLEVELEXP_SET * (math.random(40, 100)/100)
	inst.components.huli_levelsys:ExpDoDelta(math.floor(getexp))
	local spirit = SpawnPrefab("huli_spiritfx")
	spirit.Transform:SetPosition(pos:Get())
	spirit.Transform:SetScale(.5,.5,.5)	
end

local function RandomTalk(sayings) 
    return sayings[math.random(#sayings)]
end

--Be attacked to talk
local function FrozenBody(inst, data)
	local cold = .5 - (TheWorld.state.temperature / 100)
    if data.attacker and data.attacker.components.freezable and not data.attacker:HasTag("thorny") then
		inst.components.talker:Say(RandomTalk(FRZOENHURT))
		--inst.components.sanity:DoDelta(0)
		--data.attacker.components.health:DoDelta(0)
		if inst['形态'] == "冰狐狸" and math.random() < cold then
			data.attacker.components.freezable:AddColdness(1)
			data.attacker.components.freezable:SpawnShatterFX() 
		end 
	end 
end
--Ice attack
local function Hitfreeze(inst, data)
	local hitfreeze = .3 - (TheWorld.state.temperature / 100)
	if inst['形态'] == "冰狐狸" then 
		hitfreeze = .4 - (TheWorld.state.temperature / 100)
	end
	local other = data.target
	 --local summonchance = .005
	local framechance = .15
	if inst['形态'] == "月狐狸" or inst['形态'] == "冰狐狸" then
		if other and math.random() < hitfreeze 
		and other.components.freezable 
		and not other:HasTag("structure") then
			other.components.freezable:AddColdness(.7)
			other.components.freezable:SpawnShatterFX() 
		end
		if other.components.burnable 
			and other.components.burnable:IsBurning() then
			other.components.burnable:Extinguish() 
		end 
	end
--Fire attack
	if inst['形态'] == "红狐狸" then
		if math.random() < framechance 
		and other.components.burnable 
		and other.sg 
		and not other.sg:HasStateTag("frozen") 
		and not other:HasTag("wall") 
		and not other:HasTag("structure") 
		and other.sg.sg.states.hit then
			other.sg:GoToState("hit")
			other.components.burnable:Ignite() 
		end
		if other.components.burnable and other.components.burnable:IsBurning() then
			other.components.burnable:Extinguish() 
		end
		if other.components.sleeper and other.components.sleeper:IsAsleep() then
			other.components.sleeper:WakeUp() 
		end
		if other.components.freezable then
			other.components.freezable:AddColdness(-1)
			if other.components.freezable:IsFrozen() then
				other.components.freezable:Unfreeze() 
			end 
		end
    --[[if math.random() < summonchance then 
        local pt = other:GetPosition()
		local st_pt =  FindWalkableOffset(pt or owner:GetPosition(), math.random()*2*PI, 2, 3)
		local ores = {"butterflymuffin","fishsticks","dragonpie","mandrakesoup","baconeggs","perogies","waffles","flowersalad","icecream","watermelonicle"}
		local ore = ores[math.random(#ores)]
		if st_pt then
			st_pt = st_pt + pt
			local st1 = SpawnPrefab(ore)
			local st2 = SpawnPrefab("collapse_small")
			st1.Transform:SetPosition(st_pt.x, st_pt.y, st_pt.z)
			st2.Transform:SetPosition(st_pt.x, st_pt.y, st_pt.z) end 
end ]]
	end 
end
-------------------------------------------------------------------------------
local function FoxAttack_pj(inst, data)
    local other = data.target
	local damage = inst.components.combat.defaultdamage 
	local damagemul = inst.components.combat.damagemultiplier 
	if inst['形态'] == "要完蛋狐狸" then
		damagemul = 1 
		end
	--local weapon = inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS)
	local weapon = inst.components.combat:GetWeapon()
    if weapon ~= nil then
		damage =  weapon.components.weapon.damage 
	end
	if other and other.components.health and not other:HasTag("wall") and not other:HasTag("structure")  then
		SpawnPrefab("lightning").Transform:SetPosition(other:GetPosition():Get())
		SpawnPrefab("shock_fx").Transform:SetPosition(other:GetPosition():Get())
		other.components.health:DoDelta(-(damage * 1.5 * damagemul))
		other.sg:GoToState("hit") 
	end
	--if other.components.combat then other.components.combat:Suggestother(other)
end

local function foxattack(inst, data)
    local san = inst.components.sanity:GetPercent()
	local lightning = .2 - san
	if inst['形态'] == "月狐狸" and math.random() < .6 then
		FoxAttack_pj(inst, data)
	end

end
----------------------------------------------------------------------------------
----------------hulilight
----------------------------------------------------------------------------------
local function HungerFire(inst)
	if inst:HasTag("playerghost") then return end
	local hunger = inst.components.hunger:GetPercent()
	if inst.components.health and not inst.components.health:IsDead() then
		if TheWorld.state.isnight then
			if inst['形态'] == "红狐狸" then
				if hunger >= .8 then
					inst.Light:Enable(true)
					inst.Light:SetRadius(2.3)
					inst.Light:SetFalloff(.8)
					inst.Light:SetIntensity(.8)
					inst.Light:SetColour(255/255,20/255,20/255)
				elseif (hunger < .8) and (hunger >= .15) then
					inst.Light:Enable(true)
					inst.Light:SetRadius(hunger * 2.5)
					inst.Light:SetFalloff(.8)
					inst.Light:SetIntensity(.8)
					inst.Light:SetColour(255/255,20/255,20/255) 
				elseif hunger < .15 then
					inst.Light:Enable(false) 
				end
			else
				inst.Light:Enable(false) 
			end
		else 
			--or TheWorld.state.isday 
			--or TheWorld.state.isdusk then
			inst.Light:Enable(false) 
		end 
	end
end

local function FormChange(inst)
	SpawnPrefab("statue_transition").Transform:SetPosition(inst:GetPosition():Get())
	SpawnPrefab("statue_transition_2").Transform:SetPosition(inst:GetPosition():Get())
end

local function Do_Health(inst)
	if inst:HasTag("playerghost") then return end
	inst:DoPeriodicTask(2, function() 
		if inst['形态'] == "月狐狸" then 
			inst.components.health:DoDelta(1) 
		else
		end
	end)
end

local function Night_San(inst)
	if inst['形态'] == "月狐狸" then
		inst.components.sanity.night_drain_mult = 0
	else
		inst.components.sanity.night_drain_mult = 1
	end
end

local function temlisten(inst)
	local wtem = TheWorld.state.temperature 
	local ict = inst.components.temperature
	if inst['形态'] == "红狐狸" then
		if ict.current < ict.maxtemp and wtem <= 6 then
			return true
		end
	elseif inst['形态'] == "冰狐狸" then
		if wtem > ict.mintemp and wtem >= 45 then
			return true
		end
	end
	return false
end

local function tempdelta(inst)
	local ict = inst.components.temperature
	if inst['形态'] == "红狐狸" then
		if inst:HasTag("盛宴状态开启") then
			ict:DoDelta(1)
		end
	end
	if inst['形态'] == "冰狐狸" then
		if inst:HasTag("冰域状态开启") then
			ict:DoDelta(-1)
		end
	end
end

local function state_ice(inst)
	local wtem = TheWorld.state.temperature 
	local ict = inst.components.temperature
	inst.AnimState:SetBuild("huli_fox_ice")
	inst.components.hunger:SetRate(TUNING.WILSON_HUNGER_RATE * .7)
	inst.components.eater:SetDiet({ FOODGROUP.OMNI }, { FOODGROUP.OMNI })
	ict.mintemp = 6
	ict.maxtemp = 999
	ict.overheattemp = 50
	inst.components.sanity.custom_rate_fn = SanityFn
	if inst:HasTag("冰域状态开启") then
		inst.components.health.absorb = .4 - (wtem - 20) * .004
		inst.components.combat.damagemultiplier = 1.35 - (wtem - 20) * .005
		inst.components.locomotor:SetExternalSpeedMultiplier(inst, 'a', 1.35 - (wtem - 20) * .004)
	else
		inst.components.health.absorb = 0
		inst.components.combat.damagemultiplier = 1 - (wtem - 20) * .005
		inst.components.locomotor:SetExternalSpeedMultiplier(inst, 'a', 1.15 - (wtem - 20) * .004)
	end
end

local function state_red(inst)
	inst.AnimState:SetBuild("huli")
	inst.components.health.absorb = 0
	inst.components.hunger:SetRate(TUNING.WILSON_HUNGER_RATE * 1.1)
	inst.components.eater:SetDiet({ FOODGROUP.OMNI }, { FOODGROUP.OMNI })
	inst.components.temperature.mintemp = TUNING.MIN_ENTITY_TEMP
	inst.components.temperature.maxtemp = 60
	inst.components.temperature.overheattemp = 999
	inst.components.sanity.custom_rate_fn = SanityFn
end

local function state_bai(inst)
	local san = inst.components.sanity:GetPercent()
	inst.AnimState:SetBuild("huli_fox_white")
	inst.components.health.absorb = ( san )
	inst.components.hunger:SetRate(TUNING.WILSON_HUNGER_RATE * 1.6)
	inst.components.eater:SetDiet({ FOODTYPE.MEAT }, { FOODTYPE.MEAT })
	inst.components.temperature.mintemp = TUNING.MIN_ENTITY_TEMP
	inst.components.temperature.maxtemp = 999
	inst.components.temperature.overheattemp = TUNING.OVERHEAT_TEMP
	inst.components.sanity.custom_rate_fn = SanityFn
	--inst.AnimState:PushAnimation("idle_hot_loop")
	inst.components.combat.damagemultiplier = 1 - (.25 - san) * 2
	inst.components.locomotor:SetExternalSpeedMultiplier(inst, 'a', .9)
end

local function HuliChange(inst, phase)
	if inst:HasTag("playerghost") then return end
    --local pos = Vector3(inst.Transform:GetWorldPosition()) pos.y = pos.y + .5
	local san = inst.components.sanity:GetPercent()
	local wtem = TheWorld.state.temperature 
	local ict = inst.components.temperature
	local icl = inst.components.locomotor
	if inst.components.health and not inst.components.health:IsDead() then
		if TheWorld.state.isday then
			if inst['形态'] == "红狐狸" then
				state_red(inst)
				if inst:HasTag("盛宴状态开启") then
					inst.components.combat.damagemultiplier = 1.25 + (wtem - 20) * .005
					icl:SetExternalSpeedMultiplier(inst, 'a', 1.3 + (wtem - 20) * .0025)
				else
					inst.components.combat.damagemultiplier = 1 + (wtem - 20) * .005
					icl:SetExternalSpeedMultiplier(inst, 'a', 1 + (wtem - 20) * .0025)
				end
			elseif inst['形态'] == "冰狐狸" then		
				state_ice(inst)
			elseif inst['形态'] == "白狐狸" or inst['形态'] == "要完蛋狐狸" then
				state_bai(inst)
			end
		elseif TheWorld.state.isdusk then
			if inst['形态'] == "红狐狸" then
				state_red(inst)
				if inst:HasTag("盛宴状态开启") then
					inst.components.combat.damagemultiplier = 1.4 + (wtem - 20) * .005
					icl:SetExternalSpeedMultiplier(inst, 'a', 1.5 + (wtem - 20) * .0025)
				else
					inst.components.combat.damagemultiplier = 1.2 + (wtem - 20) * .005
					icl:SetExternalSpeedMultiplier(inst, 'a', 1.2 + (wtem - 20) * .0025)
				end
			elseif inst['形态'] == "冰狐狸" then
				state_ice(inst)
			elseif inst['形态'] == "白狐狸" or inst['形态'] == "要完蛋狐狸" then
				state_bai(inst)
			end
		elseif TheWorld.state.isnight then
			if inst['形态'] == "红狐狸" then
				state_red(inst)
				if inst:HasTag("盛宴状态开启") then
					inst.components.combat.damagemultiplier = 1.5 + (wtem - 20) * .005
					icl:SetExternalSpeedMultiplier(inst, 'a', 1.3 + (wtem - 20) * .0025)
				else
					inst.components.combat.damagemultiplier = 1.25 + (wtem - 20) * .005
					icl:SetExternalSpeedMultiplier(inst, 'a', .9 + (wtem - 20) * .0025)
				end
			elseif inst['形态'] == "冰狐狸" then
				state_ice(inst)
			elseif inst['形态'] == "白狐狸" or inst['形态'] == "要完蛋狐狸" then
				state_bai(inst)
			elseif inst['形态'] == "月狐狸" then
				-- local GLV = inst.LightWatcher:GetLightValue()
				inst.components.health.absorb = .7
				inst.components.hunger:SetRate(.3)
				inst.components.eater:SetDiet({ FOODTYPE.MEAT }, { FOODTYPE.MEAT })
				ict.mintemp = 6
				ict.maxtemp = 60
				ict.overheattemp = 999
				inst.components.sanity.custom_rate_fn = SanityFn
				inst.AnimState:SetBuild("huli_fox_moon")
				inst.components.combat.damagemultiplier = 2.2
				icl:SetExternalSpeedMultiplier(inst, 'a', 2)
			end 
			Night_San(inst)
		end
	end
end

local function hulisan(inst)
	if inst:HasTag("playerghost") then return end
	local fullmoon = TheWorld.state.isfullmoon
	local winter = TheWorld.state.iswinter
	local san = inst.components.sanity:GetPercent()
	inst:DoTaskInTime(0, function()
		if inst.components.health and not inst.components.health:IsDead() then
			if inst['形态'] == "红狐狸" then
				inst.hulistate_eng = "Red fox" 
				if inst:HasTag("冰域状态开启") then
					inst:RemoveTag("冰域状态开启")
				end
				if fullmoon and san > .25 then
					inst:DoTaskInTime(0, function() inst['形态'] = "月狐狸"
					FormChange(inst)
					inst.components.talker:Say("月黑风高!是时候装下B了!!!") end)
				elseif san < .25 then
						inst:DoTaskInTime(0, function() inst['形态'] = "白狐狸"
						FormChange(inst)
						inst.components.talker:Say("我开始方了!想要睡觉觉!") end)
				elseif san > .25 and not fullmoon then
					if inst.statekey > 0 then
						inst:DoTaskInTime(0, function() inst['形态'] = "冰狐狸"
						FormChange(inst)
						inst.components.talker:Say("芭拉芭拉\n变身冰狐狸!") end)
					end
				end
			elseif inst['形态'] == "白狐狸" then 
				inst.hulistate_eng = "White fox" 
				if inst:HasTag("盛宴状态开启") then
					inst:RemoveTag("盛宴状态开启")
				elseif inst:HasTag("冰域状态开启") then
					inst:RemoveTag("冰域状态开启")
				end
				if san < .15 then
					inst:DoTaskInTime(0, function() inst['形态'] = "要完蛋狐狸"
					FormChange(inst)
					inst.components.talker:Say("感觉快要完蛋了..") end)
				elseif not fullmoon and san > .27 then
					if inst.statekey <= 0 then 
						inst:DoTaskInTime(0, function() inst['形态'] = "红狐狸"
						FormChange(inst)
						inst.components.talker:Say("变回来了!么么哒!") end)
					elseif inst.statekey > 0 then 
						inst:DoTaskInTime(0, function() inst['形态'] = "冰狐狸"
						FormChange(inst)
						inst.components.talker:Say("变回小冰冰了!么么哒!") end)
					end
				end
			elseif inst['形态'] == "冰狐狸" then 
				inst.hulistate_eng = "Ice fox" 
				if inst:HasTag("盛宴状态开启") then
					inst:RemoveTag("盛宴状态开启")
				end
				if san > .25 and not fullmoon then
					if inst.statekey <= 0 then
						inst:DoTaskInTime(0, function() inst['形态'] = "红狐狸"
						FormChange(inst)
						inst.components.talker:Say("芭拉芭拉\n变身红狐狸!") end)
					end
				elseif fullmoon and san > .25 then
						inst:DoTaskInTime(0, function() inst['形态'] = "月狐狸"
						FormChange(inst)
						inst.components.talker:Say("今天月圆,借力量搞搞事吧!") end)
				elseif san < .25 then
					inst:DoTaskInTime(0, function() inst['形态'] = "白狐狸"
					FormChange(inst)
					inst.components.talker:Say("变白狐狸了,有点累了!") end)
				end
			elseif inst['形态'] == "月狐狸" then
				inst.hulistate_eng = "Moon fox" 
				if inst:HasTag("盛宴状态开启") then
					inst:RemoveTag("盛宴状态开启")
				elseif inst:HasTag("冰域状态开启") then
					inst:RemoveTag("冰域状态开启")
				end
				if san < .25 then
					inst:DoTaskInTime(0, function() inst['形态'] = "白狐狸"
					FormChange(inst)
					inst.components.talker:Say("连我都方了!你仿佛在刻意逗我笑!") end)
				elseif not fullmoon and san > .25 then 
					if inst.statekey <= 0 then 
						inst:DoTaskInTime(0, function() inst['形态'] = "红狐狸"
						FormChange(inst)
						inst.components.talker:Say("又变回来了!装B要谨慎!!") end)
					elseif inst.statekey > 0 then
						inst:DoTaskInTime(0, function() inst['形态'] = "冰狐狸"
						FormChange(inst)
						inst.components.talker:Say("天亮了,变回小冰冰了!") end)
					end
				end
			elseif inst['形态'] == "要完蛋狐狸" then
				inst.hulistate_eng = "Debilitated fox" 
				if inst:HasTag("盛宴状态开启") then
					inst:RemoveTag("盛宴状态开启")
				elseif inst:HasTag("冰域状态开启") then
					inst:RemoveTag("冰域状态开启")
				end
				if san > .17 then
					inst:DoTaskInTime(0, function() inst['形态'] = "白狐狸"
					FormChange(inst)
					inst.components.talker:Say("即使疲惫感减少了!还是有点方!") end)
				end
			end 
			HuliChange(inst)
		else
			inst['形态'] = "狐狸鬼"
			inst.hulistate_eng = "Ghost fox" 
			inst.statekey = 0
			if inst:HasTag("盛宴状态开启") then
				inst:RemoveTag("盛宴状态开启")
			elseif inst:HasTag("冰域状态开启") then
				inst:RemoveTag("冰域状态开启")
			end
		end
	end)
end

local function usedtouchstone(inst)
	inst['形态'] = "红狐狸"
end

local function DoEffects(pet)
    SpawnPrefab("spawn_fx_medium").Transform:SetPosition(pet.Transform:GetWorldPosition())
end

local function OnSpawnPet(inst, pet)
    pet:DoTaskInTime(0, DoEffects)
end

-----------------------------------------------------------------

local function Show_Party(inst, dt)
	if inst:HasTag("playerghost") then return end
	local eqp = inst.components.combat:GetWeapon()
		inst.party_time = inst.party_time - dt
	if inst.party_time <= 0 then
		if inst['形态'] == "红狐狸" then
			if inst:HasTag("盛宴状态开启") then
				-- if inst.redsikllstate == 'NOCD' then
					if not eqp or eqp.prefab ~= "gumifan" then
						if inst:HasTag("盛宴状态开启") then
							inst:RemoveTag("盛宴状态开启")
						end
						return
					end
					-- inst.party_time = .5
					local nightmare = SpawnPrefab("huli_ground_firefx")
					nightmare.Transform:SetPosition(inst.Transform:GetWorldPosition())
					nightmare.Transform:SetScale(.25,.25,.25)
				-- else
					-- inst:RemoveTag("盛宴状态开启")
				-- end
			end
		end
		if inst['形态'] == "冰狐狸" then
			if inst:HasTag("冰域状态开启") then
				-- inst.party_time = .5
				local nightmare = SpawnPrefab("icefox_fx")
				nightmare.Transform:SetPosition(inst.Transform:GetWorldPosition())
				nightmare.Transform:SetScale(.6,.6,.6)
				nightmare:DoTaskInTime(6, nightmare.Remove)
			end
		end
	end
end

local function RedPartyCD(inst)
	if inst['形态'] == "红狐狸" then
		if inst.FireSikllCD > 0 then
			inst.FireSikllCD = inst.FireSikllCD - 1 
			inst.redsikllstate = '盛宴冷却中'
		elseif inst.FireSikllCD <= 0 then
			inst.redsikllstate = 'NOCD'
			if inst.redpartycd then 
				inst.redpartycd:Cancel() 
				inst.redpartycd = nil 
				inst.components.talker:Say(hl_loc('盛宴冷却好喽!', 'Fire skill is ready!'))
			end
		end
	end
end

local function redstate_consume(inst)
	if inst['形态'] == "红狐狸" then
		if inst:HasTag("盛宴状态开启") then
			inst.components.huli_elesys:FireDoDelta(-2)
		end
	end
end

local function redstate_monitor(inst)
	local hunger = inst.components.hunger:GetPercent()
	if inst:HasTag("盛宴状态开启") then
		if hunger >= .25 and inst.components.huli_elesys['当前火元素'] < 3 then
			inst:RemoveTag("盛宴状态开启")
			inst.components.talker:Say(hl_loc('火元素不足,关闭盛宴状态.', 'Insufficient fire element，Close fire skill status.'))
		elseif hunger < .25 and inst.components.huli_elesys['当前火元素'] >= 3 then
			inst:RemoveTag("盛宴状态开启")
			inst.components.talker:Say(hl_loc('肚子饿了,关闭盛宴状态.', "I'm hungry，Close fire skill status."))
		end
	end
end
--------------------------------------------------------------------------------------------------
local function IcePartyCD(inst)

	if inst['形态'] == "冰狐狸" then
		if inst.IceSikllCD > 0 then
			inst.IceSikllCD = inst.IceSikllCD - 1 
			inst.icesikllstate = '冰域冷却中'
		elseif inst.IceSikllCD <= 0 then
				inst.icesikllstate = 'NOCD'
			if inst.icepartycd then 
				inst.icepartycd:Cancel() 
				inst.icepartycd = nil 
				inst.components.talker:Say(hl_loc('冰域冷却好喽!', 'Ice skill is ready!'))
			end
		end
	end
end

local function icestate_consume(inst)
	if inst['形态'] == "冰狐狸" then
		if inst:HasTag("冰域状态开启") then
			inst.components.huli_elesys:IceDoDelta(-2)
		end
	end
end

local function icestate_monitor(inst)
	if inst:HasTag("playerghost") then return end
	local hunger = inst.components.hunger:GetPercent()
	if inst:HasTag("冰域状态开启") then
		if hunger >= .25 and inst.components.huli_elesys['当前冰元素'] < 7 then
			inst:RemoveTag("冰域状态开启")
			inst.components.talker:Say(hl_loc('冰元素不足,关闭冰域状态.', 'Insufficient ice element，Close ice skill status.'))
		elseif hunger < .25 and inst.components.huli_elesys['当前冰元素'] >= 7 then
			inst:RemoveTag("冰域状态开启")
			inst.components.talker:Say(hl_loc('肚子饿了,关闭冰域状态.', "I'm hungry，Close ice skill status."))
		end
	end
end

-------------------------------------------------------------------------------
--------------fire party
-------------------------------------------------------------------------------
local function Start_Fire_Party(inst, data)
	if inst:HasTag("playerghost") then return end
	local other = data.target
	local level = inst.components.huli_levelsys:Get('当前等级')
	local maxlevel = inst.components.huli_levelsys:Get('最大等级')
	local get_per = inst.components.huli_elesys['当前火元素'] / inst.components.huli_elesys['最大火元素']
	local cum_sper = inst.skilldmgset/100 * inst.components.huli_elesys['当前火元素']
	local partytime = 180 - (level * 3)
	local fire_damage = cum_sper * .005
	if cum_sper / inst.Max_MEM > .2 then
		fire_damage = (1-cum_sper / inst.Max_MEM / 3) * cum_sper * .005
		partytime = 180 * (1+cum_sper / inst.Max_MEM * 2.5)  - (level * 3)
	end
	--local mult = inst.components.combat.damagemultiplier
	-- local san_dt = -(inst.components.sanity.max * .05)
	local hung_dt = -(inst.components.hunger.max * .08)
	local numRings = 2 + (level * .1)
	local damageRings = 2 + (level * .1)
	local ewai_multiplier = 1 + (level * .01)

	if other and not other:HasTag("wall") and not other:HasTag("companion") then --and not other:HasTag("veggie") then
		if inst:HasTag("盛宴状态开启") then
			if inst.redsikllstate == 'NOCD' and inst.redsikllactivation == 'ON' then
				inst.components.groundpounderds.bonusdamage = fire_damage
				inst.components.groundpounderds.ewai_multiplier = ewai_multiplier
				inst.components.groundpounderds.groundpoundfx = "huli_ground_firefx"
				-- inst.components.groundpounderds.groundpoundfx = "lightning"
				-- inst.components.groundpounderds.groundpoundringfx = "huli_ringfx"
				inst.FireSikllCD = partytime
				if level < maxlevel or inst.components.huli_elesys['当前火元素'] < cum_sper then
					-- inst.components.sanity:DoDelta(san_dt)
					inst.components.hunger:DoDelta(hung_dt)
					inst.components.groundpounderds.numRings = numRings
					inst.components.groundpounderds.damageRings = damageRings
					if (1 <= level) and (level < 15) then
						inst.components.groundpounderds:GroundPound()
					elseif (15 <= level) and (level < 30) then
						inst.components.groundpounderds:GroundPound(2)
					elseif (30 <= level) then
						inst.components.groundpounderds:GroundPound(3)
					end
				elseif level >= maxlevel and inst.components.huli_elesys['当前火元素'] >= cum_sper then
					-- inst.components.sanity:DoDelta(0)
					inst.components.hunger:DoDelta(0)
					inst.components.groundpounderds.numRings = 7
					inst.components.groundpounderds.damageRings = 7
					inst.components.groundpounderds:GroundPound(4)
				end
				inst.components.huli_elesys['当前火元素'] = inst.components.huli_elesys['当前火元素'] - cum_sper
				inst.redsikllstate = '盛宴冷却中'
				inst.redpartycd = inst:DoPeriodicTask(1, function() RedPartyCD(inst) end)
			end
		end
	end
end
-------------------------------------------------------------------------------
--------------ice domain
-------------------------------------------------------------------------------
local function Start_Ice_Domain(inst, data)
	if inst:HasTag("playerghost") then return end
	local other = data.target
	local level = inst.components.huli_levelsys:Get('当前等级')
	local maxlevel = inst.components.huli_levelsys:Get('最大等级')
	local get_per = inst.components.huli_elesys['当前冰元素']/inst.components.huli_elesys['最大冰元素']
	local cum_sper = inst.skilldmgset/100 * inst.components.huli_elesys['当前冰元素']
	local ice_domain_time = 180 - (level * 3)
	local ice_damage = cum_sper * .007
	if cum_sper / inst.Max_MEM > .2 then
		ice_damage = (1-cum_sper / inst.Max_MEM / 2.5) * cum_sper * .007
		ice_domain_time = 180 * (1+cum_sper / inst.Max_MEM * 2.5)  - (level * 3)
	end
	-- local mult = inst.components.combat.damagemultiplier
	-- local san_dt = -(inst.components.sanity.max * .05)
	local hung_dt = -(inst.components.hunger.max * .08)
	local numRings = 2 + (level * .14)
	local damageRings = 2 + (level * .14)
	local ewai_multiplier = 1 + (level * .01)

	if other and not other:HasTag("wall") and not other:HasTag("companion") then --and not other:HasTag("veggie") then
		if inst:HasTag("冰域状态开启") then
			if inst.icesikllstate == 'NOCD' and inst.icesikllactivation == 'ON' then
				inst.components.groundpounderds.ewai_multiplier = ewai_multiplier
				inst.components.groundpounderds.groundpoundfx = "icefox_fx"
				inst.IceSikllCD = ice_domain_time
				if get_per >= .1 then
					inst.components.huli_elesys['当前冰元素'] = inst.components.huli_elesys['当前冰元素'] - cum_sper
				else
					inst.components.huli_elesys['当前冰元素'] = inst.components.huli_elesys['当前冰元素'] - inst.components.huli_elesys['当前冰元素']
				end
				-- inst.components.sanity:DoDelta(san_dt)
				inst.components.hunger:DoDelta(hung_dt)
				inst.components.groundpounderds.ringDelay = .2
				inst.components.groundpounderds.numRings = numRings
				inst.components.groundpounderds.radiusStepDistance = 3.3
				inst.components.groundpounderds.damageRings = damageRings
				inst.components.groundpounderds.bonusdamage = ice_damage
				inst.components.groundpounderds:GroundPound(2)
				inst.icesikllstate = '冰域冷却中'
				inst.icepartycd = inst:DoPeriodicTask(1, function() IcePartyCD(inst) end)
			end
		end
	end
end

local function get_damage(inst)
	local cnc = inst.components.combat
	local weapon = cnc:GetWeapon()
	if weapon and weapon.components.weapon ~= nil then
		-- return math.ceil(weapon.components.weapon.damage * cnc.damagemultiplier)
		return math.ceil(weapon.components.weapon:GetDamage(inst) * cnc.damagemultiplier)
	else
		return math.ceil(cnc.defaultdamage * cnc.damagemultiplier)
	end
end

local function GiveMihobell(inst, old_mihobell, pos)
	local mihobell = old_mihobell or SpawnPrefab("mihobell")
	if mihobell then
		mihobell.owner = inst
		inst.mihobell = mihobell
		if pos then
			inst.mihobell.Physics:Teleport(pos.x, pos.y, pos.z)
			inst:DoTaskInTime(0, function()
				if inst.mihobell:IsNear(inst, 1) then
					inst.components.inventory:GiveItem(mihobell)
				end
			end)
		else
			inst.components.inventory.ignoresound = true
			inst.components.inventory:GiveItem(mihobell)
			inst.components.inventory.ignoresound = false
		end

		local name = STRINGS.NAMES[string.upper(mihobell.prefab)]
		mihobell.components.named:SetName(inst.name..hl_loc("的", " of ")..name)
	end 
end

local function GiveMiregg(inst)
	local miregg = SpawnPrefab("miregg")
	inst.components.inventory:GiveItem(miregg)
	inst['已拥有小龙蛋'] = true
end

local function OnDespawn(inst)		

	if inst.mihobell then
		local owner = inst.mihobell.components.inventoryitem.owner
		-- if owner and owner ~= inst then
			-- if owner.components.container then
				-- owner.components.container:DropItem(inst.mihobell)
			-- elseif owner.components.inventory then
				-- owner.components.inventory:DropItem(inst.mihobell)
			-- end
		-- end
		-- local pos = inst.mihobell:GetPosition()
		inst.inv_o = false
		if owner then 
			inst.inv_o = true
		end

		inst.mihobell:DoTaskInTime(FRAMES, function(inst)
			if inst:IsValid() then
				inst:Remove() 
			end 
		end) 
	end
	
	if inst.miho then
		inst.miho.components.container:DropEverythingWithTag("irreplaceable")
		inst.miho:DoTaskInTime(FRAMES, function(inst)
			if inst and inst:IsValid() then
				inst:Remove() 
			end 
		end) 
	end
end

local function OnNewSpawn(inst)
	GiveMihobell(inst)
	GiveMiregg(inst)
end

local function onsave(inst, data)

	data.level = inst.level
	data.min_exp = inst.min_exp
	data.max_exp = inst.max_exp
	
	data.Min_Fire_Element = inst.Min_Fire_Element
	data.Min_Ice_Element = inst.Min_Ice_Element
	data.Max_Fire_Element = inst.Max_Fire_Element
	data.Max_Ice_Element = inst.Max_Ice_Element
	
	data['已拥有小龙蛋'] = inst['已拥有小龙蛋']
	
	data['形态'] = inst['形态']
	data.statekey = inst.statekey
	data.redsikllstate = inst.redsikllstate
	data.icesikllstate = inst.icesikllstate
	
	data.FireSikllCD = inst.FireSikllCD
	data.IceSikllCD = inst.IceSikllCD
	
	data.labeltxt = inst.labeltxt
	data.labeltxt_edit = inst.labeltxt_edit
	data.skilldmgset = inst.skilldmgset
	
	data.hg = inst.components.hunger.max
	data.san = inst.components.sanity.max
	
	data.mihobell = inst.mihobell and inst.mihobell:GetSaveRecord()
	data.miho = inst.miho and inst.miho:GetSaveRecord()
	
	if inst.inv_o then
		data.inv_owner = true
	else
		data.inv_owner = false
	end
end

local function onload(inst, data)
	if not data then return end
	if data.labeltxt ~= nil then
		inst.labeltxt = data.labeltxt
	end
	if data.labeltxt_edit ~= nil then
		inst.labeltxt_edit = data.labeltxt_edit
	end
	
	if data.mihobell then
		inst.mihobell = SpawnSaveRecord(data.mihobell)
		if data.inv_owner then
			GiveMihobell(inst, inst.mihobell)
		else
			if inst.mihobell.pos then
				GiveMihobell(inst, inst.mihobell, inst.mihobell.pos)
			end
		end
		
		if data.miho then
			inst.miho = SpawnSaveRecord(data.miho)
			inst.mihobell:RebindMiho(inst.miho)
		end
	end
	
	if data['已拥有小龙蛋'] then
		inst['已拥有小龙蛋'] = data['已拥有小龙蛋']
	else
		GiveMiregg(inst)
	end


end

local function onpreload(inst, data)
    if data then
		if data.level  ~= nil then
			inst.components.huli_levelsys['当前等级'] = data.level
			inst.level = nil
		end
		if data.min_exp  ~= nil then
			inst.components.huli_levelsys['当前经验值'] = data.min_exp
			inst.min_exp = nil
		end
		if data.max_exp  ~= nil then
			inst.components.huli_levelsys['升级经验值'] = data.max_exp
			inst.max_exp = nil
		end
		
		if data.Min_Fire_Element and inst.components.huli_elesys then
			inst.components.huli_elesys:Set('当前火元素', data.Min_Fire_Element)
			inst.components.huli_elesys:Set('最大火元素', data.Max_Fire_Element)
			
			inst.components.huli_elesys:Set('当前冰元素', data.Min_Ice_Element)
			inst.components.huli_elesys:Set('最大冰元素', data.Max_Ice_Element)
	
			inst.Min_Fire_Element = nil
			inst.Min_Ice_Element = nil
			inst.Max_Fire_Element = nil
			inst.Max_Ice_Element = nil
		end
		
		if data['形态']  ~= nil then
			inst['形态'] = data['形态']
		end
		if data.statekey ~= nil then
			inst.statekey = data.statekey
		end
		if data.redsikllstate ~= nil then
			inst.redsikllstate = data.redsikllstate
		end
		if data.icesikllstate ~= nil then
			inst.icesikllstate = data.icesikllstate
		end
		if data.FireSikllCD ~= nil then
			inst.FireSikllCD = data.FireSikllCD
		end
		if data.IceSikllCD ~= nil then
			inst.IceSikllCD = data.IceSikllCD
		end
		if data.skilldmgset ~= nil then
			inst.skilldmgset = data.skilldmgset
		end
		
		if data.hg then 
			inst.components.hunger.max = data.hg
		end
		if data.san then 
			inst.components.sanity.max = data.san
		end
    end
end

local function labelS(inst)
	return inst._labeltxt:value()
end

local common_postinit = function(inst) 
	inst.MiniMapEntity:SetIcon( "huli.tex" )
	
	inst:AddTag("hulibuilder")
	inst:AddTag("mihoowner")
	inst:AddTag("huli")
	--inst:AddTag("groggy")
	-- inst:AddComponent("timer")
	inst:AddComponent("groundpounderds")

	inst._damage = net_shortint(inst.GUID,"huli_damage","huli_damage")
	inst._absorb = net_shortint(inst.GUID,"huli_absorb","huli_absorb")
	inst._walkspeed = net_byte(inst.GUID,"huli_walkspeed","huli_walkspeed")
	inst._walkspeedmult = net_shortint(inst.GUID,"huli_walkspeedmult","huli_walkspeedmult")
	
	inst._hulistate = net_string(inst.GUID, "形态", "大狐狸形态")
	inst._labeltxt = net_string(inst.GUID, "huli_labeltxt", "huli_labeltxt")
	inst._petnumber = net_byte(inst.GUID,"huli_petnumber","huli_petnumber")
	inst._maxpetnumber = net_byte(inst.GUID,"huli_maxpetnumber","huli_maxpetnumber")
	inst._damagemultiplier = net_shortint(inst.GUID,"huli_damagemultiplier","huli_damagemultiplier")
	
	inst._fireskillCD = net_shortint(inst.GUID,"huli_fireskillCD","huli_fireskillCD")
	inst['当前火元素net'] = net_int(inst.GUID, "当前火元素net")
	inst['最大火元素net'] = net_int(inst.GUID, "最大火元素net")
	
	inst._iceskillCD = net_shortint(inst.GUID,"huli_iceskillCD","huli_iceskillCD")
	inst['当前冰元素net'] = net_int(inst.GUID, "当前冰元素net")
	inst['最大冰元素net'] = net_int(inst.GUID, "最大冰元素net")
	
	inst._redsikllactivation = net_string(inst.GUID, "huli_redsikllactivation")
	inst._icesikllactivation = net_string(inst.GUID, "huli_icesikllactivation")
	inst._worldtemp = net_shortint(inst.GUID, "huli_worldtemp")
	
	inst._huli_coin = net_int(inst.GUID, "huli_coin", "huli_coin")
	inst._currentpage = net_byte(inst.GUID, "huli_store_currentpage", "huli_store_currentpage")
	
	inst._skilldmgset = net_byte(inst.GUID, "huli_skilldmgset", "huli_skilldmgset")
	
	inst.label = inst.entity:AddLabel()
	inst:ListenForEvent('huli_labeltxt', function() 
		inst:DoTaskInTime(.01, function() 
			if #labelS(inst) > 40 then 
				inst.label:SetWorldOffset(0, 2.8+#labelS(inst)/250, 0)
			else
				inst.label:SetWorldOffset(0, 2.8, 0)
			end
			inst.label:SetText(labelS(inst)) 
		end)
	end)
	inst.label:SetFont(SMALLNUMBERFONT)
    inst.label:SetFontSize(22)
    inst.label:SetColour(247/255, 22/255, 130/255, 1)
    inst.label:SetWorldOffset(0, 2.8, 0)
    inst.label:SetUIOffset(0, 0, 0)
    inst.label:Enable(true)
	
	-- if TheWorld.ismastersim then
		-- AddModRPCHandler("huli_rpc", "statekey", statekey) 
	-- else
		-- AddModRPCHandler("huli_rpc", "statekey", function() end)
	-- end
	-- MakeInventoryFloatable(inst, "small", 0)
	-- inst:AddComponent("huli_swimmer")
	inst:AddComponent("huli_key")
	--inst.components.huli_key:AddActionListener("huli", KEY_F9, "key_test")
	-- inst.components.huli_key:AddActionListener("huli", KEY_F11, "INFO_HL")
	
	-- inst.components.huli_key:AddActionListener("huli", HULI_TRANSFORM_SET, "huli_statekey")
		
	-- inst.components.huli_key:AddListenerZuHeKey(HULI_TRANSFORM_SET, HULI_TRANS_COMBINATIONKEY_SET, 'huli', "huli_statekey")
	-- inst.components.huli_key:AddListenerZuHeKey(XHL_CONTROL_SET, XHL_CALL_COMBINATIONKEY_SET, 'huli', "call_xhl")
	-- inst.components.huli_key:AddListenerZuHeKey(HULI_JN_KEY_SET, HULI_JN_COMBINATIONKEY_SET, 'huli', "SkillState")
	-- inst.components.huli_key:AddListenerZuHeKey(HULI_TY_KEY_SET, HULI_TY_COMBINATIONKEY_SET, 'huli', "HULI_DODGE_A")

end

local master_postinit = function(inst)
	inst.soundsname = "willow"
	
	inst.components.health:SetMaxHealth(TUNING.HULI_HEALTH)
	inst.components.health.save_maxhealth = true
	
	inst.components.hunger:SetMax(TUNING.HULI_HUNGER)
	inst.components.sanity:SetMax(TUNING.HULI_SANITY)
	inst.components.sanity.neg_aura_mult = 0
	
	inst.components.builder.science_bonus = HULI_SCIENCE_BONUS_SET
	--inst.components.sanity.dapperness = (TUNING.DAPPERNESS_SMALL)
	inst.components.combat.damagemultiplier = 1
	-- inst.components.health.absorb = 0
	-- inst.components.health.invincible = true --测试用
	
	-- inst.components.drownable.enabled = false --测试用
	
	inst:AddComponent("huli_petleash_mir")
	inst:AddComponent("huli_petleash")
	inst.components.huli_petleash:SetOnSpawnFn(OnSpawnPet)

	inst:AddComponent("lootdropper")

	inst:AddComponent("huli_store")
	
	inst:AddComponent("huli_elesys")
	
	inst:AddComponent("huli_levelsys")
	local maxexp_alg = (100 * (1 - Exp_P^5) / (1 - Exp_P)) + 0.01
	inst.components.huli_levelsys:Set({['最大等级'] = 30, ['升级经验值'] = 100, ['最大经验值'] = maxexp_alg})
	inst.components.huli_levelsys['等级变更fn'] = LevelUpFn
	inst.components.huli_levelsys['加载等级fn'] = function(inst, c_lv) inst.components.huli_petleash.maxpets = 1 + math.floor(c_lv / 10) end

	-- inst:AddComponent("huli_fighteruser")
	
    inst.components.eater:SetOnEatFn(oneat_getexp)
	-- inst.components.builder.onBuild = onBuild
	inst.components.locomotor.walkspeed = TUNING.WILSON_WALK_SPEED
	inst.components.locomotor.runspeed = TUNING.WILSON_RUN_SPEED 

	inst.labeltxt = '★萌萌哒的狐狸★'
	inst.labeltxt_edit = ''
	inst['形态'] = "红狐狸"
	inst.hulistate_eng = "Red fox"
	inst.redsikllstate = 'NOCD'
	inst.redsikllactivation = 'ON'
	inst.icesikllstate = 'NOCD'
	inst.icesikllactivation = 'ON'
	
	inst.key_test = 0
	inst.statekey = 0
	inst.party_time = .3

	inst.Max_MEM = 99999
	inst.FireSikllCD = 0
	inst.IceSikllCD = 0
	inst.skilldmgset = 10
	
	inst.mihobell = nil
	inst.miho = nil
	inst.GiveMihobell = GiveMihobell
	inst['获取经验值fn'] = GetAtkExp
			
	inst.OnSave = onsave
	inst.OnLoad = onload
    inst.OnPreLoad = onpreload
	inst.OnDespawn = OnDespawn
	inst.OnNewSpawn =OnNewSpawn 
	
	inst:WatchWorldState("isfullmoon", hulisan)
    hulisan(inst, TheWorld.state.isfullmoon)
	inst:WatchWorldState("iswinter", hulisan)
	inst:WatchWorldState("phase", HungerFire)
	
	inst:ListenForEvent( "hungerdelta", HungerFire)
	inst:ListenForEvent( "sanitydelta", hulisan)
	inst:ListenForEvent("respawnfromghost", usedtouchstone)
	inst:ListenForEvent("respawnfromcorpse", usedtouchstone)
	-- inst:ListenForEvent("ms_respawnedfromghost", usedtouchstone)
	inst:ListenForEvent( "temperaturedelta", temlisten)
	
	--inst:ListenForEvent( "animover", Fox1_Anim)
	inst:ListenForEvent("onhitother", foxattack)
	inst:ListenForEvent("onhitother", Start_Fire_Party)
	inst:ListenForEvent("onhitother", Start_Ice_Domain)
	inst:ListenForEvent("onhitother", Hitfreeze)
	-- inst:ListenForEvent("onhitother", onkilledother)
	inst:ListenForEvent("killed", onkilled)
	
	inst:ListenForEvent( "attacked", FrozenBody)
	
	inst:ListenForEvent("working", rockdrop_gem)
	-- inst:ListenForEvent("finishedwork", rockdrop_gem)

	inst:ListenForEvent( "daytime", function() HuliChange(inst) end , TheWorld)
	inst:ListenForEvent( "dusktime", function() HuliChange(inst) end , TheWorld)
    inst:ListenForEvent( "nighttime", function() HuliChange(inst) end , TheWorld)
	
	inst:DoPeriodicTask(.3334, function() if temlisten(inst) then tempdelta(inst) end end)
	inst:DoPeriodicTask(.5, function() Show_Party(inst, .1) end)
	
	inst:DoPeriodicTask(.5, function() redstate_consume(inst) end)
	inst:DoPeriodicTask(.1, function() redstate_monitor(inst) end)

	inst.redpartycd = inst:DoPeriodicTask(1, function() RedPartyCD(inst) end)
	
	inst:DoPeriodicTask(.5, function() icestate_consume(inst) end)
	inst:DoPeriodicTask(.1, function() icestate_monitor(inst) end)

	inst.icepartycd = inst:DoPeriodicTask(1, function() IcePartyCD(inst) end)

	-- inst:DoPeriodicTask(2, function() 
		-- print(inst.components.locomotor:GetExternalSpeedMultiplier(inst, 'a'))
		-- print('移速倍速'..inst.components.locomotor:GetSpeedMultiplier())
	-- end)
	
	inst:DoPeriodicTask(0, function() 
		inst._damage:set(get_damage(inst)) 
		inst._skilldmgset:set(inst.skilldmgset) 
		inst._absorb:set(inst.components.health.absorb*100) 
		inst._walkspeed:set(inst.components.locomotor:GetWalkSpeed()) 
		inst._walkspeedmult:set(inst.components.locomotor:GetSpeedMultiplier()*100) 
		inst._hulistate:set(hl_loc(inst['形态'], inst.hulistate_eng)) 
		inst._labeltxt:set(inst.labeltxt) 
		inst._petnumber:set(inst.components.huli_petleash.numpets) 
		inst._maxpetnumber:set(inst.components.huli_petleash.maxpets) 
		
		inst._damagemultiplier:set(inst.components.combat.damagemultiplier*100) 
		
		inst._fireskillCD:set(inst.FireSikllCD) 
		inst._redsikllactivation:set(inst.redsikllactivation) 
		inst._icesikllactivation:set(inst.icesikllactivation) 
		
		inst._iceskillCD:set(inst.IceSikllCD) 
		
		-- inst._worldtemp:set(string.format("%d", TheWorld.state.temperature))		
		inst._worldtemp:set(TheWorld.state.temperature)	
	end)

	Do_Health(inst)
	
	inst.components.cursable.ApplyCurse = function(self, ...) return end
	inst.components.eater.ignoresspoilage = true	
	local Old_eat = inst.components.eater.Eat
	inst.components.eater.Eat = function(self, food )
		if self:CanEat(food) then
			if food.prefab == "meat"
			or food.prefab == "smallmeat" 
			or food.prefab == "batwing" 
			or food.prefab == "froglegs" 
			or food.prefab == "plantmeat"
			or food.prefab == "cookedmonstermeat" then
				food.components.edible.sanityvalue = 0
			elseif food.prefab == "monstermeat" then
				food.components.edible.healthvalue = -2
				food.components.edible.sanityvalue = -5
			elseif food.prefab == "monstermeat_dried" then
				food.components.edible.healthvalue = 2
				food.components.edible.sanityvalue = -2
			elseif food.prefab == "monsterlasagna" then
				food.components.edible.healthvalue = -3
				food.components.edible.sanityvalue = -5 
			end 
		end 
		return Old_eat(self, food) 
	end
	
end

local str_ch = {
	"可怜的我...",
	"你伤到我了...",
	"我快要哭了...",
	"你把我弄哭了...",
	"我不能理解你...",
	"把你的手拿开!",
	"离我远点!","别...",
	"为什么...!!",
	"我很伤心...",
	"你打算杀死我么!!",
	"我要告诉妈妈!",
	"那一点都不好玩!",
}

local str_eng = {
	"Ow! Do not hurt me!",
	"Do not hit me!",
	"Ouch! Stop it!",
	"You'll get burned!",
	"You're gonna kill me?!",
	"I'm telling mama!",
	"This is not funny!",
	"No!",
	"Stop it!",
	"Oww!",
	"Poor little me...",
	"You hurt me...",
	"I'm crying...",
	"You make me cry...",
	"I can't understand you...",
	"Take your hands off me!",
	"Stay away from me!",
	"Nooo...",
	"Why...?",
	"I'm sad...",
}

FRZOENHURT = hl_loc(str_ch, str_eng)

return MakePlayerCharacter("huli", prefabs, assets, common_postinit,master_postinit, start_inv)
