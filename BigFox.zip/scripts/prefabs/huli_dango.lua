local assets =
{
    Asset("ANIM", "anim/huli_dango.zip"),
	Asset("ATLAS", "images/inventoryimages/items.xml"),
	Asset( "IMAGE", "images/inventoryimages/items.tex" ),
}

local function oneaten(inst, eater)
	
	local light = SpawnPrefab("wormlight_light")
	light.components.spell:SetTarget(eater)
	if not light.components.spell.target then
		light:Remove()
	end
	light.components.spell:StartSpell()
	if eater then
		if eater.prefab == "huli" then
			eater.components.hunger:DoDelta(70)
			eater.components.health:DoDelta(50)
			eater.components.sanity:DoDelta(30)
		end
	end
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)

    inst.AnimState:SetBank("huli_dango")
    inst.AnimState:SetBuild("huli_dango")
    inst.AnimState:PlayAnimation("idle", true)

    inst.entity:SetPristine()

	inst:AddTag("cattoy")
	inst:AddTag("狐狸兔兔包")
	
    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("inspectable")
	inst:AddComponent("tradable")
	
	inst:AddComponent("edible")
	inst.components.edible.hungervalue = (75)
	inst.components.edible.healthvalue = (50)
	inst.components.edible.sanityvalue = (25)
	inst.components.edible.foodtype = "MEAT"
	inst.components.edible:SetOnEatenFn(oneaten)
	
	inst:AddComponent("perishable")
	inst.components.perishable:SetPerishTime(TUNING.PERISH_SLOW)
	inst.components.perishable:StartPerishing()
	inst.components.perishable.onperishreplacement = "petals"

    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.atlasname = "images/inventoryimages/items.xml"
	
    inst:AddComponent("stackable")
	inst.components.stackable.maxsize = TUNING.STACK_SIZE_SMALLITEM
	
	MakeHauntableLaunch(inst)

    return inst
end

-- STRINGS.NAMES.HULI_DANGO = "狐狸的兔兔包"
-- STRINGS.RECIPE_DESC.HULI_DANGO = "看起来很美味\n狐狸家族的最爱."
-- STRINGS.CHARACTERS.GENERIC.DESCRIBE.HULI_DANGO = "狐狸家族最喜欢啦."

return Prefab("common/inventory/huli_dango", fn, assets)