require "prefabutil"

local assets =
{
	Asset("ANIM", "anim/huli_fangzi.zip"),
	Asset("ANIM", "anim/huli_fangzi_ui.zip"),
	Asset("ATLAS", "images/inventoryimages/building.xml")
}

local prefabs =
{
    "collapse_small",
}

local function onhammered(inst, worker)
    inst.components.lootdropper:DropLoot()
	inst.components.container:DropEverything()
	inst.components.container:Close()
    local fx = SpawnPrefab("collapse_big")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
    fx:SetMaterial("wood")
    inst:Remove()
end

local function onhit(inst, worker)
	inst.components.huli_workerhit:OnHit(worker)
end

local function onfinishedsound(inst)
    inst.SoundEmitter:PlaySound("dontstarve/common/tent_dis_twirl")
end

local function onfinished(inst)
	inst.AnimState:PlayAnimation("hit")
	inst:ListenForEvent("animover", inst.Remove)
	inst.SoundEmitter:PlaySound("dontstarve/common/tent_dis_pre")
	inst.persists = false
	inst:DoTaskInTime(16 * FRAMES, onfinishedsound)
end

local function onbuilt(inst, data)
    local doer = data.builder
    if doer ~= nil then
        inst._player = {
            userid = doer.userid,
            name = doer.name,
        }
    end
    inst.AnimState:PlayAnimation("hit")
    inst.AnimState:PushAnimation("closed")
end

--We don't watch "stop'phase'" because that
--would not work in a clock without 'phase'
local function wakeuptest(inst, phase)
	if inst.nimpower <= 0 and phase == 'day' then
	-- TheWorld.state.isday then
		inst.components.sleepingbag:DoWakeUp()
	end
end

local function onwake(inst, sleeper, nostatechange)
    if inst.sleeptask ~= nil then
        inst.sleeptask:Cancel()
        inst.sleeptask = nil
    end

    -- inst:StopWatchingWorldState("phase", wakeuptest)

    if not nostatechange then
        if sleeper.sg:HasStateTag("tent") then
            sleeper.sg.statemem.iswaking = true
        end
        sleeper.sg:GoToState("wakeup")
    end

    if inst.sleep_anim ~= nil then
        inst.AnimState:PushAnimation("closed")
    end

	inst.AnimState:PlayAnimation("hit")
    -- inst.components.finiteuses:Use()
end

local function onsleeptick(inst, sleeper)
    local isstarving = sleeper.components.beaverness ~= nil and sleeper.components.beaverness:IsStarving()

    if sleeper.components.hunger ~= nil then
        sleeper.components.hunger:DoDelta(inst.hunger_tick, true, true)
        isstarving = sleeper.components.hunger:IsStarving()
    end

    if sleeper.components.sanity ~= nil and sleeper.components.sanity:GetPercentWithPenalty() < 1 then
        sleeper.components.sanity:DoDelta(TUNING.SLEEP_SANITY_PER_TICK, true)
    end

    if not isstarving and sleeper.components.health ~= nil then
        sleeper.components.health:DoDelta(TUNING.SLEEP_HEALTH_PER_TICK * 2, true, inst.prefab, true)
    end

    if sleeper.components.temperature ~= nil then
        if inst.is_cooling then
            if sleeper.components.temperature:GetCurrent() > TUNING.SLEEP_TARGET_TEMP_TENT then
                sleeper.components.temperature:SetTemperature(sleeper.components.temperature:GetCurrent() - TUNING.SLEEP_TEMP_PER_TICK)
            end
        elseif sleeper.components.temperature:GetCurrent() < TUNING.SLEEP_TARGET_TEMP_TENT then
            sleeper.components.temperature:SetTemperature(sleeper.components.temperature:GetCurrent() + TUNING.SLEEP_TEMP_PER_TICK)
        end
    end

    if isstarving then
        inst.components.sleepingbag:DoWakeUp()
    end
	if inst.components.workable.workleft > 0 then
		inst.components.workable.workleft = inst.components.workable.workleft - 1
	else
		inst.components.sleepingbag:DoWakeUp()
		local fx = SpawnPrefab("collapse_big")
		fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
		onfinished(inst)
	end
end

local function onsleep(inst, sleeper)
    -- inst:WatchWorldState("phase", wakeuptest)
	-- inst:ListenForEvent( "daytime", wakeuptest, TheWorld)

    if inst.sleep_anim ~= nil then
        inst.AnimState:PlayAnimation(inst.sleep_anim, true)
    end
	inst.AnimState:PlayAnimation("hit")
    if inst.sleeptask ~= nil then
        inst.sleeptask:Cancel()
    end
    inst.sleeptask = inst:DoPeriodicTask(TUNING.SLEEP_TICK_PERIOD, onsleeptick, nil, sleeper)
end

local function onsave(inst, data)
       data._player = inst._player
       data.nimpower = inst.nimpower
	   data.workleft = inst.components.workable.workleft
    if inst:HasTag("burnt") or (inst.components.burnable ~= nil and inst.components.burnable:IsBurning()) then
        data.burnt = true
    end
	
end

local function onload(inst, data)
    inst._player = data._player
	if data.nimpower ~= nil then
		inst.nimpower = data.nimpower
	end
	if data.workleft ~= nil then
		inst.components.workable.workleft = data.workleft
	end
    if data ~= nil and data.burnt then
        inst.components.burnable.onburnt(inst)
    end
end

local function get_name(inst)
	local name = STRINGS.NAMES[string.upper(inst.prefab)]
	local ownername = inst._ownername:value()
	local workleft = inst._workleft:value()
	local nimpower = inst._nimpower:value()
	local maxpower = inst._maxpower:value()
	local maxwork = inst._maxwork:value()
	local named = name..'\n房主:'..ownername..'\n耐久度:'..workleft..'/'..maxwork..'\n能源:'..nimpower..'/'..maxpower..'\n '
	-- if get_modinfoname(inst) then
		-- named = name
	-- end
	return named
end

local function onopen(inst)
    inst.AnimState:PlayAnimation("open")
    inst.SoundEmitter:PlaySound("dontstarve/wilson/chest_open")
	if not inst:HasTag('打开') then
		inst:AddTag('打开')
	end
end

local function onclose(inst)
    inst.AnimState:PlayAnimation("close")
    inst.SoundEmitter:PlaySound("dontstarve/wilson/chest_close")
	if inst:HasTag('打开') then
		inst:RemoveTag('打开')
	end
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
	inst.entity:AddLight()
    inst.entity:AddSoundEmitter()
    inst.entity:AddMiniMapEntity()
    inst.entity:AddNetwork()

    MakeObstaclePhysics(inst, 1.5)
	inst._workleft = net_int(inst.GUID, "huli_fangzi._workleft")
	inst._nimpower = net_int(inst.GUID, "huli_fangzi._nimpower", "nimpowerchange")
	inst._maxpower = net_int(inst.GUID, "huli_fangzi._maxpower")
	inst._maxwork = net_int(inst.GUID, "huli_fangzi._maxwork")
	inst._ownername = net_string(inst.GUID, "huli_fangzi._ownername")
	inst.displaynamefn = get_name
	
	inst.entity:AddDynamicShadow()
    inst.DynamicShadow:SetSize( 8, 6 )
	
	inst:AddTag("tent")
    -- inst:AddTag("siestahut")
    inst:AddTag("structure")
	inst:AddTag("huli_build")
	inst:AddTag("huli_fangzi")

    inst.AnimState:SetBank('huli_fangzi')
    inst.AnimState:SetBuild('huli_fangzi')
    inst.AnimState:PlayAnimation("closed")

    inst.MiniMapEntity:SetIcon("huli_fangzi.tex")

    MakeSnowCoveredPristine(inst)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("inspectable")
	inst:AddComponent("z_huli_fangzi")
	inst:AddComponent("huli_workerhit")
    inst:AddComponent("lootdropper")
    inst:AddComponent("sleepingbag")
    inst.components.sleepingbag.onsleep = onsleep
    inst.components.sleepingbag.onwake = onwake
    inst.components.sleepingbag.dryingrate = math.max(0, -TUNING.SLEEP_WETNESS_PER_TICK / TUNING.SLEEP_TICK_PERIOD)
	
	inst:AddComponent("container")
    inst.components.container:WidgetSetup("huli_fangzi")
	inst.components.container.onopenfn = onopen
    inst.components.container.onclosefn = onclose
	
	inst:AddComponent("preserver")
    inst.components.preserver:SetPerishRateMultiplier(.05)

    inst:AddComponent("workable")
    inst.components.workable:SetWorkAction(ACTIONS.HAMMER)
    inst.components.workable:SetWorkLeft(TUNING.HULIBUILD_MINWORK)
    inst.components.workable:SetOnFinishCallback(onhammered)
    inst.components.workable:SetOnWorkCallback(onhit)
	
	inst.durabletask = inst:DoPeriodicTask(TUNING.HULIBUILD_NAIJIUDU_TASK, function() 
		local w = inst.components.workable
		if w.workleft > 0 then
			w.workleft = w.workleft - TUNING.HULIBUILD_NAIJIUDU_CONSUME
		else
			inst.components.container:DropEverything()
			inst.components.container:Close()
			local fx = SpawnPrefab("collapse_big")
			fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
			fx:SetMaterial("wood")
			onfinished(inst)
		end
	end)

	-- inst:ListenForEvent( "daytime", wakeuptest, TheWorld)
	inst:WatchWorldState("phase", wakeuptest)
    inst:ListenForEvent("onbuilt", onbuilt)
	inst:ListenForEvent( "nighttime", huli_fangzilight, TheWorld)

    MakeSnowCovered(inst)
    MakeHauntableWork(inst)
	
    -- inst.sleep_phase = "night"
    -- inst.sleep_anim = "sleep_loop"
    inst.hunger_tick = TUNING.SLEEP_HUNGER_PER_TICK / 3
    inst.is_cooling = false
	
	inst._player = nil
	inst.nimpower = TUNING.HULIFANGZI_MINPOWER
	inst.maxpower = TUNING.HULIFANGZI_MAXPOWER
	inst.maxwork = TUNING.HULIBUILD_MAXWORK
	inst.OnSave = onsave
    inst.OnLoad = onload
	
	inst:DoPeriodicTask(1.01, function() 
		inst._workleft:set(inst.components.workable.workleft) 
		inst._nimpower:set(inst.nimpower) 
		inst._maxpower:set(inst.maxpower) 
		inst._maxwork:set(inst.maxwork) 
		if inst._player ~= nil then
			inst._ownername:set(inst._player.name) 
		else
			inst._ownername:set('NONE') 
		end
	end)
	
	inst.powertask = inst:DoPeriodicTask(TUNING.HULIFANGZI_POWER_TASK, function() 
		if inst.nimpower > 0 then
			inst.nimpower = inst.nimpower - TUNING.HULIFANGZI_POWER_CONSUME
			if TheWorld.state.isnight then
				huli_fangzilight(inst)
			elseif TheWorld.state.isdusk then
				if inst:HasTag('siestahut') then inst:RemoveTag('siestahut') end
			else
				inst.Light:Enable(false)
				if not inst:HasTag('siestahut') then inst:AddTag('siestahut') end
			end
			inst.is_cooling = true
		elseif inst.nimpower <= 0 then
			inst.nimpower = 0
			inst.is_cooling = false
			inst.Light:Enable(false)
			inst.components.preserver:SetPerishRateMultiplier(1)
			if inst:HasTag('siestahut') then inst:RemoveTag('siestahut') end
			if TheWorld.state.isday then
				inst.components.sleepingbag:DoWakeUp()
			end
			if inst.powertask ~= nil then
				inst.powertask:Cancel()
				inst.powertask = nil
			end
		end
	end)
		
	function inst.components.workable:Destroy(destroyer)
		if self:CanBeWorked() then
			self:WorkedBy(destroyer, 200)
			self.inst.SoundEmitter:PlaySound("dontstarve/common/destroy_stone")
		end
	end

    return inst
end

return Prefab( "common/huli_fangzi", fn, assets, prefabs),
	MakePlacer( "common/huli_fangzi_placer", "huli_fangzi", "huli_fangzi", "closed" )