local assets =
{
	Asset("ANIM", "anim/wharang_spirit_fx.zip"),
	Asset("ANIM", "anim/wharang_spirit_evil_fx.zip"),
	Asset("ANIM", "anim/wharang_fx_ground_fire.zip"),
	Asset("ANIM", "anim/wharang_fx_ring.zip"),
	Asset( "ANIM", "anim/icefox_fx.zip" ),
	 Asset("ANIM", "anim/gumipot.zip"),
}

local function kill(inst)
	inst:Remove()
end

local function fn_spirit()
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddNetwork()
	inst.entity:AddAnimState()
	
	inst.entity:AddSoundEmitter()
    inst.AnimState:SetBank("wharang_spirit")
    inst.AnimState:SetBuild("wharang_spirit")
    inst.AnimState:PlayAnimation("wharang_spirit")
    inst:AddTag("NOCLICK")
	inst:AddTag("FX")
    if not TheWorld.ismastersim then
        return inst
    end
	inst.persists = false
    inst.SoundEmitter:PlaySound("dontstarve_DLC001/characters/wathgrithr/valhalla")
    inst:ListenForEvent("animover", function() inst:Remove() end)
    return inst
end

local function fn_evil()
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddNetwork()
	inst.entity:AddSoundEmitter()
    inst.AnimState:SetBank("wharang_spirit_evil")
    inst.AnimState:SetBuild("wharang_spirit_evil")
    inst.AnimState:PlayAnimation("wharang_spirit_evil")
    inst:AddTag("NOCLICK")
	inst:AddTag("FX")
    if not TheWorld.ismastersim then
        return inst
    end
	inst.persists = false
    inst.SoundEmitter:PlaySound("dontstarve_DLC001/characters/wathgrithr/valhalla")
    inst:ListenForEvent("animover", function() inst:Remove() end)
    return inst
end

local function fn_ground_fire()
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddNetwork()
	inst.entity:AddSoundEmitter()
    inst.AnimState:SetBank("dragonfly_ground_fx")
    inst.AnimState:SetBuild("wharang_ground_fire_fx")
    inst.AnimState:PlayAnimation("idle")
    inst:AddTag("NOCLICK")
	inst:AddTag("FX")
    if not TheWorld.ismastersim then
        return inst
    end
	inst.persists = false
    inst:ListenForEvent("animover", function() inst:Remove() end)
    return inst
end

local function fn_firering()
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddNetwork()
	inst.entity:AddSoundEmitter()
    inst.AnimState:SetBank("dragonfly_ring_fx")
    inst.AnimState:SetBuild("wharang_ring_fx")
    inst.AnimState:PlayAnimation("idle")
    inst:AddTag("NOCLICK")
	inst:AddTag("FX")
    if not TheWorld.ismastersim then
        return inst
    end
	inst.persists = false
    inst:ListenForEvent("animover", function() inst:Remove() end)
    return inst
end

local function fn_icefox_fx()
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddNetwork()
	inst.entity:AddSoundEmitter()
    inst.AnimState:SetBank("deer_ice_circle")
    inst.AnimState:SetBuild("icefox_fx")
    inst.AnimState:PlayAnimation("idle")
    inst:AddTag("NOCLICK")
	inst:AddTag("FX")
    if not TheWorld.ismastersim then
        return inst
    end
	inst.persists = false
    inst:ListenForEvent("animover", function() inst:Remove() end)
    return inst
end

local function OnHit(inst, owner, target)
    SpawnPrefab("bishop_charge_hit").Transform:SetPosition(inst.Transform:GetWorldPosition())
    inst:Remove()
end

local function OnThrown(inst)
    inst:DoTaskInTime(3, inst.Remove)
end

local function mir_projectile()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()
	inst.entity:AddLight()

    MakeInventoryPhysics(inst)
    RemovePhysicsColliders(inst)

    inst.Transform:SetFourFaced()

    inst.AnimState:SetBank("star_hot")
    inst.AnimState:SetBuild("star_hot")
    inst.AnimState:PlayAnimation("idle_loop", true)

    inst:AddTag("projectile")

    inst.entity:SetPristine()
	
	inst.Light:SetColour(223 / 255, 208 / 255, 69 / 255)
	inst.Light:SetFalloff(.7)
    inst.Light:SetIntensity(.8)
    inst.Light:SetRadius(5)
	inst.Light:Enable(true)
	inst.Light:EnableClientModulation(true)

    if not TheWorld.ismastersim then
        return inst
    end

    inst.persists = false

    inst:AddComponent("projectile")
    inst.components.projectile:SetSpeed(20)
    inst.components.projectile:SetHoming(false)
    inst.components.projectile:SetOnHitFn(OnHit)
    inst.components.projectile:SetOnMissFn(inst.Remove)
    inst.components.projectile:SetOnThrownFn(OnThrown)
	
	inst.SoundEmitter:PlaySound("dontstarve/common/staff_star_create")
	
	return inst
end

local function longjuanfeng() --龙卷风fx
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()

    inst.AnimState:SetFinalOffset(2)
    inst.AnimState:SetBank("tornado")
    inst.AnimState:SetBuild("tornado")
    inst.AnimState:PlayAnimation("tornado_pre")
    inst.AnimState:PushAnimation("tornado_loop")

    inst.SoundEmitter:PlaySound("dontstarve_DLC001/common/tornado", "spinLoop")

    MakeInventoryPhysics(inst)
    RemovePhysicsColliders(inst)

    inst.entity:SetPristine()
	inst:AddTag("FX")
	inst:AddTag("NOCLICK")
	inst:AddTag("NOBLOCK")

    if not TheWorld.ismastersim then
        return inst
    end
    inst.persists = false
	inst.Physics:SetMotorVel(15,0,0)

	inst:AddComponent("combat")
	inst.components.combat:SetRange(2.2)
	inst.components.combat:SetDefaultDamage(10)

	inst:DoPeriodicTask(0.2, function()
		local x, y, z = inst:GetPosition():Get()
		local r = inst.components.combat.attackrange 
		local ents = TheSim:FindEntities(x, y, z, r, nil, {"player", "companion", "wall", "INLIMBO", "NOCLICK"})
		
		for k,v in pairs(ents) do
			if inst.master and v and v:IsValid() and v.components.combat then
				if v.components.health and not v.components.health:IsDead() then
					inst.components.combat:DoAttack(v)
					v.components.combat:SuggestTarget(inst.master)
				end
			end
		end
	end)
	inst:ListenForEvent("onattackother", function() inst.Physics:Stop() end)
	inst:ListenForEvent("killed", function(inst, data)
		if inst.master then
			inst.master:PushEvent("killed", data)
		end
	end)
	inst:DoTaskInTime(3, inst.Remove)
    return inst
end

local function fxxx() --回旋类fx
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddNetwork()

    inst.AnimState:SetFinalOffset(2)
    inst.AnimState:SetBank("tornado")
    inst.AnimState:SetBuild("tornado")
    inst.AnimState:PlayAnimation("tornado_pre")
    inst.AnimState:PushAnimation("tornado_loop")

    inst.SoundEmitter:PlaySound("dontstarve_DLC001/common/tornado", "spinLoop")

    MakeInventoryPhysics(inst)
    RemovePhysicsColliders(inst)

    inst.entity:SetPristine()
	inst:AddTag("FX")
	inst:AddTag("NOCLICK")
	inst:AddTag("NOBLOCK")

    if not TheWorld.ismastersim then
        return inst
    end
    inst.persists = false
	inst.Physics:SetMotorVel(10,0,0)

	inst:AddComponent("combat")
	inst.components.combat:SetRange(2.2)
	inst.components.combat:SetDefaultDamage(10)
	
	inst.forcenum = 0

	inst:DoPeriodicTask(0.2, function()
		if inst.master then
			if inst.forcenum < 5 then
				local x, y, z = inst.master:GetPosition():Get()
				if inst:GetDistanceSqToPoint(x, y, z) >= 81 then
					inst:ForceFacePoint(x, y, z)
					inst.forcenum = inst.forcenum + 1
				end
			else
				local x, y, z = inst.master:GetPosition():Get()
				inst:ForceFacePoint(x, y, z)
			end
		end
	end)
	inst:ListenForEvent("onattackother", function() inst.Physics:Stop() end)
	inst:DoTaskInTime(15, inst.Remove)
    return inst
end

return  Prefab( "huli_spiritfx", fn_spirit, assets),
		Prefab( "huli_spirit_evilfx", fn_evil),
		Prefab( "huli_ground_firefx", fn_ground_fire),
		Prefab( "huli_ringfx", fn_firering),
		Prefab( "mir_projectile", mir_projectile),
		Prefab( "huli_longjuanfeng", longjuanfeng)
		--Prefab( "icefox_fx", fn_icefox_fx, assets_icefox_fx)