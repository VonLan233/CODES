local function make_huligem(name, qh, jh)
local assets =
{
	Asset("ANIM", "anim/"..name..".zip"),
	Asset("IMAGE", "images/inventoryimages/huligem.tex"),
    Asset("IMAGE", "images/inventoryimages/huligem.xml"),
}

local function fn()
    local inst = CreateEntity()

		inst.entity:AddTransform()
		inst.entity:AddAnimState()
		inst.entity:AddNetwork()
		inst.entity:AddLight()

		MakeInventoryPhysics(inst)
		RemovePhysicsColliders(inst)

		inst.AnimState:SetBank(name)
		inst.AnimState:SetBuild(name)
		inst.AnimState:PlayAnimation("idle", true)
		inst.entity:SetPristine()
		inst.Light:Enable(true)
		inst.Light:SetRadius(.4)
		inst.Light:SetFalloff(.7)
		inst.Light:SetIntensity(.5)
		inst.Light:SetColour(238/255, 255/255, 143/255)
		inst.AnimState:SetBloomEffectHandle( "shaders/anim.ksh" )

		if not TheWorld.ismastersim then
			return inst
		end
		
		if qh then
			inst:AddComponent("z_huli_qianghua")
		end

		if jh then
			inst:AddComponent("z_huli_jinhua")
		end

		inst:AddComponent("inspectable")

		inst:AddComponent("stackable")
		inst.components.stackable.maxsize = TUNING.STACK_SIZE_SMALLITEM
		
		inst:AddComponent("tradable")

		inst:AddComponent("inventoryitem")
		inst.components.inventoryitem.atlasname = "images/inventoryimages/huligem.xml"

		return inst
    
	end

	return Prefab(name, fn, assets)
end

return make_huligem("huligem_sj"),
	make_huligem("huligem_qh", true),
	make_huligem("huligem_hc"),
	make_huligem("huligem_jh", nil, true),
	make_huligem("huligem_gjqh", true),
	make_huligem("huligem_xy"),
	make_huligem("huligem_bj")
