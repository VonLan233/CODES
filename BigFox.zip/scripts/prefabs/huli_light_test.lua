local function fn()
	local inst = CreateEntity()

	inst.entity:AddLight()
	inst.entity:AddTransform()
	inst.entity:AddNetwork()
	
	inst:AddTag("NOCLICK")
	inst:AddTag("FX")

	inst.Light:Enable(true)
	inst.Light:SetRadius(1)
	inst.Light:SetFalloff(.7)
	inst.Light:SetIntensity(.8)
	-- inst.Light:SetColour(255/255,20/255,20/255)
    inst.Light:SetColour(180 / 255, 195 / 255, 150 / 255)
	
	inst.entity:SetPristine()
	
    if not TheWorld.ismastersim then
        return inst
    end

    inst.persists = false

	return inst
end

return Prefab("大狐狸灯光", fn)