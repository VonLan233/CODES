local assets =
{
	Asset( "ANIM", "anim/huli.zip" ),
	Asset( "ANIM", "anim/ghost_huli_build.zip" ),
}

local skins =
{
	normal_skin = "huli",
	ghost_skin = "ghost_huli_build",
}

local base_prefab = "huli"

local tags = {"BASE" ,"HULI", "CHARACTER"}

return CreatePrefabSkin("huli_none",
{
	base_prefab = base_prefab, 
	skins = skins, 
	assets = assets,
	skin_tags = tags,
	
	build_name_override = "huli",
	rarity = "Character",
})