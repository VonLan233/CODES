
local assets_rechargeNPC = {
	Asset( "ANIM", "anim/huli_fox_moon.zip" ),
}

-- local function ItemRefuseTest(inst, item)
	-- for list = 1, #TUNING.GOODSITEM do
		-- for items = 1, #TUNING.GOODSITEM[list] do
			-- if item.prefab == TUNING.GOODSITEM[list][items][1] then
				-- print(TUNING.GOODSITEM[list][items][1])
				-- return true
			-- end
		-- end
	-- end
-- end

local function It1(item)
	for k, v in pairs(TUNING.GOODSITEM) do
		for i, j in pairs(v) do
			if item.prefab == j[1] then
				-- print(j[1])
				return true
			end
		end
	end
end

local function It2(item)
	local recipe = GetValidRecipe(item.prefab)
	if recipe == nil and not It1(item) then
		-- print('没有配方，也不属于')
		return true
	end
	if recipe ~= nil then
		if recipe.numtogive > 1 then
			-- print('制造数量超标')
			return true
		end
		
		for k, v in pairs(recipe.character_ingredients) do
			if IsCharacterIngredient(v.type) and not It1(item) then
				-- print('字符类配方，并且不属于')
				return true
			end
		end
	end
	-- print('物品正常')
end

local function ItemRefuse(inst)
	local container = inst.components.container
	if inst._player == nil then
		inst.components.talker:Say('我扔') 
		container:DropEverything()
		return
	end
	for i = 1, container:GetNumSlots() do
		local item = container:GetItemInSlot(i)
		if item then
			if It2(item) then
				inst:DoTaskInTime(FRAMES, function() 
					inst.components.talker:Say(hl_loc('该物品不能兑换狐狸币或者不支持分解！\n扔出物品！', "This item can't be exchanged for Fox currency or doesn't support decomposition！\nThrow out item！")) 
					container:DropItemBySlot(i)
				end)
			end
		end
	end
end

local function onopen(inst)
    inst.SoundEmitter:PlaySound("dontstarve/wilson/chest_open")
end

local function onclose(inst, doer)
	-- NPCRechargeFn(doer, inst)
    inst.SoundEmitter:PlaySound("dontstarve/wilson/chest_close")
end

local function GetOwnerName(inst)
	local name = hl_loc('★狐狸充值员★', '★Fox recharger★')
	local _playername = inst._playername:value()
	if _playername ~= nil then
		name = name..'\n['.._playername..']'
	end
	return name
end

local function fn()
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddNetwork()
	inst.entity:AddAnimState()
	inst.entity:AddDynamicShadow()
	inst.entity:AddSoundEmitter()
	inst.Transform:SetFourFaced()
	
	inst._playername = net_string(inst.GUID, "npc_playername")
	
	MakeObstaclePhysics(inst, .5)
	-- MakeCharacterPhysics(inst, 105, .4)
	inst.DynamicShadow:SetSize(2, 1.5)
	inst.labe = inst.entity:AddLabel()
	-- inst.labe:SetText('★狐狸充值员★')
	inst:DoTaskInTime(.2, function()
	inst.labe:SetText(GetOwnerName(inst))
	inst.labe:SetFont(SMALLNUMBERFONT)
    inst.labe:SetFontSize(22)
    inst.labe:SetColour(247/255, 22/255, 130/255, 1)
    inst.labe:SetWorldOffset(0, 2.8, 0)
    inst.labe:SetUIOffset(0, 0, 0)
    inst.labe:Enable(true)
	end)
	inst.AnimState:SetBank("wilson")
	inst.AnimState:SetBuild("huli_fox_moon")
	inst.AnimState:PlayAnimation("idle_loop", true)
	inst.AnimState:Hide("ARM_carry")
	inst.AnimState:Show("ARM_normal")
	inst.entity:SetPristine()

	inst:AddComponent("talker")
	
	if not TheWorld.ismastersim then
		return inst
	end
	inst:AddComponent('container')
	inst.components.container:WidgetSetup('huli_rechargenpc')
    inst.components.container.onopenfn = onopen
    inst.components.container.onclosefn = onclose
		
	-- inst:AddComponent("locomotor")
	-- inst:AddComponent("knownlocations")
	-- inst:AddComponent("follower")
	inst._player = nil
	inst:DoTaskInTime(.001, function()
		if inst._player ~= nil then
			inst._playername:set(inst._player.name)
		end
	end)
	
	inst:ListenForEvent("itemget", ItemRefuse)
	
	local function DoEffects(inst)
		SpawnPrefab("spawn_fx_medium").Transform:SetPosition(inst.Transform:GetWorldPosition())
	end
	local function exd(inst, time, str, fn)
		inst:DoTaskInTime(time, function(inst) 
			inst.components.talker:Say(str) 
			if fn then 
				DoEffects(inst)
				inst:DoTaskInTime(.2, function(inst) 
					inst:Remove()
				end)
			end
		end)
	end
	
	inst:DoTaskInTime(.02, function() 
		if inst._player == nil then 
			exd(inst, .5, '在下是萌萌哒的测试员，有何贵干？')
			exd(inst, 4, '本萌会在20秒后离开！')
			exd(inst, 23, '时间已到，再见！')
			exd(inst, 25, '', true)
		end
	end)

    return inst
end

return  Prefab( "common/huli_rechargenpc", fn, assets_rechargeNPC)
