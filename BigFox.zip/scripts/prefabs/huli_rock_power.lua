local assets =
{
	Asset("ANIM", "anim/huli_rock_power.zip"),
	Asset("IMAGE", "images/inventoryimages/huli_rock_power.tex"),
    Asset("IMAGE", "images/inventoryimages/huli_rock_power.xml"),
}

local function fn()
    local inst = CreateEntity()

	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddNetwork()
	inst.entity:AddLight()

	MakeInventoryPhysics(inst)
	RemovePhysicsColliders(inst)

	inst.AnimState:SetBank('huli_rock_power')
	inst.AnimState:SetBuild('huli_rock_power')
	inst.AnimState:PlayAnimation("idle", true)
	inst.entity:SetPristine()
	inst.Light:Enable(true)
	inst.Light:SetRadius(.3)
	inst.Light:SetFalloff(.9)
	inst.Light:SetIntensity(.8)
	inst.Light:SetColour(238/255, 255/255, 143/255)
	inst.AnimState:SetBloomEffectHandle( "shaders/anim.ksh" )

	if not TheWorld.ismastersim then
		return inst
	end

	inst:AddComponent("inspectable")
	inst:AddComponent("z_huli_power") 
	inst:AddComponent("stackable")
	inst.components.stackable.maxsize = TUNING.STACK_SIZE_SMALLITEM
	
	inst:AddComponent("fuel")
    inst.components.fuel.fuelvalue = TUNING.LARGE_FUEL*2
	inst:AddComponent("tradable")

	inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.atlasname = "images/inventoryimages/huli_rock_power.xml"

	return inst

end

return Prefab('huli_rock_power', fn, assets)
