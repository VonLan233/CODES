require "prefabutil"

local assets =
{
	Asset("ANIM", "anim/huli_tingzi.zip"),
	Asset("ATLAS", "images/inventoryimages/building.xml")
}

local function onhammered(inst, worker)
    inst.components.lootdropper:DropLoot()
    local fx = SpawnPrefab("collapse_big")
    fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
    fx:SetMaterial("wood")
    inst:Remove()
end

local function onhit(inst, worker)
	inst.components.huli_workerhit:OnHit(worker)
end

local function onfinishedsound(inst)
    inst.SoundEmitter:PlaySound("dontstarve/common/tent_dis_twirl")
end

local function onfinished(inst)
	inst.AnimState:PlayAnimation("hit")
	inst:ListenForEvent("animover", inst.Remove)
	inst.SoundEmitter:PlaySound("dontstarve/common/tent_dis_pre")
	inst.persists = false
	inst:DoTaskInTime(16 * FRAMES, onfinishedsound)
end

local function onbuilt(inst, data)
    local doer = data.builder
    if doer ~= nil then
        inst._player = {
            userid = doer.userid,
            name = doer.name,
        }
    end
    inst.AnimState:PlayAnimation("hit")
    inst.AnimState:PushAnimation("idle")
end

--We don't watch "stop'phase'" because that
--would not work in a clock without 'phase'
local function wakeuptest(inst, phase)
    if phase ~= inst.sleep_phase then
        inst.components.sleepingbag:DoWakeUp()
    end
end

local function onwake(inst, sleeper, nostatechange)
    if inst.sleeptask ~= nil then
        inst.sleeptask:Cancel()
        inst.sleeptask = nil
    end

    inst:StopWatchingWorldState("phase", wakeuptest)

    if not nostatechange then
        if sleeper.sg:HasStateTag("tent") then
            sleeper.sg.statemem.iswaking = true
        end
        sleeper.sg:GoToState("wakeup")
    end

    if inst.sleep_anim ~= nil then
        inst.AnimState:PushAnimation("idle", true)
    end

	inst.AnimState:PlayAnimation("hit")
    -- inst.components.finiteuses:Use()
end

local function onsleeptick(inst, sleeper)
    local isstarving = sleeper.components.beaverness ~= nil and sleeper.components.beaverness:IsStarving()

    if sleeper.components.hunger ~= nil then
        sleeper.components.hunger:DoDelta(inst.hunger_tick, true, true)
        isstarving = sleeper.components.hunger:IsStarving()
    end

    if sleeper.components.sanity ~= nil and sleeper.components.sanity:GetPercentWithPenalty() < 1 then
        sleeper.components.sanity:DoDelta(TUNING.SLEEP_SANITY_PER_TICK, true)
    end

    if not isstarving and sleeper.components.health ~= nil then
        sleeper.components.health:DoDelta(TUNING.SLEEP_HEALTH_PER_TICK * 2, true, inst.prefab, true)
    end

    if sleeper.components.temperature ~= nil then
        if inst.is_cooling then
            if sleeper.components.temperature:GetCurrent() > TUNING.SLEEP_TARGET_TEMP_TENT then
                sleeper.components.temperature:SetTemperature(sleeper.components.temperature:GetCurrent() - TUNING.SLEEP_TEMP_PER_TICK)
            end
        elseif sleeper.components.temperature:GetCurrent() < TUNING.SLEEP_TARGET_TEMP_TENT then
            sleeper.components.temperature:SetTemperature(sleeper.components.temperature:GetCurrent() + TUNING.SLEEP_TEMP_PER_TICK)
        end
    end

    if isstarving then
        inst.components.sleepingbag:DoWakeUp()
    end
	if inst.components.workable.workleft > 0 then
		inst.components.workable.workleft = inst.components.workable.workleft - 1
	else
		inst.components.sleepingbag:DoWakeUp()
		local fx = SpawnPrefab("collapse_big")
		fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
		onfinished(inst)
	end
end

local function onsleep(inst, sleeper)
    inst:WatchWorldState("phase", wakeuptest)

    if inst.sleep_anim ~= nil then
        inst.AnimState:PlayAnimation(inst.sleep_anim, true)
    end
	inst.AnimState:PlayAnimation("hit")
    if inst.sleeptask ~= nil then
        inst.sleeptask:Cancel()
    end
    inst.sleeptask = inst:DoPeriodicTask(TUNING.SLEEP_TICK_PERIOD, onsleeptick, nil, sleeper)
end

local function onsave(inst, data)
       data._player = inst._player
	   data.workleft = inst.components.workable.workleft
    if inst:HasTag("burnt") or (inst.components.burnable ~= nil and inst.components.burnable:IsBurning()) then
        data.burnt = true
    end
	
end

local function onload(inst, data)
    inst._player = data._player
	if data.workleft ~= nil then
		inst.components.workable.workleft = data.workleft
	end
    if data ~= nil and data.burnt then
        inst.components.burnable.onburnt(inst)
    end
end

local function get_name(inst)
	local name = STRINGS.NAMES[string.upper(inst.prefab)]
	local ownername = inst._ownername:value()
	local workleft = inst._workleft:value()
	local maxwork = inst._maxwork:value()
	local named = name..'\n拥有者:'..ownername..'\n耐久度:'..workleft..'/'..maxwork
	-- if get_modinfoname(inst) then
		-- named = name
	-- end
	return named
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
	inst.entity:AddLight()
    inst.entity:AddSoundEmitter()
    inst.entity:AddMiniMapEntity()
    inst.entity:AddNetwork()

    MakeObstaclePhysics(inst, 1.7)
	inst._workleft = net_int(inst.GUID, "huli_tingzi._workleft")
	inst._maxwork = net_int(inst.GUID, "huli_tingzi._maxwork")
	inst._ownername = net_string(inst.GUID, "huli_tingzi._ownername")
	inst.displaynamefn = get_name
	
	inst.entity:AddDynamicShadow()
    inst.DynamicShadow:SetSize( 8, 6 )
	
	inst:AddTag("tent")
	inst:AddTag("siestahut")
    inst:AddTag("structure")
	inst:AddTag("huli_build")
	inst:AddTag("huli_tingzi")
	
    inst.AnimState:SetBank('huli_tingzi')
    inst.AnimState:SetBuild('huli_tingzi')
    inst.AnimState:PlayAnimation("idle")
    inst.MiniMapEntity:SetIcon('huli_tingzi.tex')

    MakeSnowCoveredPristine(inst)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

	inst.Light:Enable(true)
	inst.Light:SetRadius(.1)
    inst.Light:SetFalloff(.1)
    inst.Light:SetIntensity(.1)
    inst.Light:SetColour(20/255, 20/255, 20/255)
	inst.AnimState:SetBloomEffectHandle( "shaders/anim.ksh" )

    inst:AddComponent("sleepingbag")
    inst.components.sleepingbag.onsleep = onsleep
    inst.components.sleepingbag.onwake = onwake
    inst.components.sleepingbag.dryingrate = math.max(0, -TUNING.SLEEP_WETNESS_PER_TICK / TUNING.SLEEP_TICK_PERIOD)
	
    inst:AddComponent("inspectable")
	inst:AddComponent("huli_workerhit")
    inst:AddComponent("lootdropper")
    inst:AddComponent("workable")
    inst.components.workable:SetWorkAction(ACTIONS.HAMMER)
    inst.components.workable:SetWorkLeft(TUNING.HULIBUILD_MINWORK)
    inst.components.workable:SetOnFinishCallback(onhammered)
    inst.components.workable:SetOnWorkCallback(onhit)

	inst.durabletask = inst:DoPeriodicTask(TUNING.HULIBUILD_NAIJIUDU_TASK, function() 
		local w = inst.components.workable
		if w.workleft > 0 then
			w.workleft = w.workleft - TUNING.HULIBUILD_NAIJIUDU_CONSUME
		else
			local fx = SpawnPrefab("collapse_big")
			fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
			fx:SetMaterial("wood")
			onfinished(inst)
		end
	end)

    inst:ListenForEvent("onbuilt", onbuilt)
    MakeSnowCovered(inst)
    MakeHauntableWork(inst)

    inst.sleep_phase = "day"
    --inst.sleep_anim = nil
    inst.hunger_tick = TUNING.SLEEP_HUNGER_PER_TICK / 4
    inst.is_cooling = true
	
	inst._player = nil
	inst.maxwork = TUNING.HULIBUILD_MAXWORK
	inst.OnSave = onsave
    inst.OnLoad = onload
	
	inst:DoPeriodicTask(1.01, function() 
		inst._workleft:set(inst.components.workable.workleft) 
		inst._maxwork:set(inst.maxwork) 
		if inst._player ~= nil then
			inst._ownername:set(inst._player.name) 
		else
			inst._ownername:set('NONE') 
		end
	end)
	
	function inst.components.workable:Destroy(destroyer)
		if self:CanBeWorked() then
			self:WorkedBy(destroyer, 200)
			self.inst.SoundEmitter:PlaySound("dontstarve/common/destroy_stone")
		end
	end

    return inst
end

return Prefab( "common/huli_tingzi", fn, assets),
	MakePlacer( "common/huli_tingzi_placer", "huli_tingzi", "huli_tingzi", "idle" )