local brain = require "brains/huliclonebrain"
--require "prefabutil"

local assets = {
    Asset("ANIM", "anim/ui_hulicl_3x3.zip"),
    Asset("ATLAS", "images/inventoryimages/items.xml")
}

local prefabs = {
    "huli",
    --"handfan",

}

local function get_damage(inst)
    local cnc = inst.components.combat
    local weapon = cnc:GetWeapon()
    if weapon and weapon.components.weapon ~= nil then
        return math.ceil(weapon.components.weapon.damage * cnc.damagemultiplier)
    else
        return math.ceil(cnc.defaultdamage * cnc.damagemultiplier)
    end
end

local function LvLoadFn(inst, c_lv, max_lv)
    -- inst.components.health.absorb = .4 + c_lv * .01
    inst.components.health.externalabsorbmodifiers:SetModifier(inst, 0.4 + c_lv * .01, "自身减伤")
    inst.components.combat.damagemultiplier = 1 + c_lv * .025
    inst.components.combat:SetAttackPeriod(2 - c_lv * .035)
    inst.Transform:SetScale(.6 + c_lv * 0.008, .6 + c_lv * 0.008, .6 + c_lv * 0.008)
end

local function LevelUpFn(inst, c_lv, max_lv)
    local pos = Vector3(inst.Transform:GetWorldPosition())
    pos.y = pos.y + 1
	local health_percent = inst.components.health:GetPercent()
    inst.components.health.maxhealth = math.ceil(300 + c_lv * 20)
	LvLoadFn(inst, c_lv, max_lv)
    inst.SoundEmitter:PlaySound("foxpointup/foxpoint/pointup")
    local spirit_evil = SpawnPrefab("huli_spirit_evilfx")
    spirit_evil.Transform:SetPosition(pos:Get())
    spirit_evil.Transform:SetScale(.5, .5, .5)
    --[[else
    local spirit = SpawnPrefab("huli_spiritfx")
    spirit.Transform:SetPosition(pos:Get())
    spirit.Transform:SetScale(.5,.5,.5)]]
	
	inst.components.health:SetPercent(health_percent)
end

local function ShouldAcceptItem(inst, item, giver)
    local newslot = item.components.equippable and item.components.equippable.equipslot
    local current = inst.components.inventory:GetEquippedItem(newslot)
    if giver ~= inst._player and current and item.components.equippable then
        inst.components.talker:Say(hl_loc("禁止偷装备", "Can't steal equipment"))
        return 
    end

    local _edible = item.components.edible and item.components.edible.hungervalue > 0 and item.components.edible.foodtype == "MEAT" and not item:HasTag("monstermeat")
    if _edible or item.prefab == "hulisoul" or item.components.healer then
        return true
    end
    if item.components.equippable and 
        (item.components.equippable.equipslot == EQUIPSLOTS.HEAD or 
        item.components.equippable.equipslot == EQUIPSLOTS.HANDS or 
        item.components.equippable.equipslot == EQUIPSLOTS.BODY)
         and not item.components.projectile then
        -- if item.prefab == "batbat" then
        -- return false 
        -- end
        return true
    end
end

local function OnGetItemFromPlayer(inst, giver, item)
    if item.components.equippable and 
        (item.components.equippable.equipslot == EQUIPSLOTS.HEAD or 
        item.components.equippable.equipslot == EQUIPSLOTS.HANDS or 
        item.components.equippable.equipslot == EQUIPSLOTS.BODY) then
        local newslot = item.components.equippable.equipslot
        local current = inst.components.inventory:GetEquippedItem(newslot)
        if current then
            inst.components.inventory:DropItem(current)
        end

        inst.components.inventory:Equip(item)
        --inst._damagemul:set((inst.components.combat.damagemultiplier - 1)*100)
        --inst._damage:set(get_damage(inst))
    elseif item.prefab == "hulisoul" or item.prefab == "huli_dango" then
        inst.components.huli_levelsys:LvDoDelta(1)
        inst.components.health:DoDelta(inst.components.health.maxhealth)
        inst:PushEvent("oneatsomething", {food = item})
        inst.sg:GoToState("eat")
        item:Remove()
    elseif item.components.healer then
        inst.components.health:DoDelta(item.components.healer.health)
        inst:PushEvent("oneatsomething", {food = item})
        inst.sg:GoToState("eat")
        item:Remove()
    elseif item.components.edible then
        inst.components.health:DoDelta(item.components.edible:GetHunger(inst), nil, item.prefab)
        inst:PushEvent("oneatsomething", {food = item})
        inst.sg:GoToState("eat")
        item:Remove()
        --elseif inst.components.eater:CanEat(item) then
        --inst.components.eater:Eat(item)
        --elseif item.prefab == "spidergland" or item.prefab == "mosquitosack" or item.prefab == "spidergland" then
        --elseif item.components.healer and item.components.healer.health then
    end
end

--[[local function ShouldAcceptItem(inst, item)
return inst.components.eater:CanEat(item)
and not inst.components.combat:HasTarget()
end

local function OnGetItemFromPlayer(inst, giver, item)
if inst.components.eater:CanEat(item) then
inst.components.eater:Eat(item)
end
end]]

local function DoEffects(inst)
	SpawnPrefab("spawn_fx_medium").Transform:SetPosition(inst.Transform:GetWorldPosition())
end

local function exd(inst, time, str, fn)
	inst:DoTaskInTime(time, function(inst) 
		inst.components.talker:Say(str) 
		if fn then 
			DoEffects(inst)
			inst:DoTaskInTime(.2, function(inst) 
				inst:Remove()
			end)
		end
	end)
end

local function CryForQt(inst)
	if inst._player == nil then
		exd(inst, 1, "请从合法渠道召唤本萌")
		exd(inst, 5, "不管你信不信，我始终是个演员")
		exd(inst, 10, "请不要给我东西，因为30秒后我就消失")
		exd(inst, 38, "时间到，溜了溜了")
		exd(inst, 40, "", true)
	end
end

local function RandomTalk(sayings)
    return sayings[math.random(#sayings)]
end

local refuseitemtak_m = {
    "你真调皮!",
    "人家不要这种东西啦",
    "再这样人家不跟你玩了",
    "哼哼,你肯定是故意的!",
    "你别玩了",
    "你怎么不自己吃呢.",
    "你欺负我,5555",
    "才不吃这种东西，会长不大的!",
}

local refuseitemtak_o = {
    "去你的!屎里有毒!",
    "滚滚滚!",
    "走开,别闹!",
    "我要报警了啊!",
    "留着你自己啃吧.",
    "别闹...",
    "要给就给好吃的\n别整这种给我.",
    "你走开，别来逗我.",
}

local function OnRefuseItem(inst, giver, item)
    -- local leader = inst.components.follower:GetLeader()
    local leader = inst._player
    if leader == nil then return end
    if giver == leader then
        inst.components.talker:Say(RandomTalk(refuseitemtak_m))
    else
        inst.components.talker:Say(RandomTalk(refuseitemtak_o))
    end
    inst.sg:GoToState("refuse")
end

local function OnAttacked(inst, data)
    local attacker = data.attacker
    if attacker == inst._player then
		inst.components.combat:GiveUp()
		return 
	end
	
    if attacker._player and attacker._player == inst._player then
		inst.components.combat:GiveUp()
		return 
	end
    inst.components.combat:SetTarget(attacker)
    inst.components.combat:ShareTarget(attacker, 15, function(dude)
		return dude._player ~=nil and dude._player == inst._player
			or (dude.components.follower and dude.components.follower:GetLeader()) == (inst.components.follower and inst.components.follower:GetLeader())
		end, 10)
end

local function OnAttackOther(inst, data)
    local target = data.target
	local lv_sys = inst.components.huli_levelsys
    inst.components.combat:ShareTarget(target, 20, nil, 5)
    local eqp = inst.components.combat:GetWeapon()
    local rand = lv_sys:Get('当前等级') * .004
    local numRings = 1 + (lv_sys:Get('当前等级') * .07)
    local damageRings = 1 + (lv_sys:Get('当前等级') * .07)
    local pt = target:GetPosition()
    inst.components.groundpounderds.numRings = numRings
    inst.components.groundpounderds.damageRings = damageRings
    inst.components.groundpounderds.bonusdamage = lv_sys:Get('当前等级') * .5
    if eqp and eqp.prefab == "gumifan" then
        if target and not target:HasTag("wall") and not target:HasTag("companion") then
			if math.random() <= rand then
				inst.components.groundpounderds:GroundPound(nil, nil, pt)
			end
        end
    end
end

local function retargetfn(inst)
    local leader = inst.components.follower:GetLeader()
    return leader ~= nil
     and FindEntity(leader, 13, function(guy)
		return guy ~= inst 
			and (guy.components.combat:TargetIs(leader) or guy.components.combat:TargetIs(inst))
			and inst.components.combat:CanTarget(guy)
    end, {"_combat"}, {"playerghost", "INLIMBO"})
     or nil
end

local function keeptargetfn(inst, target)
    return inst.components.follower:IsNearLeader(13)
		and inst.components.combat:CanTarget(target)
end

local function GetStatus(inst, viewer)
	local lv_sys = inst.components.huli_levelsys
    return (viewer == inst._player and inst.components.combat ~= nil and inst.components.combat.target ~= nil and "DAJIA")
     or (viewer == inst._player and inst.components.health ~= nil and inst.components.health:GetPercent() < 0.5 and "CANXUE")
     or (viewer == inst._player and lv_sys and lv_sys:Get('当前等级') < 10 and "GENERIC_A")
     or (viewer == inst._player and lv_sys and lv_sys:Get('当前等级') >= 10 and lv_sys and lv_sys:Get('当前等级') < 20 and "GENERIC_B")
     or (viewer == inst._player and lv_sys and lv_sys:Get('当前等级') >= 20 and "GENERIC_C")
     or "TONGYONG"
end

local function onsave(inst, data)
    data.level = nil
end

local function onload(inst, data)
    if data then
        if data.level then
            inst.components.huli_levelsys['当前等级'] = data.level
			LevelUpFn(inst, data.level)
        end
    end
end

local function tempedelta(inst)
    inst._temperature:set(inst.components.temperature.current)
end

local function tempdel(inst)
    inst.temptask = inst:DoPeriodicTask(.2, function ()
        local t = inst.components.temperature
        local wt = TheWorld.state.temperature
        if wt < t.current then
            t:DoDelta(.15)
        else
            t:DoDelta(0)
        end
    end)
end

local function get_name(inst)
    local name = STRINGS.NAMES[string.upper(inst.prefab)]
    local level = inst.replica.huli_levelsys and inst.replica.huli_levelsys:Get('当前等级') or ''
    local maxlevel = inst.replica.huli_levelsys and inst.replica.huli_levelsys:Get('最大等级') or ''
    local currenthealth = inst.replica.health and inst.replica.health:GetCurrent() or ''
    local maxhealth = inst.replica.health and inst.replica.health:Max() or ''
    local damage = inst._damage:value()
    local damagemul = inst._damagemul:value()
    local absorb = inst._absorb:value()
    local temperature = inst._temperature:value()
    local named = name .. "\n等级" .. level .. "/" .. maxlevel .. "\n当前体温:" .. temperature .. "℃\n生命值:" .. currenthealth .. "/" .. maxhealth .. "\n当前伤害:" .. damage .. "\n基础伤害:+" .. damagemul .. "%\n基础防御:" .. absorb .. "%\n \n "
    if get_modinfoname(inst) then
        named = name .. "\n等级:" .. level .. "/" .. maxlevel .. "\n当前体温:" .. temperature .. "℃\n "
    end
    return named
end

local function fn()
    local inst = CreateEntity()
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddMiniMapEntity()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddNetwork()

    MakeCharacterPhysics(inst, 30, .3)

    inst.DynamicShadow:SetSize(2, 1.5)

    inst.Transform:SetFourFaced()
    inst.Transform:SetScale(0.6, 0.6, 0.6)

    inst.AnimState:SetBank("wilson")
    inst.AnimState:SetBuild("huli")
    inst.AnimState:PlayAnimation("idle_loop", true)
    inst.AnimState:Hide("ARM_carry")
    inst.AnimState:Show("ARM_normal")

    inst.MiniMapEntity:SetIcon("huliclone.tex")
    inst.MiniMapEntity:SetCanUseCache(false)
    inst.MiniMapEntity:SetPriority(4)

    inst:AddTag("huliclone")
    inst:AddTag("scarytoprey")
    inst:AddTag("companion")
    inst:AddTag("nomagic")
    inst.entity:SetPristine()

    inst._absorb = net_shortint(inst.GUID, "huliclone._absorb")
    inst._damage = net_shortint(inst.GUID, "huliclone._damage")
    inst._damagemul = net_shortint(inst.GUID, "huliclone._damagemul")
    inst._temperature = net_shortint(inst.GUID, "huliclone._temperature")
    inst['所有者net'] = net_entity(inst.GUID, "huliclone.player")
    inst.displaynamefn = get_name

    inst:AddComponent("talker")
    inst.components.talker:StopIgnoringAll()

    if not TheWorld.ismastersim then
        return inst
    end

    -- inst:AddComponent("timer")

    --[[inst:AddComponent("playerprox")
    inst.components.playerprox:SetDist(16, 10) 
    inst.components.playerprox:SetOnPlayerNear(on_close)
    inst.components.playerprox:SetOnPlayerFar(far)]]

    MakeMediumBurnableCharacter(inst, "pig_torso")

    inst:AddComponent("hunger")
    -- function inst.components.hunger:DoDec(dt, ignore_damage)
    function inst.components.hunger:DoDelta(delta, overtime, ignore_invincible)
        return 
    end

    inst:AddComponent("sanity")

    function inst.components.sanity:DoDelta(delta, overtime)
        return 
    end

    function inst.components.sanity:Recalc(self, dt)
        return 
    end

    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(300)
    inst.components.health:StartRegen(1, 3)
    -- inst.components.health.absorb = 0.4
	inst.components.health.externalabsorbmodifiers:SetModifier(inst, 0.4, "自身减伤")
	inst.components.health.save_maxhealth = true
    local OldDoDelta = inst.components.health.DoDelta
    inst.components.health.DoDelta = function (self, amount, overtime, cause, ignore_invincible, afflicter, ignore_absorb)
		if amount > 0 then
			ignore_invincible = true
		end
		return OldDoDelta(self, amount, overtime, cause, ignore_invincible, afflicter, ignore_absorb)
    end

    inst:AddComponent("clone_xhl")

    inst:AddComponent("combat")
    inst.components.combat:SetDefaultDamage(TUNING.UNARMED_DAMAGE)
    inst.components.combat:SetAttackPeriod(2)
    inst.components.combat.damagemultiplier = 1
    --inst.components.combat.playerdamagepercent = 0
    inst.components.combat.hiteffectsymbol = "torso"
    inst.components.combat:SetKeepTargetFunction(keeptargetfn)
    inst.components.combat:SetRetargetFunction(1, retargetfn)
    local old_attacked = inst.components.combat.GetAttacked
    inst.components.combat.GetAttacked = function(self, attacker, damage, weapon, stimuli)
        if attacker == self.inst._player then
            if self.inst.components.health.currenthealth > 30 then
                self.inst.components.health:DoDelta(-30, nil, nil, true, nil, true)
            else
                self.inst.components.health.currenthealth = 1
            end
            if attacker and attacker.SoundEmitter then
                attacker.SoundEmitter:PlaySound("dontstarve/common/staff_dissassemble")
            end

            local xhl_db = SpawnPrefab("xhl_cl_qp_db_build")
            if xhl_db ~= nil then
                xhl_db.Transform:SetPosition(self.inst.Transform:GetWorldPosition())
                xhl_db.AnimState:PlayAnimation("idle_atkloop")
                xhl_db._info = self.inst:GetSaveRecord()
                xhl_db.components.xhl_qp_db.packageuserid = self.inst._player.userid
                xhl_db.components.xhl_qp_db.name = "挨打的" .. get_name(inst)
                self.inst:Remove()
            end
		else
			return old_attacked(self, attacker, damage, weapon, stimuli)
        end
    end

    inst:AddComponent("follower")
    inst.components.follower:KeepLeaderOnAttacked()
    inst.components.follower.keepdeadleader = true

    inst:AddComponent("xhl_command")
	
	inst:AddComponent("huli_levelsys")
	inst.components.huli_levelsys:Set({['最大等级'] = 30})
	inst.components.huli_levelsys['等级变更fn'] = LevelUpFn
	inst.components.huli_levelsys['加载等级fn'] = LvLoadFn
	
    inst:AddComponent("temperature")
    inst.components.temperature.maxtemp = 55
    --inst.components.temperature.IsFreezing
    --[[function inst.components.temperature:IsFreezing()
    return self.current < -20
    end]]

    inst:AddComponent("inspectable")
    inst.components.inspectable:RecordViews()
    inst.components.inspectable.getstatus = GetStatus

    inst:AddComponent("inventory")
    --[[inst.handfan = SpawnPrefab( "handfan" )
    if inst.handfan ~= nil then
    inst.components.inventory:Equip( inst.handfan )
    end]]

    inst:AddComponent("trader")
    inst.components.trader:SetAcceptTest(ShouldAcceptItem)
    inst.components.trader.deleteitemonaccept = false
    inst.components.trader.onaccept = OnGetItemFromPlayer
    inst.components.trader.onrefuse = OnRefuseItem
    inst.components.trader:Enable()

    --if TheSim:FindFirstEntityWithTag("huli") then
    --[[inst:AddComponent("container")
    inst.components.container:WidgetSetup("huliclone")
    inst.components.container.onopenfn = onopen
    inst.components.container.onclosefn = onclose]]
    --else end

    inst:AddComponent("groundpounderds")
    inst.components.groundpounderds.groundpoundfx = "huli_ground_firefx"
    inst.components.groundpounderds.groundpoundringfx = "huli_ringfx"

    inst:AddComponent("locomotor")
    inst.components.locomotor.runspeed = 11
    inst.components.locomotor.walkspeed = 8

    --inst:AddComponent("lootdropper")
    inst:AddComponent("eater")
    -- inst.components.eater:SetOnEatFn(oneat)
    --inst.components.eater:SetDiet({ FOODTYPE.MEAT }, { FOODTYPE.MEAT })
    --inst.components.eater:SetDiet({ FOODTYPE.VEGGIE, FOODTYPE.ROUGHAGE }, { FOODTYPE.VEGGIE, FOODTYPE.ROUGHAGE })

    inst:SetBrain(brain)
    inst:SetStateGraph("SGhuliclone")

    --inst:WatchWorldState("startnight", function() inst.components.health:DoDelta(-10) end)

    inst.aida_name = nil

    inst.OnSave = onsave
    inst.OnLoad = onload
    --inst.OnPreLoad = onpreload
	
	inst:DoTaskInTime(0.1, CryForQt)

    inst:DoPeriodicTask(1.01, function ()
        inst._damage:set(get_damage(inst))
        inst._damagemul:set((inst.components.combat.damagemultiplier - 1) * 100)
		inst._absorb:set(inst.components.health.absorb * 100)
    end)
    inst._temperature:set(inst.components.temperature.current)

    --inst:ListenForEvent("onbuilt", onbuilt)
    --inst:ListenForEvent("death", ondeath)
    --inst:ListenForEvent("healthdelta", ondeath)
    inst:ListenForEvent("attacked", OnAttacked)
    inst:ListenForEvent("onattackother", OnAttackOther)
    inst:ListenForEvent("temperaturedelta", tempedelta)
    tempdel(inst)
    return inst
end
return Prefab("common/huliclone", fn, assets, prefabs)
