local assets =
{
	Asset("ANIM", "anim/hulisoul.zip"),
    Asset("ATLAS", "images/inventoryimages/items.xml"),
    Asset("IMAGE", "images/inventoryimages/items.tex"),
}

local function hulisoul_fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()
	inst.entity:AddLight()

    MakeInventoryPhysics(inst)
    RemovePhysicsColliders(inst)

    inst.AnimState:SetBank("hulisoul")
    inst.AnimState:SetBuild("hulisoul")
    inst.AnimState:PlayAnimation("idle", true)
    inst.entity:SetPristine()
	inst.Light:Enable(true)
	inst.Light:SetRadius(.5)
    inst.Light:SetFalloff(.7)
    inst.Light:SetIntensity(.5)
    inst.Light:SetColour(238/255, 255/255, 143/255)
	inst.AnimState:SetBloomEffectHandle( "shaders/anim.ksh" )

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("inspectable")

    inst:AddComponent("stackable")
	inst.components.stackable.maxsize = TUNING.STACK_SIZE_SMALLITEM
	
	inst:AddComponent("fuel")
    inst.components.fuel.fuelvalue = TUNING.MED_LARGE_FUEL

    inst:AddComponent("tradable")

    inst:AddComponent("inventoryitem")
    --inst.components.inventoryitem.imagename = "hulisoul"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/items.xml"

    return inst
    
end

return Prefab("common/inventory/hulisoul", hulisoul_fn, assets)
