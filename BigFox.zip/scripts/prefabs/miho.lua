require "prefabutil"
local brain = require "brains/mihobrain"
local WAKE_TO_FOLLOW_DISTANCE = 14
local SLEEP_NEAR_LEADER_DISTANCE = 7

local assets =
{
   Asset("ANIM", "anim/ui_miho_4x4.zip"),
   Asset("ANIM", "anim/ui_miho_5x5.zip"),
   Asset( "ANIM", "anim/miho.zip" ),
   Asset( "ANIM", "anim/miho_new.zip" ),
    Asset( "SOUND" , "sound/miho.fsb" ),
	Asset( "SOUNDPACKAGE" , "sound/miho.fev" ),
}

local prefabs =
{
    "mihobell",
}

local function OnOpen(inst)
    if not inst.components.health:IsDead() then
        inst.sg:GoToState("open")
    end
end

local function OnClose(inst)
    if not inst.components.health:IsDead() and inst.sg.currentstate.name ~= "transition" then
        inst.sg:GoToState("close")
    end
end

local function OnStopFollowing(inst)
    inst:RemoveTag("companion")
end

local function OnStartFollowing(inst)
    inst:AddTag("companion")
end

local function MorphShadowMiho(inst)
	inst.AnimState:SetBank("fox_miho")
    inst.AnimState:SetBuild("miho_new")
    inst.components.container:WidgetSetup("miho_new")
	inst.components.preserver:SetPerishRateMultiplier(.4)
	inst.components.locomotor.walkspeed = 9
	inst.components.locomotor.runspeed = 11
	inst:AddTag('huli_mihoup')
	if inst:HasTag('huli_miho') then
		inst:RemoveTag('huli_miho')
	end
    inst.MihoState = "MIHOUP"
    inst._isshadowmiho:set(true)
end

local function CanMorph(inst)
    if inst.MihoState ~= "NORMAL" or not TheWorld.state.isfullmoon then
        return false
    end

    local container = inst.components.container
    if container:IsOpen() then
        return false
    end

    local canShadow = true

    for i = 1, container:GetNumSlots() do
        local item = container:GetItemInSlot(i)
        if item == nil then
            return false
        end

        canShadow = canShadow and item.prefab == "huli_dango"

        if not canShadow then
            return false
        end
    end

    return canShadow
end

local function CheckForMorph(inst)
    local canShadow = CanMorph(inst)
    if canShadow then
		inst.sg:GoToState("transition")
    end
end

local function DoMorph(inst, fn)
    inst.MorphMiho = nil
    inst:StopWatchingWorldState("isfullmoon", CheckForMorph)
    inst:RemoveEventCallback("onclose", CheckForMorph)
    fn(inst) 
end

local function MorphMiho(inst)
    local canShadow = CanMorph(inst)
    if not canShadow then
        return
    end

    local container = inst.components.container
    for i = 1, container:GetNumSlots() do
        container:RemoveItem(container:GetItemInSlot(i)):Remove()
    end

    DoMorph(inst, canShadow and MorphShadowMiho)
end

local function OnSave(inst, data)
    data.MihoState = inst.MihoState
end

local function OnPreLoad(inst, data)
    if data == nil then
        return
    elseif data.MihoState == "MIHOUP" then
        DoMorph(inst, MorphShadowMiho)
    end
end

local function OnIsShadowMihoDirty(inst)
    if inst._isshadowmiho:value() ~= inst._clientshadowmorphed then
        inst._clientshadowmorphed = inst._isshadowmiho:value()
        inst.replica.container:WidgetSetup(inst._clientshadowmorphed and "miho_new" or nil)
    end
end

local function OnEntityReplicated(inst)
	if inst.MihoState == "MIHOUP" then
		inst.replica.container:WidgetSetup(inst._isshadowmiho:value() and  "miho_now")
	end
end

local function create_miho()

    local inst = CreateEntity()
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
    inst.entity:AddDynamicShadow()
    inst.entity:AddMiniMapEntity()
    inst.entity:AddNetwork()
	inst.entity:AddLight()
	
	-- inst.labe = inst.entity:AddLabel()
	-- inst.labe:SetText('lalala')
	-- inst.labe:SetFont(SMALLNUMBERFONT)
    -- inst.labe:SetFontSize(23)
	-- inst.labe:SetColour(247/255, 22/255, 130/255, 1)
    -- inst.labe:SetWorldOffset(0, 2, 0)
    -- inst.labe:SetUIOffset(0, 0, 0)
    -- inst.labe:Enable(true)
	
	inst.Light:Enable(true)
	inst.Light:SetRadius(1)
    inst.Light:SetFalloff(.5)
    inst.Light:SetIntensity(.4)
    inst.Light:SetColour(150/255,150/255, 0/255)
	inst.AnimState:SetBloomEffectHandle( "shaders/anim.ksh" )

    MakeCharacterPhysics(inst, 75, .5)
    inst.Physics:SetCollisionGroup(COLLISION.CHARACTERS)
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.WORLD)
    inst.Physics:CollidesWith(COLLISION.OBSTACLES)
    inst.Physics:CollidesWith(COLLISION.CHARACTERS)

    inst:AddTag("companion")
    inst:AddTag("character")
    inst:AddTag("scarytoprey")
    inst:AddTag("huli_miho")
    inst:AddTag("notraptrigger")
    inst:AddTag("_named")
    inst:AddTag("noauradamage")
    inst:AddTag("nomagic")

    inst.MiniMapEntity:SetIcon("miho.tex")
    inst.MiniMapEntity:SetCanUseCache(false)

    inst.AnimState:SetBank("miho")
    inst.AnimState:SetBuild("miho")

    inst.DynamicShadow:SetSize(2, 1.5)

    inst.Transform:SetFourFaced()

    inst._isshadowmiho = net_bool(inst.GUID, "_isshadowmiho", "onisshadowmihodirty")

    inst.entity:SetPristine()
	
	inst:AddComponent("talker")
    --inst.components.talker.ontalk = ontalk
    inst.components.talker.fontsize = 32
    inst.components.talker.font = TALKINGFONT
    inst.components.talker.colour = Vector3(.9, .4, .4, 1)
    inst.components.talker.offset = Vector3(0,-210,0)
    inst.components.talker.symbol = "swap_object"
	
    if not TheWorld.ismastersim then
		-- inst:DoTaskInTime(.1, function(inst)
		-- inst.replica.container:WidgetSetup(inst._isshadowmiho:value() and "miho_now")
		-- end)
        inst._clientshadowmorphed = false
        inst:ListenForEvent("onisshadowmihodirty", OnIsShadowMihoDirty)
		-- inst.OnEntityReplicated = OnEntityReplicated
        return inst
    end
	
	inst.persists = false

    inst:AddComponent("health")
    inst.components.health:SetMaxHealth(233)
    inst.components.health:StartRegen(100, 1)
	inst.components.health.invincible = true
	inst.components.health.fire_damage_scale = 0

    inst:AddComponent("inspectable")
    inst.components.inspectable:RecordViews()
    --inst.components.inspectable.getstatus = GetStatus
    inst.components.inspectable.nameoverride = "miho"

    inst:AddComponent("locomotor")
    inst.components.locomotor.walkspeed = 8
    inst.components.locomotor.runspeed = 9

    inst:AddComponent("follower")
    inst:ListenForEvent("stopfollowing", OnStopFollowing)
    inst:ListenForEvent("startfollowing", OnStartFollowing)

    inst:AddComponent("knownlocations")
	
	inst:AddComponent("preserver")
    inst.components.preserver:SetPerishRateMultiplier(.8)
	
    inst:AddComponent("container")
    inst.components.container:WidgetSetup("miho")
    inst.components.container.onopenfn = OnOpen
    inst.components.container.onclosefn = OnClose
	inst.components.container.skipopensnd = true
	inst.components.container.skipclosesnd = true

    inst:AddComponent("named")

    MakeHauntableDropFirstItem(inst)
    AddHauntableCustomReaction(inst, function(inst, haunter)
        if math.random() <= TUNING.HAUNT_CHANCE_ALWAYS then
            inst.components.hauntable.panic = true
            inst.components.hauntable.panictimer = TUNING.HAUNT_PANIC_TIME_SMALL
            inst.components.hauntable.hauntvalue = TUNING.HAUNT_SMALL
            return true
        end
        return false
    end, false, false, true)

    inst:SetStateGraph("SGmiho")
    inst.sg:GoToState("idle")

    inst:SetBrain(brain)
    inst.MihoState = "NORMAL"
    inst.MorphMiho = MorphMiho
	inst:WatchWorldState("isfullmoon", CheckForMorph)
    inst:ListenForEvent("onclose", CheckForMorph)
    -- inst:ListenForEvent("itemget", itemgetfn)
    -- inst:ListenForEvent("itemlose", itemlosefn)
    inst.OnSave = OnSave
    inst.OnPreLoad = OnPreLoad
	
    return inst
end

return Prefab("common/miho", create_miho, assets, prefabs)