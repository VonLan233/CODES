local assets =
{
    Asset("ATLAS", "images/inventoryimages/items.xml"),
    Asset("ANIM", "anim/mihobell.zip"),
	Asset( "SOUND" , "sound/mihobell.fsb" ),
	Asset( "SOUNDPACKAGE" , "sound/mihobell.fev" ),
}

local function RebindMiho(inst, miho)

	if inst.owner and not inst.setname then
		local name = STRINGS.NAMES[string.upper(miho.prefab)]
		miho.components.named:SetName(inst.owner.name..hl_loc("的", " of ")..name)
		inst.setname = true
	end
	if miho.components.follower.leader ~= inst then
		miho.components.follower:SetLeader(inst)
	end
end

local function OnSound(inst)
	inst.SoundEmitter:PlaySound("mihobell/mihobell/inv")
end

local function SpawnMiho(inst)
	OnSound(inst)

	inst:DoTaskInTime(0, function()
		if not inst.owner then
			return
		end

		if inst.owner and inst.owner.miho then
			return
		end

		local miho = SpawnPrefab("miho")
		if miho ~= nil then
			RebindMiho(inst, miho)
			if inst.owner then
				inst.owner.miho = miho
			end
		end
	end)
end

local function OnEnterLimbo(inst)
	inst.inv_o = true
	print("进入")
end

local function OnExitLimbo(inst)
	inst.inv_o = false
	print("离开")
end

local function OnSave(inst, data)
	data.pos = inst:GetPosition()
end

local function OnLoad(inst, data)
    if data then
		if data.pos then
			inst.pos = data.pos
		end		
    end
end

local function GetStatus(inst)
    --print("smallbird - GetStatus")
    if inst.respawntask ~= nil then
        return "WAITING"
    end
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()
	inst.entity:AddSoundEmitter()
	inst.entity:AddMiniMapEntity()
    inst.MiniMapEntity:SetIcon("mihobell.tex")
    MakeInventoryPhysics(inst)

    inst:AddTag("mihobell")
    inst:AddTag("irreplaceable")
    -- inst:AddTag("nonpotatable")
	-- inst:AddTag("_named")

    inst.AnimState:SetBank("mihobell")
    inst.AnimState:SetBuild("mihobell")
    inst.AnimState:PlayAnimation("idle_loop", true)

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst.persists = false

    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.atlasname = "images/inventoryimages/items.xml"
	inst.components.inventoryitem:ChangeImageName("mihobell")
	inst.components.inventoryitem:SetOnPutInInventoryFn(SpawnMiho)

    inst:AddComponent("inspectable")
    inst.components.inspectable.getstatus = GetStatus
    inst.components.inspectable:RecordViews()
	-- inst.components.inspectable.nameoverride = "mihobell"

    inst:AddComponent("leader")
	inst:AddComponent("named")

    MakeHauntableLaunch(inst)
	
	inst.owner = nil
	
    inst.OnLoad = OnLoad
    inst.OnSave = OnSave
    inst.RebindMiho = RebindMiho
	
	-- inst:ListenForEvent("enterlimbo", OnEnterLimbo)
    -- inst:ListenForEvent("exitlimbo", OnExitLimbo)
	
    return inst
end

return Prefab("common/inventory/mihobell", fn, assets)