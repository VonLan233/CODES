require "prefabutil"

local assets = 
{
	Asset("ANIM", "anim/mir.zip"),
	
	Asset( "SOUND" , "sound/mir.fsb" ),
	Asset( "SOUNDPACKAGE" , "sound/mir.fev" ),
}

local prefabs = {}

local WAKE_TO_FOLLOW_DISTANCE = 10
local SLEEP_NEAR_LEADER_DISTANCE = 7


local function GetAtkExp(inst, val)
	local exp = 0
	if inst.components.huli_levelsys then
		exp = math.abs(math.random(3, 9)/10 * val)
		inst.components.huli_levelsys:ExpDoDelta(exp)
	end
end

local function OnAttackOther(inst, data)
	local target = data.target

    inst.components.combat:ShareTarget(target, 15, function(dude)
		return dude._player ~=nil and dude._player == inst._player
			or (dude.components.follower and dude.components.follower:GetLeader()) == (inst.components.follower and inst.components.follower:GetLeader())
		end, 10)
		
end

local function OnAttacked(inst, data)
    local attacker = data.attacker
    if attacker == inst._player then
		inst.components.combat:GiveUp()
		return 
	end
	
    if attacker._player and attacker._player == inst._player then
		inst.components.combat:GiveUp()
		return 
	end
    inst.components.combat:SetTarget(attacker)
    inst.components.combat:ShareTarget(attacker, 15, function(dude)
		return dude._player ~=nil and dude._player == inst._player
			or (dude.components.follower and dude.components.follower:GetLeader()) == (inst.components.follower and inst.components.follower:GetLeader())
		end, 10)
end

local function OnEat(inst, food)
	inst.components.health:DoDelta(10)
	inst.components.combat:SetTarget(nil)
	if math.random() < .1 and food and food.components.edible.foodtype == "MEAT" then
		local fx = SpawnPrefab("collapse_small")
		local item = {"rock","nitre"}
		local randomitem = item[math.random(#item)]
		local prank = SpawnPrefab(randomitem)
		fx.Transform:SetScale(.6,.6,.6)
		fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
		prank.Transform:SetPosition(inst.Transform:GetWorldPosition())
	end
end

local function OnRefuseItem(inst, item)
end
local function CanEatTest(inst, item)
    local canEat = (item.components.edible.foodtype == "MEAT")
    return canEat
end
local function ShouldAcceptItem(inst, item)
    if item.components.edible and inst.components.eater then
        return inst.components.eater:CanEat(item)
    end
end
local function OnGetItemFromPlayer(inst, giver, item)
    if inst.components.sleeper then
        inst.components.sleeper:WakeUp()
    end
    if item.components.edible then
        if inst.components.combat.target and inst.components.combat.target == giver then
            inst.components.combat:SetTarget(nil)
        end
        if inst.components.eater:Eat(item) then
			inst.sg:GoToState("eat")
        end
    end
end

local function ShouldWakeUp(inst)
    return DefaultWakeTest(inst) or not inst.components.follower:IsNearLeader(WAKE_TO_FOLLOW_DISTANCE)
end

local function ShouldSleep(inst)
    return DefaultSleepTest(inst)
    and inst.components.follower:IsNearLeader(SLEEP_NEAR_LEADER_DISTANCE) 
end

local function retargetfn(inst)
    local leader = inst.components.follower:GetLeader()
    return leader ~= nil
     and FindEntity(leader, 20, function(guy)
		return guy ~= inst 
			and (guy.components.combat:TargetIs(leader) or guy.components.combat:TargetIs(inst))
			and inst.components.combat:CanTarget(guy)
    end, {"_combat"}, {"playerghost", "INLIMBO"})
     or nil
end

local function keeptargetfn(inst, target)
    return inst.components.follower:IsNearLeader(20)
		and inst.components.combat:CanTarget(target)
end

local function ck_atk(inst)
	local x, y, z = inst.Transform:GetWorldPosition()
	local ents = TheSim:FindEntities(x, y, z, 10, {"_combat", "_health"}, {"INLIMBO", "NOCLICK"})
	for k, v in pairs(ents) do
		if not v.components.health:IsDead() and (v.components.combat:TargetIs(inst) or v.components.combat:TargetIs(inst.components.follower:GetLeader())) then
			return true
		end
	end
	return false
end

local function SetMir2(inst)
	inst.AnimState:SetAddColour(.8, .8, .2, 1)
	inst:DoPeriodicTask(2, function()
		if not ck_atk(inst) then
			if not inst.sg:HasStateTag("growup") then
				inst.sg:GoToState("growup")
			end
		end
	end)
end

local function SpawnMir2(inst)
	local player = inst._player --or inst.components.follower.leader
	local x, y, z = inst.Transform:GetWorldPosition()
	if not player then return end
	if player.components.huli_petleash_mir then
		inst:Remove()
		local mir2 = player.components.huli_petleash_mir:SpawnPetAt(x, y, z, "mir2")
		mir2.sg:GoToState("growstop")
		local fx = SpawnPrefab("collapse_small")
		fx.Transform:SetPosition(inst.Transform:GetWorldPosition())
	end
end

local function LevelUpFn(inst, lv, m_lv)
	inst.components.combat:SetDefaultDamage(10 + lv)
	inst.components.combat:SetAttackPeriod(2.2 - (lv / 10))
	inst.components.health.absorb = .2 + .02 * lv
	inst.components.huli_levelsys:SetUpExp(300 * (lv + 1))
	if lv >= m_lv then
		SetMir2(inst)
	end
end

local function LoadFn2(inst, lv, m_lv)
	inst.components.combat:SetDefaultDamage(30 + lv * 3)
	inst.components.health.absorb = .5 + .01 * lv
	local sc = 1 + lv/m_lv/2
	inst.Transform:SetScale(sc, sc, sc)
end

local function LevelUpFn2(inst, lv, m_lv)
	inst.components.health.maxhealth = 1200 + lv * 60
	inst.components.huli_levelsys:SetUpExp((lv > 0 and 500 * lv * 3) or 500)
	LoadFn2(inst, lv, m_lv)
end

local function EquipWeapon(inst)
    if inst.components.inventory ~= nil and not inst.components.inventory:GetEquippedItem(EQUIPSLOTS.HANDS) then
        local weapon = CreateEntity()
        weapon.entity:AddTransform()
        weapon:AddTag("nosteal")
        weapon.persists = false
        weapon:AddComponent("weapon")
        weapon.components.weapon:SetDamage(inst.components.combat.defaultdamage)
        -- weapon.components.weapon:SetRange(inst.components.combat.attackrange)
        weapon.components.weapon:SetRange(10)
        weapon.components.weapon:SetProjectile("mir_projectile")
        -- weapon.components.weapon:SetProjectile("bishop_charge")
        -- weapon.components.weapon:SetProjectile("stafflight") --类似火球特效
        weapon:AddComponent("inventoryitem")
        weapon.components.inventoryitem:SetOnDroppedFn(function() 
			if inst and inst:IsValid() then
				inst.components.inventory:Equip(weapon)
			else
				weapon:Remove()
			end
		end)
        weapon:AddComponent("equippable")
		weapon:ListenForEvent("等级变更事件", function() weapon.components.weapon:SetDamage(inst.components.combat.defaultdamage) end, inst)
        inst.components.inventory:Equip(weapon)
    end
end

local function create_common()
	local inst = CreateEntity()

	inst.entity:AddNetwork()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
	inst.entity:AddDynamicShadow()
	
	inst.AnimState:SetBuild("mir")
    inst.AnimState:SetBank("mir")
    inst.AnimState:PlayAnimation("idle")
    inst.Transform:SetFourFaced()	
	
    inst.entity:AddMiniMapEntity()
	inst.MiniMapEntity:SetIcon( "mir.tex" )
	inst.MiniMapEntity:SetCanUseCache(false)
	
	MakeCharacterPhysics(inst, 1, .25)
    inst.Physics:SetCollisionGroup(COLLISION.CHARACTERS)
    inst.Physics:ClearCollisionMask()
    inst.Physics:CollidesWith(COLLISION.WORLD)
    inst.Physics:CollidesWith(COLLISION.OBSTACLES)
    inst.Physics:CollidesWith(COLLISION.CHARACTERS)
	
	inst:AddTag("huli_mir")
	inst:AddTag("imoogi")
	inst:AddTag("scarytoprey")
	inst:AddTag("noauradamage")
	inst:AddTag("notraptrigger")
    inst:AddTag("companion")
    inst:AddTag("nomagic")
	inst:AddTag("stronggrip")
    -- inst:AddTag("character")
	
	inst['所有者net'] = net_entity(inst.GUID, "小龙所有者net")
	
	inst:AddComponent("talker")
	inst.components.talker.font = TALKINGFONT
	inst.components.talker.colour = Vector3(.9, .4, .4, 1)
	
	if not TheWorld.ismastersim then
		return inst
	end
	inst.persists = false
	
    inst.userfunctions = 
    {
        SpawnMir2 = SpawnMir2,
    }
	
    inst:AddComponent("health")
	inst.components.health.fire_damage_scale = 0
	-- inst.components.health.absorb = .8
	
    inst:AddComponent("knownlocations")
    MakeSmallBurnableCharacter(inst, "body")

    inst:AddComponent("combat")
    inst.components.combat:SetRange(2, 2.5)
	inst.components.combat:SetKeepTargetFunction(keeptargetfn)
	inst.components.combat:SetRetargetFunction(1, retargetfn)
	inst.components.combat:SetHurtSound("mir/mir/hit")
	
    -- inst:AddComponent("eater")
    -- inst.components.eater:SetOmnivore()
    -- inst.components.eater:SetOnEatFn(OnEat)

    -- inst:AddComponent("trader")
    -- inst.components.trader:SetAcceptTest(ShouldAcceptItem)
    -- inst.components.trader.onaccept = OnGetItemFromPlayer
    -- inst.components.trader.onrefuse = OnRefuseItem

    inst:AddComponent("inspectable")
	inst:AddComponent("huli_levelsys")
    inst:AddComponent("xhl_command")
	inst:AddComponent("inventory")
	
    inst:AddComponent("locomotor")
    inst.components.locomotor.walkspeed = 8
	
    inst:AddComponent("follower")
	inst.components.follower:KeepLeaderOnAttacked()
	inst.components.follower.keepdeadleader = true
	
    inst:AddComponent("sleeper")
    inst.components.sleeper:SetResistance(3)
    inst.components.sleeper.testperiod = GetRandomWithVariance(6, 2)
    inst.components.sleeper:SetSleepTest(ShouldSleep)
    inst.components.sleeper:SetWakeTest(ShouldWakeUp)
	
	inst:AddComponent("lootdropper")
	inst.components.lootdropper.numrandomloot = 1
	inst.components.lootdropper:AddRandomLoot("miregg", 1)
	
	local brain = require "brains/mirbrain"
    inst:SetBrain(brain)
	inst:SetStateGraph("SGmir")
	
	inst:ListenForEvent("onattackother", OnAttackOther)
	inst:ListenForEvent("attacked", OnAttacked)
	
	inst['获取经验值fn'] = GetAtkExp
    return inst
end

local function create_mir() --【【【【【【小龙1】】】】】】
	local inst = create_common()

	inst.DynamicShadow:SetSize(1.25, .75)
	inst.Transform:SetScale(.8,.8,.8)

    inst.components.talker.fontsize = 40
    inst.components.talker.offset = Vector3(0, -250, 0)
	
	if not TheWorld.ismastersim then
		return inst
	end

    inst.components.combat:SetDefaultDamage(10)
    inst.components.combat:SetAttackPeriod(2.2)
	inst.components.health:SetMaxHealth(800)
	inst.components.health:StartRegen(2, 5)
	inst.components.health.absorb = .2
	
	inst.components.huli_levelsys:Set({['最大等级'] = 10, ['升级经验值'] = 300, ['最大经验值'] = 99999, ['自动升级'] = true})
	inst.components.huli_levelsys['等级变更fn'] = LevelUpFn
	inst.components.huli_levelsys['加载等级fn'] = LevelUpFn
	
	-- inst:DoTaskInTime(1, function()
	-- inst:DoPeriodicTask(2, function()

    -- local growth_stages = {
        -- {name="mir", time = GetSmallGrowTime, fn = function() end },
        -- {name="mir2", fn = SetMir2}
    -- }

	-- inst:AddComponent("growable")
    -- inst.components.growable.stages = growth_stages
    -- inst.components.growable:SetStage(1)
    -- inst.components.growable:StartGrowing()
	

	return inst
end

local function create_mir2() --【【【【【【小龙2】】】】】】
	local inst = create_common()

	inst.DynamicShadow:SetSize(1.25, .75)
	
    inst.components.talker.fontsize = 35
    inst.components.talker.offset = Vector3(0, -300, 0)

	if not TheWorld.ismastersim then
		return inst
	end
	
    inst.components.combat:SetDefaultDamage(30)
    inst.components.combat:SetAttackPeriod(1)
    inst.components.health:SetMaxHealth(1200)
	inst.components.health:StartRegen(2, 3)
	inst.components.health.absorb = .5
	inst.components.health.save_maxhealth = true
	
	inst.components.huli_levelsys:Set({['最大等级'] = 30, ['升级经验值'] = 500, ['最大经验值'] = 999999, ['自动升级'] = true})
	inst.components.huli_levelsys['等级变更fn'] = LevelUpFn2
	inst.components.huli_levelsys['加载等级fn'] = LoadFn2
	inst:DoTaskInTime(0, EquipWeapon)
	
	return inst
end


return Prefab( "mir", create_mir, assets, prefabs),
			Prefab( "mir2", create_mir2)
