
local assets_skirt=
{
    Asset("ANIM", "anim/skirt.zip"),
    Asset("IMAGE", "images/inventoryimages/items.tex"),
    Asset("ATLAS", "images/inventoryimages/items.xml"),
}
local COND = 1

local function getab_per(inst)
	return inst.components.armor.absorb_percent * 100
end

local function getab_count(inst)
	return .5 * 1.022685^inst.level
end

local function insu_count(inst)
	return math.ceil(TUNING.INSULATION_SMALL * 1.09466^inst.level)
end

local function wate_count(inst)
	return TUNING.WATERPROOFNESS_SMALLMED * 1.04527^inst.level
end

local function onequip(inst, owner) 
    owner.AnimState:OverrideSymbol("swap_body", "skirt", "swap_body")
	local armor = inst.components.armor
	if armor.condition > 0 then
		inst.condition_val = inst:DoPeriodicTask(1, function() 
			if armor.condition > 0 then
				armor.condition = armor.condition - COND
				inst:PushEvent("percentusedchange", { percent = armor:GetPercent() })
			elseif armor.condition <= 0 then
				if inst.condition_val then 
					inst.condition_val:Cancel() 
					inst.condition_val = nil 
				end
			end
		inst._condition:set(armor.condition)
		end)
	end
	--[[inst.components.fueled:StartConsuming()
	inst.damagefn = function(attacked, data)
		local attacker = data and data.attacker
	    if attacker then
			local damage = data.damage / .4 * .6
			inst.components.fueled:DoDelta(- damage)
		end
		--owner.components.inventory:SetOverflow(inst)
	end
	inst:ListenForEvent("attacked", inst.damagefn, owner)]]
end

local function onunequip(inst, owner) 
    owner.AnimState:ClearOverrideSymbol("swap_body")
	if inst.condition_val then 
		inst.condition_val:Cancel() 
		inst.condition_val = nil 
	end
	if inst.components.armor.condition > 0 then
		inst.components.armor:SetAbsorption(getab_count(inst))
		inst.components.insulator:SetInsulation(insu_count(inst))
		inst.components.waterproofer:SetEffectiveness(wate_count(inst))
		
		inst._absorb_percent:set(inst.components.armor.absorb_percent * 100)
		inst._insulation:set(inst.components.insulator.insulation)
		inst._effectiveness:set(inst.components.waterproofer.effectiveness * 100)
	else
		inst.components.armor.condition = 0
		inst._condition:set(0)
		inst._absorb_percent:set(0)
		inst._insulation:set(0)
		inst._effectiveness:set(0)
	end
	--inst.components.fueled:StopConsuming()
	--inst:RemoveEventCallback("attacked", inst.damagefn, owner)
    --owner.components.inventory:SetOverflow(nil)
end

local function setaccepttest(inst, item, giver)
	local armor = inst.components.armor
	--local owner = inst.components.inventoryitem.owner
	for k,v in pairs(TUNING.ITEM.skirt) do
		if item.prefab == v[1] then
			if armor.condition < armor.maxcondition then
				return true
			elseif armor.condition >= armor.maxcondition then
				if inst.level < inst.maxlevel then
					if item.prefab == "huligem_qh" 
					or item.prefab == "huligem_gjqh" then 
						return true
					end
				end
				if inst.level >= 9 then
					if item.prefab == "huligem_jh" then
						return true
					end
				end
				giver.components.talker:Say("耐久已满.")	
				return false
			end
		end
	end
	giver.components.talker:Say("这个物品不能修复\n这件装备的耐久.")	
	return false
end

local function onaccept(inst, giver, item)
	local armor = inst.components.armor
	local rand = .8^(inst.level + 1)
	local rand2 = .7^(inst.level - 8)
	local gin_xy = giver.components.inventory and giver.components.inventory:Has("huligem_xy", 1)
		--giver.components.inventory:FindItems(function(item) return item.prefab == "huligem_xy" end) then
		--giver.components.inventory:ConsumeByName("huligem_xy", 1) 
	
	for k,v in pairs(TUNING.ITEM.skirt) do
		if item.prefab == v[1] then
			if item.prefab == "huligem_jh" then
				if inst.level >= 9 then
					if armor.condition > 0 then
						local fmw =SpawnPrefab("skirt_x")
						if fmw ~= nil then
							local fca = fmw.components.armor
							if giver and giver.components.inventory then
								giver.components.inventory:GiveItem(fmw)
								giver.components.talker:Say("进化成功")
								fmw.level = inst.level - 9
								fca.condition = armor.condition
								fca.maxcondition = math.ceil(3000 * 1.130699^fmw.level)
								if fca.condition >= fca.maxcondition then
									fca.condition = fca.maxcondition
								end
								fca:SetAbsorption(fca.absorb_percent + fmw.level / 100)
								fmw.components.insulator:SetInsulation(inst.components.insulator.insulation)
								fmw.components.waterproofer:SetEffectiveness(inst.components.waterproofer.effectiveness)
								--fmw._insu = insu_count(inst)
								--fmw._wate = wate_count(inst)
								
								fmw._level:set(fmw.level)
								fmw._condition:set(fca.condition)
								fmw._maxcondition:set(fca.maxcondition)
								fmw._absorb_percent:set(fca.absorb_percent * 100)
								fmw._insulation:set(inst.components.insulator.insulation)
								fmw._effectiveness:set(inst.components.waterproofer.effectiveness * 100)
								fmw:PushEvent("percentusedchange", { percent = fca:GetPercent() })
								inst:Remove()
							end
						end
					else
						giver.components.talker:Say("耐久度过低,无法进化!")
					end
				end
			end
			if inst.level < inst.maxlevel then
				if v[3] ~= nil then
					if item.prefab == "huligem_qh" then
						if gin_xy then
							rand = .8^(inst.level + 1) + .2
							giver.components.inventory:ConsumeByName("huligem_xy", 1)
						end
						if inst.level < 9 then
							if math.random() < rand then
								inst.level = inst.level + v[3]
								giver.components.talker:Say("强化成功")
							else
								giver.components.talker:Say("强化失败")
							end
							if armor.condition < armor.maxcondition then
								armor.condition = armor.condition + (armor.maxcondition* .02 - v[2])
							end
						elseif inst.level >= 9 then
							if math.random() < rand / 2 then
								inst.level = inst.level + v[3]
								giver.components.talker:Say("强化成功")
							else
								if giver.components.inventory and giver.components.inventory:Has("huligem_bj", 1) then
									giver.components.inventory:ConsumeByName("huligem_bj", 1) 
									giver.components.talker:Say("强化失败,等级保留.")
								else
									giver.components.talker:Say("强化失败")
									inst.level = inst.level - 1
								end
							end
							if armor.condition < armor.maxcondition then
								armor.condition = armor.condition + (armor.maxcondition* .02 - v[2])
							end
						end
					elseif item.prefab == "huligem_gjqh" then
						if inst.level < 9 then
							inst.level = inst.level + v[3]
							giver.components.talker:Say("强化成功")
							if armor.condition < armor.maxcondition then
								armor.condition = armor.condition + (armor.maxcondition* .02 - v[2])
							end
						elseif inst.level >= 9 then
							if gin_xy then
								rand2 = .7^(inst.level - 8) + .1
								giver.components.inventory:ConsumeByName("huligem_xy", 1)
							end
							if math.random() < rand2 then
								inst.level = inst.level + v[3]
								giver.components.talker:Say("强化成功")
							else
								if giver.components.inventory and giver.components.inventory:Has("huligem_bj", 1) then
									giver.components.inventory:ConsumeByName("huligem_bj", 1) 
									giver.components.talker:Say("强化失败,等级保留.")
								else
									giver.components.talker:Say("强化失败")
									inst.level = inst.level - 1
								end
							end
							if armor.condition < armor.maxcondition then
								armor.condition = armor.condition + (armor.maxcondition* .02 - v[2])
							end
						end
					end
				end
			end
			if armor.condition < armor.maxcondition then
				armor.condition = armor.condition + v[2]
			end
		end
	end
	armor.maxcondition = math.ceil(1800 * 1.140892^inst.level)
	inst.components.armor:SetAbsorption(getab_count(inst))
	inst.components.insulator:SetInsulation(insu_count(inst))
	inst.components.waterproofer:SetEffectiveness(wate_count(inst))
	if inst.condition_val then 
		inst.condition_val:Cancel() 
		inst.condition_val = nil 
	end
	if inst.components.equippable:IsEquipped() then
		inst.condition_val = inst:DoPeriodicTask(1, function() 
			if armor.condition > 0 then
				armor.condition = armor.condition - COND
				inst:PushEvent("percentusedchange", { percent = armor:GetPercent() })
			elseif armor.condition <= 0 then
				if inst.condition_val then 
					inst.condition_val:Cancel() 
					inst.condition_val = nil 
				end
			end
			inst._condition:set(armor.condition)
		end)
	end
	if inst.level >= inst.maxlevel then
		inst.level = inst.maxlevel
	end
	if armor.condition >= armor.maxcondition then
		armor.condition = armor.maxcondition
	end
	inst._level:set(inst.level)
	inst._condition:set(inst.components.armor.condition)
	inst._maxcondition:set(inst.components.armor.maxcondition)
	inst._absorb_percent:set(inst.components.armor.absorb_percent * 100)
	inst._insulation:set(inst.components.insulator.insulation)
	inst._effectiveness:set(inst.components.waterproofer.effectiveness * 100)
	inst:PushEvent("percentusedchange", { percent = armor:GetPercent() })
end

local function dapupdate(inst)
	inst._dapperness:set(inst.components.equippable.dapperness * 100)
end

local function get_name(inst)
	local name = STRINGS.NAMES[string.upper(inst.prefab)]
	local level = inst._level:value()
	local maxlevel = inst._maxlevel:value()
	local condition = inst._condition:value()
	local maxcondition = inst._maxcondition:value()
	local absorb_percent = inst._absorb_percent:value()
	local insulation = inst._insulation:value()
	local effectiveness = inst._effectiveness:value()
	local dapperness = inst._dapperness:value()
	local named = name.."+"..level.."\n耐久度:"..condition.."/"..maxcondition.."\n防御力:"..absorb_percent.."%\n防热:"..insulation.."\n防水:"..effectiveness.."%\n脑子回复:"..dapperness.."/S\n "
	if get_modinfoname(inst) then
		named = name.."+"..level
	end
	return named
end

local function onsave(inst, data) 
	data.level = inst.level
	data.getab_count = getab_count(inst)
	--data.condition = inst.components.armor.condition
	data.maxcondition = inst.components.armor.maxcondition
	data.absorb_percent = inst.components.armor.absorb_percent
	data.insulation = inst.components.insulator.insulation
	data.effectiveness = inst.components.waterproofer.effectiveness
end

local function onlaod(inst, data)
	inst.level = data.level
	inst.components.armor:SetAbsorption(data.getab_count)
	--inst.components.armor.condition = data.condition
	inst.components.armor.maxcondition = data.maxcondition
	inst.components.insulator.insulation = data.insulation
	inst.components.waterproofer.effectiveness = data.effectiveness
	inst._level:set(data.level)
	inst._condition:set(inst.components.armor.condition)
	inst._maxcondition:set(data.maxcondition)
	inst._absorb_percent:set(data.absorb_percent * 100)
	inst._insulation:set(data.insulation)
	inst._effectiveness:set(data.effectiveness * 100)
	inst._dapperness:set(inst.components.equippable.dapperness * 100)
end

local function fn_skirt()
    local inst = CreateEntity()
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
	inst.entity:AddNetwork()
    MakeInventoryPhysics(inst)
    
    inst.AnimState:SetBank("torso_rain")
    inst.AnimState:SetBuild("skirt")
    inst.AnimState:PlayAnimation("anim")
	
	inst._level = net_shortint(inst.GUID, "skirt._level")
	inst._maxlevel = net_shortint(inst.GUID, "skirt._maxlevel")	
	inst._condition = net_shortint(inst.GUID, "skirt._condition")
	inst._maxcondition = net_shortint(inst.GUID, "skirt._maxcondition")
	inst._absorb_percent = net_shortint(inst.GUID, "skirt._absorb_percent")
	inst._insulation = net_shortint(inst.GUID, "skirt._insulation")
	inst._effectiveness = net_shortint(inst.GUID, "skirt._effectiveness")
	inst._dapperness = net_shortint(inst.GUID, "skirt._dapperness")
	
    inst.AnimState:SetBank("fox_foxhat")
    inst.AnimState:SetBuild("fox_foxhat")
    inst.AnimState:PlayAnimation("anim")
	inst.AnimState:PlayAnimation("idle")
	inst.displaynamefn = get_name
    
	if not TheWorld.ismastersim then
		return inst
	end
	
    inst:AddComponent("inspectable")
    
    inst:AddComponent("inventoryitem")
    inst.components.inventoryitem.atlasname = "images/inventoryimages/items.xml"

	inst:AddComponent("waterproofer")
    inst.components.waterproofer:SetEffectiveness(TUNING.WATERPROOFNESS_SMALLMED)
	
	inst:AddComponent("insulator")
    inst.components.insulator:SetInsulation(TUNING.INSULATION_SMALL)
	
	inst:AddComponent("armor")
	inst.components.armor.condition = 100
	inst.components.armor.maxcondition = 1000
	inst.components.armor:SetAbsorption(.5)
	--inst.components.armor:InitIndestructible(.6)
	
	inst:AddComponent("trader")
	inst.components.trader:SetAcceptTest(setaccepttest)
	inst.components.trader.onaccept = onaccept
	inst.components.trader:Enable()
	
	--[[inst:AddComponent("fueled")
    inst.components.fueled.fueltype = FUELTYPE.USAGE
    inst.components.fueled.accepting = true
	inst.components.fueled:InitializeFuelLevel(2400)
	inst.components.fueled.updatefn = updatefn
    inst.components.fueled:SetDepletedFn(inst.Remove)]]
	
    inst:AddComponent("equippable")
    inst.components.equippable.equipslot = EQUIPSLOTS.BODY
    inst.components.equippable:SetOnEquip( onequip )
    inst.components.equippable:SetOnUnequip( onunequip )
	inst.components.equippable.dapperness = .1
	
	inst.level = 0
	inst.maxlevel = 15
	inst.OnSave = onsave
	inst.OnLoad = onlaod
	
	inst._level:set(inst.level)
	inst._maxlevel:set(inst.maxlevel)
	inst._condition:set(inst.components.armor.condition)
	inst._maxcondition:set(inst.components.armor.maxcondition)
	inst._absorb_percent:set(inst.components.armor.absorb_percent * 100)
	inst._insulation:set(inst.components.insulator.insulation)
	inst._effectiveness:set(inst.components.waterproofer.effectiveness * 100)
	inst._dapperness:set(inst.components.equippable.dapperness * 100)
	
	function inst.components.armor:SetCondition(amount)
		self.condition = math.min(amount, self.maxcondition)
		self.inst:PushEvent("percentusedchange", { percent = self:GetPercent() })
		
		if self.condition <= 0 then
			self.condition = 0
		end
	end
	
    return inst
end

STRINGS.NAMES.SKIRT = "狐狸裙子"
STRINGS.RECIPE_DESC.SKIRT = "是一件\n漂亮的裙子"
STRINGS.CHARACTERS.GENERIC.DESCRIBE.SKIRT = "防雨防寒防伤回脑残"

return Prefab( "common/inventory/skirt", fn_skirt, assets_skirt)
