local assets = {
    Asset("ANIM", "anim/skirt.zip"),
	Asset("ANIM", "anim/ui_skirtbag_2x8.zip"),
    Asset("IMAGE", "images/inventoryimages/items.tex"),
    Asset("ATLAS", "images/inventoryimages/items.xml"),
}

local function getab_count(inst)
	return .55 * 1.02646^inst.level
end

local function insu_count(inst)
	return TUNING.INSULATION_SMALL * 1.12062^inst.level
end

local function wate_count(inst)
	return TUNING.WATERPROOFNESS_SMALLMED * 1.05055^inst.level
end

local function dap_count(inst)
	return .05 * 1.06294^inst.level
end

local function abper(inst)
	return inst.components.armor.absorb_percent * 100
end

local function insu(inst)
	return inst.components.insulator.insulation
end

local function wate(inst)
	return inst.components.waterproofer.effectiveness * 100
end

local function dap(inst)
	return inst.components.equippable.dapperness * 100
end

local LEVEL_A = 9
local LEVEL_B = 13
local LEVEL_C = 11

local function OnOpen(inst, owner)
	if inst.level >= LEVEL_C then
		if inst.components.container ~= nil then
			inst.components.container:Open(owner)
		end
	end
end

local function OnClose(inst, owner)
	if inst.components.container ~= nil then
		inst.components.container:Close(owner)
	end
end

local function unequip(inst)
	local armor = inst.components.armor
	if armor:GetPercent() > 0 then
		armor:SetAbsorption(getab_count(inst))
		inst.components.insulator:SetInsulation(insu_count(inst))
		inst.components.waterproofer:SetEffectiveness(wate_count(inst))
		inst.components.equippable.dapperness = dap_count(inst)
	else
		armor.condition = 0
		armor:SetAbsorption(0)
		inst.components.insulator:SetInsulation(0)
		inst.components.waterproofer:SetEffectiveness(0)
		inst.components.equippable.dapperness = 0
		if inst.condition_val then 
			inst.condition_val:Cancel() 
			inst.condition_val = nil 
		end
		if inst.components.container:IsOpen() then
			inst:DoTaskInTime(0, inst.components.container:Close())
		end
	end
end

local function onequip(inst, owner) 
	owner.AnimState:OverrideSymbol("swap_body", "skirt", "swap_body")
	OnOpen(inst, owner)
	local armor = inst.components.armor
	if armor.condition > 0 then
		inst.condition_val = inst:DoPeriodicTask(TUNING.SKIRT_NAIJIUDU_TASK, function() 
			armor.condition = armor.condition - TUNING.SKIRT_NAIJIUDU_CONSUME
			inst:PushEvent("percentusedchange", { percent = armor:GetPercent() })
		end)
	end
	inst:ListenForEvent("percentusedchange", unequip)
end

local function onunequip(inst, owner) 
	owner.AnimState:ClearOverrideSymbol("swap_body")
	OnClose(inst, owner)
	if inst.condition_val then 
		inst.condition_val:Cancel() 
		inst.condition_val = nil 
	end
	-- inst:RemoveEventCallback("percentusedchange", unequip)
end

local function TongYongFn(inst, armor, giver)
	if inst.components.equippable:IsEquipped() then
		OnOpen(inst, giver)
		if not inst.condition_val then 
			inst.condition_val = inst:DoPeriodicTask(TUNING.FOXMASKNEW_NAIJIUDU_TASK, function() 
				armor.condition = armor.condition - TUNING.SKIRT_NAIJIUDU_CONSUME
				inst:PushEvent("percentusedchange", { percent = armor:GetPercent() })
			end)
		end
	end
	if inst.level >= inst.maxlevel then
		inst.level = inst.maxlevel
	end
	if armor.condition >= armor.maxcondition then
		armor.condition = armor.maxcondition
	end
	inst:PushEvent("percentusedchange", { percent = armor:GetPercent() })	
end

local function val(inst, item)
	for k, v in pairs(TUNING.ITEM.skirt) do 
		if item.prefab == v[1] then
			if v[3] then
				return v[2], v[3]
			else
				return v[2], 0
			end
		end
	end
	return 0, 0
end

local function QiangHuaFn(inst, giver, item)
	local armor = inst.components.armor
	local rand = .83^inst.level*HULI_EQUIPLEVELUP_SET
	local rand2 = .9^inst.level*HULI_EQUIPLEVELUP_SET
	local gin_xy = giver.components.inventory and giver.components.inventory:Has("huligem_xy", 1)
	local value, lev = val(inst, item)
	
	if item.prefab == "huligem_qh" then
		if inst.level < inst.maxlevel then
			if gin_xy then
				rand = rand + .2
				giver.components.inventory:ConsumeByName("huligem_xy", 1)
			end
			if math.random() < rand then
				inst.level = inst.level + lev
				giver.components.talker:Say("强化成功")
			else
				giver.components.talker:Say("强化失败")
			end
			armor.condition = armor.condition + (armor.maxcondition* .02)
		end
	elseif item.prefab == "huligem_gjqh" then
		if inst.level < inst.maxlevel then
			if inst.level < 9 then
				inst.level = inst.level + lev
				giver.components.talker:Say("强化成功")
				if armor.condition < armor.maxcondition then
					armor.condition = armor.condition + (armor.maxcondition* .02)
				end
			else
				if gin_xy then
					rand2 = rand2 + .2
					giver.components.inventory:ConsumeByName("huligem_xy", 1)
				end
				if math.random() < rand2 then
					inst.level = inst.level + lev
					giver.components.talker:Say("强化成功")
				else
					giver.components.talker:Say("强化失败")
				end
				armor.condition = armor.condition + (armor.maxcondition* .02)
			end
		end
	end
	armor.maxcondition = math.ceil(2000 * 1.1462369^inst.level)
	armor:SetAbsorption(getab_count(inst))
	inst.components.insulator:SetInsulation(insu_count(inst))
	inst.components.waterproofer:SetEffectiveness(wate_count(inst))
	inst.components.equippable.dapperness = dap_count(inst)

	item.components.stackable:Get():Remove()
	TongYongFn(inst, armor, giver)
end

local function XiuLiFn(inst, giver, item)
	local armor = inst.components.armor
	local xvalue = armor.maxcondition - armor.condition
	local stkitem = item.components.stackable and item.components.stackable:StackSize()
	local value = val(inst, item)
	
	if armor.condition < armor.maxcondition - 10 then						
		if xvalue / value - stkitem >= 0 then
			armor.condition = armor.condition + value * stkitem
			item:Remove()
		else
			local Consumeitem = math.ceil(xvalue / value)
			local items = item.components.stackable and  item.components.stackable:Get(Consumeitem)
			armor.condition = armor.condition + value * Consumeitem
			items:Remove()
		end	
		giver.components.talker:Say("修理成功!")
	else
		giver.components.talker:Say("已经修好了!")
	end
	TongYongFn(inst, armor, giver)
end

local function onsave(inst, data) 
	
	data.level = inst.level
	data.condition = inst.components.armor.condition
	data.maxcondition = inst.components.armor.maxcondition
	data.absorb_percent = inst.components.armor.absorb_percent
	data.insulation = inst.components.insulator.insulation
	data.effectiveness = inst.components.waterproofer.effectiveness
	data.dapperness = inst.components.equippable.dapperness
end

local function onlaod(inst, data)
	if data then
		inst.level = data.level
		inst.components.armor.condition = data.condition
		inst.components.armor.maxcondition = data.maxcondition
		inst.components.insulator.insulation = data.insulation
		inst.components.waterproofer.effectiveness = data.effectiveness
		inst.components.armor:SetAbsorption(data.absorb_percent)
		inst.components.equippable.dapperness = data.dapperness
	end
end

local function onpreload(inst, data)
	inst._level:set(data.level)
end

local function get_name(inst)
	local name = STRINGS.NAMES[string.upper(inst.prefab)]
	local level = inst._level:value()
	local maxlevel = inst._maxlevel:value()
	local condition = inst._condition:value()
	local maxcondition = inst._maxcondition:value()
	local absorb_percent = inst._absorb_percent:value()
	local insulation = inst._insulation:value()
	local effectiveness = inst._effectiveness:value()
	local dapperness = inst._dapperness:value()
	--local named = name.."\n强化等级"..level.."/"..maxlevel.."\n耐久度:"..condition.."/"..maxcondition.."\n防御力:"..absorb_percent.."%\n防热:"..insulation.."\n防水:"..effectiveness.."%\n "
	local named = name.."+"..level..'/'..maxlevel.."\n耐久度:"..condition.."/"..maxcondition.."\n防御力:"..absorb_percent.."%\n防热:"..insulation.."\n防水:"..effectiveness.."%\n精神回复:"..dapperness.."/s"
	if get_modinfoname(inst) then
		named = name.."+"..level..'/'..maxlevel
	end
	return named
end

local function fn()
	local inst = CreateEntity()

	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
	inst.entity:AddNetwork()
	
	MakeInventoryPhysics(inst)  
	
	inst._level = net_shortint(inst.GUID, "skirt_x.level")
	inst._maxlevel = net_shortint(inst.GUID, "skirt_x.maxlevel")	
	inst._condition = net_shortint(inst.GUID, "skirt_x._condition")
	inst._maxcondition = net_shortint(inst.GUID, "skirt_x._maxcondition")
	inst._absorb_percent = net_shortint(inst.GUID, "skirt_x._absorb_percent")
	inst._insulation = net_shortint(inst.GUID, "skirt_x._insulation")
	inst._effectiveness = net_shortint(inst.GUID, "skirt_x._effectiveness")
	-- inst._dapperness = net_shortint(inst.GUID, "skirt_x._dapperness")
	inst._dapperness = net_string(inst.GUID, "skirt_x._dapperness")
	inst.displaynamefn = get_name
	
	inst.AnimState:SetBank("torso_rain")
    inst.AnimState:SetBuild("skirt")
    inst.AnimState:PlayAnimation("anim")
	--inst.AnimState:PlayAnimation("idle")
	inst.foleysound = "dontstarve/movement/foley/backpack"
	inst:AddTag("huli_skirt_x")
	inst:AddTag("huli_level_item")

	if not TheWorld.ismastersim then
		return inst
	end
	
	inst:AddComponent("container")
    inst.components.container:WidgetSetup("skirt_x")
	-- inst.components.container.onopenfn = op
	-- inst.components.container.onclosefn = cl
	
    inst:AddComponent("inspectable")
    
    inst:AddComponent("inventoryitem")
    inst.components.inventoryitem.atlasname = "images/inventoryimages/items.xml"
	
	inst:AddComponent("timer")
	
	inst:AddComponent("insulator")
    inst.components.insulator:SetInsulation(TUNING.INSULATION_SMALL)

	inst:AddComponent("waterproofer")
    inst.components.waterproofer:SetEffectiveness(TUNING.WATERPROOFNESS_SMALLMED)
	
	-- inst:AddComponent("trader")
	-- inst.components.trader:SetAcceptTest(setaccepttest)
	-- inst.components.trader.onaccept = onaccept
	-- inst.components.trader:Enable()
	
	inst:AddComponent("equippable")
	inst.components.equippable.equipslot = EQUIPSLOTS.BODY
	inst.components.equippable:SetOnEquip( onequip )
	inst.components.equippable:SetOnUnequip( onunequip )
	inst.components.equippable.dapperness = .05
	
	inst:AddComponent("armor")
	inst.components.armor.condition = 2000
	inst.components.armor.maxcondition = 2000
	inst.components.armor:SetAbsorption(.55)
	
	inst.QiangHuaFn = QiangHuaFn
	inst.XiuLiFn = XiuLiFn
	inst.level = 0
	inst.maxlevel = 18
	inst.OnSave = onsave
	inst.OnLoad = onlaod
	inst.OnPreLoad = onpreload
	
	inst._maxlevel:set(inst.maxlevel)
	inst:DoPeriodicTask(0, function() 
	inst._level:set(inst.level)
	inst._condition:set(inst.components.armor.condition)
	inst._maxcondition:set(inst.components.armor.maxcondition)
	inst._absorb_percent:set(inst.components.armor.absorb_percent * 100)
	inst._insulation:set(inst.components.insulator.insulation)
	inst._effectiveness:set(inst.components.waterproofer.effectiveness * 100)
	inst._dapperness:set(string.format("%.2f",inst.components.equippable.dapperness)) end)
	
	function inst.components.armor:SetCondition(amount)
		self.condition = math.min(amount, self.maxcondition)
		self.inst:PushEvent("percentusedchange", { percent = self:GetPercent() })
		
		if self.condition <= 0 then
			self.condition = 0
		end
	end
	
	local oldOpen = inst.components.container.Open
	inst.components.container.Open = function(self, doer)
		if inst.level >= LEVEL_C and inst.components.armor.condition > 0 then
			return oldOpen(self, doer)
		elseif inst.level >= LEVEL_C and inst.components.armor.condition <= 0 then
			doer.components.talker:Say("裙子已损坏,无法使用背包空间")
			return
		elseif inst.level < LEVEL_C and inst.components.armor.condition > 0 then
			doer.components.talker:Say("强化等级+11才能使用背包空间")
			return
		else
			doer.components.talker:Say("先强化装备再说.")
			return
		end
	end

	return inst
end

-- STRINGS.NAMES.SKIRT_X = "狐狸裙子"
-- STRINGS.RECIPE_DESC.SKIRT_X = "性能强大的裙子\n可以强化升级"
-- STRINGS.CHARACTERS.GENERIC.DESCRIBE.SKIRT_X = "防雨防寒防伤回脑残还能装东西"

return Prefab("common/inventory/skirt_x", fn, assets)
