
local function ondeploy(inst, pt, deployer)
    if deployer and deployer.SoundEmitter then
        deployer.SoundEmitter:PlaySound("dontstarve/wilson/dig")
    end

    local map = TheWorld.Map
    local original_tile_type = map:GetTileAtPoint(pt:Get())
    local x, y = map:GetTileCoordsAtPoint(pt:Get())
    if x and y then
        map:SetTile(x,y, inst.data.tile)
        map:RebuildLayer( original_tile_type, x, y )
        map:RebuildLayer( inst.data.tile, x, y )
    end

    local minimap = TheWorld.minimap.MiniMap
    minimap:RebuildLayer(original_tile_type, x, y)
    minimap:RebuildLayer(inst.data.tile, x, y)

    inst.components.stackable:Get():Remove()
end

local assets =
{
    Asset("ANIM", "anim/marble_turf.zip"),
    Asset("ATLAS", "images/inventoryimages/turfturf.xml")
}
	
local prefabs =
{
	"gridplacer",
}


local data = {name = "turf_marble", anim = "road", tile = GROUND.MARBLE}
	
local function fn(Sim)

	local inst = CreateEntity()
	
    inst.entity:AddTransform()
	inst.entity:AddAnimState()
    inst.entity:AddNetwork()
	
	MakeInventoryPhysics(inst)
	
	inst:AddTag("groundtile")
		
	inst.AnimState:SetBank("naturedesert")
    inst.AnimState:SetBuild("naturedesert")
    --inst.AnimState:PlayAnimation(data.anim)
    inst.AnimState:PlayAnimation("idle")
	
    inst:AddTag("molebait")
    MakeDragonflyBait(inst, 3)

    inst.entity:SetPristine()
	
	if not TheWorld.ismastersim then
    return inst
end
	
	inst:AddComponent("stackable")
	inst.components.stackable.maxsize = TUNING.STACK_SIZE_LARGEITEM
		
	inst:AddComponent("inspectable")
	inst:AddComponent("inventoryitem")
	--inst.components.inventoryitem.imagename = "turf_marble"
    inst.components.inventoryitem.atlasname = "images/inventoryimages/turfturf.xml"
    inst.data = data
	
    inst:AddComponent("bait")
        
        inst:AddComponent("deployable")
        --inst.components.deployable:SetDeployMode(DEPLOYMODE.ANYWHERE)
        inst.components.deployable.ondeploy = ondeploy
        if data.tile == "webbing" then
            inst.components.deployable:SetDeployMode(DEPLOYMODE.ANYWHERE)
        else
            inst.components.deployable:SetDeployMode(DEPLOYMODE.TURF)
        end
        inst.components.deployable:SetUseGridPlacer(true)

	---------------------  
	return inst	  
end

return Prefab( "common/objects/turf_marble", fn, assets, prefabs)
