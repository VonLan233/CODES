local function builder_onbuilt(inst, builder)
    local theta = math.random() * 2 * PI
    local pt = builder:GetPosition()
    local radius = 1
    local offset = FindWalkableOffset(pt, theta, radius, 6, true)
    if offset ~= nil then
        pt.x = pt.x + offset.x
        pt.z = pt.z + offset.z
    end
	if builder.components.huli_petleash.numpets < builder.components.huli_petleash.maxpets then
		builder.components.huli_petleash:SpawnPetAt(pt.x, 0, pt.z, "huliclone")
		inst:Remove()
	else
		builder.components.talker:Say("小孩够多了，还造，猪么你！")
		--[[builder:DoTaskInTime(0, function() 
			builder.components.lootdropper:SpawnLootPrefab("hulisoul")
		end)]]
		local recipe = AllRecipes[inst.prefab]
		for i, v in ipairs(recipe.ingredients) do
			local amt = math.max(1, math.ceil(v.amount))
			for n = 1, amt do
				builder.components.lootdropper:SpawnLootPrefab(v.type)
			end
		end
	end
    --builder.components.talker:Say("666")
end

local function fn()
	local inst = CreateEntity()
	inst.entity:AddTransform()
	
	if not TheWorld.ismastersim then
		return inst
	end
	inst.persists = false
	
	inst:DoTaskInTime(0, inst.Remove)
	
	inst.OnBuiltFn = builder_onbuilt
	return inst
end
	
return Prefab("xhl_cl", fn)