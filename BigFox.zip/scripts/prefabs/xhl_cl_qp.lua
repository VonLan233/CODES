
local assets =
{
	Asset("ANIM", "anim/xhl_cl_qp.zip"),
	Asset("ANIM", "anim/xhl_cl_qp_db.zip"),
	Asset("ATLAS", "images/inventoryimages/xhl_cl_qp.xml"),
	Asset("IMAGE", "images/inventoryimages/xhl_cl_qp.tex"),
	Asset("ATLAS", "images/inventoryimages/xhl_cl_qp_db.xml"),
	Asset("IMAGE", "images/inventoryimages/xhl_cl_qp_db.tex"),
}

local function ondeploy(inst, pt, deployer)
	if deployer.userid == inst.components.xhl_qp_db.packageuserid and deployer.prefab == 'huli' then
		if deployer.components.huli_petleash.numpets >= deployer.components.huli_petleash.maxpets then
			deployer.components.talker:Say(hl_loc("不能带那么多小狐狸", "You can't take so many pets with you."))
			if deployer and deployer.components.inventory then
				deployer.components.inventory:GiveItem(inst)
			end
			return false
		end
		if inst._info ~= nil then
			local pt = deployer:GetPosition()
			local pet = SpawnSaveRecord(inst._info)
			pet.Transform:SetPosition( pt:Get() ) 
			deployer.components.huli_petleash:LinkPet(pet)
			inst._info = nil
			inst:Remove()
		elseif inst.components.xhl_qp_db.package ~= nil then
			local pt = deployer:GetPosition()
			inst.components.xhl_qp_db:Unpackbulid(pt, deployer)
			inst:Remove()
			if deployer and deployer.components.inventory then
				local xhl_cl_qp =SpawnPrefab("xhl_cl_qp")
				deployer.components.inventory:GiveItem(xhl_cl_qp)
			end
		else
			deployer.components.talker:Say(hl_loc("里面没有小狐狸", "There is no little fox in it"))
			return false
		end
	else
		deployer.components.talker:Say(hl_loc("需要小狐狸的主人", "Owners who need pets."))
		if deployer and deployer.components.inventory then
			deployer.components.inventory:GiveItem(inst)
		end
		return false
	end
end	

local function get_name(inst)
	return #inst._name:value() > 0 and inst._name:value().."水晶球"
end

--[[local function get_name(inst)
	local owner = inst.components.inventoryitem.owner
	local name = STRINGS.NAMES[string.upper(inst.prefab)]
	if owner ~= nil then
		name = owner.name.."的狐狸水晶球"
		return name
	end
end]]

local function onsave(inst,data)
	if inst._info ~=nil then
		data._info = inst._info
	end	
end

local function onload(inst,data)
	if data then
		if data._info ~=nil then
			inst._info = data._info
		end
	end
end
	
local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddSoundEmitter()
	inst.entity:AddLight()
    inst.entity:AddNetwork()

    MakeInventoryPhysics(inst)
	
    inst.AnimState:SetBank("xhl_cl_qp")
    inst.AnimState:SetBuild("xhl_cl_qp")
    inst.AnimState:PlayAnimation("idle")
	inst.Light:Enable(true)
	inst.Light:SetRadius(.5)
    inst.Light:SetFalloff(.7)
    inst.Light:SetIntensity(.5)
    inst.Light:SetColour(238/255, 255/255, 143/255)
	inst.AnimState:SetBloomEffectHandle( "shaders/anim.ksh" )
	
	inst:AddTag("xhl_cl_qp")
	
    inst.entity:SetPristine()

	if not TheWorld.ismastersim  then
		return inst
    end
	
    inst:AddComponent("inspectable")
    inst:AddComponent("z_huli_xhl_qp")
    inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "xhl_cl_qp"	
    inst.components.inventoryitem.atlasname = "images/inventoryimages/xhl_cl_qp.xml"
	
	MakeMediumBurnable(inst)
    MakeMediumPropagator(inst)
    return inst
end

local function qpdbbuildfn()
	local inst = CreateEntity()
    inst.entity:AddTransform()
    inst.entity:AddAnimState()
	inst.entity:AddSoundEmitter()
	inst.entity:AddLight()
    inst.entity:AddNetwork()

	MakeInventoryPhysics(inst)
	
	inst.AnimState:SetBank("xhl_cl_qp_db")
    inst.AnimState:SetBuild("xhl_cl_qp_db")
    inst.AnimState:PlayAnimation("idle")
	inst.Light:Enable(true)
	inst.Light:SetRadius(.5)
    inst.Light:SetFalloff(.7)
    inst.Light:SetIntensity(.5)
    inst.Light:SetColour(238/255, 255/255, 143/255)
	inst.AnimState:SetBloomEffectHandle( "shaders/anim.ksh" )
	
	inst:AddTag("xhl_cl_qp_db_build")	
	inst:AddTag("nonpackable")
	inst._name = net_string(inst.GUID, "xhl_qp_db_build._name")
	inst.displaynamefn = get_name
	inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end
	
	inst:AddComponent("inspectable")

	inst:AddComponent("xhl_qp_db")	
	
	inst:AddComponent("deployable")
	inst.components.deployable.ondeploy = ondeploy
	
	inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "xhl_cl_qp_db"
	inst.components.inventoryitem.atlasname = "images/inventoryimages/xhl_cl_qp_db.xml"

	MakeHauntableLaunchAndSmash(inst)

	MakeMediumBurnable(inst)
    MakeMediumPropagator(inst)
	
	inst._info = nil
	inst.OnSave = onsave
    inst.OnLoad = onload
    return inst
end	

-- STRINGS.NAMES.XHL_CL_QP = "大狐狸的水晶球"
-- STRINGS.RECIPE_DESC.XHL_CL_QP = "把小狐狸装起来\n但不可以吃哦."
-- STRINGS.CHARACTERS.GENERIC.DESCRIBE.XHL_CL_QP = "拿来装小狐狸的."
-- STRINGS.CHARACTERS.GENERIC.DESCRIBE.XHL_CL_QP_DB_BUILD = "小狐狸在里面."

return Prefab("xhl_cl_qp", fn, assets),
		Prefab("xhl_cl_qp_db_build", qpdbbuildfn, assets),
		MakePlacer("xhl_cl_qp_db_build_placer", "xhl_cl_qp_db", "xhl_cl_qp_db", "idle")
