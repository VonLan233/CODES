require "util"
local Screen = require "widgets/screen"
local Widget = require "widgets/widget"
local TextEdit = require "widgets/textedit"

local HuLi_Hud_TextEdit = Class(Screen, function(self, cfg)
	Screen._ctor(self, "HuLi_Hud_TextEdit")
	self.cfg = cfg

	self:DoInit()

end)

function HuLi_Hud_TextEdit:Close()
	if self.cfg.closefn ~= nil then
		self.cfg.closefn()
	end
	TheFrontEnd:PopScreen(self)
end

function HuLi_Hud_TextEdit:OnTextEntered()
	if self.cfg.acceptfn ~= nil then
		self.cfg.acceptfn(self:GetString())
	end
	self:Close()
end

function HuLi_Hud_TextEdit:DoInit()
	self.root = self:AddChild(Widget(""))
	self.root:SetScaleMode(SCALEMODE_PROPORTIONAL)
	self.root:SetHAnchor(ANCHOR_MIDDLE)
	self.root:SetVAnchor(ANCHOR_MIDDLE)

	self.edit_text = self.root:AddChild( TextEdit(self.cfg.font, self.cfg.fontsize, "" ) )
	self.edit_text:SetPosition(self.cfg.pos)
	self.edit_text:SetRegionSize( self.cfg.size[1], self.cfg.size[2] )
	self.edit_text.OnTextEntered = function() self:OnTextEntered() end
	self.edit_text:SetPassControlToScreen(CONTROL_CANCEL, true)
	self.edit_text:SetPassControlToScreen(CONTROL_MENU_MISC_2, true)
	self.edit_text:SetEditing(self.cfg.isediting)
	self.edit_text:SetForceEdit(self.cfg.isediting)

end

function HuLi_Hud_TextEdit:OverrideText(text)
	self.edit_text:SetString(text)
	self.edit_text:SetFocus()
end

function HuLi_Hud_TextEdit:GetString()
	return self.edit_text:GetString()
end

function HuLi_Hud_TextEdit:OnBecomeActive()
	HuLi_Hud_TextEdit._base.OnBecomeActive(self)
	if self.cfg.activefn ~= nil then
		self.cfg.activefn()
	end
	self.edit_text:SetFocus()
	TheFrontEnd:LockFocus(true)
end

function HuLi_Hud_TextEdit:OnBecomeInactive()
	HuLi_Hud_TextEdit._base.OnBecomeInactive(self)
end

function HuLi_Hud_TextEdit:OnRawKey(key, down)
	if HuLi_Hud_TextEdit._base.OnRawKey(self, key, down) then return true end

	if down then return end

	return true
end

function HuLi_Hud_TextEdit:OnControl(control, down)
	if HuLi_Hud_TextEdit._base.OnControl(self, control, down) then return true end

	--jcheng: don't allow debug menu stuff going on right now
	if control == CONTROL_OPEN_DEBUG_CONSOLE then
		return true
	end

	if not down and (control == CONTROL_CANCEL ) then
		self:Close()
		return true
	end
end

return HuLi_Hud_TextEdit
