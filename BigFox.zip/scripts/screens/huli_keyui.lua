local Screen = require "widgets/screen"
local Widget = require "widgets/widget" 
local Text = require "widgets/text" 
local Button = require "widgets/button"
local AnimButton = require "widgets/animbutton"
local ImageButton = require "widgets/imagebutton"
local Image = require "widgets/image"
local TextEdit = require "widgets/textedit" 
local TextButton = require "widgets/textbutton"


local HuLi_KeyUi = Class(Screen, function(self) 

	Screen._ctor(self, 'HuLi_KeyUi') 
	self.fkk = nil
	self.slot = 1
	
	self.textsize = 45
	self.TextFont = SMALLNUMBERFONT
		
	self.root = self:AddChild(Widget("ROOT"))
	self.root:SetVAnchor(ANCHOR_MIDDLE)
	self.root:SetHAnchor(ANCHOR_MIDDLE)
	self.root:SetScaleMode(SCALEMODE_PROPORTIONAL)
	
	self.bg = self.root:AddChild(Image("images/scoreboard.xml","scoreboard_frame.tex"))
	-- self.bg:SetPosition(250, -150, 0) 	
	self.bg:SetSize(500, 400)

	self.CloseButton = self.bg:AddChild(ImageButton("images/global_redux.xml", "close.tex"))
	-- self.CloseButton:SetScale(.7,.7)
	self.CloseButton:SetPosition(0,-120,0)
	-- self.CloseButton:SetTooltip("关闭窗口")
	self.CloseButton:SetOnClick(function() self:Close() end)

	self.bg_text = self.bg:AddChild(Text(BODYTEXTFONT, self.textsize, hl_loc("按下按键更改按键绑定", "Press a key on the keyboard \n to change the binding")))
	-- self.bg_text:SetColour(92/255,255/255,75/255,1)
    self.bg_text:SetPosition(0,50,0) 
		
end)

function HuLi_KeyUi:ShowInFo(slot, key, fa)
	self.fkk = fa
	self.slot = slot
	fa.owner.HUD:OpenScreenUnderPause(self)
	-- self:MoveToFront()
end

function HuLi_KeyUi:AddInFo(key)
	self.fkk:UpdateKey(self.slot, key)
	TheFrontEnd:PopScreen(self)
end

function HuLi_KeyUi:Close()
	TheFrontEnd:PopScreen(self)
end

function HuLi_KeyUi:OnRawKey(key, down)
    if HuLi_KeyUi._base.OnRawKey(self, key, down) then return true end
	if down and key == 27 then self:Close() return end
	if not down then 
		self:AddInFo(key) 
	end
end

return HuLi_KeyUi