local Screen = require "widgets/screen"
local Widget = require "widgets/widget" 
local Text = require "widgets/text" 
local Button = require "widgets/button"
local AnimButton = require "widgets/animbutton"
local ImageButton = require "widgets/imagebutton"
local Image = require "widgets/image"
local TextEdit = require "widgets/textedit" 
local TextButton = require "widgets/textbutton"
local HuLi_Hud_TextEdit = require "screens/huli_hud_textedit"

local function label_hide(player)
	if player.labeltxt == '' then
		if player.labeltxt_edit ~= '' then
			player.labeltxt = player.labeltxt_edit
		end
	else
		player.labeltxt = ''
	end
end
AddModRPCHandler("huli_rpc", 'label_hide', label_hide)

local function label_button(player, label)
	if label == '' then 
		return 
	else
		player.labeltxt = label
		player.labeltxt_edit = label
	end
end
AddModRPCHandler("huli_rpc", 'label_button', label_button)

local HuLi_Label = Class(Screen, function(self, owner) 

	Screen._ctor(self, 'HuLi_Label') 
	self.owner = owner
	self.textsize = 45
	self.str = ''
	self.Text_bg_w = 300
	self.Text_bg_h = 25
	self.ButtonPos_x = -120
	self.ButtonPos_y = -70
	self.TextFont = SMALLNUMBERFONT
	
	self:InitScreen()
	
	self.root = self:AddChild(Widget("ROOT"))
	self.root:SetVAnchor(ANCHOR_MIDDLE)
	self.root:SetHAnchor(ANCHOR_MIDDLE)
	self.root:SetScaleMode(SCALEMODE_PROPORTIONAL)

	self.bg = self.root:AddChild(Image("images/scoreboard.xml","scoreboard_frame.tex"))
	self.bg:SetPosition(0, -160, 0) 	
	self.bg:SetSize(400, 230)
	-- self.bg:Hide()

	self.CloseButton = self.bg:AddChild(ImageButton("images/global_redux.xml", "close.tex"))
	self.CloseButton:SetScale(.7,.7)
	self.CloseButton:SetPosition(160,75,0)
	self.CloseButton:SetOnClick(function() self:Close() end)

	self.bg_text = self.bg:AddChild(Text(BODYTEXTFONT, self.textsize, "头衔控制器"))
	self.bg_text:SetColour(92/255,255/255,75/255,1)
    self.bg_text:SetPosition(0,70,0) 
		
	self.edit_text_copy = self.bg:AddChild(Text(self.TextFont, self.Text_bg_h))
	self.edit_text_copy:SetColour(229/255, 204/255, 153/255,1)
    self.edit_text_copy:SetPosition(0, 0 ,0) 
	self.edit_text_copy:SetHAlign(ANCHOR_LEFT)
		
	self.edit_text_bg = self.bg:AddChild( Image() )
    self.edit_text_bg:SetTexture( "images/textboxes.xml", "textbox2_grey.tex" )
    self.edit_text_bg:SetPosition(0, 0, 0 )
    self.edit_text_bg:ScaleToSize( 325, self.Text_bg_h*5 )
	
	self.edit_bg_text = self.bg:AddChild(TextButton())
	self.edit_bg_text:SetText('在此处输入自定义头衔')
	self.edit_bg_text:SetTextSize(44)
	-- self.edit_bg_text:SetColour(92/255,255/255,75/255,1)
	-- self.edit_bg_text:SetOverColour(252/255, 231/255, 28/255, 1)
    self.edit_bg_text:SetPosition(0, 0, 0)
	self.edit_bg_text:SetOnClick(function() self:EditTextScreen() end)

	self.label_button = self.bg:AddChild(TextButton())
	self.label_button:SetText('确定')
	-- self.label_button:SetTooltip('')
	self.label_button:SetColour(92/255,255/255,75/255,1)
	self.label_button:SetOverColour(252/255, 231/255, 28/255, 1)
    self.label_button:SetPosition(135, self.ButtonPos_y, 0)	
	self.label_button:SetOnClick(function()
		if TheWorld.ismastersim then
			label_button(self.owner, self.edit_text_copy:GetString())
		else
			SendModRPCToServer(MOD_RPC['huli_rpc']['label_button'], self.edit_text_copy:GetString())
		end
	end)	
	
	self.label_cls = self.bg:AddChild(TextButton())
	self.label_cls:SetText('清空')
	-- self.label_cls:SetTooltip('清空输入框')
	self.label_cls:SetColour(92/255,255/255,75/255,1)
	self.label_cls:SetOverColour(252/255, 231/255, 28/255, 1)
    self.label_cls:SetPosition(80, self.ButtonPos_y, 0)	
	self.label_cls:SetOnClick(function() self.str = '' self:TipScreen() end)

	self.label_default = self.bg:AddChild(TextButton())
	self.label_default:SetText('默认')
	-- self.label_default:SetTooltip('恢复默认头衔')
	self.label_default:SetColour(92/255,255/255,75/255,1)
	self.label_default:SetOverColour(252/255, 231/255, 28/255, 1)
    self.label_default:SetPosition(25, self.ButtonPos_y, 0)	
	self.label_default:SetOnClick(function() self.str = '★萌萌哒的狐狸★' self:TipScreen() end)

	self.label_before_one = self.bg:AddChild(TextButton())
	self.label_before_one:SetText('当前')
	-- self.label_before_one:SetTooltip('载入当前显示的头衔到输入框')
	self.label_before_one:SetColour(92/255,255/255,75/255,1)
	self.label_before_one:SetOverColour(252/255, 231/255, 28/255, 1)
    self.label_before_one:SetPosition(-30, self.ButtonPos_y, 0)	
	self.label_before_one:SetOnClick(function() self.str = self.owner._labeltxt:value() self:TipScreen() end)

-----------头衔开关
	self.label_hide = self.bg:AddChild(TextButton())
	self.label_hide:SetColour(92/255,255/255,75/255,1)
	self.label_hide:SetOverColour(252/255, 231/255, 28/255, 1)
    self.label_hide:SetPosition(-120, self.ButtonPos_y, 0)
    -- self.label_hide:SetTooltip('点击显示/隐藏头衔')
	self.label_hide:SetOnClick(function()
		if TheWorld.ismastersim then
			label_hide(self.owner)
		else
			SendModRPCToServer(MOD_RPC['huli_rpc']['label_hide'])
		end
	end)
	self:TipScreen()
	self:StartUpdating()
end)

function HuLi_Label:EditTextScreen()
	self.edit_text = HuLi_Hud_TextEdit(self.EditBgTextScreenConfig)
	self.owner.HUD:OpenScreenUnderPause(self.edit_text)
	if TheFrontEnd:GetActiveScreen() == self.edit_text then
		self.edit_text.edit_text:SetFocusedImage( self.edit_text_bg, "images/textboxes.xml", 	"textbox2_grey.tex", "textbox2_gold.tex", "textbox2_gold_greyfill.tex" )
		self.edit_text.edit_text:SetHAlign(ANCHOR_LEFT)
		self.edit_text.edit_text:SetIdleTextColour(229/255, 204/255, 153/255,1)
		self.edit_text.edit_text:SetEditTextColour(1,1,1,1)
		self.edit_text.edit_text:SetEditCursorColour(1,1,1,1)
		self.edit_text.edit_text:SetTextLengthLimit(self.Text_bg_w)
		self.edit_text.edit_text:EnableWordWrap(true)
		self.edit_text.edit_text:EnableRegionSizeLimit(true)
		self.edit_text.edit_text:EnableScrollEditWindow(false)
		self.edit_text.edit_text:SetString(self.str)
	end
end

function HuLi_Label:TipScreen()
	if self.str ~= '' then
		-- self.edit_text_copy:SetString(self.str) 
		self.edit_text_copy:SetMultilineTruncatedString(self.str, 4, self.Text_bg_w)
		self.edit_bg_text:SetColour(229/255,204/255,153/255,0)
		self.edit_bg_text:SetOverColour(229/255, 204/255, 153/255,0)
		local edit_text_copy_w, edit_text_copy_h = self.edit_text_copy:GetRegionSize()
		if edit_text_copy_w > self.Text_bg_w then
			self.edit_text_copy:SetRegionSize( self.Text_bg_w, edit_text_copy_h)
			self.edit_text_copy:SetPosition(0, 0, 0)
		else
			self.edit_text_copy:SetPosition(edit_text_copy_w * .5 - self.Text_bg_w * .5, 0, 0)
		end
	else
		self.edit_text_copy:SetString('') 
		self.edit_bg_text:SetColour(229/255, 204/255, 153/255,1)
		self.edit_bg_text:SetOverColour(229/255, 204/255, 153/255,1)
	end
end
		
function HuLi_Label:InitScreen()
	local function EditBgTextActive()
		self.edit_bg_text:Hide()
		self.edit_text_copy:Hide()
	end
	local function EditBgTextAccept(str)
		if str then
			self.str = str
			self:TipScreen()
		end
	end

	local function EditBgTextClose()
		self.edit_bg_text:Show()
		self.edit_text_copy:Show()
	end

	self.EditBgTextScreenConfig = {
		font = self.TextFont,
		fontsize = self.Text_bg_h,
		size = {self.Text_bg_w, self.Text_bg_h*3},
		isediting = true,
		pos = Vector3(0, -160, 0),
		acceptfn = EditBgTextAccept,
		closefn = EditBgTextClose,
		activefn = EditBgTextActive,
	}
end

function HuLi_Label:Close()
	-- TheInput:EnableDebugToggle(true)
	TheFrontEnd:PopScreen(self)
end

function HuLi_Label:OnControl(control, down)
	if HuLi_Label._base.OnControl(self, control, down) then return true end

	--jcheng: don't allow debug menu stuff going on right now
	if control == CONTROL_OPEN_DEBUG_CONSOLE then
		return true
	end

	if not down and (control == CONTROL_CANCEL ) then
		self:Close()
		return true
	end
end

function HuLi_Label:OnRawKey(key, down)
    -- if self.runtask ~= nil then return true end
    if HuLi_Label._base.OnRawKey(self, key, down) then
        return true 
    end
	if down then return end

    return true
end

function HuLi_Label:OnUpdate(dt)

	if self.owner._labeltxt:value() == '' then
		self.label_hide:SetText(hl_loc('显示头衔', 'Display title')) 
	else
		self.label_hide:SetText(hl_loc('隐藏头衔', 'Hidden titles'))
	end
	
end

return HuLi_Label