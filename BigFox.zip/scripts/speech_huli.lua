return {
	ACTIONFAIL_GENERIC = { "我现在不能做任何事.", "我不能这样做.", "阿狸 不能做到这一点", },
	
	ANNOUNCE_SHOW_COLLECT_SOULHEART = "收集魂心",
	ANNOUNCE_ALL_SOUL = "收集所有魂心",
	
	ANNOUNCE_SAN_UP = "阿狸正在恢复力量!",
	ANNOUNCE_SAN_DOWN = "阿狸正在失去力量...",
	
	ANNOUNCE_SAN_GO_EVIL = "不要碰我...",
	ANNOUNCE_SAN_NO_EVIL = "你愿意和我一起玩吗?",
	
	ANNOUNCE_PRIORITY_FOLLOW = "宠物指令\n-跟随优先-",
	ANNOUNCE_PRIORITY_FIGHT = "宠物指令\n-战斗优先-",
	
	ANNOUNCE_CAN_PARTY = "真是惊喜!\n我准备好开始新的 烟火盛宴 了!",
	ANNOUNCE_END_PARTY = "阿狸的 烟火盛宴 被取消了...",
	ANNOUNCE_NO1_PARTY = "别, 我还需要 50 精神值...",
	ANNOUNCE_NO2_PARTY = "或许... 当我收集满 100 个魂心的时候,\n我会开始 烟火盛宴!",
	ANNOUNCE_NO_TIME_PARTY = "到下一次 烟火盛宴 还有... ",
	ANNOUNCE_NO_TIME_PARTY2 = " 秒!",
	
	ANNOUNCE_MILLENNIUMFOXSTAYFOLLOW = "我亲爱的朋友,\n你必须在这里等待!",
	ANNOUNCE_MILLENNIUMFOXSTAYFOLLOW_CANCEL = "来吧, 哥们!\n过来跟着我!",
	ANNOUNCE_MILLENNIUMFOXSTAYFOLLOW_NO_MOVE = "好了, 你为什么不听我的话...\n你怎么累了?",
	
	ANNOUNCE_ADVENTUREFAIL = "我做了一个噩梦...",
	ANNOUNCE_BOOMERANG = 
	{
		"哎呦! 好痛啊!",
		"抱歉, 这只是一个... 错误!",
		"你已经能够...",
	},
	ANNOUNCE_LIGHTNING = "轰-隆!!\n闪电差点吓到我了!",
	ANNOUNCE_CHARLIE = "里面有人吗?",
	ANNOUNCE_CHARLIE_ATTACK = "嘿, 请你别这么无礼!",
	ANNOUNCE_COLD = "快抱抱我\n我的心好冷.",
	ANNOUNCE_HOT = "好热啊,我想上凉快的地方吹吹风!",
	ANNOUNCE_CRAFTING_FAIL = "我缺乏必要的材料.",
	ANNOUNCE_DUSK = "我妈妈总是告诉我\n太阳落山了要回家...",
	ANNOUNCE_EAT =
	{
		GENERIC = "啊呣啊呣啊呣!",
		PAINFUL = "这个不能吃哦.",
		SPOILED = "食物快腐烂了.",
		STALE = "是陈旧的吗?",
		INVALID = "不可以这么做.",
	},
	ANNOUNCE_ENTER_DARK =
	{
		"晚上你不会离开我, 对吧?",
		"大概, 阿狸被独自留在黑暗之中了...",
		"哥哥，这里是哪里?\n我好害怕!",
	},
	ANNOUNCE_ENTER_LIGHT =
	{
		"这儿有光!",
		"你回来了吗?",
		"我从黑暗里回来了.",
	},
	ANNOUNCE_HOUNDS = "嘘! 二货狗狗又要来送牙牙了.",
	ANNOUNCE_HUNGRY =
	{
		"我要吃饭饭!",
		"我想吃中国料理!",
		"是时候来点点心了.",
		"我的肚子正在抗议!",
		"阿狸饿了.",
	},
	ANNOUNCE_HUNT_BEAST_NEARBY = "我的朋友在那里!",
	ANNOUNCE_HUNT_LOST_TRAIL = "我在这里. 一次又一次...",
	ANNOUNCE_HUNT_LOST_TRAIL_SPRING = "我在这里. 一次又一次...",
	ANNOUNCE_INV_FULL = { "我拿不下了!", "我放不下更多的东西了!", },
	ANNOUNCE_KNOCKEDOUT = "狐狸是什么?",
	ANNOUNCE_NOHUNGERSLEEP = "我不想睡觉啊, 我的肚肚在抗议.",
	ANNOUNCE_PECKED = "你在考验我的耐心.",
	ANNOUNCE_QUAKE = "看看地面震动! 地球在跳舞!",
	ANNOUNCE_THORNS =
	{
		"嗷! 荆棘, 好痛!",
		"真的好痛!",
	},
	ANNOUNCE_TORCH_OUT =
	{
		"天黑了!",
		"火灭了...",
	},
	ANNOUNCE_TRAP_WENT_OFF = "哦, 危险.",
	ANNOUNCE_WORMHOLE = "这是一个奇怪的冒险!",
	ANNOUNCE_CANFIX = "那个\n我认为我可以修好它!",
	ANNOUNCE_ACCOMPLISHMENT = "所有这一切是短暂的.",
	ANNOUNCE_ACCOMPLISHMENT_DONE = "有一天,终究会被遗忘.",
	ANNOUNCE_INSUFFICIENTFERTILIZER = "我感觉它有更多用途!",
	ANNOUNCE_LIGHTNING_DAMAGE_AVOIDED = "我感觉快见到阎王了.",
	ANNOUNCE_BEES = "蜜蜂嗡嗡嗡!! 快跑!! 快跑!!!!",
	ANNOUNCE_DEERCLOPS = "我想来了一位不请自来的客人!",
	ANNOUNCE_FREEDOM = "阿狸获得了自由!",
	ANNOUNCE_MOSQUITOS = "可恶的蚊子! 它会吸我血!",
	ANNOUNCE_NODANGERSLEEP = "你知道胖丁的歌声吗? \n它会让你陷入沉睡...",--
	ANNOUNCE_NODAYSLEEP = "太阳使我心烦意乱. 我不想睡觉.",
	ANNOUNCE_NODAYSLEEP_CAVE = "我还不困.",
	ANNOUNCE_NOSLEEPONFIRE = "还有很长的路要走.",
	ANNOUNCE_NODANGERSIESTA = "你知道胖丁的歌声吗? \n它会让你陷入沉睡...",--
	ANNOUNCE_NONIGHTSIESTA = "我真的很想在帐篷里睡觉.",
	ANNOUNCE_NONIGHTSIESTA_CAVE = "我真的很想在帐篷里睡觉.",
	ANNOUNCE_NOHUNGERSIESTA = "我的肚子快饿疯了, 我现在不能打盹.",
	ANNOUNCE_SHELTER = "大自然总是有意的.",
	ANNOUNCE_BURNT = "噢! 地狱之火!",
	ANNOUNCE_TOOL_SLIP = "哎呀, 我已经不需要了.",
	ANNOUNCE_DAMP = "我的怒火被雨淋湿了...",--
	ANNOUNCE_WET = "或许这些水会流经我的心中.",
	ANNOUNCE_WETTER = "我要变成水鸭子啦.",
	ANNOUNCE_SOAKED = "水的启示.",
	BATTLECRY =
	{
		GENERIC = "来啊,\n让我咬一口.",--
		PIGMAN = "小猪猪,缴蹄不杀!",--
		PREY = "我要逮到你!",--
		SPIDER = "别动!变成肉丸滚过来!",--
		SPIDER_WARRIOR = "别动! 变成肉丸自己滚过来!",--
		HOUND = "我要拔了你的狗牙! 小狗狗!",--
		FIREHOUND = "嘿!小火狗,你来咬我呀!",
		ICEHOUND = "嘿!小白狗来玩打雪仗吗!",
		WARG = "可怕的巨狼来了!打!打!",--
	},
	COMBAT_QUIT =
	{
		GENERIC = "你现在要活下去.",
	},
	DESCRIBE =
	{

		UNKNOWNLETTERTOWHARANG =
		{
			"他总是这样.",
			"给我的一封信.",
			"这是什么意思?",
		},
	
		GLOMMER =
		{
			"一个健谈的小东西!",
			"啊呜! 小小的翅膀.",
		},
        GLOMMERFLOWER = 
        {
        	GENERIC = "夜来香.",
        	DEAD = "即使是花在夜晚也会死去.",
        },
        GLOMMERWINGS = "噢, 可怜的小东西.\n你是怎样在这样恶劣的条件下活下来的?",--
        GLOMMERFUEL = "我没有见过它,我不知道那是什么.",--
        BELL = "我离开后,你会记得我吗?",--
        STATUEGLOMMER = 
        {	
        	GENERIC = "我可以百分之百的肯定,这雕像是活的!",
        	EMPTY = "也许... 我杀了它...",
    	},
		WEBBERSKULL = "噢, 你这个可怜的小东西. 让我送你一朵花.",--
		MOLE =
		{
			HELD = "可以打地鼠吗?!",--
			UNDERGROUND = "呆在那里, 离开这个可怕的地方.",
			ABOVEGROUND = "你应该回到黑暗.",
		},
		MOLEHILL = "来啊, 来啊, 到地上来.",
		MOLEHAT = "这就是地鼠所看的.",
		NIGHTSTICK =
		{
			"晴天霹雳!",
			"哇哦, 电击!",
		},
		RABBITHOUSE=
		{
			GENERIC = "这并不像看起来那么实用.",
			BURNT = "它没有煮好.",
		},
		TURF_DECIDUOUS = "漂亮的地皮.",
		TURF_SANDY = "一些地皮.",
		TURF_BADLANDS = "一些地皮.",
		BEARGER =
		{
			"哇呀呀呀! 这是吃货熊拆迁 快跑!",
			"别啊! 别破坏大自然!",
		},
		BEARGERVEST = "耶! 这会让我看起来很蓬松!",--
		ICEPACK = "他不会让感到世界的恐怖.",
		BEARGER_FUR =
		{
			"这是发一个巨大的熊皮!",
			"我爱皮草! 这让我想起 papa..."
		},
		BIGFOOT = "哦, 你是个很好的朋友. 如果你离我远点的话.",--
		BONESHARD = "犀利尖锐的骨头.",
		BUZZARD =
		{
			"丑秃鹫!",
			"它们爱吃腐烂的肉.",
		},
		CACTUS = 
		{
			GENERIC = "当心刺!",
			PICKED = "烤烤更好吃...",
		},
		CACTUS_MEAT_COOKED = "我来切开.",
		CACTUS_MEAT = "仙人掌肉!它仍然很危险.",
		CACTUS_FLOWER = "如果我们能从这朵花中看到奇迹,\n我们的生活将会改变.",--
		COLDFIRE =
		{
			EMBERS = "黑暗中若隐若现.",
			GENERIC = "我也许这个夜晚生存!",
			HIGH = "冰火烧的太旺了!",
			LOW = "火焰弱了.",
			NORMAL = "这是一个奇怪的火.",
			OUT = "这不是一个好兆头.",
		},
		CATCOON =
		{
			"它是自由的.",
			"喵呜呜呜呜! 可爱的猫咪!",
		},
		CATCOONDEN = 
		{
			GENERIC = "我爸爸常说，猫有九条命.",
			EMPTY = "所有的猫猫都走了. 它是空的.",
		},
		CATCOONHAT = "嗨!你看! 我像一只狸猫!",--
		COONTAIL = "这是乱蓬蓬的.",
		COOKPOT =
		{
			COOKING_LONG = "无论现在是在哪里\n至少我还没有死.",
			COOKING_SHORT = "需要油.",
			DONE = "完成, 食物.",
			EMPTY = "跟我没有灵魂一样.",
			BURNT = "烧焦了.",
		},
		EYEBRELLAHAT = "现在你不能流泪.",--
		ARMORDRAGONFLY = "我想里外反穿.",
		DRAGON_SCALES = "剧烈的疼痛.",
		DRAGONFLYCHEST = "箱子.",
		DECIDUOUSTREE = 
		{
			BURNING = "它明亮地燃烧.",
			BURNT = "用完了.",
			CHOPPED = "一切都死了.",
			GENERIC = "这棵橡树真漂亮. 我最爱吃烤熟的橡果啦.",
			POISON = "真奇特!",
		},
		ACORN_COOKED = "咦? 这是松鼠的食物.",
		BIRCHNUTDRAKE = "他们不是我的朋友! 但是, 太可爱了!",
		FARMPLOT =
		{
			GENERIC = "我要播下什么种子?",
			GROWING = "绿叶从新泥中出来了.",
			NEEDSFERTILIZER = "这个星球很荒凉.",
			BURNT = "我是在饥荒的世界里吗.",
		},
		COLDFIREPIT =
		{
			EMBERS = "黑暗中若隐若现.",
			GENERIC = "我会在夜晚幸存的!",
			HIGH = "像地狱火一样耀眼!",
			LOW = "火焰弱了.",
			NORMAL = "这是一个奇怪的火焰.",
			OUT = "这不是个好的信号.",
		},
		FIRESUPPRESSOR = 
		{	
			ON = "夏天会下冰雹吗?",--
			OFF = "它好冰冷.",
			LOWFUEL = "它在烟雾上跑.",
		},
		ICEHAT = "我不想戴上它. 它会冻坏我的脑袋!",--
		LIGHTNINGGOAT = 
		{
			GENERIC = "如果他们都会被闪电击中是会发生什么?",--
			CHARGED = "哇!电灯耶!",
		},
		LIGHTNINGGOATHORN = "一些静电.",
		GOATMILK = "我希望我更高! 这会让我更强大?",--
		MEATRACK =
		{
			DONE = "干燥结束.",
			DRYING = "我等不及了!",--
			DRYINGINRAIN = "下雨要保持干燥.",
			GENERIC = "我可以把肉晾在这里.",
			BURNT = "它永远的晾干了.",
		},
		MERMHEAD = 
		{
			GENERIC = "哈哈, 看看这张傻脸!",--
			BURNT = "有时候, 它看起来脸向下拉得厉害.",
		},
		MERMHOUSE = 
		{
			GENERIC = "我不能进去.",--
			BURNT = "火焰更大了.",
		},
		FLOWERSALAD = "这是什么? 不是肉吗?",
        ICECREAM =
		{
			"我喜欢吃冰淇淋!",
			"这冰淇淋真是爽.",
		},
        WATERMELONICLE = "这瓜好甜.",
        TRAILMIX = "这些食物太少了.",
        HOTCHILI = "这是什么? 你想看我热的嘴冒火吗?",--
        GUACAMOLE = "阴森. 我喜欢.",
		MOOSE = "这是我见过的最大的鸭子,它是个万年酱油党.",
		MOOSEEGG = "我喜欢这个蛋.",--
		MOSSLING = "哇, 你这可爱的小鸭子!",
		FEATHERFAN = "哇哦, 这是我见过最大的羽毛!",--
		GOOSE_FEATHER = "哈哈哈! 停住! 好痒!",--
		STAFF_TORNADO = "嘘. 我可以感到强烈的风暴即将来临!",--
		PIGHEAD = 
		{	
			GENERIC = "你知道中国习俗吗, 人们过年用猪头供奉神仙?",--
			BURNT = "它被烧毁了.",
		},
		PIGHOUSE =
		{
			FULL = "我打赌里面很暖和...",--
			GENERIC = "这真是个糟糕的房子!",--
			LIGHTSOUT = "现在就我一个人了.",
			BURNT = "万物皆会消失没有永恒.",
		},
		FERTILIZER = "一桶污垢.",
		RAINOMETER = 
		{	
			GENERIC = "我希望明天阳光灿烂! 因为 我会玩一整天!",--
			BURNT = "那意味着明天没有太阳, 是吗?",
		},
		RAINCOAT = "我想跳进水坑里!",--
		RAINHAT = "如果下雨淋湿的话,那一定很有趣?",
		RESEARCHLAB = 
		{	
			GENERIC = "我想我可以做一些很酷的事.",--
			BURNT = "烧的一塌糊涂.",
		},
		RESEARCHLAB2 = 
		{
			GENERIC = "我要做些另人吃惊的事.",--
			BURNT = "烧得一塌糊涂.",
		},
		RESEARCHLAB3 = 
		{
			GENERIC = "皮影戏吗!好看吗?",--
			BURNT = "烧得一塌糊涂.",
		},
		RESEARCHLAB4 = 
		{
			GENERIC = "什么!? 新玩具!? 在哪儿呢!?",--
			BURNT = "玩火自焚.",
		},
		RESURRECTIONSTATUE = 
		{
			GENERIC = "我想我们有时候需要两次机会.",--
			BURNT = "自动防护装置不见了我很开心.",
		},
		ROCK_ICE = 
		{
			GENERIC = "嘿, 这里好冷.",--
			MELTED = "结冰了.",
		},
		ROCK_ICE_MELTED = "结冰了.",
		ICE = "旺旺碎碎冰.",
        REFLECTIVEVEST = "完美背心.",
		HAWAIIANSHIRT = "什么时候去野营?",--
		TENT = 
		{
			GENERIC = "这能让我舒服的睡一个晚上.",
			BURNT = "地狱之火将会开始燃烧.",
		},
		SIESTAHUT = 
		{
			GENERIC = "这能让我有一个舒服的睡一个午觉.",
			BURNT = "地狱之火将会开始燃烧.",
		},
		TRANSISTOR = "电器是什么?",
		TREASURECHEST = 
		{
			GENERIC = "为了我的财富.",
			BURNT = "他不能是灰烬.",
		},
		TUMBLEWEED = "过来, 风滚草! 我需要你!",--
		GRASS_UMBRELLA = "看我的新雨伞! 它漂亮吧.",--
		UNIMPLEMENTED = "它不完整, 如生活一样.",
		WALL_HAY = 
		{	
			GENERIC = "这只是防御的建议.",
			BURNT = "挡下来.",
		},
		WALL_WOOD = 
		{
			GENERIC = "事不宜迟.",
			BURNT = "它一定会来的.",
		},
		WARG = "噢, 别别别. 我一定要和狗狗做朋友.",--
		WATERMELON = "它大部分是水. 有什么大不了的?",
		WATERMELON_COOKED = "现在是温水.",
		WATERMELONHAT = "那个, 我妈妈告诉我不要和食物玩耍.",--
		WINTEROMETER = 
		{
			GENERIC = "为什么这是衡量我的死亡率?",
			BURNT = "这意味着我终有一天会死亡在这里?",
		},
		HOMESIGN = 
		{
			GENERIC = "它说什么? 你明天会死的. 开玩笑啦.",--
			BURNT = "的确瞬息万变.",
		},
		BEEBOX =
		{
			GENERIC = "蜜蜂很勤劳,它们会把蜂蜜放在里面.",
			READY = "它们艰苦的工作已经取得丰硕的成果!",
			FULLHONEY = "他们的辛劳取得了成果!",
			NOHONEY = "去采蜜, 小蜜蜂!",
			SOMEHONEY = "采蜜中.",
			BURNT = "焦蜜.",
		},
		LIVINGTREE = "这棵树好可怕,我好像在万圣节看到过?",
		ICESTAFF = "我讨厌寒冷!",--
		WORMLIGHT = "我是唯一一个可以在晚上发光的狐狸!",--
		WORM =
		{
		    PLANT = "看来是世外桃源.",
		    DIRT = "有什么东西在这里?",
		    WORM = "他们来自黑暗.",
		},
		EEL = "那令人恶心的东西是什么?",--
		EEL_COOKED = "嗯 脆皮!",--
		UNAGI = "嗯. 我叫它寿司吧!",--
		EYETURRET = "你究竟在看什么?",--
		EYETURRET_ITEM = "嘿,你好 小家伙!",--
		MINOTAURHORN = "一个曾经伟大的野兽的遗骸.",
		MINOTAURCHEST = "这是黄金和钻石的气味!",--
		THULECITE_PIECES = "一种强力材料的碎片.",
		POND_ALGAE = "一些藻类.",
		GREENSTAFF = "我能看到内在的力量.",
		POTTEDFERN = "噢, 可爱的小东西! 你看起来需要一个永远的家.",--

		THULECITE = "我能感受到强烈的神秘力量在里头.",--
		ARMORRUINS = "没有人能敢碰我!",--
		RUINS_BAT = "这个神奇的蝙蝠会带给我一个朋友.",--
		RUINSHAT = "白马王子在哪?",--
		NIGHTMARE_TIMEPIECE = --Keeps track of the nightmare cycle
		{
			CALM = "我不知道什么潜伏在阴影中.",	--calm phase
			WARN = "我能感觉到窥视的眼睛.",	--Before nightmare
			WAXING = "它们接近了.", --Nightmare Phase first 33%
			STEADY = "它们把我包围了!", --Nightmare 33% - 66%
			WANING = "我认为它们离开了.", --Nightmare 66% +
			DAWN = "都结束了.", --After nightmare
			NOMAGIC = "我很孤独.", --Place with no nightmare cycle.
		},
		BISHOP_NIGHTMARE = "这场战争时间赢了.",
		ROOK_NIGHTMARE = "岁月是把杀猪刀.",
		KNIGHT_NIGHTMARE = "又一次败给时间.",
		MINOTAUR = "为什么你这么小气? 我们是朋友吗?",-- --Monster in labyrinth
		SPIDER_DROPPER = "鬼鬼祟祟的小东西! 你在偷窥什么!",-- --White spider that comes from the roof
		NIGHTMARELIGHT = "我不想做恶梦.",-- --Lights that activate during nightmare.
		RELIC = "都已是明日黄花.",	--Fixed relic
		RUINS_RUBBLE = "都已是明日黄花.",	--Broken relic
		MULTITOOL_AXE_PICKAXE = "这个东西有多种用途.",	--Works as axe and pickaxe
		GREENGEM = "这花美过头了.",
		ORANGESTAFF = "好吧, 可是我不懒惰.",-- --Teleports player.
		YELLOWAMULET = "现在黑暗也能离我远点了!",-- --Emits light, player walks faster.
		GREENAMULET = "闪光的辉煌!",	--Reduce cost of crafting

		SLURPER = "它看起来像我70岁玩过的玩具.",--
		SLURPER_PELT = "嗯, 是这种头发吗?",--
		ARMORSLURPER = "不. 我不胖. 至少现在不是.",--
		ORANGEAMULET = "真好!它能帮我自动收集附近东西.",
		YELLOWSTAFF = "这根棍子想我的灵魂一样扭曲.",
		YELLOWGEM = "神秘的宝石镶嵌在古城遗址.",
		ORANGEGEM = "这个让我感到很开心.",
		TELEBASE = 
		{
			VALID = "有能量在流动.",
			GEMS = "死气沉沉.",
		},
		GEMSOCKET = 
		{
			VALID = "它镶满了宝石.",
			GEMS = "你看它像什么.",
		},
		STAFFLIGHT = "星星点灯, 照亮我的家门\n让迷失的孩子找到来时的路.",--

        ANCIENT_ALTAR = "它身边充满死亡的气息.",
        ANCIENT_ALTAR_BROKEN = "我听到死亡的喘息了.",
        ANCIENT_STATUE = "呵, 这东西应该是可怕的?",--

        LICHEN = "怎样能让它快速成长?",
		CUTLICHEN = "转瞬即逝, 就像生活一样.",
		CAVE_BANANA = "猴子最爱这个.",
		CAVE_BANANA_COOKED = "熟香蕉真美味\n都止不住我的口水了.",
		CAVE_BANANA_TREE = "可怜的植物, 不愿享受阳光.",
		ROCKY = "吖, 可怜的岩石. 你会永远的记住.",

		BLUEAMULET = "这个会冰冻我的心吗?",--
		PURPLEAMULET = "他的精神困扰着我!",--
		TELESTAFF = "呀! 现在我可以玩一整个晚上了!",--
		MONKEY =
		{
			"哼, 愚蠢的猴子!",
			"洞穴猴子实在太可恶了! 我讨厌它们!",
		},
		MONKEYBARREL = "这是猴子们的家.",
		MONSTERLASAGNA = "垃圾食品有害健康.",--
		HOUNDSTOOTH="哦!我的小狐狸! 这些牙齿! 它们是我的一部分!",--
		ARMORSNURTLESHELL="看! 我有一个移动的家.",--
		BAT=
		{
			"它们傍晚醒来.",
			"不要碰它们! 我不想打...",
			"它们的祖先和我是朋友!",
		},
		BATBAT = "蝙蝠很强,但是没啥影响.",--
		BATWING="我希望我可以飞.",--
		BATWING_COOKED="哈哈! 这看起来就像我的回旋镖.",--
		BEDROLL_FURRY="毛茸茸的真好看\n它让我想起兔子哥哥.",
		BUNNYMAN="兔哥哥最讨厌肉了.",--
		FLOWER_CAVE="这个看起来很脆.",
		FLOWER_CAVE_DOUBLE="它看起来真脆.",
		FLOWER_CAVE_TRIPLE="它看起来真脆.",
		GUANO="可以用它浇灌我的植物.",
		LANTERN="照亮黑暗的路.",
		LIGHTBULB="有了它,我不在害怕黑暗了.",--
		MANRABBIT_TAIL="它包含了糊里糊涂的本质.",
		MUSHTREE_TALL  ="它会发光呢.",
		MUSHTREE_MEDIUM="它看起来像小精灵的房子.",
		MUSHTREE_SMALL ="有些小矮人生活在这里?",
		SLURTLE="这是盲目追求的岩石.",
		SLURTLE_SHELLPIECES="破碎的梦想碎片.",
		SLURTLEHAT="我怀疑它会帮助我,就像帮助它原来的主人一样.",
		SLURTLEHOLE="当它们长大了就会被抛弃.",
		SLURTLESLIME="它眼里闪烁着期待.",
		SNURTLE="那一个有巨大的壳.",
		SPIDER_HIDER="一只懦弱的蜘蛛.",
		SPIDER_SPITTER="它在咀嚼什么.",
		SPIDERHOLE="这里有怪物出没.",
		STALAGMITE="大地放弃了它的恩惠.",
		STALAGMITE_FULL="大地放弃了它的恩惠.",
		STALAGMITE_LOW="大地放弃了它的恩惠.",
		STALAGMITE_MED="大地放弃了它的恩惠.",
		STALAGMITE_TALL="地球在翻转.",
		STALAGMITE_TALL_FULL="地球在翻转.",
		STALAGMITE_TALL_LOW="地球在翻转.",
		STALAGMITE_TALL_MED="地球在翻转.",

		TURF_CARPETFLOOR = "地毯地板.",
		TURF_CHECKERFLOOR = "方格地板.",
		TURF_DIRT = "污垢地皮.",
		TURF_FOREST = "森林草皮.",
		TURF_GRASS = "长草草皮.",
		TURF_MARSH = "沼泽地皮.",
		TURF_ROAD = "有速度加成.",
		TURF_ROCKY = "岩石地皮.",
		TURF_SAVANNA = "热带草原草皮.",
		TURF_WOODFLOOR = "木质地板.",

		TURF_CAVE="祥云地皮.",
		TURF_FUNGUS="真菌地.",
		TURF_SINKHOLE="天坑地.",
		TURF_UNDERROCK="一些地皮.",
		TURF_MUD="浑浑......某处触角!",

		POWCAKE =
		{
			"嘿嘿嘿! 这不是食物!",
			"会死的...",
		},
		CAVE_ENTRANCE = 
		{
			GENERIC="这扇门之外还有另外一个世界.",--
			OPEN = "这是一扇通往永恒之夜的门.",--
		},
        CAVE_EXIT = "嘿,小朋友!你能把我带上来吗?",--
		BOOMERANG = "死亡会通向地狱.",
		MAXWELLPHONOGRAPH = "我们可以跳一支死亡之舞吗?",
		ABIGAIL = "这是双胞胎妹妹, 阿比盖尔.",
		PIGGUARD = "无聊的小猪...",--
		ADVENTURE_PORTAL = "嗅嗅. 我闻到了一个新的冒险!",--
		AMULET = "这将保护我远离死亡和危险.",--
		ANIMAL_TRACK = "有人在这里...",--
		ARMORGRASS = "我有拖延症.",
		ARMORMARBLE = "不要刺伤我的心.",
		ARMORWOOD = "我要抓住这不可避免的一点.",
		ARMOR_SANITY = "一个非常安全的方式去疯狂.",
		ASH =
		{
			GENERIC = "所有这一切都留下了另一个美丽的火灾.",
			REMAINS_GLOMMERFLOWER = "当我传送时,花朵会化为粉末!",
			REMAINS_EYE_BONE = "当我传送时,眼骨会化为粉末!",
			REMAINS_THINGIE = "这是之前烧过的...",
		},
		AXE = "工作和谋杀的工具.",
		BABYBEEFALO = "成长是艰难的世界是粗糙的.",--
		BACKPACK = "耶, 野餐时间!",--
		BACONEGGS = "早餐? 你谁真的?",--
		BANDAGE = "我不会再受伤了.",
		BASALT = "试图打破它是毫无意义的.",
		BEARDHAIR = "真是恶心.",
		BEDROLL_STRAW = "睡眠不过是一种短暂的死亡.",
		BEE =
		{
			GENERIC = "我将摆脱那毒刺.",
			HELD = "真执着, 小家伙.",
		},
		BEEFALO =
		{
			FOLLOWER = "它跟随我到它的末日.",
			GENERIC = "我在它眼里看到了疯狂.",
			NAKED = "哈哈!它没穿衣服.",
			SLEEPING = "它睡着了在做噩梦吗?",
		},
		BEEFALOHAT = "我要盖住我的头.",
		BEEFALOWOOL = "有时, 它们也会感到冷的.",
		BEEHAT = "这将保护我远离那些蜜蜂的骚扰.",
		BEEHIVE = "可怜的蜂巢和花粉.",
		BEEMINE = "什么? 我? 调皮? 你说对了!",--
		BERRIES = "这些浆果.",
		BERRIES_COOKED = "很美味, 但是它们不会持续很长时间.",
		BERRYBUSH =
		{
			BARREN = "太少了.",
			WITHERED = "它会被煮熟.",
			GENERIC = "一份小吃, 是偶然吗?",
			PICKED = "我必须等着.",
		},
		BIRDCAGE =
		{
			GENERIC = "它们可以看到我们的笼子.",
			OCCUPIED = "一闪一闪亮晶晶!",--
			SLEEPING = "它死了?不. 只是睡着而已.",
		},
		BIRDTRAP = "加点小树枝和蛛丝就能做出来.",
		BIRD_EGG = "蛋蛋的忧伤.",
		BIRD_EGG_COOKED = "我喜欢煎鸡蛋.",
		BISHOP = "它在祈祷什么?",
		BLOWDART_SLEEP = "不会睡得很死, 只是短暂的休眠.",
		BLOWDART_PIPE = "提莫酱的吹箭,试试还能用不.",
		BLOWDART_FIRE = "我又可以恶作剧啦,烧掉谁的屁屁呢?",
		BLUEGEM = "蓝色的鸟... 儿... 唱出忧伤?",
		BLUEPRINT = "无论谁画的,它都已经死了.",
		BELL_BLUEPRINT = "无论谁画的,它都已经死了.",
		BLUE_CAP = "蘑菇好可爱.",
		BLUE_CAP_COOKED = "美味的烤蘑菇.",
		BLUE_MUSHROOM =
		{
			GENERIC = "陈旧的.",
			INGROUND = "如果可以的话, 我应该冷藏起来.",
			PICKED = "捡起来.",
		},
		BOARDS =
		{
			"木板是一个很好的燃料!",
			"我真的需要很多木板!",
		},
		BONESTEW = "它们死了. 然后我把它们炖了.",
		BUGNET = "一个小虫子.",
		BUSHHAT = "哦!别消失啊.",
		BUTTER = "我喜欢这世界. 这就是我的生活!",--
		BUTTERFLY =
		{
			GENERIC = "漂亮,但太短暂.",
			HELD = "它的命在我手里.",
		},
		BUTTERFLYWINGS = "没有翅膀蝴蝶就不能飞了.",
		BUTTERFLYMUFFIN = "你是掉进糖罐子里面了吗!",
		CAMPFIRE =
		{
			EMBERS = "黑夜要来了.",
			GENERIC = "我会活过今晚的!",
			HIGH = "像地狱!",
			LOW = "黑暗侵蚀.",
			NORMAL = "这是火.",
			OUT = "快没有燃料了.",
		},
		CANE = "这能让我跑得更快.",
		CARROT = "这是兔哥哥最喜欢的胡萝卜.",
		CARROT_COOKED = "烤过的胡箩卜真好吃.",
		CARROT_PLANTED = "这颗长在地上的胡萝卜可以采摘了.",
		CARROT_SEEDS = "总有一天, 这颗种子也会变成胡萝卜.",
		CAVE_FERN = "黑暗中的一点色彩.",
		CHARCOAL = "他是冷的,死的, 就像我的心.",
        CHESSJUNK1 = "冷, 没有感情的机械生物.",
        CHESSJUNK2 = "冷, 没有感情的机械生物.",
        CHESSJUNK3 = "冷, 没有感情的机械生物.",
		CHESTER = "啊呜, 这是一只可爱的小狗狗!",--
		CHESTER_EYEBONE =
		{
			GENERIC = "它深入我的灵魂.",
			WAITING = "没有那么多的睡眠... 等待.",
		},
		COOKEDMANDRAKE = "这是一份好食物. 它会很好吃的.",
		COOKEDMEAT = "总是牛排当晚餐吗!",--
		COOKEDMONSTERMEAT = "煮熟的怪物肉,真邪恶.",
		COOKEDSMALLMEAT = "开吃了!",--
		CORN = "这些乌鸦可能会为了它挖我的坟墓.",--
		CORN_COOKED = "还记得小时候街头卖爆米花的老爷爷吗!?",
		CORN_SEEDS = "这是一颗种子.",
		CROW =
		{
			GENERIC = "天下乌鸦一般黑!",
			HELD = "这是我的.",
		},
		CUTGRASS = "我喜欢猎杀一些小东西.",
		CUTREEDS = "我喜欢收割它.",
		CUTSTONE = "它能让我能修建好多建筑.",
		DEADLYFEAST = "这是最后的一次晚餐.",
		DEERCLOPS = "我不喜欢它们的眼睛.",
		DEERCLOPS_EYEBALL = "最恐怖的是什么.",
		DEPLETED_GRASS =
		{
			GENERIC = "一丛草.",
		},
		DIRTPILE = "哦 看. 好多脏东西.",
		DIVININGROD =
		{
			COLD = "源头很遥远.",
			GENERIC = "它永远在寻找它失去的另一半.",
			HOT = "一些邪恶的东西在这里!",
			WARM = "邪恶的接近了.",
			WARMER = "已经非常接近了.",
		},
		DIVININGRODBASE =
		{
			GENERIC = "这是什么新玩意儿嘛?",
			READY = "它仍然需要一个大的钥匙.",
			UNLOCKED = "让我们看看我们能找到什么!",
		},
		DRAGONFLY =
		{
			"你喜欢烟花吗?",
			"它看起来很生气!",
		},
		LAVASPIT = 
		{
			HOT = "它吐了.",
			COOL = "冷却下来的气味真有趣.",
		},
		DRAGONFRUIT = "这根本不像龙的外形.",
		DRAGONFRUIT_COOKED = "还不是龙. 至少它已经死了.",
		DRAGONFRUIT_SEEDS = "它的种子. 它不会长出一条龙.",
		DRAGONPIE = "嗯, 至少这是一个陷阱吧.",
		DRUMSTICK = "做一份有营养的食品!",
		DRUMSTICK_COOKED = "熟一点的就更美味一点.",
		DUG_BERRYBUSH = "我想它死了, 我应该种了它.",
		DUG_GRASS = "我想它死了, 我应该种了它.",
		DUG_MARSH_BUSH = "我想它死了, 我应该种了它.",
		DUG_SAPLING = "我想它死了, 我应该种了它.",
		DURIAN = "带刺而且很臭!",
		DURIAN_COOKED = "没有刺了, 但是还是有点臭!",
		DURIAN_SEEDS = "奇怪, 种子不臭.",
		EARMUFFSHAT = "保护我免受严寒.",
		EGGPLANT = "致命的茄子.",
		EGGPLANT_COOKED = "烹饪使它更美味.",
		EGGPLANT_SEEDS = "这是茄子的种子.",
		ACORN = 
		{
		    GENERIC = "一个小生命, 脆弱很容易逝去.",
		    PLANTED = "小树~小树~快快长大!!!.",
		},
		EVERGREEN =
		{
			BURNING = "这棵树燃烧着.",
			BURNT = "点着了.",
			CHOPPED = "一切都死了.",
			GENERIC = "这是颗松树.你猜它上面会有松鼠吗?",
		},
		EVERGREEN_SPARSE =
		{
			BURNING = "这棵树燃烧着.",
			BURNT = "点着了.",
			CHOPPED = "一切都死了.",
			GENERIC = "它很稀有，真想看看它变成树人的样子.",
		},
		EYEPLANT = "他们跟着主人形影不离.",
		FEATHERHAT = "一闪一闪亮晶晶! 1 2 3 唱",--
		FEATHER_CROW = "乌鸦的羽毛, 黑色的像泥鳅.",
		FEATHER_ROBIN = "红色的羽毛, 红得像火焰.",
		FEATHER_ROBIN_WINTER = "雪鸟的羽毛, 白得像云彩.",
		FEM_PUPPET = "我好奇它做了什么.",
		FIREFLIES =
		{
			GENERIC = "这荧光真美.",
			HELD = "小小的灯光, 搁浅在我的口袋外面的世界.",
		},
		FIREHOUND = "狗狗着火了!",--
		FIRESTAFF = "我要烧毁一切! 哇哈哈哈!",--
		FISH = "这是在为生命拼命扑腾. 可怜的小鱼.",
		FISHINGROD = "这个, 我可以把小鱼们放到我的鱼缸里.",
		FISHSTICKS = "完美成型的鱼块.",
		FISHTACOS = "我希望没有骨头.",
		FISH_COOKED = "放到锅里会让它们停止跳动.",
		FLINT = "喜欢摇滚.",
		FLOWER = "她们美丽而令人温馨.",
		FLOWERHAT = "但是我感到悲哀...",
		FLOWER_EVIL = "至少它们比其他花要好.",
		FOLIAGE = "我记得风滚草里会有的.",
		FOOTBALLHAT = "猪猪酱给我做的. 好看吗?",
		FROG =
		{
			DEAD = "人生是如此的短暂和渺小.",
			GENERIC = "它很小.",
			SLEEPING = "它睡着了.",
		},
		FROGGLEBUNWICH = "我从来没想过青蛙腿会这么好.",
		FROGLEGS = "嗯. 青蛙没有腿还会跳吗?",--
		FROGLEGS_COOKED = "绝对美味.",
		FRUITMEDLEY = "甜, 一杯美味.",
		GEARS = "机械的重要零件.",
		GHOST = "它从坟墓里爬出来了!",
		GOLDENAXE = "我可以砍更多树.",
		GOLDENPICKAXE = "我可以凿出更多岩石.",
		GOLDENPITCHFORK = "至少我可以看到地球的风格.",
		GOLDENSHOVEL = "我可以挖的更多.",
		GOLDNUGGET = "我会随身携带它.",
		GRASS =
		{
			BARREN = "我需要肥料浇灌它.",
			WITHERED = "它只是不能承受太热的环境.",
			BURNING = "它看起来很有趣.",
			GENERIC = "它只是一株草.",
			PICKED = "小草,小草,快快长大!",
		},
		GREEN_CAP = "绿色的蘑菇.",
		GREEN_CAP_COOKED = "好好吃呦.",
		GREEN_MUSHROOM =
		{
			GENERIC = "小精灵的蘑菇房.",
			INGROUND = "如果可以的话, 我要藏起来.",
			PICKED = "收获.",
		},
		GUNPOWDER = "这是我踏上的黑暗之路.",
		HAMBAT = "感觉如何?被一块肉攻击! 哈哈哈!",--
		HAMMER = "哦,我可能会粉碎世界.",
		HEALINGSALVE = "生活带来痛苦, 痛苦让你学会坚强.",
		HEATROCK =
		{
			FROZEN = "冰冷的像我的心.",
			COLD = "只是一个冰冷的岩石块.",
			GENERIC = "它能帮我顺利的度过夏天和冬天.",
			WARM = "暖暖的像妈妈的怀抱,真好.",
			HOT = "热得发亮, 热得越快.",
		},
		HONEY = "甜到心里了.",
		HONEYCOMB = "一片蜂巢.",
		HONEYHAM = "它会产蜜.",
		HONEYNUGGETS = "它会产蜜.",
		HORN = "听起来有牛被困在里面了.",
		HOUND =
		{
			"邪恶... 可恶... 野蛮!",
			"它们真是粗鲁, 对吧?",
			"猎狗总是吃不饱!",
		},
		HOUNDBONE = "有些是无法避免的. 死亡就是其中之一.",--
		HOUNDMOUND = "这里最恐怖的生物.",
		ICEBOX = "食物, 食物, 我的食物在哪里?",--
		ICEHOUND = "你要和我打雪仗吗?小狗狗.",
		INSANITYROCK =
		{
			ACTIVE = "这里写我的名字了吗.",
			INACTIVE = "黑暗和冰冷.",
		},
		JAMMYPRESERVES = "完美的浆果.",
		KABOBS = "肉串.",
		KILLERBEE =
		{
			GENERIC = "我是一只小蜜蜂, 嗡嗡嗡.",
			HELD = "小家伙.",
		},
		KNIGHT = "没有灵魂.",
		KOALEFANT_SUMMER = "它预示着夏天要来了吗.",
		KOALEFANT_WINTER = "冬天会有它的身影.",
		KRAMPUS = "圣诞! 要来了吗!? 我要拔圣诞老人的胡子!",--
		KRAMPUS_SACK = "它能给我装下好多玩具.",
		LEIF = "这是树人雷夫.",
		LEIF_SPARSE = "树神雷夫,好威武.",
		LIGHTNING_ROD =
		{
			CHARGED = "嗞啦嗞啦,嗞嗞.",
			GENERIC = "有了这个妈妈再也不担心我被雷劈了.",
		},
		LITTLE_WALRUS = "暴力循环.",
		LIVINGLOG = "它永远在无声的尖叫.",
		LOCKEDWES = "麦斯威尔的雕像, 永远的活在饥荒的世界.",
		LOG = "如果树能说话, 它会说请珍惜好我的小心肝儿.",
		LUREPLANT = "它耗尽所有.",
		LUREPLANTBULB = "生命的延续.",
		MALE_PUPPET = "我好奇它做了什么.",
		MANDRAKE =
		{
			DEAD = "唉,可怜的曼德拉!",
			GENERIC = "真可爱. 我应该晚上带它回家.",
			PICKED = "前进, 我的曼德拉士兵!",
		},
		MANDRAKESOUP = "煮了它.",
		MARBLE = "光滑而无生气.",
		MARBLEPILLAR = "即使石头也不能承受磨损.",
		MARBLETREE = "这棵树在跟寒冷抗争.",
		MARSH_BUSH =
		{
			BURNING = "就像荆棘一样燃烧.",
			GENERIC = "好多刺呦,我得小心点.",
			PICKED = "它会刺伤我的.",
		},
		MARSH_PLANT = "这是一种植物.",
		MARSH_TREE =
		{
			BURNING = "它在燃烧",
			BURNT = "它让我想起了乌鸦的羽毛",
			CHOPPED = "它的尖峰没有保护.",
			GENERIC = "一棵树,只知道痛苦.",
		},
		MAXWELL = "你的脸. 我要给你画只小乌龟!",--
		MAXWELLHEAD = "他肯定爱好魔术.",
		MAXWELLLIGHT = "等等! 你说要带我去哪里?",--
		MAXWELLLOCK = "看上去很神奇.",
		MAXWELLTHRONE = "没有超出我的预期.",
		MEAT = "它是生的.",
		MEATBALLS = "看着让我流口水.",
		MEAT_DRIED = "肉晒干了. 更美味了.",
		MERM = "可怕的沼泽!",
		MINERHAT = "免提照明!",
		MONSTERMEAT = "邪恶的怪物肉.",
		MONSTERMEAT_DRIED = "肉晒干了. 更美味了.",
		MOSQUITO =
		{
			GENERIC = "生命是个奇迹.",
			HELD = "我能感觉到它的温暖.",
		},
		MOSQUITOSACK = "一代蚊子血,我喜欢这个.",
		MOUND =
		{
			DUG = "地球吐出他的秘密.",
			GENERIC = "我有一天, 也会加入你们.",
		},
		NIGHTLIGHT = "邪恶而美丽.",
		NIGHTMAREFUEL = "带着美梦入睡.",
		NIGHTSWORD = "梦到奇怪的人.",
		NITRE = "硝石能带我度过炎热的夏季.",
		ONEMANBAND = "跟我跳支舞吧!",--
		PANDORASCHEST = "如果打开盒子会发生什么?",--
		PANFLUTE = "音乐填满我空虚的心灵.",
		PAPYRUS = "记录我的成长.",
		PENGUIN = "你们打扮这么一致, 打算去参加舞会吗?",
		PERD = "小鸟! 远离我的浆果!",
		PEROGIES = "营养小袋子.",
		PETALS = "我已经摧毁了一些美丽的东西.",
		PETALS_EVIL = "他们把我的灵魂涂上了颜色.",
		PICKAXE = "这样我们可以凿穿地球.",
		PIGGYBACK = "它死了更有用.",
		PIGKING = "猪王大大,请给我好多金子吧.",
		PIGMAN =
		{
			DEAD = "它现在好了.",
			FOLLOWER = "我仍然感到孤独.",
			GENERIC = "小猪猪,笨笨哒.",
			GUARD = "难不倒我.",
			WEREPIG = "夜出动物!",
		},
		PIGSKIN = "猪成精阴暗面.",
		PIGTORCH = "它在消减黑暗.",
		PINECONE = 
		{
		    GENERIC = "一个脆弱的小生命很容易逝去.",
		    PLANTED = "小树 小树 快快长大.",
		},
		PITCHFORK = "什么邪恶的工具!",
		PLANTMEAT = "食人花的肉肉.",
		PLANTMEAT_COOKED = "烤熟了更好吃.",
		PLANT_NORMAL =
		{
			GENERIC = "一种可食用的植物.",
			GROWING = "继续成长. 我会等你.",
			READY = "我已经准备好了.",
			WITHERED = "失去了生命的活力.",
		},
		POMEGRANATE = "好多石榴籽,像珍珠一样美丽!",
		POMEGRANATE_COOKED = "熟透了.",
		POMEGRANATE_SEEDS = "我希望有更多的种子.",
		POND = "小鱼鱼? 你在里面吗?",
		POOP = "我可以用它浇灌我的农田.",
		PUMPKIN = "它和我的心一样大.",
		PUMPKINCOOKIE = "我自己做的饭!",
		PUMPKIN_COOKED = "我喜欢.",
		PUMPKIN_LANTERN = "你不那么可怕.",
		PUMPKIN_SEEDS = "它只是种子.",
		PURPLEGEM = "紫色的就像... 薰衣草那样美丽.",
		RABBIT =
		{
			GENERIC = "小兔兔,摸摸哒!",--
			HELD = "它现在安全了.",
		},
		RABBITHOLE = 
		{
			GENERIC = "这里面住着一只可爱的兔兔.",
			SPRING = "兔兔去度假了,好想它们吖.",--
		},
		RATATOUILLE = "一堆煮熟的蔬菜.",
		RAZOR = "这只是为了刮胡子.",
		REDGEM = "红得像小苹果.",
		RED_CAP = "红蘑菇,不能生吃哦.",
		RED_CAP_COOKED = "可以把它和别的煮在一起.",
		RED_MUSHROOM =
		{
			GENERIC = "蘑菇长大了.",
			INGROUND = "如果可以的话, 我会藏起来.",
			PICKED = "收获.",
		},
		REEDS =
		{
			BURNING = "很快成为灰烬.",
			GENERIC = "这只是一堆芦苇.",
			PICKED = "收获.",
		},
        RELIC = 
        {
            GENERIC = "一个古老世界的残骸.",
            BROKEN = "破碎的石头",
        },
        RUINS_RUBBLE = "一堆破碎的梦.",
		RESURRECTIONSTONE = "一都是徒劳.",
		ROBIN =
		{
			GENERIC = "这意味着春天即将到来吗? 我希望不是.",
			HELD = "它喜欢被困在我的口袋里.",
		},
		ROBIN_WINTER =
		{
			GENERIC = "这意味着冬天即将到来吗? 我希望不是.",
			HELD = "它喜欢被困在我的口袋里.",
		},
		ROBOT_PUPPET = "我好奇它在想什么.",
		ROCK_LIGHT =
		{
			GENERIC = "熔岩坑.",
			OUT = "它看起来是无害的.",
			LOW = "阴影的侵蚀.",
			NORMAL = "熔岩的火.",
		},
		ROCK = "不是永久性的.",
		ROCKS = "一些小石头.",
        ROOK = "乌鸦? 还是一座城堡?",
		ROPE = "从这个地方看将是一件很容易的事.",
		ROTTENEGG = "万事通.",
		SANITYROCK =
		{
			ACTIVE = "这是给我的.",
			INACTIVE = "它离开了我.",
		},
		SAPLING =
		{
			BURNING = "燃起熊熊大火.",
			WITHERED = "它枯萎后得到了这个.",
			GENERIC = "它在慢慢长大.",
			PICKED = "树苗 树苗 快快长大.",
		},
		SEEDS = "生命, 它的承诺.",
		SEEDS_COOKED = "我烤熟了它.",
		SEWING_KIT = "哈哈哈!我喜欢这个,它能帮我修复很多漂亮衣服.",
		SHOVEL = "什么可怕的秘密要被我发现了?",
		SILK = "很黏.",
		SKELETON = "我很羡慕他不用遭受痛苦.",
		SKELETON_PLAYER = "我是如此的接近它.",
		SKULLCHEST = "包含了我的象征.",
		SMALLBIRD =
		{
			GENERIC = "你好, 小家伙.",
			HUNGRY = "你饿了吗?",
			STARVING = "你要饿晕了吗.",
		},
		SMALLMEAT = "小肉肉.",
		SMALLMEAT_DRIED = "肉晒干了更美味了.",
		SPEAR = "我成了世界的先驱者.",
		SPIDER =
		{
			DEAD = "我们会再见的.",
			GENERIC = "这是我的肉丸子!",--
			SLEEPING = "恶魔睡着了.",
		},
		SPIDERDEN = "一窝团结的小动物.",
		SPIDEREGGSACK = "一个小小的卵里面有好多可爱的小蜘蛛.",
		SPIDERGLAND = "即使死了,还是很痛.",
		SPIDERHAT = "带上它我就是蜘蛛的家人了.",
		SPIDERQUEEN = "它是蜘蛛的女王，真是丑爆了.",
		SPIDER_WARRIOR =
		{
			DEAD = "唉, 勇敢的战士.",
			GENERIC = "一个勇士的夜晚!",
			SLEEPING = "我必须小心.",
		},
		SPOILED_FOOD = "最终还是失败了.",
		STATUEHARP = "也许这些雕塑将一直陪伴着我.",
		STATUEMAXWELL = "他把我带到了这里.",
		STINGER = "锋利致命.",
		STRAWHAT = "我要盖住我的头.",
		STUFFEDEGGPLANT = "充满了毒药.",
		SUNKBOAT = "一个残酷的玩笑!",
		SWEATERVEST = "我可以穿背心!",
		TAFFY = "你相信太妃糖可以让你的牙齿长蛀牙吗? 我觉得不会的.",--
		TALLBIRD = "你真高,我希望我能和你一样高.",--
		TALLBIRDEGG = "充满生命力.",
		TALLBIRDEGG_COOKED = "真好吃 喵 喵 喵 .",
		TALLBIRDEGG_CRACKED =
		{
			COLD = "它感到冷了.",
			GENERIC = "一个微小脆弱的生命，向着光的方向努力.",
			HOT = "太快热晕了.",
			LONG = "生命越早开始而生命就会越早结束.",
			SHORT = "很快.",
		},
		TALLBIRDNEST =
		{
			GENERIC = "鸡蛋代表新生活. 嗯嗯.",
			PICKED = "鸟巢是空的.",
		},
		TEENBIRD =
		{
			GENERIC = "你会离开我吗?",
			HUNGRY = "我们都会饿的.",
			STARVING = "你要离开我了吗!",
		},
		TELEPORTATO_BASE =
		{
			ACTIVE = "我相信下一个世界会更糟糕!",
			GENERIC = "没有比这更好的了.",
			LOCKED = "它是锁着的.",
			PARTIAL = "难道是半建成, 或半毁?",
		},
		TELEPORTATO_BOX = "它是我到下一个世界重要的部件.",
		TELEPORTATO_CRANK = "它看起来很复杂.",
		TELEPORTATO_POTATO = "什么可怕的创作!",
		TELEPORTATO_RING = "它没有锋利的边缘.",
		TENTACLE = "长而薄,危险!",
		TENTACLESPOTS = "这些就不错.",
		TENTACLESPIKE = "锋利, 黏糊和危险.",
        TENTACLE_PILLAR = "所以这就是去下面了.",
        TENTACLE_PILLAR_ARM = "宝宝!",
        TENTACLE_GARDEN = "这是一个不同的.",
		TOPHAT = "我要把它戴在头上.",
		TORCH = "在深夜的一个小小的堡垒.",
		TRAP = "小狗狗最害怕这个.",
		TRAP_TEETH = "从地下会冒出一个狡猾的惊喜.",
		TRAP_TEETH_MAXWELL = "这是麦斯威尔制作的陷阱.",
		TRINKET_1 = "好难看.",
		TRINKET_10 = "谁丢了他的假牙.",
		TRINKET_11 = "幸运的机器人, 它没有灵魂.",
		TRINKET_12 = "不再那么粘粘糊糊,是吗?",
		TRINKET_2 = "这是假的. 用来诱惑你犯罪.",
		TRINKET_3 = "如果刀能解决我的问题...",
		TRINKET_4 = "我会把这带到世界的尽头.",
		TRINKET_5 = "我将追逐着阳光奔跑.",
		TRINKET_6 = "一旦充满电它就会结束了.",
		TRINKET_7 = "只是一个简单的游戏.",
		TRINKET_8 = "我希望我能给它洗给澡.",
		TRINKET_9 = "生活的按钮.",
		TRUNKVEST_SUMMER = "温暖覆盖在我的皮肤上.",
		TRUNKVEST_WINTER = "它温暖我的身体, 但我的精神呢?",
		TRUNK_COOKED = "它看起来更糟了.",
		TRUNK_SUMMER = "我想要更好的耳朵.",
		TRUNK_WINTER = "脱离他的唯一朋友.",
		TURKEYDINNER = "谁吃了吗?",
		TWIGS = "从这里拔出来.",
		UMBRELLA = "我讨厌雨!",
		WAFFLES = "这绝对是华夫饼.",
		WALL_HAY_ITEM = "他们的防御值值得怀疑.",
		WALL_STONE = "里面的什么东西会保护我?",
		WALL_STONE_ITEM = "他们不能保护内心的恶魔.",
		WALL_RUINS = "他们没有保护远古人吗!",
		WALL_RUINS_ITEM = "它们闹鬼?",
		WALL_WOOD_ITEM = "捆绑日志.",
		WALRUS = "离开这个老人. 他认为我在浪费时间.",
		WALRUSHAT = "这里发生过什么有趣的事情?",
		WALRUS_CAMP =
		{
			EMPTY = "如果他们不在那里, 那他们在哪里?",
			GENERIC = "这个房子让我感到很害怕.",
		},
		WALRUS_TUSK = "我要咬你.",
		WASPHIVE = "它们躲在地下的堡垒.",
		WETGOOP = "命运多舛.",
		WINTERHAT = "它有助于保暖.",
		WORMHOLE =
		{
			GENERIC = "看这个! 巨大的嘴!",
			OPEN = "这把我带到哪里去?",
		},
		ACCOMPLISHMENT_SHRINE = "我从不关心隐喻.",
	},
	DESCRIBE_GENERIC = "这是难以启齿的.",
	DESCRIBE_TOODARK = "黑暗!太黑暗了!",
	DESCRIBE_SMOLDERING = "这是被吞噬的火焰.",
	EAT_FOOD =
	{
		TALLBIRDEGG_CRACKED = "我让它解脱.",
	},
}
