STRINGS.GF_DIG =
{
        "挖挖挖.",
		"我是淘金者!",
		"挖金子双人版?",
		"小霸王游戏机的淘金者玩过吗？.",
		"我要挖点东西.",
		"我最好找主人帮忙!",
		"有没有觉得我很时尚!",
		"会不会从里面蹦出一个孙悟空?",
}
STRINGS.GF_DIG_ENG =
{
		"Dig dig dig.",
		"Digging!",
		"Why are you digging?",
		"Don't play with dirt.",
		"You can dig something.",
		"Destroy!",
		"Tunnel!",
		"What is that?",
		"Awesome!",
		"It's cool!",
		"Well done!",
		"Great!",
		"And more!",
		"Let's again!",
		"Let's break!",
		"You funny?",
		"I love the feeling!",
		"I need more!",
		"You're the best!",
		"I want to see you...",
		"Play with me!",
		"But I can not see...",
		"Oh!",
		"Oww!",
		"Hihihi!",
}

return hl_loc(STRINGS.GF_DIG, STRINGS.GF_DIG_ENG)


