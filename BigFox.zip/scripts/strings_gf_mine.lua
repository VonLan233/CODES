STRINGS.GF_MINE =
{
        "摇起来!",
		"滚开!",
		"看起来好有趣.",
		"妲己，我才不是那个妖狐呢.",
		"你在做什么?",
		"你不会的吃石头对吧？.",
		"听说B站的UP主“爱喝假酒的FA”在用我做解说?",
		"我要卖肾，用上IPhone 6 Plus.",
		"花千骨.",
		"猎狗是什么?",
		"没有的啦!",
		"我是卖报的小黄家!",
}
STRINGS.GF_MINE_ENG =
{
        "Rock!",
		"Break away!",
		"That looks fun.",
		"Come on, Fox miner.",
		"What are you doing?",
		"Sounds like it.",
		"You don't eat the Rocks, right?",
		"I want a tunnel house.",
		"You're destroying nature.\nBut i don't care.",
		"What is this sound?",
		"Awesome!",
		"It's cool!",
		"Well done!",
		"Great!",
		"And more!",
		"Let's again!",
		"Let's break!",
		"You funny?",
		"I love the feeling!",
		"I need more!",
		"You're the best!",
		"I want to see you...",
		"Play with me!",
		"But I can not see...",
		"Oh!",
		"Oww!",
		"Hihihi!",
}
return hl_loc(STRINGS.GF_MINE, STRINGS.GF_MINE_ENG)


