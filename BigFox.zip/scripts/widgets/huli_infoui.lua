local Screen = require "widgets/screen"
local Widget = require "widgets/widget" 
local Text = require "widgets/text" 
local Button = require "widgets/button"
local AnimButton = require "widgets/animbutton"
local ImageButton = require "widgets/imagebutton"
local Image = require "widgets/image"
local TextEdit = require "widgets/textedit" 
local TextButton = require "widgets/textbutton"
local ImagePopupDialogScreen = require "screens/imagepopupdialog"
local PopupDialogScreen = require "screens/popupdialog"
local MouseTracker = require "widgets/mousetracker"
local TEMPLATES = require "widgets/templates"
local UIAnim = require "widgets/uianim"
-- local huli_ui_help = require "widgets/huli_ui_help"
local huli_uiutil = require "huli_uiutil"
local huli_labelui = require "screens/huli_label"
local huli_keyui = require "screens/huli_keyui"
local huli_skillui = require "widgets/huli_skillui"
local huli_storeui = require "widgets/huli_storeui"
local huli_infouibutton = require "widgets/huli_infouibutton"
local INTRODUCE = [[鼠标拖动显示板位置
按<Ctrl+鼠标>拖动整体位置]]
local INTRODUCE_ENG = [[Mouse dragging display board position
Press <Ctrl+Mouse> to drag the whole position]]

local allkey = { 
	{description="TAB", data = 9},
	{description="KP_PERIOD", data = 266},
	{description="KP_DIVIDE", data = 267},
	{description="KP_MULTIPLY", data = 268},
	{description="KP_MINUS", data = 269},
	{description="KP_PLUS", data = 270},
	{description="KP_ENTER", data = 271},
	{description="KP_EQUALS", data = 272},
	{description="MINUS", data = 45},
	{description="EQUALS", data = 61},
	{description="SPACE", data = 32},
	{description="ENTER", data = 13},
	{description="ESCAPE", data = 27},
	{description="HOME", data = 278},
	{description="INSERT", data = 277},
	{description="DELETE", data = 127},
	{description="END", data   = 279},
	{description="PAUSE", data = 19},
	{description="PRINT", data = 316},
	{description="CAPSLOCK", data = 301},
	{description="SCROLLOCK", data = 302},
	{description="RSHIFT", data = 303}, -- 右shift
	{description="LSHIFT", data = 304}, -- 左shift
	{description="RCTRL", data = 305}, -- 右ctrl
	{description="LCTRL", data = 306}, -- 左ctrl
	{description="RALT", data = 307}, -- 右alt
	{description="LALT", data = 308}, -- 左alt
	{description="ALT", data = 400},
	{description="CTRL", data = 401},
	{description="SHIFT", data = 402},
	{description="BACKSPACE", data = 8},
	{description="PERIOD", data = 46},
	{description="SLASH", data = 47},
	{description="LEFTBRACKET", data     = 91},
	{description="BACKSLASH", data     = 92},
	{description="RIGHTBRACKET", data = 93},
	{description="TILDE", data = 96},
	{description="A", data = 97},
	{description="B", data = 98},
	{description="C", data = 99},
	{description="D", data = 100},
	{description="E", data = 101},
	{description="F", data = 102},
	{description="G", data = 103},
	{description="H", data = 104},
	{description="I", data = 105},
	{description="J", data = 106},
	{description="K", data = 107},
	{description="L", data = 108},
	{description="M", data = 109},
	{description="N", data = 110},
	{description="O", data = 111},
	{description="P", data = 112},
	{description="Q", data = 113},
	{description="R", data = 114},
	{description="S", data = 115},
	{description="T", data = 116},
	{description="U", data = 117},
	{description="V", data = 118},
	{description="W", data = 119},
	{description="X", data = 120},
	{description="Y", data = 121},
	{description="Z", data = 122},
	{description="F1", data = 282},
	{description="F2", data = 283},
	{description="F3", data = 284},
	{description="F4", data = 285},
	{description="F5", data = 286},
	{description="F6", data = 287},
	{description="F7", data = 288},
	{description="F8", data = 289},
	{description="F9", data = 290},
	{description="F10", data = 291},
	{description="F11", data = 292},
	{description="F12", data = 293},
	{description="UP", data = 273},
	{description="DOWN", data = 274},
	{description="RIGHT", data = 275},
	{description="LEFT", data = 276},
	{description="PAGEUP", data = 280},
	{description="PAGEDOWN", data = 281},
	{description="0", data = 48},
	{description="1", data = 49},
	{description="2", data = 50},
	{description="3", data = 51},
	{description="4", data = 52},
	{description="5", data = 53},
	{description="6", data = 54},
	{description="7", data = 55},
	{description="8", data = 56},
	{description="9", data = 57},
	{description="小键盘0", data = 256},
	{description="小键盘1", data = 257},
	{description="小键盘2", data = 258},
	{description="小键盘3", data = 259},
	{description="小键盘4", data = 260},
	{description="小键盘5", data = 261},
	{description="小键盘6", data = 262},
	{description="小键盘7", data = 263},
	{description="小键盘8", data = 264},
	{description="小键盘9", data = 265},
	{description="NUMLUCK", data = 300},
}

local function redsikll_off(player)
	player.redsikllactivation = 'OFF'
	player.components.talker:Say(hl_loc('禁用火焰盛宴技能', 'Disable Flame Feast Skills'))
end
AddModRPCHandler("huli_rpc", 'redsikll_off', redsikll_off)

local function redsikll_on(player)
	player.redsikllactivation = 'ON'
	player.components.talker:Say(hl_loc('启用火焰盛宴技能', 'Enable Flame Feast Skills'))
end
AddModRPCHandler("huli_rpc", 'redsikll_on', redsikll_on)

local function icesikll_off(player)
	player.icesikllactivation = 'OFF'
	player.components.talker:Say(hl_loc('禁用冰域技能', 'Disable ice domain skills'))
end
AddModRPCHandler("huli_rpc", 'icesikll_off', icesikll_off)

local function icesikll_on(player)
	player.icesikllactivation = 'ON'
	player.components.talker:Say(hl_loc('启用冰域技能', 'Enable ice domain skills'))
end
AddModRPCHandler("huli_rpc", 'icesikll_on', icesikll_on)

local function levelup(player)
	if player.components.huli_levelsys then
		player.components.huli_levelsys:LvDoDeltaForExp(1)
	end
end
AddModRPCHandler("huli_rpc", 'levelup', levelup)

local function leftrpc(player, val)
	if player.skilldmgset > 0 then
		player.skilldmgset = player.skilldmgset - (val or 1)
	end
	if player.skilldmgset <= 0 then
		player.skilldmgset = 0
	end
end
AddModRPCHandler("huli_rpc", 'leftrpc', leftrpc)

local function rightrpc(player, val)
	if player.skilldmgset < 100 then
		player.skilldmgset = player.skilldmgset + (val or 1)
	end
	if player.skilldmgset >= 100 then
		player.skilldmgset = 100
	end
end
AddModRPCHandler("huli_rpc", 'rightrpc', rightrpc)

local function call_xhl_fn(player)
	local pets = player.components.huli_petleash
	if pets then
		pets:CallAllPets()
	end
end
AddModRPCHandler("huli_rpc", 'call_xhl_fn', call_xhl_fn)

local function call_mihobell_fn(player)
	local mihobell = player.components.huli_petleash
	if mihobell then
		mihobell:CallMihobell()
	end
end
AddModRPCHandler("huli_rpc", 'call_mihobell_fn', call_mihobell_fn)

local function temcolor(self)
	local tem = TheWorld.state.temperature 
	if tem <= 0 then
		self.temcolor_r = 0
		self.temcolor_g = 230 + (tem * 4)
		self.temcolor_b = 230
	elseif tem > 0 and tem <= 20 then
		self.temcolor_r = 0
		self.temcolor_g = 230
		self.temcolor_b = 50 + (20 - tem)*4.5
	elseif tem > 20 and tem <= 50 then
		self.temcolor_r = (tem - 20) * 7.6
		self.temcolor_g = 230
		self.temcolor_b = 50
	elseif tem > 50 then
		self.temcolor_r = 230
		self.temcolor_g = 230 - (tem-50) * 7.6
		self.temcolor_b = 50
	end
end

local function Pos_x(tar)
	local x, y = tar:GetPosition():Get()
	return x
end
	
local function Pos_y(tar)
	local x, y = tar:GetPosition():Get()
	return y
end

local function GetKeyID(numkey)
	if type(numkey) ~= "number" then
		return numkey
	end
	for k, v in pairs(allkey) do 
		if numkey == v.data then
			return v.description
		end
	end
	return "还没想好"
end

local function CanUseKey(player)
	if (player.components.huli_key and player.components.huli_key:CanUseKey()) and not (player:HasTag("playerghost") or (player.components.health and player.components.health:IsDead()) or player['文本编辑中']) then 
		return true
	end
end

local function SendRPC(rpcname)
	local ent = TheInput:GetWorldEntityUnderMouse()
	local x, y, z = TheInput:GetWorldPosition():Get()
	SendModRPCToServer(MOD_RPC["huli_rpc"][rpcname], ent, x, y, z)
end

local HuLi_InFoUi = Class(Widget, function(self, owner, huli_ui_help) 

	Widget._ctor(self, 'HuLi_InFoUi') 
	self.owner = owner
	self.fkk = nil
	
	self.textsize = 30
	self.textsize_l = 40
	
	self.offset_pos_y = 25
	
	self.temcolor_r = 0
	self.temcolor_g = 230
	self.temcolor_b = 50
	
	local function get_Level()
		local lv_sys = self.owner.replica.huli_levelsys
		if lv_sys and lv_sys:Get('当前等级') and lv_sys:Get('最大等级') then
			return lv_sys:Get('当前等级')..'/'..lv_sys:Get('最大等级')
		end
		return hl_loc('寄', 'nil')
	end
	
	local function get_Exp()
		local lv_sys = self.owner.replica.huli_levelsys
		if lv_sys and lv_sys:Get('当前经验值') and lv_sys:Get('升级经验值') then
			return lv_sys:Get('当前经验值')..'/'..lv_sys:Get('升级经验值')
		end
		return hl_loc('寄', 'nil')
	end
	
	local function get_State()
		if self.owner._hulistate and self.owner._hulistate:value() then
			return self.owner._hulistate:value()
		end
		return hl_loc('寄', 'nil')
	end
	
	local function get_Dmg()
		if self.owner._damage and self.owner._damage:value() then
			if self.owner._damagemultiplier and self.owner._damagemultiplier:value() then
				return self.owner._damage:value()..'('..self.owner._damagemultiplier:value().."%)"
			end
		end
		return hl_loc('寄', 'nil')
	end
	
	local function get_Abs()
		if self.owner._absorb and self.owner._absorb:value() then
			return self.owner._absorb:value().."%"
		end
		return hl_loc('寄', 'nil')
	end
	
	local function get_Speed()
		if self.owner._walkspeed and self.owner._walkspeed:value() then
			if self.owner._walkspeedmult and self.owner._walkspeedmult:value() then
				return self.owner._walkspeed:value()..'('..self.owner._walkspeedmult:value().."%)"
			end
		end
		return hl_loc('寄', 'nil')
	end
	
	local function get_Pet()
		if self.owner._petnumber and self.owner._petnumber:value() then
			if self.owner._maxpetnumber and self.owner._maxpetnumber:value() then
				return self.owner._petnumber:value()..'/'..self.owner._maxpetnumber:value()
			end
		end
		return hl_loc('寄', 'nil')
	end
	
	self.text_list = {
		{name = hl_loc('等级：', 'Level：'), val = get_Level }, --等级
		{name = hl_loc('经验：', 'Exp：'), val = get_Exp }, --经验
		{name = hl_loc('当前形态：', 'State：'), val = get_State }, --形态
		{name = hl_loc('当前伤害：', 'Current Attack：'), val = get_Dmg }, --伤害
		{name = hl_loc('自身伤害减免：', 'Self dmg absorb：'), val = get_Abs }, --减伤
		{name = hl_loc('移动速度：', 'Moving speed：'), val = get_Speed }, --移速
		{name = hl_loc('小狐狸数量：', 'Number of pets：'), val = get_Pet }, --宠物
	}
	
	self.root = self:AddChild(Widget("ROOT"))--设置一个爸爸
	-- self.root:SetVAnchor(ANCHOR_MIDDLE)--把整个界面的中心点设成屏幕中心点
	-- self.root:SetHAnchor(ANCHOR_MIDDLE)
	-- self.root:SetScaleMode(SCALEMODE_PROPORTIONAL)
	-- self.root:MoveToFront() --移动到前面
	--self.root:MoveToBack() --移动到后面
	-- self.root:SetScaleMode(SCALEMODE_PROPORTIONAL)
	-- self.root:SetTint(49/255,49/255,49/255,1) --设置颜色
	-- local width, heigth = TheSim:GetScreenSize()
	self.inst:DoTaskInTime(FRAMES, function()
		if self.fkk then
			-- local fx, fy = self.fkk.root:GetWorldPosition():Get()
			local fx, fy = self.fkk.root:GetPosition():Get()
			self.root:SetPosition(fx -180, fy + 240, 0) 	
		end
		TheSim:GetPersistentString("HuLi_InFoUiSetting", function(load_success, pos)
			if load_success and pos then
				pos = json.decode(pos)
				self.root:SetPosition(pos.x, pos.y, pos.z)	
			end
		end)
	end)
	
	self.owner:ListenForEvent('信息UI面板控制事件', function(oo, ct) 
		if ct then
			self:Show()
			self:MoveToBack()
		else
			self:Hide()
		end
	end)

-----------UI主页
	-- self.info_bg = self:AddChild(Image("images/info_ui.xml","info_ui.tex"))
	self.info_bg = self.root:AddChild(Image("images/scoreboard.xml","scoreboard_frame.tex"))
	self.info_bg:SetSize(400, 560)
	self.info_bg:SetTint(1, 1, 1, .9)
	-- self.info_bg:SetPosition(133,70,0) 	
	-- self.info_bg:SetTooltip(hl_loc(INTRODUCE, INTRODUCE_ENG))
	-- self.info_bg:Hide()
	
	self.info_bg.text = {}
	for k, v in pairs(self.text_list) do
		local text = self.info_bg.text
		text[k] = self.info_bg:AddChild(Text(BODYTEXTFONT, self.textsize, "")) 
		text[k]:SetString(v.name)
		-- text[k]:SetColour(92/255,255/255,75/255,1)
		text[k]:SetPosition(0, 210 - k * 25, 0)		
		
	end
	
-----------升级按钮	
	self.level_up = self.info_bg:AddChild(ImageButton("images/huli_levelup.xml","huli_levelup.tex"))
	self.level_up:SetScale(.45, .45)
	-- self.level_up:SetImageNormalColour(184/255,184/255,184/255,1)
	self.level_up:SetPosition(75, 185, 0)
	-- self.level_up:SetTooltip(hl_loc('点击升级', 'Click to level up'))
	self.level_up:SetOnClick(function()
		if TheWorld.ismastersim then
			levelup(self.owner)
		else
			SendRPC("levelup")
		end
	end)
	
-----------火技能CD	
	self.fireskillCD_text = self.info_bg:AddChild(Text(BODYTEXTFONT, self.textsize, ""))
	self.fireskillCD_text:SetColour(245/255,108/255,23/255,1)
    -- self.fireskillCD_text:SetPosition(0, Pos_y(self.huli_walkspeed_text) - self.offset_pos_y,0) 
    self.fireskillCD_text:SetPosition(0, 10,0) 
-----------火元素	
	self.fire_element_text = self.info_bg:AddChild(Text(BODYTEXTFONT, self.textsize, ""))
	self.fire_element_text:SetColour(245/255,108/255,23/255,1)
    self.fire_element_text:SetPosition(0, Pos_y(self.fireskillCD_text) - self.offset_pos_y,0)
-----------冰技能CD		
	self.iceskillCD_text = self.info_bg:AddChild(Text(BODYTEXTFONT, self.textsize, ""))
	self.iceskillCD_text:SetColour(55/255,151/255,247/255,1)
    self.iceskillCD_text:SetPosition(0, Pos_y(self.fire_element_text) - self.offset_pos_y,0) 
-----------冰元素	
	self.ice_element_text = self.info_bg:AddChild(Text(BODYTEXTFONT, self.textsize, ""))
	self.ice_element_text:SetColour(55/255,151/255,247/255,1)
    self.ice_element_text:SetPosition(0, Pos_y(self.iceskillCD_text) - self.offset_pos_y,0)
-----------气温
	self.worldtemp_text = self.info_bg:AddChild(Text(BODYTEXTFONT, self.textsize*.9, ""))
	-- self.worldtemp_text:SetColour(self.temcolor_r/255, self.temcolor_g/255, self.temcolor_b/255, 1)
    self.worldtemp_text:SetPosition(-108, 215,0)
	
--[[----------技能设置图标
	local skill_bg_cfg = {
		size = {380, 200},
		pos = Vector3(0, -300, 0),
	}
	self.skill_ui = self:AddChild(huli_skillui(self.owner, skill_bg_cfg))
	self.skill_ui:Hide()
	
	self.skill_set_bg = self.info_bg:AddChild(ImageButton("images/global_redux.xml", "button_carny_square_normal.tex"))
	self.skill_set_bg:SetScale(.4, .45, .4)
	self.skill_set_bg:SetPosition(-115, Pos_y(self.fire_element_text) + 70, 0) 
	self.skill_set_bg:SetTooltip('技能设置')

	self.skill_set = self.skill_set_bg:AddChild(Image("images/button_icons.xml","configure_mod.tex"))
	self.skill_set:SetScale(.25, .25)
	
	self.skill_set_bg:SetOnClick(function()
		if self.skill_ui.shown then
			self.skill_ui:Hide()
		else
			self.skill_ui:Show()
		end
	end)]]

-----------火技能图标
	self.fireskill = self.info_bg:AddChild(ImageButton("images/firetab.xml","firetab.tex"))
	self.fireskill:SetScale(.4, .4)
	self.fireskill:SetPosition(-125, Pos_y(self.fire_element_text) + 10, 0)
	self.fireskill:SetTooltip(hl_loc('禁用火焰盛宴技能', 'Disable Flame Feast Skills'))
	self.fireskill:SetOnClick(function()    
		if TheWorld.ismastersim then
			redsikll_off(self.owner)
		else
			SendRPC("redsikll_off")
		end
		self.fireskill:Hide()
		self.fireskill_off:Show()
	end)
	
	self.fireskill_off = self.info_bg:AddChild(ImageButton("images/firetab_off.xml","firetab_off.tex"))
	self.fireskill_off:SetScale(.4,.4)
	self.fireskill_off:SetPosition(self.fireskill:GetWorldPosition():Get())
	self.fireskill_off:SetTooltip(hl_loc('启用火焰盛宴技能', 'Enable Flame Feast Skills'))
		
	self.fireskill_off:SetOnClick(function()    
		if TheWorld.ismastersim then
			redsikll_on(self.owner)
		else
			-- SendModRPCToServer(MOD_RPC['huli_rpc']['redsikll_on'])
			SendRPC("redsikll_on")
		end
		self.fireskill_off:Hide()
		self.fireskill:Show()
	end)
	self.fireskill_off:Hide()
		
-----------冰技能图标
	self.iceskill = self.info_bg:AddChild(ImageButton("images/icetab.xml","icetab.tex"))
	self.iceskill:SetScale(.4,.4)
	self.iceskill:SetPosition(-125, Pos_y(self.ice_element_text) + 10, 0)
	self.iceskill:SetTooltip(hl_loc('禁用冰域技能', 'Disable ice domain skills'))
	self.iceskill:SetOnClick(function()    
		if TheWorld.ismastersim then
			icesikll_off(self.owner)
		else
			-- SendModRPCToServer(MOD_RPC['huli_rpc']['icesikll_off'])
			SendRPC("icesikll_off")
		end
		self.iceskill:Hide()
		self.iceskill_off:Show()
	end)
	
	self.iceskill_off = self.info_bg:AddChild(ImageButton("images/icetab_off.xml","icetab_off.tex"))
	self.iceskill_off:SetScale(.4,.4)
	self.iceskill_off:SetPosition(self.iceskill:GetWorldPosition():Get())
	self.iceskill_off:Hide()
	self.iceskill_off:SetTooltip(hl_loc('启用冰域技能', 'Enable ice domain skills'))
		
	self.iceskill_off:SetOnClick(function()    
		if TheWorld.ismastersim then
			icesikll_on(self.owner)
		else
			SendRPC("icesikll_on")
		end
		self.iceskill_off:Hide()
		self.iceskill:Show()
	end)
	
-----------召唤小狐狸图标
	self.call_xhl_imagebutton = self.info_bg:AddChild(ImageButton("images/huli_callallxhl.xml", "huli_callallxhl.tex"))
	self.call_xhl_imagebutton:SetScale(.6, .6)
	self.call_xhl_imagebutton:SetPosition(35, -150, 0)
	self.call_xhl_imagebutton:SetTooltip(hl_loc("召唤所有小狐狸到身边", "Call all the little foxes to your side"))
	self.call_xhl_imagebutton:SetOnClick(function()    
		if TheWorld.ismastersim then
			call_xhl_fn(self.owner)
		else
			SendRPC("call_xhl_fn")
		end
		self:Control()
	end)

-----------召唤狐狸铃铛图标
	self.call_xhl_imagebutton = self.info_bg:AddChild(ImageButton("images/inventoryimages/items.xml", "mihobell.tex"))
	-- self.call_xhl_imagebutton:SetScale(.6, .6)
	self.call_xhl_imagebutton:SetPosition(120, -150, 0)
	self.call_xhl_imagebutton:SetTooltip(hl_loc("强制召唤狐狸铃铛", "Forced call mihobell"))
	self.call_xhl_imagebutton:SetOnClick(function()    
		if TheWorld.ismastersim then
			call_mihobell_fn(self.owner)
		else
			SendRPC("call_mihobell_fn")
		end
		self:Control()
	end)

-----------狐狸商店
	self['狐狸商店按钮'] = self.info_bg:AddChild(TextButton())
	self['狐狸商店按钮']:SetText(hl_loc('打开狐狸商店', 'Open Store'))
	self['狐狸商店按钮']:SetColour(92/255,255/255,75/255,1)
	self['狐狸商店按钮']:SetOverColour(252/255, 231/255, 28/255, 1)
	self['狐狸商店按钮']:SetTextSize(self.textsize+5)
    self['狐狸商店按钮']:SetPosition(-75, -120, 0)
	self['狐狸商店按钮']:SetTooltip(hl_loc('狐狸商店', 'Fox store'))
	if HULI_STORE_SET == "关闭" then
		self['狐狸商店按钮']:Hide()
	end
	self['狐狸商店按钮']:SetOnClick(function()
		if self['狐狸商店按钮']:GetText() == hl_loc('打开狐狸商店', 'Open Store') then
			self.owner:PushEvent('狐狸商店开关事件', true)
		else
			self.owner:PushEvent('狐狸商店开关事件')
		end
	end)
	
	self.owner:ListenForEvent('狐狸商店开关事件', function(oo, ct) 
		if ct then
			self:Control()
			self['狐狸商店按钮']:SetText(hl_loc('关闭狐狸商店', 'Close Store'))
		else
			-- self:Show()
			self['狐狸商店按钮']:SetText(hl_loc('打开狐狸商店', 'Open Store'))
		end
	end)

-----------头衔控制面板
	self.label_control = self.info_bg:AddChild(TextButton())
	self.label_control:SetTextSize(self.textsize+5)
	self.label_control:SetText(hl_loc('头衔控制器', 'Title control')) 
	self.label_control:SetColour(92/255,255/255,75/255,1)
	self.label_control:SetOverColour(252/255, 231/255, 28/255, 1)
    self.label_control:SetPosition(-75,-150,0)
    self.label_control:SetTooltip(hl_loc('点击显示头衔控制面板', 'Click to display the label control panel'))
	
	self.label_control:SetOnClick(function()
		self:Control()
		self.owner:DoTaskInTime(0, function()
			self.labelui = huli_labelui(self.owner)
			self.owner.HUD:OpenScreenUnderPause(self.labelui)
		end)
	end)
	
	
-----------帮助/Help面板
	self.huli_ui_help = huli_ui_help
	self.help_ui_text = self.info_bg:AddChild(TextButton())
	self.help_ui_text:SetTextSize(self.textsize+5)
	self.help_ui_text:SetText(hl_loc('帮助', 'Help'))
	self.help_ui_text:SetTooltip(hl_loc('点击显示/隐藏MOD使用说明', 'Click to show/hide MOD instructions'))
	self.help_ui_text:SetColour(92/255,255/255,75/255,1)
	self.help_ui_text:SetOverColour(252/255, 231/255, 28/255, 1)
    self.help_ui_text:SetPosition(-75,-180,0)	
	self.help_ui_text:SetOnClick(function()
		if self.huli_ui_help.shown then
			self.huli_ui_help:Hide()
		else
			self.huli_ui_help:Show()
			self:Control()
		end
	end)	
	
	-- local rx, ry = self.info_bg:GetWorldPosition():Get()
	-- self.fkk = self.root:AddChild(huli_infouibutton(self.owner, self.info_bg ))
	-- self.fkk:SetPosition(rx + 150, ry - 240, 0)	
	-- self.fkk:Show()
	
---------更新说明面板开关字
	self['更新UI面板开关按钮'] = self.info_bg:AddChild(TextButton())
	self['更新UI面板开关按钮']:SetText(hl_loc('更新面板', 'Update content'))
	self['更新UI面板开关按钮']:SetColour(92/255,255/255,75/255,1)
	self['更新UI面板开关按钮']:SetOverColour(252/255, 231/255, 28/255, 1)
	self['更新UI面板开关按钮']:SetTextSize(self.textsize+5)
    self['更新UI面板开关按钮']:SetPosition(-80, Pos_y(self.help_ui_text) - 30, 0)
	self['更新UI面板开关按钮']:SetTooltip(hl_loc('点击查看/关闭更新面板', 'Click to view/close update content'))
	self['更新UI面板开关按钮']:SetOnClick(function()
		self.owner:PushEvent('更新面板开关事件')
		-- self:Control()
	end)

---------★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★

	self.huli_skill_list = {
		{name = hl_loc("变身技能：", "Transformation Skill："), rpcname = "huli_statekey"},
		{name = hl_loc("盛宴技能：", "Feast Skill："), rpcname = "SkillState"},
		{name = hl_loc("小狐狸控制：", "Little fox control："), rpcname = "call_xhl"},
		{name = hl_loc("跳跃按键：", "Jump button："), rpcname = "HULI_DODGE_A"},
	}
	
	self.numkey = {
		122, 
		114, 
		120, 
		103, 
	}
	TheSim:GetPersistentString("HuLi_KeySetting", function(load_success, str)
		if load_success and str then
			str = json.decode(str)
			if #self.numkey ~= #str then --
				return
			end
			self.numkey = str	
		end
	end)
-----------按键UI
	self.keyui = self.info_bg:AddChild(Image("images/scoreboard.xml","scoreboard_frame.tex"))
	self.keyui:SetSize(hl_loc(355, 555), 560)
	self.keyui:SetPosition(hl_loc(345, 430), 3, 0)
	self.keyui:SetTint(1, 1, 1, .8)
	-- self.keyui:Hide()
	
	self.keyui.keylist = {}
	self.inst:DoTaskInTime(FRAMES, function()
		for k, v in pairs(self.huli_skill_list) do
			local kl = self.keyui.keylist
			kl[k] = self.keyui:AddChild(TextButton())
			kl[k]:SetText(v.name..GetKeyID(self.numkey[k]))
			kl[k]:SetColour(92/255,255/255,75/255,1)
			kl[k]:SetOverColour(252/255, 231/255, 28/255, 1)
			kl[k]:SetTextSize(self.textsize+5)
			kl[k]:SetPosition(0, 190 - k * 30, 0)
			kl[k]:SetTooltip(hl_loc("点击设置按键", "Click the setting button"))
			kl[k]:SetOnClick(function()
				self.huli_keyui = huli_keyui(self.owner)
				self.huli_keyui:ShowInFo(k, self.numkey[k], self)
			end)
			
			kl[k].keyfn = TheInput:AddKeyDownHandler(self.numkey[k], function() 
				if CanUseKey(self.owner) then
					SendRPC(v.rpcname)
				end
			end)
		end
	end)

-------------顶大字
	self.keyui_toptext = self.keyui:AddChild(Text(BODYTEXTFONT, 50, "")) 
	self.keyui_toptext:SetString(hl_loc("技能按键设置", "Skill key setting"))
	-- self.keyui_toptext:SetColour(92/255,255/255,75/255,1)
    self.keyui_toptext:SetPosition(0, 200, 0)	


--★★★★★★★★元素消耗设置★★★★★★★★
	self.pos_y = -180

	----左/减
	self.left = self.keyui:AddChild(ImageButton("images/global_redux.xml", "arrow2_left_over.tex"))
	self.left:SetPosition(-40, self.pos_y, 0)
	self.left:SetScale(.4, .3, .7)
	-- self.left:SetTooltip('')
	self.left:SetOnClick(function() self:Left(self.owner) end)
	
	self.left2 = self.keyui:AddChild(ImageButton("images/global_redux.xml", "arrow2_left_over.tex"))
	self.left2:SetPosition(-80, self.pos_y, 0)
	self.left2:SetScale(.6, .3, .7)
	-- self.left2:SetTooltip('')
	self.left2:SetOnClick(function() self:Left(self.owner, 10) end)
	
----右/加
	self.right = self.keyui:AddChild(ImageButton("images/global_redux.xml", "arrow2_right_over.tex"))
	self.right:SetPosition(40, self.pos_y, 0)
	self.right:SetScale(.4, .3, .7)
	-- self.right:SetTooltip('')
	self.right:SetOnClick (function() self:Right(self.owner) end)	

	self.right2 = self.keyui:AddChild(ImageButton("images/global_redux.xml", "arrow2_right_over.tex"))
	self.right2:SetPosition(80, self.pos_y, 0)
	self.right2:SetScale(.6, .3, .7)
	-- self.right2:SetTooltip('')
	self.right2:SetOnClick (function() self:Right(self.owner, 10) end)	

----底字
	self.eme_text = self.keyui:AddChild(Text(DIALOGFONT, 28, ''))
	self.eme_text:SetPosition(0, self.pos_y, 0)
	
----顶字
	self.toptext = self.keyui:AddChild(Text(DIALOGFONT, 35, hl_loc('技能元素消耗设置', 'Skill Element Consumption Settings')))
	self.toptext:SetPosition(0, hl_loc(-60, 20), 0)

----中间字
	self.toptext = self.keyui:AddChild(Text(DIALOGFONT, 26, hl_loc('消耗当前元素量百分比 \n消耗的元素越多,技能伤害越高\n消耗量达到一定值后技能冷却时间增加', 'Consume the percentage of the current \n element amount. \nThe more elements consumed, \n the higher the skill damage. \n After the consumption reaches a certain value, \n the skill cooling time increases')))
	self.toptext:SetPosition(0, Pos_y(self.toptext) - hl_loc(130, 90), 0)
	
	
	huli_uiutil.DragableUI(self, "HuLi_InFoUiSetting", self.root)
	--更新UI板
	self:StartUpdating()
end)

function HuLi_InFoUi:UpdateKey(slot, key)
	--检测键位是否重复
	for i, v in ipairs(self.numkey) do
		if v == key then
			-- key = self.numkey[slot]
			self.owner.components.talker:Say("重复键位")
			-- break
			return
		end
	end

	--设定键位
	local kl = self.keyui.keylist
	self.numkey[slot] = key
	kl[slot]:SetText(self.huli_skill_list[slot].name..GetKeyID(key))

	--修改按键触发
	if kl[slot].keyfn then
		kl[slot].keyfn:Remove()
		self.inst:DoTaskInTime(FRAMES, function()
			kl[slot].keyfn = TheInput:AddKeyDownHandler(key, function()
				if CanUseKey(self.owner) then
					-- SendModRPCToServer(MOD_RPC['hugh'][self.huli_skill_list[slot].rpcname])
					SendRPC(self.huli_skill_list[slot].rpcname)
				end
			end)
		end)
	end
	if kl[slot].keyupfn then
		kl[slot].keyupfn:Remove()
		self.inst:DoTaskInTime(FRAMES, function()
			if self.huli_skill_list[slot].rpcname_up ~= nil then
				kl[slot]:SetText(self.huli_skill_list[slot].name..GetKeyID(key).."+")
				kl[slot].keyupfn = TheInput:AddKeyUpHandler(key, function() 
					if CanUseKey(self.owner) then
						-- SendModRPCToServer(MOD_RPC['hugh'][self.huli_skill_list[slot].rpcname_up])
						SendRPC(self.huli_skill_list[slot].rpcname_up)
					end
				end)	
			end
		end)
	end

	--保存键位至客户端
	local _,data = pcall(json.encode, self.numkey)
	TheSim:SetPersistentString("HuLi_KeySetting", data, false)
end

function HuLi_InFoUi:Left(player, val)
	if TheWorld.ismastersim then
		leftrpc(player, val)
	else
		SendModRPCToServer(MOD_RPC['huli_rpc']['leftrpc'], val)
	end
end

function HuLi_InFoUi:Right(player, val)
	if TheWorld.ismastersim then
		rightrpc(player, val)
	else
		SendModRPCToServer(MOD_RPC['huli_rpc']['rightrpc'], val)
	end	
end

function HuLi_InFoUi:Control(ctrl)
    self.owner:PushEvent('信息UI面板控制事件', ctrl)
	self.owner:PushEvent('小龙空间开关事件') --测试用
end

--[[
function HuLi_InFoUi:OnControl(control, down)
	if HuLi_InFoUi._base.OnControl(self, control, down) then return true end
	if self.owner.components.playercontroller:IsControlPressed(39) then
		if control == 29 and down then
			self:FollowMouse()
		else
			self:StopFollowMouse()
		end
	end
end

function HuLi_InFoUi:OnRawKey(key, down)
    if HuLi_InFoUi._base.OnRawKey(self, key, down) then return true end
end
]]

--UI板上显示的内容
function HuLi_InFoUi:OnUpdate(dt)

	temcolor(self)
	self.worldtemp_text:SetColour(self.temcolor_r/255, self.temcolor_g/255, self.temcolor_b/255, 1)
	local lv_sys = self.owner.replica.huli_levelsys
	if lv_sys then
		if lv_sys:Get('当前等级') < lv_sys:Get('最大等级') and
			lv_sys:Get('当前经验值') >= lv_sys:Get('升级经验值') then
			self.level_up:SetImageNormalColour(1,1,1,1)
			self.level_up:SetImageFocusColour(1,1,1,1)
			self.level_up:SetTooltip(hl_loc('点击升级', 'Click to level up'))
		else
			self.level_up:SetImageNormalColour(66/255,66/255,66/255,1)
			self.level_up:SetImageFocusColour(66/255,66/255,66/255,1)
			self.level_up:SetTooltip('')
		end
	end
	
	for k, v in pairs(self.text_list) do
		local text = self.info_bg.text
		if v.val then
			text[k]:SetString(v.name..v.val())
		end
	end
	self.eme_text:SetString(self.owner._skilldmgset:value()..'%')
		--技能CD
	if self.owner._fireskillCD:value() > 0 then
		if self.owner._redsikllactivation:value() == 'ON' then
			self.fireskillCD_text:SetString(hl_loc('技能CD：', 'SkillCD：')..self.owner._fireskillCD:value()..hl_loc('(启用)', '(Enable)') )
		else
			self.fireskillCD_text:SetString(hl_loc('技能CD：', 'SkillCD：')..self.owner._fireskillCD:value()..hl_loc('(禁用)', '(Disable)') )
		end
	else
		if self.owner._redsikllactivation:value() == 'ON' then
			self.fireskillCD_text:SetString(hl_loc('技能已就绪', 'Skill is ready')..hl_loc('(启用)', '(Enable)'))
		else
			self.fireskillCD_text:SetString(hl_loc('技能已就绪', 'Skill is ready')..hl_loc('(禁用)', '(Disable)'))
		end
	end
	--火元素
	if self.owner['当前火元素net']:value() < self.owner['最大火元素net']:value() then
		self.fire_element_text:SetString(hl_loc('火元素：', 'Fire element：')..self.owner['当前火元素net']:value()..'/'..self.owner['最大火元素net']:value())
	else
		self.fire_element_text:SetString(hl_loc('火元素：已满/', 'Fire element：Full/')..self.owner['最大火元素net']:value())
	end
	--<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
	if self.owner._iceskillCD:value() > 0 then
		if self.owner._icesikllactivation:value() == 'ON' then
			self.iceskillCD_text:SetString(hl_loc('技能CD：', 'SkillCD：')..self.owner._iceskillCD:value()..hl_loc('(启用)', '(Enable)'))
		else
			self.iceskillCD_text:SetString(hl_loc('技能CD：', 'SkillCD：')..self.owner._iceskillCD:value()..hl_loc('(禁用)', '(Disable)'))
		end
	else
		if self.owner._icesikllactivation:value() == 'ON' then
			self.iceskillCD_text:SetString(hl_loc('技能已就绪', 'Skill is ready')..hl_loc('(启用)', '(Enable)'))
		else
			self.iceskillCD_text:SetString(hl_loc('技能已就绪', 'Skill is ready')..hl_loc('(禁用)', '(Disable)'))
		end
	end
	if self.owner['当前冰元素net']:value() < self.owner['最大冰元素net']:value() then
		self.ice_element_text:SetString(hl_loc('冰元素：', 'Ice element：')..self.owner['当前冰元素net']:value()..'/'..self.owner['最大冰元素net']:value())
	else
		self.ice_element_text:SetString(hl_loc('冰元素：已满/', 'Ice element：Full/')..self.owner['最大冰元素net']:value())
	end
	self.worldtemp_text:SetString(hl_loc('气温：', 'World temp:')..self.owner._worldtemp:value()..'C°')
	
------------------------------------------------------------------------------------------------------
	-- self.huli_exp_text:SetString(hl_loc('经验：', 'Exp：')..self.owner._min_exp:value()..'/'..self.owner._max_exp:value()) --经验

	-- self.hulidmgmult_text:SetString(hl_loc('伤害倍率：', 'Damage Multipler：')..self.owner._damagemultiplier:value()..'%')
	-- self.huli_walkspeedmult_text:SetString(hl_loc('移速倍率：', 'Speed multiplier：')..self.owner._walkspeedmult:value()..'%')
	-- self.petnumber_text:SetString(hl_loc('小狐狸数量：', 'Number of pets：')..self.owner._petnumber:value()..'/'..self.owner._maxpetnumber:value()) --宠物
end

return HuLi_InFoUi