local Screen = require "widgets/screen"
local Widget = require "widgets/widget" 
local Text = require "widgets/text" 
local Button = require "widgets/button"
local AnimButton = require "widgets/animbutton"
local ImageButton = require "widgets/imagebutton"
local Image = require "widgets/image"
local TextEdit = require "widgets/textedit" 
local TextButton = require "widgets/textbutton"
local ImagePopupDialogScreen = require "screens/imagepopupdialog"
local PopupDialogScreen = require "screens/popupdialog"
local MouseTracker = require "widgets/mousetracker"
local TEMPLATES = require "widgets/templates"
local UIAnim = require "widgets/uianim"
local huli_scrollablelist = require "widgets/huli_scrollablelist"
local huli_uiutil = require "huli_uiutil"
local ScrollableList = require "widgets/scrollablelist"
-- local huli_infoui = require "widgets/huli_infoui"
local INTRODUCE = [[按<Ctrl+鼠标>拖动面板位置]]
local INTRODUCE_ENG = [[Mouse dragging display board position
Press <Ctrl+Mouse> to drag the whole position]]

local HuLi_InFoUiButton = Class(Widget, function(self, owner, huli_infoui) 

	Widget._ctor(self, 'HuLi_InFoUiButton') 
	self.owner = owner
	
--设置根基
	self.root = self:AddChild(Widget("ROOT"))--可理解为创建屏幕的一个基础点
	-- self.root:SetVAnchor(ANCHOR_MIDDLE)--把整个界面的中心点设成屏幕中心点
	-- self.root:SetHAnchor(ANCHOR_MIDDLE)
	-- self.root:SetScaleMode(SCALEMODE_PROPORTIONAL)
	-- self:GetPosition()
	-- local width, heigth = TheSim:GetScreenSize()
	-- self.root:SetPosition(188, heigth/2 + 200, 0)	
	self.root:SetPosition(350, 133, 0)	
	self.inst:DoTaskInTime(0, function()
		self:MoveToBack()
	end)
	TheSim:GetPersistentString("HuLi_MainUiSetting", function(load_success, pos)
		if load_success and pos then
			pos = json.decode(pos)
			self.root:SetPosition(pos.x, pos.y, pos.z)	
		end
	end)

	self.root:SetTooltip(hl_loc(INTRODUCE, INTRODUCE_ENG))
	
	-- local rx, ry = self.root:GetWorldPosition():Get()
	
	-- self.huli_infoui = self.root:AddChild(huli_infoui(self.owner, helpstr))
	self.huli_infoui = huli_infoui
	-- self.huli_infoui:SetPosition(rx - 180, ry + 240, 0)	
	-- self.huli_infoui:Hide()
	self.huli_infoui.fkk = self
	--按钮
	self.main = self.root:AddChild(ImageButton("images/huli_button.xml", "huli_button.tex"))
	self.main:SetScale(.44, .44, .44)
	self.main:SetOnClick(function()    
		if self.huli_infoui.shown then
			self.huli_infoui:Control()
		else
			self.huli_infoui:Control(true)
		end
	end)
	
	self.owner:ListenForEvent('信息UI面板控制事件', function(oo, ct) 
		if ct then
			self.main:SetTextures("images/huli_button1.xml", "huli_button1.tex")
		else
			self.main:SetTextures("images/huli_button.xml", "huli_button.tex")
		end
	end)
	
	huli_uiutil.DragableUI(self, "HuLi_MainUiSetting", self.root)
end)

function HuLi_InFoUiButton:Close()
	self.main:SetTextures("images/huli_button.xml", "huli_button.tex")
end

return HuLi_InFoUiButton