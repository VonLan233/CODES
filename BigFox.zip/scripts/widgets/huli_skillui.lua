--[[
★★★★★★★★★★★★★
★★★该文件已弃用★★★
★★★★★★★★★★★★★
]]


local Screen = require "widgets/screen"
local Widget = require "widgets/widget" 
local Text = require "widgets/text" 
local Button = require "widgets/button"
local AnimButton = require "widgets/animbutton"
local ImageButton = require "widgets/imagebutton"
local Image = require "widgets/image"
local TextEdit = require "widgets/textedit" 
local TextButton = require "widgets/textbutton"
local ImagePopupDialogScreen = require "screens/imagepopupdialog"
local PopupDialogScreen = require "screens/popupdialog"
local MouseTracker = require "widgets/mousetracker"
local TEMPLATES = require "widgets/templates"
local UIAnim = require "widgets/uianim"
local huli_uiutil = require "huli_uiutil"

local function leftrpc(player, test)
	if player.skilldmgset > 0 then
		if test then
			player.skilldmgset = player.skilldmgset - 10
		else
			player.skilldmgset = player.skilldmgset - 1
		end
	end
	if player.skilldmgset <= 0 then
		player.skilldmgset = 0
	end
end
AddModRPCHandler("huli_rpc", 'leftrpc', leftrpc)

local function rightrpc(player, test)
	if player.skilldmgset < 100 then
		if test then
			player.skilldmgset = player.skilldmgset + 10
		else
			player.skilldmgset = player.skilldmgset + 1
		end
	end
	if player.skilldmgset >= 100 then
		player.skilldmgset = 100
	end
end
AddModRPCHandler("huli_rpc", 'rightrpc', rightrpc)

local HuLi_SkillUi = Class(Widget, function(self, owner, cfg) 

	Widget._ctor(self, 'HuLi_SkillUi') 
	self.owner = owner
	self.cfg = cfg
	self.pos = Vector3(0, 0, 0)
	self.pos_y = -57
	
	self.root = self:AddChild(Widget("ROOT"))--设置一个爸爸
	-- self.root:SetVAnchor(ANCHOR_MIDDLE)--把整个界面的中心点设成屏幕中心点
	-- self.root:SetHAnchor(ANCHOR_MIDDLE)
	-- self.root:SetScaleMode(SCALEMODE_PROPORTIONAL)
	-- self.root:MoveToFront() --移动到前面
	--self.root:MoveToBack() --移动到后面
	-- self.root:SetScaleMode(SCALEMODE_PROPORTIONAL)
	
	self.bg = self.root:AddChild(Image("images/scoreboard.xml","scoreboard_frame.tex"))
	self.bg:SetSize(self.cfg.size[1], self.cfg.size[2])
	self.bg:SetTint(1, 1, 1, self.cfg.tint_A or 1)
	self.bg:SetPosition(self.cfg.pos or self.pos) 	
	-- self.bg:Hide()
----左/减
	self.left = self.bg:AddChild(ImageButton("images/global_redux.xml", "arrow2_left_over.tex"))
	self.left:SetPosition(-40, self.pos_y, 0)
	self.left:SetScale(.4, .3, .7)
	-- self.left:SetTooltip('')
	self.left:SetOnClick(function() self:Left(self.owner) end)
	
	self.left2 = self.bg:AddChild(ImageButton("images/global_redux.xml", "arrow2_left_over.tex"))
	self.left2:SetPosition(-80, self.pos_y, 0)
	self.left2:SetScale(.6, .3, .7)
	-- self.left2:SetTooltip('')
	self.left2:SetOnClick(function() self:Left(self.owner, true) end)
	
----右/加
	self.right = self.bg:AddChild(ImageButton("images/global_redux.xml", "arrow2_right_over.tex"))
	self.right:SetPosition(40, self.pos_y, 0)
	self.right:SetScale(.4, .3, .7)
	-- self.right:SetTooltip('')
	self.right:SetOnClick (function() self:Right(self.owner) end)	

	self.right2 = self.bg:AddChild(ImageButton("images/global_redux.xml", "arrow2_right_over.tex"))
	self.right2:SetPosition(80, self.pos_y, 0)
	self.right2:SetScale(.6, .3, .7)
	-- self.right2:SetTooltip('')
	self.right2:SetOnClick (function() self:Right(self.owner, true) end)	

----底字
	self.text = self.bg:AddChild(Text(DIALOGFONT, 28, ''))
	self.text:SetPosition(0, self.pos_y, 0)
	
----顶字
	self.toptext = self.bg:AddChild(Text(DIALOGFONT, 35, '技能元素消耗设置'))
	self.toptext:SetPosition(0, 60, 0)
----中间字
	self.toptext = self.bg:AddChild(Text(DIALOGFONT, 26, '消耗当前元素量百分比 \n消耗的元素越多,技能伤害越高\n消耗量达到一定值后技能冷却时间增加'))
	self.toptext:SetPosition(0, 0, 0)
	
	-- huli_uiutil.MakeDragableUI(self)
	self:StartUpdating()
	
end)

function HuLi_SkillUi:Left(player, test)
	if TheWorld.ismastersim then
		leftrpc(player, test)
	else
		SendModRPCToServer(MOD_RPC['huli_rpc']['leftrpc'], test)
	end
end

function HuLi_SkillUi:Right(player, test)
	if TheWorld.ismastersim then
		rightrpc(player, test)
	else
		SendModRPCToServer(MOD_RPC['huli_rpc']['rightrpc'], test)
	end	
end

function HuLi_SkillUi:OnUpdate(dt)
	self.text:SetString(self.owner._skilldmgset:value()..'%')
end

return HuLi_SkillUi