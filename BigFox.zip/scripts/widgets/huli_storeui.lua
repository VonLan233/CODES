local Screen = require "widgets/screen"
local Widget = require "widgets/widget" 
local Text = require "widgets/text" 
local Button = require "widgets/button"
local AnimButton = require "widgets/animbutton"
local ImageButton = require "widgets/imagebutton"
local Image = require "widgets/image"
local TextEdit = require "widgets/textedit" 
local TextButton = require "widgets/textbutton"
local ImagePopupDialogScreen = require "screens/imagepopupdialog"
local PopupDialogScreen = require "screens/popupdialog"
local MouseTracker = require "widgets/mousetracker"
local TEMPLATES = require "widgets/templates"
local UIAnim = require "widgets/uianim"

-- local function DoEffects(npc)
    -- SpawnPrefab("spawn_fx_medium").Transform:SetPosition(npc.Transform:GetWorldPosition())
-- end

local function SendRPC(rpcname, ... )
	SendModRPCToServer(MOD_RPC['huli_rpc'][rpcname], ...)
end

local InvSlot = Class(ImageButton, function(self, text) 
	ImageButton._ctor(self, 'images/hud.xml', 'inv_slot.tex') 
end)

function InvSlot:AddImg(xml, tex)
	self.img = self:AddChild(ImageButton(xml, tex))
end

function InvSlot:SetRClickFn(fn)
	self.RClickFn = fn
end

function InvSlot:OnControl(control, down)
	if InvSlot._base.OnControl(self, control, down) then return true end
	if not down and control == CONTROL_SECONDARY then
		if self.RClickFn then
			self:RClickFn()
			return true
		end
	end
end

local function SpawnRechargeNPC(player)
	local x,y,z = player.Transform:GetWorldPosition()
	player.components.huli_petleash:SpawnNPCAt(x,y,z,'huli_rechargenpc')
end
AddModRPCHandler("huli_rpc", '召唤NPC', SpawnRechargeNPC)
----------买东西
local function PurchItem(player, prefab, coinconsume, num)
	if player.components.huli_store then
		player.components.huli_store:ItemBuy(prefab, coinconsume, num)
	end
end
AddModRPCHandler('huli_rpc', '购买物品', PurchItem)

--[[
----------抽奖
local function LuckDrawFn(player, prefab, coinconsume)
	local prefab = prefab or TUNING.PRIZEITEM
	local itemtable = math.random(#prefab)
	local item = prefab[itemtable][1]
	local coinconsume = coinconsume or 100
	if player.components.huli_store.huli_coin >= coinconsume then
		player.components.huli_store:LuckDraw(item, coinconsume) 
	else
		player.components.talker:Say("狐狸币不足，请充值！")
	end
end
AddModRPCHandler("huli_rpc", "LuckDrawFn", LuckDrawFn)
]]

local HuLi_ArrowButton = Class(ImageButton, function(self, datas) 

	ImageButton._ctor(self, 'images/global_redux.xml', 'scrollbar_arrow_up.tex') 

	self.pos_x = datas.x or 0
	self.pos_y = datas.y or 0
	self.rotation = datas.rotation or 0
	self.tooltip = datas.tooltip or ''
	self.scale = datas.scale or .3
	self.WhileDownFn = datas.WhileDownFn
	self.d_time = .3
	
	local Old_WhileDownTime = 0
	self:SetScale(self.scale)
	self:SetPos(self.pos_x, self.pos_y, 0)
	self:SetRotation(self.rotation)
	self:SetTooltip(self.tooltip)
	self:SetTooltipPos(0, 20, 0)
	if self.WhileDownFn then
		self:SetWhileDown(function()
			if GetTime() - Old_WhileDownTime > self.d_time then
				Old_WhileDownTime = GetTime()
				self.d_time = self.d_time - FRAMES
				self:WhileDownFn()
			end
		end)
	end
	
	self:SetOnClick(function() self.d_time = .3 end)

end)

function HuLi_ArrowButton:SetPos(x, y, z)
	self:SetPosition(x, y, z)
end

local HuLi_Store = Class(Widget ,function(self, owner, goodsitem)

	Widget._ctor(self, "HuLi_Store") --创建这个界面,HuLi_Store为screen名称
	-- TheInput:ClearCachedController() --让玩家不能使用摁键? 禁用键盘操作
	self.owner = owner
    self.goodsitem = goodsitem
    self.page_number = 30

	self.root = self:AddChild(Widget("ROOT"))--可理解为创建屏幕的一个基础点
	self.root:SetVAnchor(ANCHOR_MIDDLE)--把整个界面的中心点设成屏幕中心点
	self.root:SetHAnchor(ANCHOR_MIDDLE)
	-- self.root:SetPosition(0,0,0)
	self.root:SetScaleMode(SCALEMODE_PROPORTIONAL)

	-- self.bg = self.root:AddChild(Image("images/ui.xml","black.tex"))
	self.bg = self.root:AddChild(Image("images/scoreboard.xml","scoreboard_frame.tex"))
	-- self.bg:SetVRegPoint(ANCHOR_MIDDLE)
	-- self.bg:SetHRegPoint(ANCHOR_MIDDLE)
	-- self.GoldCoin_bg:SetHAnchor(2)    --H: 0=中间 1=左端 2=右端
    -- self.GoldCoin_bg:SetVAnchor(1)    --V: 0=中间 1=顶端 2=底端
	-- self.bg:SetPosition(0,90,0)
	self.bg:SetSize(888, 666)
	self.bg:SetScale(.9, .9, .9)
	-- self.bg:SetTint(1, 1, 1, .8)
	self.bg:Hide()
	self.inst:DoTaskInTime(0, function() self:MoveToBack() end)
	
----------关闭按钮
	self.bg_close = self.bg:AddChild(ImageButton("images/global_redux.xml", "close.tex"))
	-- self.bg_close:SetScale(.5, .5, .5)
	self.bg_close:SetPosition(370,-243,0) 
	self.bg_close:SetTooltip(hl_loc('关闭', 'Close'))
	self.bg_close:SetOnClick(function()    
		self:Control()
	end)
----------商店图标按钮
	self.main = self.root:AddChild(ImageButton("images/storehud/huli_storebutton.xml", "huli_storebutton.tex"))
	self.main:SetScale(.88, .88, .88)
	self.main:SetHAnchor(1) 
	self.main:SetVAnchor(2) 
	self.main:SetPosition(60,40,0) 
	self.main:SetTooltip(hl_loc('狐狸商店', 'Fox store'))
	
	self.main:SetOnClick(function()    
		if self.bg.shown then
			self:Control()
		else
			self:Control(true)
		end
	end)
	
	self.owner:ListenForEvent('狐狸商店开关事件', function(oo, ct) 
		if ct then
			self.bg:Show()
		else
			self['获取数量bg']:Hide()
			self.bg:Hide()
		end
	end)

--[[
	-- self.main_text = self.main:AddChild(TextButton())
	-- self.main_text:SetScale(.5, .5, .5)
	-- self.main_text:SetHAnchor(1) 
	-- self.main_text:SetVAnchor(2) 
	-- self.main_text:SetPosition(60,50,0) 
	-- self.main_text:SetText('狐狸\n商店') 
	-- self.main_text:SetTextSize(35) 
	-- self.main_text:SetTextColour(22/255, 242/255, 53/255, 1)
	-- self.main_text:SetOverColour(252/255, 231/255, 28/255, 1) 

----------抽奖背景
	-- self.luck_draw = self.bg:AddChild(ImageButton("images/storehud/luck_draw.xml", "luck_draw.tex"))
	-- self.luck_draw:SetPosition(337, 87, 0)
	-- self.luck_draw:SetOnClick(function() 
		-- for list = 1, #self.goodsitem do
			-- if self.goods.listbutton[list].goodsitem_bg.shown then
				-- self.goods.listbutton[list].goodsitem_bg:Hide()
			-- end
		-- end
	-- end)
	
----------动画
	-- self.luck_draw_anim = self.bg:AddChild(UIAnim())
	-- self.luck_draw_anim:SetPosition(300, -200, 0)
	-- self.luck_draw_anim:SetScale(1, 1)
	-- self.luck_draw_anim:GetAnimState():SetBuild("luck_draw_anim")
	-- self.luck_draw_anim:GetAnimState():SetBank("luck_draw_anim")
	-- self.luck_draw_anim:GetAnimState():PlayAnimation("idle", true)	
----------抽奖按钮
	-- self.luck_draw_button = self.luck_draw:AddChild(ImageButton("images/storehud/luck_draw_button.xml", "luck_draw_button.tex"))
	-- self.luck_draw_button = self.bg:AddChild(ImageButton("images/hud.xml","inv_slot.tex"))
	-- self.luck_draw_button:SetPosition(300, -100, 0)
	-- self.luck_draw_button:SetTooltip('抽奖')
	
	-- self.luck_draw_button:SetOnClick(function() 
		-- if not self.owner:HasTag("playerghost") then
			-- if TheWorld.ismastersim then
				-- LuckDrawFn(self.owner)
			-- else
				-- SendModRPCToServer(GetModRPC("huli_rpc", "LuckDrawFn"))
			-- end
		-- end
	-- end)
]]
----------商品显示位置
	self.goods = self.bg:AddChild(Widget("goods"))
	self.goods:SetPosition(68 ,-23, 0)
	self.goods.listbutton = {}
	self.goodslist = {
		[1] = hl_loc('★资源类★', 'Resources'),
		[2] = hl_loc('★装备类★', 'Equip'),
		[3] = hl_loc('★食物类★', 'Food'),
		[4] = hl_loc('★狐狸专属★', 'FoxItem'),
	}

	for listnum = 1, #self.goodsitem  do
		local pos_y = - (75 * (listnum - 1 ))
----------商品主界面物品目录列表背景
		self.goods.listbutton[listnum] = self.bg:AddChild(ImageButton("images/storehud/goodslistimg.xml", "goodslistimg.tex"))
		local sgll = self.goods.listbutton[listnum]
		sgll:SetPosition(-300, 50 + pos_y, 0)
		sgll:SetImageNormalColour(1, 1, 1, .8)
		-- sgll:SetScale(1, 1, 1)

		self.list_text = sgll:AddChild(TextButton())
		self.list_text:SetText(self.goodslist[listnum])
		self.list_text:SetTextSize(30)
		self.list_text:SetTextColour(22/255, 242/255, 53/255, 1)
		self.list_text:SetOverColour(252/255, 231/255, 28/255, 1)
----------商品信息主界面
		sgll.goodsitem_bg = self.bg:AddChild(Image("images/ui.xml","in-window_button_tile_hl_noshadow.tex"))
		sgll.goodsitem_bg:SetTint(1, 1, 1, .8)
		sgll.goodsitem_bg:SetSize(500 ,460, 0)
		sgll.goodsitem_bg:SetPosition(-5 ,-8, 0)
		sgll.goodsitem_bg:Hide()
		
----------顶端类别显示
		self.goodslist_bg = sgll.goodsitem_bg:AddChild(Image("images/ui.xml","update_banner.tex"))
		self.goodslist_bg:SetTint(1, 1, 1, .8)
		self.goodslist_bg:SetPosition(-8 ,242, 0)
		
		self.goodslist_bg_text = self.goodslist_bg:AddChild(Text(NEWFONT_OUTLINE, 37, self.goodslist[listnum], {50/255, 237/255, 13/255, 1}))
		self.goodslist_bg_text:SetPosition(0 ,10, 0)
	
		sgll:SetOnClick(function()	
			for list = 1, #self.goodsitem do
				if list == listnum then
					sgll.goodsitem_bg:Show()
				else
					self.goods.listbutton[list].goodsitem_bg:Hide()
				end
			end
			self:CreatItems(listnum)
		end)
		sgll.currentpage = 1
		sgll.maxpage = math.ceil(#self.goodsitem[listnum] / self.page_number) or 1
		-- self.owner:PushEvent('huli_store_currentpage', {sgll = sgll})
		
		sgll.items = sgll.goodsitem_bg:AddChild(Widget("goods"))
		-- sgll.items:SetPosition(0,0, 0)
		
----------上一页
		sgll.lastpage = sgll.goodsitem_bg:AddChild(ImageButton("images/global_redux.xml", "arrow2_left_over.tex"))
		sgll.lastpage:SetPosition(-50, -235, 0)
		sgll.lastpage:SetScale(.8, .4, .7)
		sgll.lastpage:SetTooltip(hl_loc('上一页', 'last page'))
		sgll.lastpage:SetOnClick(function() self:PageLast(listnum) end)
		sgll.lastpage:Hide()

		sgll.lastpage_disabled = sgll.goodsitem_bg:AddChild(Image("images/global_redux.xml", "arrow_left_disabled.tex"))
		sgll.lastpage_disabled:SetPosition(-50, -235, 0)
		sgll.lastpage_disabled:SetScale(.8, .4, .7)
		sgll.lastpage_disabled:SetTooltip(hl_loc('上一页', 'last page'))

----------页码
		sgll.pages = sgll.goodsitem_bg:AddChild(Text(DIALOGFONT, 35))
		sgll.pages:SetPosition(-3, -235, 0)
		sgll.pages:SetString(sgll.currentpage.."/"..sgll.maxpage)
		-- sgll.pages:SetColour(0, 0, 0, 1)
----------下一页
		sgll.nextpage = sgll.goodsitem_bg:AddChild(ImageButton("images/global_redux.xml", "arrow2_right_over.tex"))
		sgll.nextpage:SetPosition(45, -235, 0)
		sgll.nextpage:SetScale(.8, .4, .7)
		sgll.nextpage:SetTooltip(hl_loc('下一页', 'next page'))
		sgll.nextpage:SetOnClick (function() self:PageNext(listnum) end)	
		
		sgll.nextpage_disabled = sgll.goodsitem_bg:AddChild(Image("images/global_redux.xml", "arrow_right_disabled.tex"))
		sgll.nextpage_disabled:SetPosition(45, -235, 0)
		sgll.nextpage_disabled:SetScale(.8, .4, .7)
		sgll.nextpage_disabled:SetTooltip(hl_loc('下一页', 'next page'))
		sgll.nextpage_disabled:Hide()
		
		self.owner._currentpage:set(sgll.currentpage)
		self.owner:ListenForEvent('huli_coin' , function() self:CreatItems(listnum) end)
		self.owner:ListenForEvent('huli_store_currentpage' , function() 
			if sgll.currentpage > 1 then
				sgll.lastpage:Show()
				sgll.lastpage_disabled:Hide()
			else
				sgll.lastpage:Hide()
				sgll.lastpage_disabled:Show()
			end
			if sgll.currentpage < sgll.maxpage then 	
				sgll.nextpage:Show()
				sgll.nextpage_disabled:Hide()
			else
				sgll.nextpage:Hide()
				sgll.nextpage_disabled:Show()
			end
		end)
		self.owner:PushEvent('huli_store_currentpage', {sgll = sgll})
		self:CreatItems(listnum)
	end
----------狐狸币
	self.GoldCoin_bg = self.bg:AddChild(Image("images/ui.xml", "button_large.tex"))
	self.GoldCoin_bg:SetPosition(300, 240, 0)
	self.GoldCoin_bg:SetSize(140, 40, 0)
	-- self.GoldCoin_bg:SetScale(1, .6, 1)
	-- self.GoldCoin_bg:SetTooltip('狐狸币')
	
	self.GoldCoin_text_ico = self.GoldCoin_bg:AddChild(Image("images/storehud/huli_coinico.xml", "huli_coinico.tex"))
	self.GoldCoin_text_ico:SetScale(.4, .4, .4)
	self.GoldCoin_text_ico:SetPosition(45, 3, 0)
	self.GoldCoin_text_ico:SetTooltip(hl_loc('狐狸币', 'Fox coins'))
	
	self.GoldCoin_text = self.GoldCoin_bg:AddChild(Text(DEFAULTFONT, 27, ''))
	-- self.GoldCoin_text:KillAllChildren()
	self.GoldCoin_text:SetColour(22/255, 242/255, 53/255, 1)
	self.GoldCoin_text:SetPosition(-15, 3, 0)
	
	self.GoldCoin_recharge = self.GoldCoin_bg:AddChild(ImageButton("images/storehud/recharge.xml", "recharge.tex"))
	self.GoldCoin_recharge:SetPosition(77, 3, 0)
	self.GoldCoin_recharge:SetScale(.5, .5, .5)
	self.GoldCoin_recharge:SetTooltip(hl_loc('我要充钱', 'I want to recharge.'))
	
	self.GoldCoin_recharge:SetOnClick(function() 
		if TheWorld.ismastersim then
			SpawnRechargeNPC(self.owner)
		else
			SendRPC('召唤NPC')
		end
		self:Control()
	end)
	
	self['获取数量bg'] = self.root:AddChild(Image('images/ui.xml', 'black.tex'))
	self['获取数量bg']:SetSize(hl_loc(255, 300), 180)
	self['获取数量bg']:SetScale(.8)
	self['获取数量bg']:SetTint(0, 0, 0, .9)
	self['获取数量bg']:Hide()
	local set_bg_w, set_bg_h = self['获取数量bg']:GetSize()
	
	local AddButton = {
		{name = hl_loc('取消', 'cancel'), fn = function() self['获取数量bg']:Hide() end},
		{name = hl_loc('重置', 'reset'), fn = function() self:ReSetItemNumFn() end},
		{name = hl_loc('确定', 'accept'), fn = function() self:GetItem() end},
	}
	for k, v in pairs(AddButton) do
		self['底下按钮'..k] = self['获取数量bg']:AddChild(TextButton())
		self['底下按钮'..k]:SetPosition(-(hl_loc(70, 90) * (#AddButton + 1) / 2) + k * hl_loc(70, 90), -set_bg_h/2 + 40, 0)
		self['底下按钮'..k]:SetText(v.name)
		self['底下按钮'..k]:SetColour(92/255,255/255,75/255,1)
		self['底下按钮'..k]:SetOverColour(252/255, 231/255, 28/255, 1)
		self['底下按钮'..k]:SetTextSize(30)
		self['底下按钮'..k]:SetOnClick(v.fn)
	end

	self['获取物品数量字'] = self['获取数量bg']:AddChild(Text(DEFAULTFONT, 30, '1'))	
	self['设置数量UI左箭头'] = self['获取数量bg']:AddChild(HuLi_ArrowButton({x = -45, rotation = -90, WhileDownFn = function() self:SetItemNumFn(-1) end, tooltip = hl_loc('按住可连续减少', 'Press and hold to decrease continuously')}))
	self['设置数量UI右箭头'] = self['获取数量bg']:AddChild(HuLi_ArrowButton({x = 45, rotation = 90, WhileDownFn = function() self:SetItemNumFn(1) end,  tooltip = hl_loc('按住可连续增加', 'Press and hold to increase continuously')}))	

	
----------预显示
	self.goods.listbutton[1].goodsitem_bg:Show()

	self:StartUpdating()
end)

----------商品刷新
function HuLi_Store:CreatItems(listnum)

	self.goods.listbutton[listnum].items:KillAllChildren()
	
	for column = 1, 5, 1 do
		for line = 1, 6, 1 do 
			local sgll = self.goods.listbutton[listnum]
			local num = (sgll.currentpage - 1) * 30 + (column - 1) * 6 + line

			if num <= #self.goodsitem[listnum] then
				local _prefab = self.goodsitem[listnum][num][1]
				local _Price = self.goodsitem[listnum][num][2] or 99999
				
				local _name = self.goodsitem[listnum][num][1]
				if STRINGS.NAMES[string.upper(_prefab)] ~= nil and STRINGS.NAMES[string.upper(_prefab)] ~= "" then
					_name = STRINGS.NAMES[string.upper(_prefab)]
					-- if type(_name) == 'table' then
						-- _name = _name[STRINGS.NAMES[string.upper(_name)]]
					-- else
					-- end
				end
				local pos = Vector3(line - line * .5, column - column * .5 ,0)
				self['物品槽'] = sgll.items:AddChild(InvSlot())
				self['物品槽']:SetTooltip(_name)
				self['物品槽']:SetPosition(73 * (line - 3) - 40, -80 * (column - 2.8) + 28, 0)
				self['物品槽']:SetScale(.8, .8, .8)
				----------图标
				self['物品槽']:AddImg(GetInventoryItemAtlas(_prefab..'.tex'), _prefab..'.tex')

				self['物品槽']:SetOnClick(function()
					self:ItemClick(_prefab, _Price)
				end)

				self['物品槽']:SetRClickFn(function()
					if not self.owner:HasTag("playerghost") then
						if TheWorld.ismastersim then
							PurchItem(self.owner, _prefab, _Price)
						else
							SendRPC('购买物品', _prefab, _Price)
						end
					end
				end)
				----------价格显示
				self.text_num = self['物品槽']:AddChild(Text(DEFAULTFONT, 30))
				self.text_num:SetString(''.._Price)
				self.text_num:SetPosition(-5, -50, 0)
				-- self.text_num:SetColour(249/255,43/255,43/255,1)
				if self.owner._huli_coin:value() >= _Price then
					self.text_num:SetColour(50/255, 237/255, 13/255, 1)
				else
					self.text_num:SetColour(249/255, 43/255, 43/255, 1)
				end
			end
		end
    end
end

function HuLi_Store:ItemClick(name, price)
	self['设置物品名'] = name
	self['设置物价格'] = price
	self:ReSetItemNumFn()
	self['获取数量bg']:Show()
	self['获取数量bg']:MoveToFront()
end

function HuLi_Store:ReSetItemNumFn()
	self.SetItemNum = 1
	self['获取物品数量字']:SetString(self.SetItemNum)
end

function HuLi_Store:SetItemNumFn(num)
	local maxnum = math.floor(self.owner._huli_coin:value() / self['设置物价格'])
	if maxnum >= 200 then
		maxnum = 200
	elseif maxnum <= 1 then
		maxnum = 1
	end

	self.SetItemNum = self.SetItemNum + num
	if self.SetItemNum <= 1 then
		self.SetItemNum = 1
	elseif self.SetItemNum >= maxnum then
		self.SetItemNum = maxnum
	end
	self['获取物品数量字']:SetString(self.SetItemNum)
end

function HuLi_Store:GetItem()	
	if self.owner:HasTag("playerghost") then return end
	SendRPC('购买物品', self['设置物品名'], self['设置物价格'], tonumber(self['获取物品数量字']:GetString()))
	self['获取数量bg']:Hide()
end
	
----------上一页
function  HuLi_Store:PageLast(listnum)
	local sgll = self.goods.listbutton[listnum]
    if sgll.currentpage <= 1 then 	
		return 
	else
		sgll.currentpage = sgll.currentpage - 1 
	end
    self:CreatItems(listnum)
    sgll.pages:SetString(sgll.currentpage.."/"..sgll.maxpage)
	self.owner._currentpage:set(sgll.currentpage)
	self.owner:PushEvent('huli_store_currentpage', {sgll = sgll})
end

----------下一页
function  HuLi_Store:PageNext(listnum)
	local sgll = self.goods.listbutton[listnum]
    if sgll.currentpage >= sgll.maxpage then
		return  
	else
		sgll.currentpage = sgll.currentpage + 1
	end
    self:CreatItems(listnum)
    sgll.pages:SetString(sgll.currentpage.."/"..sgll.maxpage)
	self.owner._currentpage:set(sgll.currentpage)
	self.owner:PushEvent('huli_store_currentpage', {sgll = sgll})
end

function HuLi_Store:Control(ctrl)
	self.owner:PushEvent('狐狸商店开关事件', ctrl)
end

function HuLi_Store:OnControl(control, down)
	if HuLi_Store._base.OnControl(self, control, down) then 
		return true 
	end
	-- if down then
		-- if control == 13 or control == 30 or control == 42 then
			-- self:Control()
			-- return true
		-- end
	-- end
end

function HuLi_Store:OnRawKey(key, down)
    if HuLi_Store._base.OnRawKey(self, key, down) then return true end
	if down then
		if key == 27 or key == 96 then
			self:Control()
			return true
		end
	end
end

function HuLi_Store:OnUpdate(dt)
	self.GoldCoin_text:SetString(''..self.owner._huli_coin:value())
end

return HuLi_Store