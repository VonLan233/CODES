local Screen = require "widgets/screen"
local Widget = require "widgets/widget" 
local Text = require "widgets/text" 
local Button = require "widgets/button"
local AnimButton = require "widgets/animbutton"
local ImageButton = require "widgets/imagebutton"
local Image = require "widgets/image"
local TextEdit = require "widgets/textedit" 
local TextButton = require "widgets/textbutton"
local ImagePopupDialogScreen = require "screens/imagepopupdialog"
local PopupDialogScreen = require "screens/popupdialog"
local MouseTracker = require "widgets/mousetracker"
local TEMPLATES = require "widgets/templates"
local UIAnim = require "widgets/uianim"


local HuLi_Ui_Help = Class(Widget ,function(self, owner, helpstr)

	Widget._ctor(self, "HuLi_Ui_Help") --创建这个界面,HuLi_Store为screen名称
	-- TheInput:ClearCachedController() --让玩家不能使用摁键? 禁用键盘操作
	self.owner = owner
    self.helpstr = helpstr
    self.page_number = 30

	self.root = self:AddChild(Widget("ROOT"))--可理解为创建屏幕的一个基础点
	self.root:SetVAnchor(ANCHOR_MIDDLE)--把整个界面的中心点设成屏幕中心点
	self.root:SetHAnchor(ANCHOR_MIDDLE)
	-- self.root:SetPosition(0,0,0)
	self.root:SetScaleMode(SCALEMODE_PROPORTIONAL)

	-- self.bg = self.root:AddChild(Image("images/ui.xml","black.tex"))
	self.bg = self.root:AddChild(Image("images/scoreboard.xml","scoreboard_frame.tex"))
	self.bg:SetVRegPoint(ANCHOR_MIDDLE)
	self.bg:SetHRegPoint(ANCHOR_MIDDLE)
	-- self.bg:SetHAnchor(2)    --H: 0=中间 1=左端 2=右端
    -- self.bg:SetVAnchor(1)    --V: 0=中间 1=顶端 2=底端
	-- self.bg:SetPosition(0,90,0)
	self.bg:SetSize(888, 666)
	self.bg:SetScale(.9, .9, .9)
	-- self.bg:SetTint(1, 1, 1, .8)
	-- self.bg:Hide()
	self.inst:DoTaskInTime(0, function() self:MoveToBack() end)
	
	self.bg_close = self.bg:AddChild(ImageButton("images/global_redux.xml", "close.tex"))
	-- self.bg_close:SetScale(.5, .5, .5)
	self.bg_close:SetPosition(370,-243,0) 
	self.bg_close:SetTooltip(hl_loc('关闭', 'Close'))
	self.bg_close:SetOnClick(function()    
		if self.shown then
			self:Hide()
		end
	end)
----------帮助按钮
	-- self.main = self.root:AddChild(Widget("MAIN"))
	-- self.main:SetVAnchor(ANCHOR_BOTTOM)
	-- self.main:SetHAnchor(ANCHOR_LEFT)
	-- self.main:SetPosition(150, 25, 0)
	
	-- self.main_text = self.main:AddChild(TextButton())
	-- self.main_text:SetText('帮助/Help')
	-- self.main_text:SetTextSize(30)
	-- self.main_text:SetTextColour(22/255, 242/255, 53/255, 1)
	-- self.main_text:SetOverColour(252/255, 231/255, 28/255, 1)
	-- self.main_text:SetOnClick(function()    
		-- if self.bg.shown then
			-- self.bg:Hide()
		-- else
			-- self.bg:Show()
		-- end
	-- end)
	
	self.bg_text = self.bg:AddChild(Text(NEWFONT_OUTLINE, 45, '帮助/Help'))
	self.bg_text:SetPosition(-300, 250, 0)
	
----------显示位置
	self.help = self.bg:AddChild(Widget("help"))
	self.help:SetPosition(68 ,-23, 0)
	self.help.listbutton = {}

	for listnum = 1, #self.helpstr  do
		local pos_y = - (22 * (listnum - 1 ))
----------目录列表
		self.help.listbutton[listnum] = self.bg:AddChild(Widget('text_root'))
		local shll = self.help.listbutton[listnum]
		shll:SetPosition(-310, 207 + pos_y, 0)
		-- shll:SetScale(1, 1, 1)
		if listnum >= 21 then
			shll:SetPosition(310, 647 + pos_y, 0)
		end

		self.list_text = shll:AddChild(TextButton())
		self.list_text:SetText(self.helpstr[listnum][1])
		self.list_text:SetTextSize(27)
		self.list_text:SetTextColour(22/255, 242/255, 53/255, 1)
		self.list_text:SetOverColour(252/255, 231/255, 28/255, 1)
----------说明显示主界面
		shll.helpstr_bg = self.bg:AddChild(Image("images/ui.xml","in-window_button_tile_hl_noshadow.tex"))
		shll.helpstr_bg:SetTint(1, 1, 1, .8)
		shll.helpstr_bg:SetSize(500 ,460, 0)
		shll.helpstr_bg:SetPosition(5 ,-8, 0)
		shll.helpstr_bg:Hide()
		
----------顶端目录显示
		self.goodslist_bg = shll.helpstr_bg:AddChild(Image("images/ui.xml","update_banner.tex"))
		self.goodslist_bg:SetTint(1, 1, 1, .8)
		self.goodslist_bg:SetPosition(-8 ,242, 0)
		
		self.goodslist_bg_text = self.goodslist_bg:AddChild(Text(NEWFONT_OUTLINE, 33, self.helpstr[listnum][1], {50/255, 237/255, 13/255, 1}))
		self.goodslist_bg_text:SetPosition(0 ,10, 0)
	
		self.list_text:SetOnClick(function()	
			for list = 1, #self.helpstr do
				if list == listnum then
					shll.helpstr_bg:Show()
				else
					self.help.listbutton[list].helpstr_bg:Hide()
				end
			end
			self:HelpStr(listnum)
		end)
		
		shll.help_text = shll.helpstr_bg:AddChild(Widget("help"))
		-- shll.help_text:SetPosition(0,0, 0)
		
		self:HelpStr(listnum)
	end
		
----------预显示
	self.help.listbutton[1].helpstr_bg:Show()

	-- self:StartUpdating()
end)

----------说明显示
function HuLi_Ui_Help:HelpStr(listnum)

	self.help.listbutton[listnum].help_text:KillAllChildren()
	local shll = self.help.listbutton[listnum]
	local Str = '★'..self.helpstr[listnum][2] or ''
	
	self.text = shll.help_text:AddChild(Text(DEFAULTFONT, 28))
	-- self.text:SetPosition(-5, -50, 0)
	-- self.text:SetString(Str)
	self.text:SetMultilineTruncatedString(Str, 20, 450, nil, nil)
	self.text:SetHAlign(ANCHOR_LEFT)
	-- self.text:SetColour(249/255,43/255,43/255,1)
end

function HuLi_Ui_Help:Close()
	self:Hide()
end

function HuLi_Ui_Help:OnControl(control, down)
	if HuLi_Ui_Help._base.OnControl(self, control, down) then 
		return true 
	end
	if not down then
		if control == 13 or control == 30 then
			self:Close()
		end
	end
	return true
end

function HuLi_Ui_Help:OnUpdate(dt)

end

return HuLi_Ui_Help