local Screen = require "widgets/screen"
local Widget = require "widgets/widget" 
local Text = require "widgets/text" 
local Button = require "widgets/button"
local AnimButton = require "widgets/animbutton"
local ImageButton = require "widgets/imagebutton"
local Image = require "widgets/image"
local TextEdit = require "widgets/textedit" 
local TextButton = require "widgets/textbutton"
local ScrollableList = require "widgets/scrollablelist"
local huli_updateui_ls = require "widgets/huli_updateui_ls"
local huli_uiutil = require "huli_uiutil"


local Str_cn = {
	"以下是本次更新内容：",
	"1、修复芭蕉扇给“假人”会导致崩溃的bug。。",
	"2、小龙二阶段：新增升级功能、远程火球攻击。。。",
	"",
}

local Str_Eng = {

	"The following is the content of this update：", --以下是本次更新内容
	"1、Fixed a bug that caused the game to crash when equipping Mannequin with gumifan.",
	"2、mir Phase 2: Added upgrade function and remote fireball attack.",
	"",

}

local function GetModVer()
	local ver
	-- if KnownModIndex:IsModEnabled("TheMillenniumHuLi") then
		-- ver = GetModVersion("TheMillenniumHuLi")
	-- elseif KnownModIndex:IsModEnabled("workshop-1694540893") then
		-- ver = GetModVersion("workshop-1694540893")
	-- end
	if hl_modinfo.version then
		ver = hl_modinfo.version
	end
	return ver
end

local function GetVerStr()
	local str = GetModVer()
	return str and hl_loc("(大狐狸)", "(MillenniumFox)")..str..hl_loc("版本更新说明", "Version update description") or hl_loc("错误：无法获取MOD版本号", "Error: Unable to get MOD version number")
end

local function Pos_y(tar)
	local x, y = tar:GetPosition():Get()
	return y
end

local HuLi_UpDateUi = Class(Widget, function(self, owner) 

	Widget._ctor(self, 'HuLi_UpDateUi') 
	self.owner = owner
	self.version = 0
	
	self.textsize = 40
	self.TextFont = SMALLNUMBERFONT
		
	self.root = self:AddChild(Widget("ROOT"))
	self.root:SetVAnchor(ANCHOR_MIDDLE)
	self.root:SetHAnchor(ANCHOR_MIDDLE)
	self.root:SetScaleMode(SCALEMODE_PROPORTIONAL)
	-- self:MoveToFront()
	-- self:MoveToBack()
	
	self['历史更新面板'] = self:AddChild(huli_updateui_ls(self.owner))
	self['历史更新面板']:Hide()
	
	self.bg = self.root:AddChild(Image("images/scoreboard.xml","scoreboard_frame.tex"))
	-- self.bg:SetPosition(250, -150, 0) 	
	self.bg:SetSize(hl_loc(800, 1000), 600)
	

	self.textlist = {}
	local VersionUpdateStr = hl_loc(Str_cn, Str_Eng)
	for i, v in ipairs(VersionUpdateStr) do
        local widg = Widget("str"..i)
        -- local strWidg = widg:AddChild(Text(NEWFONT, 25, "", {0,0,0,1}))
        local strWidg = widg:AddChild(Text(NEWFONT, 22, ""))
        -- strWidg:SetTruncatedString(i.."："..v, 600, 275, true)
        -- strWidg:SetMultilineTruncatedString(i.."："..v, 30, 580)
        strWidg:SetMultilineTruncatedString(v, 30, hl_loc(580, 800))
		strWidg:SetHAlign(ANCHOR_LEFT)
        local w, h = strWidg:GetRegionSize()
        strWidg:SetPosition(hl_loc(23, 0) + w * .5, 0, 0)
		-- strWidg:SetPosition(23 + w * .5, -#v/580*28, 0)
        widg.text = strWidg
        table.insert(self.textlist, widg)
		
    end
	
	self["更新内容文本"] = self.bg:AddChild(ScrollableList(self.textlist, hl_loc(630, 810), 360, 35, hl_loc(5, 15), nil, nil, nil, nil, nil, 10, nil, nil, "GOLD"))
	self["更新内容文本"]:SetPosition(-10, -10)
	
	self["标题"] = self.bg:AddChild(Text(BODYTEXTFONT, self.textsize, GetVerStr()))
	-- self["标题"]:SetColour(92/255,255/255,75/255,1)
    self["标题"]:SetPosition(0,220,0) 

	self["关闭按钮"] = self.bg:AddChild(ImageButton("images/global_redux.xml", "close.tex"))
	-- self["关闭按钮"]:SetScale(.7,.7)
	self["关闭按钮"]:SetPosition(hl_loc(320, 390), 210, 0)
	self["关闭按钮"]:SetTooltip(hl_loc("关闭窗口", "close window"))
	self["关闭按钮"]:SetOnClick(function() 
		self.bg:Hide() 
	end)

	self["历史更新面板按钮"] = self.bg:AddChild(TextButton())
	self["历史更新面板按钮"]:SetPosition(hl_loc(220, 280), -220, 0)
	self["历史更新面板按钮"]:SetText(hl_loc("历史更新", "History update"))
	self["历史更新面板按钮"]:SetColour(92/255,255/255,75/255,1)
	self["历史更新面板按钮"]:SetOverColour(252/255, 231/255, 28/255, 1)
	self["历史更新面板按钮"]:SetTextSize(hl_loc(self.textsize, 25))
	self["历史更新面板按钮"]:SetTooltip(hl_loc('历史更新记录', "History update record"))
	self["历史更新面板按钮"]:SetOnClick(function() 
		self.bg:Hide() 
		self['历史更新面板']:Show()
	end)

	self["不再显示按钮"] = self.bg:AddChild(TextButton())
    self["不再显示按钮"]:SetPosition(hl_loc(-260, -300), -220, 0) 
	self["不再显示按钮"]:SetText(hl_loc("不再显示", "Don't show again"))
	self["不再显示按钮"]:SetColour(92/255,255/255,75/255,1)
	self["不再显示按钮"]:SetOverColour(252/255, 231/255, 28/255, 1)
	self["不再显示按钮"]:SetTextSize(hl_loc(self.textsize, 25))
	self["不再显示按钮"]:SetTooltip(hl_loc('下次更新前不再自动显示', "Don't show it automatically until the next update"))
	self["不再显示按钮"]:SetOnClick(function()
		TheSim:SetPersistentString("HuLi_UpDateUiData", json.encode({version = GetModVer()}), false)
		self.bg:Hide() 
	end)
	
	TheSim:GetPersistentString("HuLi_UpDateUiData", function(load_success, data) 
		if load_success and data then
			data = json.decode(data)
			self.version = data.version
		end
	end)
	
	self.inst:DoTaskInTime(0, function()
		self:MoveToBack()
		if self.version == GetModVer() then
			self.bg:Hide() 
		end
	end)
	
	self.owner:ListenForEvent("更新面板开关事件", function() self:Control() end)
	huli_uiutil.CtrlScale(self.bg)
end)

function HuLi_UpDateUi:Control()
	if self.bg.shown then
		self.bg:Hide()
	else
		self.bg:Show()
	end
	self['历史更新面板']:Hide()
end

function HuLi_UpDateUi:OnControl(control, down)
    if HuLi_UpDateUi._base.OnControl(self,control, down) then 
		return true 
	end

    if not down then
		if control == 13 or control == 42 then
		   self:Control()
		   return true
		end
	end
end

-- function HuLi_UpDateUi:OnRawKey(key, down)
    -- if HuLi_UpDateUi._base.OnRawKey(self, key, down) then return true end
	-- if down and key == 27 then self.bg:Hide() return end
-- end

return HuLi_UpDateUi