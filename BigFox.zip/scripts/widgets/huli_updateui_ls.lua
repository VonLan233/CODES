local Screen = require "widgets/screen"
local Widget = require "widgets/widget" 
local Text = require "widgets/text" 
local Button = require "widgets/button"
local AnimButton = require "widgets/animbutton"
local ImageButton = require "widgets/imagebutton"
local Image = require "widgets/image"
local TextEdit = require "widgets/textedit" 
local TextButton = require "widgets/textbutton"
local ScrollableList = require "widgets/scrollablelist"
local huli_uiutil = require "huli_uiutil"


local Str_cn = {
	-- {	ver = '2.5.7.0',
		-- str = {
			-- "",
		-- }
	-- },
	{	ver = '2.5.6.0',
		str = {
			"1、修复龙卷风技能杀死的怪物不掉狐狸宝石的BUG。。",
			"2、优化冰狐狸冰域技能的减速效果不再对小狐狸箱、小龙、小妾之类的生效。。",
			"3、修复装备芭蕉扇时不能右键点小狐狸、小龙停止跟随的bug。。",
		}
	},
	{	ver = '2.5.5.0',
		str = {
			"1、修复小龙打怪不加经验的bug。。",
			"2、龙卷风技能调整。。",
		}
	},
	{	ver = '2.5.4.0',
		str = {
			"1、新增芭蕉扇技能，右键释放龙卷风技能，消耗精神，扇子耐久。。",
			"2、商店新增：无花果，盐晶。。",
			"3、商店新增：可调整回收价格比例，在MOD设置中设置。。", 
		}
	},
	{	ver = '2.5.3.0',
		str = {
			"1、商店增加物品：种壳，藤壶，土豆，西红柿，辣椒，大蒜，洋葱，鼹鼠。", 
			"2、增加两种石笋矿石掉落狐狸专属宝石。",
		}
	},
	{	ver = '2.5.2.0',
		str = {
			"1、狐狸商店增加批量购买功能，鼠标左键批量购买，鼠标右键单个购买", 
		}
	},
	{	ver = '2.5.1.0',
		str = {
			"以下是本次更新内容：",
			"1、修复mod设置里面商店开关设置选项显示错误问题", ----------
			"2、修复扇子装备期间，扇子的台词却与当前语言不匹配的问题", --------
			"3、修复狐狸商店某些商品图标不显示的问题", --------
			"4、新增可查看历史更新内容的UI面板，可在信息UI面板中打开", --------
			"5、商店增加了一些新的物品，作者已经较久没玩过饥荒了，所以对目前一些物品的获取难易度不太了解，可能定价不太靠谱，要是有离谱的地方（包括以前的物品定价），欢迎大家反馈。", 
			"6、其它优化。。。",
			"",
		}
	},
	{	ver = '2.5.0.0',
		str = {
			"注：本次更新我还是做了一些旧档兼容，但还是有可能会让已有的大狐狸存档出现一些问题，要是没问题，那就继续玩耍，要是出现问题，建议重新开档。。。",

			"以下是本次更新内容：",
			"1、修复铃铛在身上时退出游戏后，下次进入游戏时铃铛却出现在地面的BUG。", -----
			"2、更改人物打怪获取经验方式，更改为只要造成伤害就能获得经验和元素。【原来是要杀死怪物才能获得经验和元素】", -----
			"3、增加英文支持的覆盖率", -----
			"4、专属宠物优化：防止自相残杀。", -----
			"5、狐狸商店：", -----
			"一、进一步降低物品收购价格。", -----
			"二、调整部分物品价格。", -----
			"三、关于商店需要增加新物品的问题，下个版本再添加吧。。。", -----

			"6、新增小龙蛋、小龙：", -----
			"获取方式：开局自带小龙蛋，地图上有一个【需要新档】", -----
			"孵化方式：将小龙蛋带身上开始孵化，必须是大狐狸角色携带才能开始孵化，孵化时间完成后扔出地面孵化出小龙，只能带一只小龙。", -----
			"功能：小龙可升级，打怪造成伤害就能获得经验值，10级时自动进化。其它后续功能待开发。", -----
			"",
		}
	},
	{	ver = '没有更多了',
		str = {
		'',
		'历史记录从 2.5.0.0 版本开始，在此之前的更新内容不记录。',
		}
	},

}

local Str_Eng = {

	-- {	ver = '2.5.7.0',
		-- str = {
		-- '',
		-- }
	-- },
	{	ver = '2.5.6.0',
		str = {
			"1、Fix the bug where the monster killed by the tornado skill will not drop the fox gem",
			"2、Optimizing the deceleration effect of Ice Fox's Ice Domain skills no longer affects miho, mir, and chester",
			"3、Fix the bug where you cannot right-click on Little Fox or Mir to stop following while equipping Gumifan",
		}
	},
	{	ver = '2.5.5.0',
		str = {
			"1、Fixed a bug where Mir did not increase experience points during battles with monsters",
			"2、Tornado skill adjustment",
		}
	},
	{	ver = '2.5.4.0',
		str = {
			"1、Add Gumifan skill, right-click to release tornado skill, consume spirit, Gumifan durability",
			"2、Store added: figs, salt crystals",
			"3、Store addition: Adjustable store recycling price ratio, set in MOD settings",
		}
	},
	{	ver = '2.5.3.0',
		str = {
		'1、Add items to the store：waterplant_bomb、barnacle、potato、tomato、pepper、garlic、onion、mole',
		}
	},

	{	ver = '2.5.2.0',
		str = {
			"1、The Fox Store adds the function of batch purchase. Click the left mouse button for batch purchase, and click the right mouse button for individual purchase.",
		}
	},
	{	ver = '2.5.1.0',
		str = {
			"The following is the content of this update：", --以下是本次更新内容
			"1、Fix the display error of store setting options in mod settings.",
			"2、Fix the problem that gumifan's lines do not match the current language while wearing gumifan.",
			"3、Fix the problem that some item icons in the store are not displayed.",
			"4、Add a UI panel to view the history update content, which can be opened in the information UI panel.",
			"5、The store added some new items.",
			"",
		}
	},
	{	ver = '2.5.0.0',
		str = {
			"Note: I have done some compatibility with the old archive in this update, but it may still cause some problems with the existing Fox archive. ",
				"If there is no problem, then continue to play. If there is a problem, it is recommended to create a new archive...",

			"The following is the content of this update：",
			"1、Increase the coverage of English support.",
			"2、Fix the bug that mihobell appears on the ground the next time you enter the game after exiting the game when mihobell is on your body.",
			"3、Change the way characters gain experience in combat, and change it to gain experience points and elemental values as long as they cause damage. 【Originally you need to kill monsters to gain experience and elements】.",
			"4、Exclusive pet optimization: prevent pets from killing each other.",
			"5、Fox  store：",
			"①、Further reduce the repurchase price of goods.",
			"②、Adjust the price of some items.",

			"6、Add Imoogi Egg、Imoogi：",
			"Obtaining method: initially bring a small dragon egg. There is one on the map【Need a new archive】.",
			"Hatching method: Bring Imoogi Egg on your body to start hatching. It must be carried by a big fox character to start hatching. After the hatching time is completed, throw it out of the ground to hatch Imoogi. You can only bring one Imoogi.",
			"Function: Imoogi can be upgraded, you can get experience points by inflicting damage in battle, and it will automatically evolve at level 10. Other functions are to be developed later.",
			"",
		}
	},
	{	ver = 'There is no more content',
		str = {
		'',
		'The history starts from 2.5.0.0 version, and the updated content before this is not recorded.',
		}
	},

}

local function Pos_y(tar)
	local x, y = tar:GetPosition():Get()
	return y
end

local HuLi_UpDateUi_Ls = Class(Widget, function(self, owner) 

	Widget._ctor(self, 'HuLi_UpDateUi_Ls') 
	self.owner = owner
	self.version = 0
	
	self.textsize = 40
	self.TextFont = SMALLNUMBERFONT
		
	self.root = self:AddChild(Widget("ROOT"))
	self.root:SetVAnchor(ANCHOR_MIDDLE)
	self.root:SetHAnchor(ANCHOR_MIDDLE)
	self.root:SetScaleMode(SCALEMODE_PROPORTIONAL)
	-- self:MoveToFront()
	-- self:MoveToBack()
	
	self.bg = self.root:AddChild(Image("images/scoreboard.xml","scoreboard_frame.tex"))
	-- self.bg:SetPosition(250, -150, 0) 	
	self.bg:SetSize(hl_loc(800, 1000), 600)
	
	self["标题"] = self.bg:AddChild(Text(BODYTEXTFONT, self.textsize, hl_loc('历史更新内容', 'History update record')))
	-- self["标题"]:SetColour(92/255,255/255,75/255,1)
    self["标题"]:SetPosition(0,225,0) 

	self["关闭按钮"] = self.bg:AddChild(ImageButton("images/global_redux.xml", "close.tex"))
	-- self["关闭按钮"]:SetScale(.7,.7)
	self["关闭按钮"]:SetPosition(hl_loc(320, 390), 210, 0)
	self["关闭按钮"]:SetTooltip(hl_loc("关闭窗口", "close window"))
	self["关闭按钮"]:SetOnClick(function() 
		self:Close() 
	end)

	-- self["测试按钮"] = self.bg:AddChild(TextButton())
	-- self["测试按钮"]:SetPosition(0,-220,0)
	-- self["测试按钮"]:SetText("测试")
	-- self["测试按钮"]:SetTextSize(self.textsize)
	-- self["测试按钮"]:SetOnClick(function() 
	-- end)
	
	
	local VStr = hl_loc(Str_cn, Str_Eng)
	self['当前页码'] = 1
	self['最大页码'] = #VStr
	self['文本页面表'] = {}
	self.textlist = {}
	
	for i, v in ipairs(VStr) do
		self['文本页面表'][i] = self.bg:AddChild(Widget("更新文本ROOT"))
		self['文本页面表'][i]:Hide()
		local text_root = self['文本页面表'][i]
		self.textlist[i] = {}
		
		for k, n in ipairs(v.str) do
			local widg = Widget("str"..k)
			local strWidg = widg:AddChild(Text(NEWFONT, 22, ""))
			strWidg:SetMultilineTruncatedString(n, 30, hl_loc(580, 800))
			strWidg:SetHAlign(ANCHOR_LEFT)
			local w, h = strWidg:GetRegionSize()
			strWidg:SetPosition(hl_loc(23, 0) + w * .5, 0, 0)
			widg.text = strWidg
			table.insert(self.textlist[i], widg)
			text_root["更新内容文本"] = self.bg:AddChild(ScrollableList(self.textlist[i], hl_loc(630, 810), 360, 35, hl_loc(5, 15), nil, nil, nil, nil, nil, 10, nil, nil, "GOLD"))
			text_root["更新内容文本"]:SetPosition(-10, -10)
			text_root["更新内容文本"]:Hide()
			
			text_root["标题版本号"] = text_root["更新内容文本"]:AddChild(Text(BODYTEXTFONT, 26))
			text_root["标题版本号"]:SetString(hl_loc('版本：', 'version：')..v.ver) 
			text_root["标题版本号"]:SetPosition(10, 210, 0) 

		end
		
    end
		
	self['上一页按钮'] = self.bg:AddChild(ImageButton("images/global_redux.xml", "arrow2_left_over.tex", nil, "arrow_left_disabled.tex"))
	self['上一页按钮']:SetPosition(-50, -210, 0)
	self['上一页按钮']:SetScale(.8, .4, .7)
	self['上一页按钮']:SetTooltip(hl_loc('上一页', 'last page'))
	self['上一页按钮']:SetOnClick(function() self:PageLast() end)
	self['上一页按钮']:Disable()

	self['页码'] = self.bg:AddChild(Text(DIALOGFONT, 35))
	self['页码']:SetPosition(-3, Pos_y(self['上一页按钮']), 0)
	self['页码']:SetString(self['当前页码'].."/"..self['最大页码'])
	-- self['页码']:SetColour(0, 0, 0, 1)

	self['下一页按钮'] = self.bg:AddChild(ImageButton("images/global_redux.xml", "arrow2_right_over.tex", nil, "arrow_right_disabled.tex"))
	self['下一页按钮']:SetPosition(45, Pos_y(self['上一页按钮']), 0)
	self['下一页按钮']:SetScale(.8, .4, .7)
	self['下一页按钮']:SetTooltip(hl_loc('下一页', 'next page'))
	self['下一页按钮']:SetOnClick (function() self:PageNext() end)	
	-- if self['最大页码'] < 2 then
		-- self['下一页按钮']:Disable()
	-- end

	self['文本页面表'][1]["更新内容文本"]:Show()
	self.inst:DoTaskInTime(0, function()
		self:MoveToBack()
	end)
	huli_uiutil.CtrlScale(self.bg)
	
end)

function  HuLi_UpDateUi_Ls:PageLast() -------上一页
	local old_page = self['当前页码']
    if old_page <= 1 then return end
	
	self['当前页码'] = self['当前页码'] - 1 
	self['下一页按钮']:Enable()
    if self['当前页码'] <= 1 then 	
		self['上一页按钮']:Disable()
	end
		
	self['文本页面表'][old_page ]["更新内容文本"]:Hide()
	self['文本页面表'][self['当前页码']]["更新内容文本"]:Show()
	self['页码']:SetString(self['当前页码'].."/"..self['最大页码'])
	-- self.inst:PushEvent('页面变化事件', {old_page = old_page, c_page = self['当前页码']})
end

function  HuLi_UpDateUi_Ls:PageNext() --------下一页
	local old_page = self['当前页码']
    if old_page >= self['最大页码'] then return end
	
	self['当前页码'] = self['当前页码'] + 1
	self['上一页按钮']:Enable()
    if self['当前页码'] >= self['最大页码'] then
		self['下一页按钮']:Disable()
	end
		
	self['文本页面表'][old_page ]["更新内容文本"]:Hide()
	self['文本页面表'][self['当前页码']]["更新内容文本"]:Show()
	self['页码']:SetString(self['当前页码'].."/"..self['最大页码'])
	-- self.inst:PushEvent('页面变化事件', {old_page = old_page, c_page = self['当前页码']})
end

function HuLi_UpDateUi_Ls:Close()
	self:Hide()
end

function HuLi_UpDateUi_Ls:OnControl(control, down)
    if HuLi_UpDateUi_Ls._base.OnControl(self,control, down) then 
		return true 
	end

    if not down then
		if control == 13 or control == 42 then
		   self:Close()
		   return true
		end
	end
end

-- function HuLi_UpDateUi_Ls:OnRawKey(key, down)
    -- if HuLi_UpDateUi_Ls._base.OnRawKey(self, key, down) then return true end
	-- if down and key == 27 then self:Close() return end
-- end

return HuLi_UpDateUi_Ls