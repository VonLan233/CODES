function HuLi_SetInfo()

--To add a new tile, you should set some parameters in the table below.
--0 [STRING] - name, name of your tile (in lower case, should match the texture and atlas in levels/tiles/) .
--1 [TABLE] (not necessary) - specs, tile edge texture, run/walk/snow/mud sounds for your tile.
--2 [TABLE] (not necessary) - turf, loot for terraformer (prefab, min count, max count), there is no loot, if not setted.
--3 [INTEGER] (not necessary) - layer, tile order in render
--4 [BOOL] (not necessary) - isfloor, if true, then the tile will be counted as flooring (can't place plants on it)

--For example: marsh_sw = { specs = {}, turf = {{"turf_test"}}, layer = 5},


	local NEW_TILE_DESCRIPTION =
	{
		asia = { specs = {name = "carpet"}, turf = {{"turf_asia"}}, layer = 30, isfloor = true}, 
		orient = { specs = {name = "carpet"}, turf = {{"turf_orient"}}, layer = 30, isfloor = true}, 
		flamerose = { specs = {name = "carpet"}, turf = {{"turf_flamerose"}}, layer = 30, isfloor = true}, 
		marble = { specs = {name = "carpet"}, turf = {{"turf_marble"}}, layer = 30, isfloor = true}, 
		jade = { specs = {name = "carpet"}, turf = {{"turf_jade"}}, layer = 30, isfloor = true}, 
		-- jade = { specs = {name = "cave"}, turf = {{"turf_jade"}}, layer = 35}, 
		-- jade = { specs = {name = "carpet"}, turf = {{"turf_jade"}}, layer = 35}, 
		-- jungle = { specs = {name = "jungle"}, turf = {{"turf_jungle"}} ,	layer = 25}, 
		-- beach = { specs = {name = "beach"}, turf = {{"turf_beach"}}, layer = 30},
		-- rocky = { specs = {name = "rocky"}, turf = {{"turf_rocky"}}, layer = 30, isfloor = true}, 
	}

	return NEW_TILE_DESCRIPTION
end